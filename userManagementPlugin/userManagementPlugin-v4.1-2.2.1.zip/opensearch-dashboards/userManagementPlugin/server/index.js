"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.plugin = plugin;
Object.defineProperty(exports, "UserManagementPluginPluginSetup", {
  enumerable: true,
  get: function () {
    return _types.UserManagementPluginPluginSetup;
  }
});
Object.defineProperty(exports, "UserManagementPluginPluginStart", {
  enumerable: true,
  get: function () {
    return _types.UserManagementPluginPluginStart;
  }
});

var _plugin = require("./plugin");

var _types = require("./types");

// This exports static code and TypeScript types,
// as well as, OpenSearch Dashboards Platform `plugin()` initializer.
function plugin(initializerContext) {
  return new _plugin.UserManagementPluginPlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbInBsdWdpbiIsImluaXRpYWxpemVyQ29udGV4dCIsIlVzZXJNYW5hZ2VtZW50UGx1Z2luUGx1Z2luIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0E7O0FBU0E7O0FBUEE7QUFDQTtBQUVPLFNBQVNBLE1BQVQsQ0FBZ0JDLGtCQUFoQixFQUE4RDtBQUNuRSxTQUFPLElBQUlDLGtDQUFKLENBQStCRCxrQkFBL0IsQ0FBUDtBQUNEIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0IH0gZnJvbSAnLi4vLi4vLi4vc3JjL2NvcmUvc2VydmVyJztcbmltcG9ydCB7IFVzZXJNYW5hZ2VtZW50UGx1Z2luUGx1Z2luIH0gZnJvbSAnLi9wbHVnaW4nO1xuXG4vLyBUaGlzIGV4cG9ydHMgc3RhdGljIGNvZGUgYW5kIFR5cGVTY3JpcHQgdHlwZXMsXG4vLyBhcyB3ZWxsIGFzLCBPcGVuU2VhcmNoIERhc2hib2FyZHMgUGxhdGZvcm0gYHBsdWdpbigpYCBpbml0aWFsaXplci5cblxuZXhwb3J0IGZ1bmN0aW9uIHBsdWdpbihpbml0aWFsaXplckNvbnRleHQ6IFBsdWdpbkluaXRpYWxpemVyQ29udGV4dCkge1xuICByZXR1cm4gbmV3IFVzZXJNYW5hZ2VtZW50UGx1Z2luUGx1Z2luKGluaXRpYWxpemVyQ29udGV4dCk7XG59XG5cbmV4cG9ydCB7IFVzZXJNYW5hZ2VtZW50UGx1Z2luUGx1Z2luU2V0dXAsIFVzZXJNYW5hZ2VtZW50UGx1Z2luUGx1Z2luU3RhcnQgfSBmcm9tICcuL3R5cGVzJztcbiJdfQ==