"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_VERSION = exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'elastAlertPlugin';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'Advanced Alerting';
exports.PLUGIN_NAME = PLUGIN_NAME;
const PLUGIN_VERSION = '(v15.2)';
exports.PLUGIN_VERSION = PLUGIN_VERSION;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbIlBMVUdJTl9JRCIsIlBMVUdJTl9OQU1FIiwiUExVR0lOX1ZFUlNJT04iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFPLE1BQU1BLFNBQVMsR0FBRyxrQkFBbEI7O0FBQ0EsTUFBTUMsV0FBVyxHQUFHLG1CQUFwQjs7QUFDQSxNQUFNQyxjQUFjLEdBQUcsU0FBdkIiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgUExVR0lOX0lEID0gJ2VsYXN0QWxlcnRQbHVnaW4nO1xuZXhwb3J0IGNvbnN0IFBMVUdJTl9OQU1FID0gJ0FkdmFuY2VkIEFsZXJ0aW5nJztcbmV4cG9ydCBjb25zdCBQTFVHSU5fVkVSU0lPTiA9ICcodjE1LjIpJztcbiJdfQ==