"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.plugin = plugin;
Object.defineProperty(exports, "WazuhActiveResponsePluginPluginSetup", {
  enumerable: true,
  get: function () {
    return _types.WazuhActiveResponsePluginPluginSetup;
  }
});
Object.defineProperty(exports, "WazuhActiveResponsePluginPluginStart", {
  enumerable: true,
  get: function () {
    return _types.WazuhActiveResponsePluginPluginStart;
  }
});

var _plugin = require("./plugin");

var _types = require("./types");

// This exports static code and TypeScript types,
// as well as, OpenSearch Dashboards Platform `plugin()` initializer.
function plugin(initializerContext) {
  return new _plugin.WazuhActiveResponsePluginPlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbInBsdWdpbiIsImluaXRpYWxpemVyQ29udGV4dCIsIldhenVoQWN0aXZlUmVzcG9uc2VQbHVnaW5QbHVnaW4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTs7QUFTQTs7QUFQQTtBQUNBO0FBRU8sU0FBU0EsTUFBVCxDQUFnQkMsa0JBQWhCLEVBQThEO0FBQ25FLFNBQU8sSUFBSUMsdUNBQUosQ0FBb0NELGtCQUFwQyxDQUFQO0FBQ0QiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQgfSBmcm9tICcuLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xuaW1wb3J0IHsgV2F6dWhBY3RpdmVSZXNwb25zZVBsdWdpblBsdWdpbiB9IGZyb20gJy4vcGx1Z2luJztcblxuLy8gVGhpcyBleHBvcnRzIHN0YXRpYyBjb2RlIGFuZCBUeXBlU2NyaXB0IHR5cGVzLFxuLy8gYXMgd2VsbCBhcywgT3BlblNlYXJjaCBEYXNoYm9hcmRzIFBsYXRmb3JtIGBwbHVnaW4oKWAgaW5pdGlhbGl6ZXIuXG5cbmV4cG9ydCBmdW5jdGlvbiBwbHVnaW4oaW5pdGlhbGl6ZXJDb250ZXh0OiBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQpIHtcbiAgcmV0dXJuIG5ldyBXYXp1aEFjdGl2ZVJlc3BvbnNlUGx1Z2luUGx1Z2luKGluaXRpYWxpemVyQ29udGV4dCk7XG59XG5cbmV4cG9ydCB7XG4gIFdhenVoQWN0aXZlUmVzcG9uc2VQbHVnaW5QbHVnaW5TZXR1cCxcbiAgV2F6dWhBY3RpdmVSZXNwb25zZVBsdWdpblBsdWdpblN0YXJ0LFxufSBmcm9tICcuL3R5cGVzJztcbiJdfQ==