"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var _exportNames = {
  WazuhElasticCtrl: true,
  WazuhApiCtrl: true,
  WazuhReportingCtrl: true,
  WazuhHostsCtrl: true
};
Object.defineProperty(exports, "WazuhApiCtrl", {
  enumerable: true,
  get: function () {
    return _wazuhApi.WazuhApiCtrl;
  }
});
Object.defineProperty(exports, "WazuhElasticCtrl", {
  enumerable: true,
  get: function () {
    return _wazuhElastic.WazuhElasticCtrl;
  }
});
Object.defineProperty(exports, "WazuhHostsCtrl", {
  enumerable: true,
  get: function () {
    return _wazuhHosts.WazuhHostsCtrl;
  }
});
Object.defineProperty(exports, "WazuhReportingCtrl", {
  enumerable: true,
  get: function () {
    return _wazuhReporting.WazuhReportingCtrl;
  }
});

var _wazuhElastic = require("./wazuh-elastic");

var _wazuhApi = require("./wazuh-api");

var _wazuhReporting = require("./wazuh-reporting");

var _wazuhHosts = require("./wazuh-hosts");

var _wazuhUtils = require("./wazuh-utils");

Object.keys(_wazuhUtils).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  if (Object.prototype.hasOwnProperty.call(_exportNames, key)) return;
  if (key in exports && exports[key] === _wazuhUtils[key]) return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function () {
      return _wazuhUtils[key];
    }
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQVdBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxyXG4gKiBXYXp1aCBhcHAgLSBNb2R1bGUgdG8gZXhwb3J0IGFsbCB0aGUgY29udHJvbGxlcnNcclxuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cclxuICpcclxuICogVGhpcyBwcm9ncmFtIGlzIGZyZWUgc29mdHdhcmU7IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcclxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcclxuICogdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbjsgZWl0aGVyIHZlcnNpb24gMiBvZiB0aGUgTGljZW5zZSwgb3JcclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cclxuICpcclxuICogRmluZCBtb3JlIGluZm9ybWF0aW9uIGFib3V0IHRoaXMgb24gdGhlIExJQ0VOU0UgZmlsZS5cclxuICovXHJcbmV4cG9ydCB7IFdhenVoRWxhc3RpY0N0cmwgfSBmcm9tICcuL3dhenVoLWVsYXN0aWMnO1xyXG5leHBvcnQgeyBXYXp1aEFwaUN0cmwgfSBmcm9tICcuL3dhenVoLWFwaSc7XHJcbmV4cG9ydCB7IFdhenVoUmVwb3J0aW5nQ3RybCB9IGZyb20gJy4vd2F6dWgtcmVwb3J0aW5nJztcclxuZXhwb3J0IHsgV2F6dWhIb3N0c0N0cmwgfSBmcm9tICcuL3dhenVoLWhvc3RzJztcclxuZXhwb3J0ICogZnJvbSAnLi93YXp1aC11dGlscyc7XHJcbiJdfQ==