"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/*
 * Wazuh app - Cluster monitoring visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Statistics-remoted-Recv-bytes',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics remoted Recv bytes',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics remoted Recv bytes',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:remoted.recv_bytes, q='*').label(recv_bytes),.es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:remoted.recv_bytes, q='*').trend().label(Trend).lines(width=1.5)",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Statistics-remoted-event-count',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics remoted event count',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics remoted event count',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:remoted.evt_count, q='*').label(evt_count),.es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:remoted.evt_count, q='*').trend().label(Trend).lines(width=1.5)",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Statistics-remoted-messages',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics remoted messages',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics remoted messages',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:remoted.msg_sent, q='*').label(msg_sent),.es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:remoted.ctrl_msg_count, q='*').label(ctrl_msg_count),.es(index=wazuh-statistics-*,timefield=timestamp,metric=avg:remoted.discarded_count).label(discarded_count),.es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:remoted.dequeued_after_close, q='*').label(dequeued_after_close)",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Statistics-remoted-tcp-sessions',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics remoted tcp sessions',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics remoted tcp sessions',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=sum:remoted.tcp_sessions, q='*').label(tcp_sessions)",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Statistics-Analysisd-Overview-Events-Decoded',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics Overview events decoded',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics Overview events decode',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscheck_events_decoded, q='*').label('Syscheck Events Decoded').bars(stack=true), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscheck, q='*').label('Syscollector Events Decoded').bars(stack=true), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.rootcheck_events_decoded, q='*').label('Rootcheck Events Decoded').bars(stack=true), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.sca_events_decoded, q='*').label('SCA Events Decoded').bars(stack=true), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.other_events_decoded, q='*').label('Other Events Decoded').bars(stack=true), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.hostinfo_events_decoded, q='*').label('Host Info Events Decoded').bars(stack=true)",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Statistics-Analysisd-Syscheck',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics Syscheck',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics Syscheck',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscheck_events_decoded, q='*').label('Syscheck Events Decoded'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscheck_edps, q='*').label('Syscheck EDPS'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscheck_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscheck_queue_usage, q='*') ).label('Queue Usage').color('green'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscheck_queue_usage, q='*').if(gte, 0.7, .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscheck_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscheck_queue_usage, q='*') ), null) .color('#FFCC11').label('Queue Usage 70%+'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscheck_queue_usage, q='*').if(gte, 0.9, .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscheck_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscheck_queue_usage, q='*') ), null) .color('red').label('Queue Usage 90%+')",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Statistics-Analysisd-Syscollector',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics Syscollector',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics Syscollector',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscollector_events_decoded, q='*').label('syscollector Events Decoded'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscollector_edps, q='*').label('syscollector EDPS'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscollector_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscollector_queue_usage, q='*') ).label('Queue Usage').color('green'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscollector_queue_usage, q='*').if(gte, 0.7, .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscollector_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscollector_queue_usage, q='*') ), null) .color('#FFCC11').label('Queue Usage 70%+'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscollector_queue_usage, q='*').if(gte, 0.9, .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscollector_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.syscollector_queue_usage, q='*') ), null) .color('red').label('Queue Usage 90%+')",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Statistics-Analysisd-Rootcheck',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics Rootcheck',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics Rootcheck',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.rootcheck_events_decoded, q='*').label('Rootcheck Events Decoded'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.rootcheck_edps, q='*').label('Rootcheck EDPS'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.rootcheck_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.rootcheck_queue_usage, q='*') ).label('Queue Usage').color('green'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.rootcheck_queue_usage, q='*').if(gte, 0.7, .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.rootcheck_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.rootcheck_queue_usage, q='*') ), null) .color('#FFCC11').label('Queue Usage 70%+'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.rootcheck_queue_usage, q='*').if(gte, 0.9, .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.rootcheck_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.rootcheck_queue_usage) ), null) .color('red').label('Queue Usage 90%+')",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Statistics-Analysisd-SCA',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics SCA',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics SCA',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.sca_events_decoded, q='*').label('SCA Events Decoded'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.sca_edps, q='*').label('SCA EDPS'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.sca_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.sca_queue_usage, q='*') ).label('Queue Usage').color('green'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.sca_queue_usage, q='*').if(gte, 0.7, .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.sca_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.sca_queue_usage, q='*') ), null) .color('#FFCC11').label('Queue Usage 70%+'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.sca_queue_usage, q='*').if(gte, 0.9, .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.sca_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.sca_queue_usage, q='*') ), null) .color('red').label('Queue Usage 90%+')",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Statistics-Analysisd-HostInfo',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics HostInfo',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics HostInfo',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.hostinfo_events_decoded, q='*').label('Host info Events Decoded'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.hostinfo_edps, q='*').label('Host info EDPS'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.hostinfo_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.hostinfo_queue_usage, q='*') ).label('Queue Usage').color('green'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.hostinfo_queue_usage, q='*').if(gte, 0.7, .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.hostinfo_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.hostinfo_queue_usage, q='*') ), null) .color('#FFCC11').label('Queue Usage 70%+'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.hostinfo_queue_usage, q='*').if(gte, 0.9, .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.hostinfo_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.hostinfo_queue_usage, q='*') ), null) .color('red').label('Queue Usage 90%+')",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Statistics-Analysisd-Other',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics Other',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics Other',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.other_events_decoded, q='*').label('Host info Events Decoded'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.other_edps, q='*').label('Host info EDPS'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.other_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.other_queue_usage, q='*') ).label('Queue Usage').color('green'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.other_queue_usage, q='*').if(gte, 0.7, .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.other_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.other_queue_usage, q='*') ), null) .color('#FFCC11').label('Queue Usage 70%+'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.other_queue_usage, q='*').if(gte, 0.9, .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.other_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.other_queue_usage, q='*') ), null) .color('red').label('Queue Usage 90%+')",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Statistics-Analysisd-Events-By-Node',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics Events by Node',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics Events by Node',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=sum:analysisd.events_processed, q='*') .label('Total'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=sum:analysisd.events_processed, q='*', split=nodeName.keyword:5).label('Events processed by Node: $1','^.* > nodeName.keyword:(\\\\S+) > .*')",
        interval: '5m'
      },
      aggs: []
    }),
    visStateByNode: JSON.stringify({
      title: 'Wazuh App Statistics Events by Node',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=sum:analysisd.events_processed, q='*') .label('Events processed by Node: NODE_NAME')",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Statistics-Analysisd-Events-Dropped-By-Node',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics Events Dropped by Node',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics Events Dropped by Node',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=sum:analysisd.events_dropped, q='*') .label('Total'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=sum:analysisd.events_dropped, q='*', split=nodeName.keyword:5).label('Events dropped by Node: $1','^.* > nodeName.keyword:(\\\\S+) > .*')",
        interval: '5m'
      },
      aggs: []
    }),
    visStateByNode: JSON.stringify({
      title: 'Wazuh App Statistics Events by Node',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=sum:analysisd.events_dropped, q='*') .label('Events dropped by Node: NODE_NAME')",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Statistics-Analysisd-Queues-Usage',
  _type: 'visualization',
  _source: {
    title: 'Wazuh App Statistics Queues Usage',
    visState: JSON.stringify({
      title: 'Wazuh App Statistics Queues Usage',
      type: 'timelion',
      params: {
        expression: ".es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.event_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.event_queue_usage, q='*') ).label('Event queue usage'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.rule_matching_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.rule_matching_queue_usage, q='*') ).label('Rule matching queue usage'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.alerts_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.alerts_queue_usage, q='*') ).label('Alerts log queue usage'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.firewall_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.firewall_queue_usage, q='*') ).label('Firewall log queue usage'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.statistical_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.statistical_queue_usage, q='*') ).label('Statistical log queue usage'), .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.archives_queue_size, q='*').multiply( .es(index=wazuh-statistics-*, timefield=timestamp,metric=avg:analysisd.archives_queue_usage, q='*') ).label('Statistical log queue usage')",
        interval: '5m'
      },
      aggs: []
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-statistics-*',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0YXRpc3RpY3MudHMiXSwibmFtZXMiOlsiX2lkIiwiX3R5cGUiLCJfc291cmNlIiwidGl0bGUiLCJ2aXNTdGF0ZSIsIkpTT04iLCJzdHJpbmdpZnkiLCJ0eXBlIiwicGFyYW1zIiwiZXhwcmVzc2lvbiIsImludGVydmFsIiwiYWdncyIsInVpU3RhdGVKU09OIiwiZGVzY3JpcHRpb24iLCJ2ZXJzaW9uIiwia2liYW5hU2F2ZWRPYmplY3RNZXRhIiwic2VhcmNoU291cmNlSlNPTiIsImluZGV4IiwiZmlsdGVyIiwicXVlcnkiLCJsYW5ndWFnZSIsInZpc1N0YXRlQnlOb2RlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtlQUNlLENBQ2I7QUFDRUEsRUFBQUEsR0FBRyxFQUFFLHlDQURQO0FBRUVDLEVBQUFBLEtBQUssRUFBRSxlQUZUO0FBR0VDLEVBQUFBLE9BQU8sRUFBRTtBQUNQQyxJQUFBQSxLQUFLLEVBQUUseUNBREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QkgsTUFBQUEsS0FBSyxFQUFFLHlDQURnQjtBQUV2QkksTUFBQUEsSUFBSSxFQUFFLFVBRmlCO0FBR3ZCQyxNQUFBQSxNQUFNLEVBQUU7QUFDTkMsUUFBQUEsVUFBVSxFQUNSLHlPQUZJO0FBR05DLFFBQUFBLFFBQVEsRUFBRTtBQUhKLE9BSGU7QUFRdkJDLE1BQUFBLElBQUksRUFBRTtBQVJpQixLQUFmLENBRkg7QUFZUEMsSUFBQUEsV0FBVyxFQUFFLElBWk47QUFhUEMsSUFBQUEsV0FBVyxFQUFFLEVBYk47QUFjUEMsSUFBQUEsT0FBTyxFQUFFLENBZEY7QUFlUEMsSUFBQUEscUJBQXFCLEVBQUU7QUFDckJDLE1BQUFBLGdCQUFnQixFQUFFWCxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUMvQlcsUUFBQUEsS0FBSyxFQUFFLG9CQUR3QjtBQUUvQkMsUUFBQUEsTUFBTSxFQUFFLEVBRnVCO0FBRy9CQyxRQUFBQSxLQUFLLEVBQUU7QUFBRUEsVUFBQUEsS0FBSyxFQUFFLEVBQVQ7QUFBYUMsVUFBQUEsUUFBUSxFQUFFO0FBQXZCO0FBSHdCLE9BQWY7QUFERztBQWZoQjtBQUhYLENBRGEsRUE0QmI7QUFDRXBCLEVBQUFBLEdBQUcsRUFBRSwwQ0FEUDtBQUVFQyxFQUFBQSxLQUFLLEVBQUUsZUFGVDtBQUdFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLDBDQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSwwQ0FEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxVQUZpQjtBQUd2QkMsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLFVBQVUsRUFDUixzT0FGSTtBQUdOQyxRQUFBQSxRQUFRLEVBQUU7QUFISixPQUhlO0FBUXZCQyxNQUFBQSxJQUFJLEVBQUU7QUFSaUIsS0FBZixDQUZIO0FBWVBDLElBQUFBLFdBQVcsRUFBRSxJQVpOO0FBYVBDLElBQUFBLFdBQVcsRUFBRSxFQWJOO0FBY1BDLElBQUFBLE9BQU8sRUFBRSxDQWRGO0FBZVBDLElBQUFBLHFCQUFxQixFQUFFO0FBQ3JCQyxNQUFBQSxnQkFBZ0IsRUFBRVgsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDL0JXLFFBQUFBLEtBQUssRUFBRSxvQkFEd0I7QUFFL0JDLFFBQUFBLE1BQU0sRUFBRSxFQUZ1QjtBQUcvQkMsUUFBQUEsS0FBSyxFQUFFO0FBQUVBLFVBQUFBLEtBQUssRUFBRSxFQUFUO0FBQWFDLFVBQUFBLFFBQVEsRUFBRTtBQUF2QjtBQUh3QixPQUFmO0FBREc7QUFmaEI7QUFIWCxDQTVCYSxFQXVEYjtBQUNFcEIsRUFBQUEsR0FBRyxFQUFFLHVDQURQO0FBRUVDLEVBQUFBLEtBQUssRUFBRSxlQUZUO0FBR0VDLEVBQUFBLE9BQU8sRUFBRTtBQUNQQyxJQUFBQSxLQUFLLEVBQUUsdUNBREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QkgsTUFBQUEsS0FBSyxFQUFFLHVDQURnQjtBQUV2QkksTUFBQUEsSUFBSSxFQUFFLFVBRmlCO0FBR3ZCQyxNQUFBQSxNQUFNLEVBQUU7QUFDTkMsUUFBQUEsVUFBVSxFQUNSLG1jQUZJO0FBR05DLFFBQUFBLFFBQVEsRUFBRTtBQUhKLE9BSGU7QUFRdkJDLE1BQUFBLElBQUksRUFBRTtBQVJpQixLQUFmLENBRkg7QUFZUEMsSUFBQUEsV0FBVyxFQUFFLElBWk47QUFhUEMsSUFBQUEsV0FBVyxFQUFFLEVBYk47QUFjUEMsSUFBQUEsT0FBTyxFQUFFLENBZEY7QUFlUEMsSUFBQUEscUJBQXFCLEVBQUU7QUFDckJDLE1BQUFBLGdCQUFnQixFQUFFWCxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUMvQlcsUUFBQUEsS0FBSyxFQUFFLG9CQUR3QjtBQUUvQkMsUUFBQUEsTUFBTSxFQUFFLEVBRnVCO0FBRy9CQyxRQUFBQSxLQUFLLEVBQUU7QUFBRUEsVUFBQUEsS0FBSyxFQUFFLEVBQVQ7QUFBYUMsVUFBQUEsUUFBUSxFQUFFO0FBQXZCO0FBSHdCLE9BQWY7QUFERztBQWZoQjtBQUhYLENBdkRhLEVBa0ZiO0FBQ0VwQixFQUFBQSxHQUFHLEVBQUUsMkNBRFA7QUFFRUMsRUFBQUEsS0FBSyxFQUFFLGVBRlQ7QUFHRUMsRUFBQUEsT0FBTyxFQUFFO0FBQ1BDLElBQUFBLEtBQUssRUFBRSwyQ0FEQTtBQUVQQyxJQUFBQSxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ3ZCSCxNQUFBQSxLQUFLLEVBQUUsMkNBRGdCO0FBRXZCSSxNQUFBQSxJQUFJLEVBQUUsVUFGaUI7QUFHdkJDLE1BQUFBLE1BQU0sRUFBRTtBQUNOQyxRQUFBQSxVQUFVLEVBQ1IsK0dBRkk7QUFHTkMsUUFBQUEsUUFBUSxFQUFFO0FBSEosT0FIZTtBQVF2QkMsTUFBQUEsSUFBSSxFQUFFO0FBUmlCLEtBQWYsQ0FGSDtBQVlQQyxJQUFBQSxXQUFXLEVBQUUsSUFaTjtBQWFQQyxJQUFBQSxXQUFXLEVBQUUsRUFiTjtBQWNQQyxJQUFBQSxPQUFPLEVBQUUsQ0FkRjtBQWVQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQUVYLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQy9CVyxRQUFBQSxLQUFLLEVBQUUsb0JBRHdCO0FBRS9CQyxRQUFBQSxNQUFNLEVBQUUsRUFGdUI7QUFHL0JDLFFBQUFBLEtBQUssRUFBRTtBQUFFQSxVQUFBQSxLQUFLLEVBQUUsRUFBVDtBQUFhQyxVQUFBQSxRQUFRLEVBQUU7QUFBdkI7QUFId0IsT0FBZjtBQURHO0FBZmhCO0FBSFgsQ0FsRmEsRUE2R2I7QUFDRXBCLEVBQUFBLEdBQUcsRUFBRSx3REFEUDtBQUVFQyxFQUFBQSxLQUFLLEVBQUUsZUFGVDtBQUdFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLDhDQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSw2Q0FEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxVQUZpQjtBQUd2QkMsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLFVBQVUsRUFDUixvNEJBRkk7QUFHTkMsUUFBQUEsUUFBUSxFQUFFO0FBSEosT0FIZTtBQVF2QkMsTUFBQUEsSUFBSSxFQUFFO0FBUmlCLEtBQWYsQ0FGSDtBQVlQQyxJQUFBQSxXQUFXLEVBQUUsSUFaTjtBQWFQQyxJQUFBQSxXQUFXLEVBQUUsRUFiTjtBQWNQQyxJQUFBQSxPQUFPLEVBQUUsQ0FkRjtBQWVQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQUVYLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQy9CVyxRQUFBQSxLQUFLLEVBQUUsb0JBRHdCO0FBRS9CQyxRQUFBQSxNQUFNLEVBQUUsRUFGdUI7QUFHL0JDLFFBQUFBLEtBQUssRUFBRTtBQUFFQSxVQUFBQSxLQUFLLEVBQUUsRUFBVDtBQUFhQyxVQUFBQSxRQUFRLEVBQUU7QUFBdkI7QUFId0IsT0FBZjtBQURHO0FBZmhCO0FBSFgsQ0E3R2EsRUF3SWI7QUFDRXBCLEVBQUFBLEdBQUcsRUFBRSx5Q0FEUDtBQUVFQyxFQUFBQSxLQUFLLEVBQUUsZUFGVDtBQUdFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLCtCQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSwrQkFEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxVQUZpQjtBQUd2QkMsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLFVBQVUsRUFDUixrdUNBRkk7QUFHTkMsUUFBQUEsUUFBUSxFQUFFO0FBSEosT0FIZTtBQVF2QkMsTUFBQUEsSUFBSSxFQUFFO0FBUmlCLEtBQWYsQ0FGSDtBQVlQQyxJQUFBQSxXQUFXLEVBQUUsSUFaTjtBQWFQQyxJQUFBQSxXQUFXLEVBQUUsRUFiTjtBQWNQQyxJQUFBQSxPQUFPLEVBQUUsQ0FkRjtBQWVQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQUVYLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQy9CVyxRQUFBQSxLQUFLLEVBQUUsb0JBRHdCO0FBRS9CQyxRQUFBQSxNQUFNLEVBQUUsRUFGdUI7QUFHL0JDLFFBQUFBLEtBQUssRUFBRTtBQUFFQSxVQUFBQSxLQUFLLEVBQUUsRUFBVDtBQUFhQyxVQUFBQSxRQUFRLEVBQUU7QUFBdkI7QUFId0IsT0FBZjtBQURHO0FBZmhCO0FBSFgsQ0F4SWEsRUFtS2I7QUFDRXBCLEVBQUFBLEdBQUcsRUFBRSw2Q0FEUDtBQUVFQyxFQUFBQSxLQUFLLEVBQUUsZUFGVDtBQUdFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLG1DQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSxtQ0FEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxVQUZpQjtBQUd2QkMsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLFVBQVUsRUFDUixreENBRkk7QUFHTkMsUUFBQUEsUUFBUSxFQUFFO0FBSEosT0FIZTtBQVF2QkMsTUFBQUEsSUFBSSxFQUFFO0FBUmlCLEtBQWYsQ0FGSDtBQVlQQyxJQUFBQSxXQUFXLEVBQUUsSUFaTjtBQWFQQyxJQUFBQSxXQUFXLEVBQUUsRUFiTjtBQWNQQyxJQUFBQSxPQUFPLEVBQUUsQ0FkRjtBQWVQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQUVYLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQy9CVyxRQUFBQSxLQUFLLEVBQUUsb0JBRHdCO0FBRS9CQyxRQUFBQSxNQUFNLEVBQUUsRUFGdUI7QUFHL0JDLFFBQUFBLEtBQUssRUFBRTtBQUFFQSxVQUFBQSxLQUFLLEVBQUUsRUFBVDtBQUFhQyxVQUFBQSxRQUFRLEVBQUU7QUFBdkI7QUFId0IsT0FBZjtBQURHO0FBZmhCO0FBSFgsQ0FuS2EsRUE4TGI7QUFDRXBCLEVBQUFBLEdBQUcsRUFBRSwwQ0FEUDtBQUVFQyxFQUFBQSxLQUFLLEVBQUUsZUFGVDtBQUdFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLGdDQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSxnQ0FEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxVQUZpQjtBQUd2QkMsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLFVBQVUsRUFDUix1dUNBRkk7QUFHTkMsUUFBQUEsUUFBUSxFQUFFO0FBSEosT0FIZTtBQVF2QkMsTUFBQUEsSUFBSSxFQUFFO0FBUmlCLEtBQWYsQ0FGSDtBQVlQQyxJQUFBQSxXQUFXLEVBQUUsSUFaTjtBQWFQQyxJQUFBQSxXQUFXLEVBQUUsRUFiTjtBQWNQQyxJQUFBQSxPQUFPLEVBQUUsQ0FkRjtBQWVQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQUVYLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQy9CVyxRQUFBQSxLQUFLLEVBQUUsb0JBRHdCO0FBRS9CQyxRQUFBQSxNQUFNLEVBQUUsRUFGdUI7QUFHL0JDLFFBQUFBLEtBQUssRUFBRTtBQUFFQSxVQUFBQSxLQUFLLEVBQUUsRUFBVDtBQUFhQyxVQUFBQSxRQUFRLEVBQUU7QUFBdkI7QUFId0IsT0FBZjtBQURHO0FBZmhCO0FBSFgsQ0E5TGEsRUF5TmI7QUFDRXBCLEVBQUFBLEdBQUcsRUFBRSxvQ0FEUDtBQUVFQyxFQUFBQSxLQUFLLEVBQUUsZUFGVDtBQUdFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLDBCQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSwwQkFEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxVQUZpQjtBQUd2QkMsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLFVBQVUsRUFDUixzcUNBRkk7QUFHTkMsUUFBQUEsUUFBUSxFQUFFO0FBSEosT0FIZTtBQVF2QkMsTUFBQUEsSUFBSSxFQUFFO0FBUmlCLEtBQWYsQ0FGSDtBQVlQQyxJQUFBQSxXQUFXLEVBQUUsSUFaTjtBQWFQQyxJQUFBQSxXQUFXLEVBQUUsRUFiTjtBQWNQQyxJQUFBQSxPQUFPLEVBQUUsQ0FkRjtBQWVQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQUVYLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQy9CVyxRQUFBQSxLQUFLLEVBQUUsb0JBRHdCO0FBRS9CQyxRQUFBQSxNQUFNLEVBQUUsRUFGdUI7QUFHL0JDLFFBQUFBLEtBQUssRUFBRTtBQUFFQSxVQUFBQSxLQUFLLEVBQUUsRUFBVDtBQUFhQyxVQUFBQSxRQUFRLEVBQUU7QUFBdkI7QUFId0IsT0FBZjtBQURHO0FBZmhCO0FBSFgsQ0F6TmEsRUFvUGI7QUFDRXBCLEVBQUFBLEdBQUcsRUFBRSx5Q0FEUDtBQUVFQyxFQUFBQSxLQUFLLEVBQUUsZUFGVDtBQUdFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLCtCQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSwrQkFEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxVQUZpQjtBQUd2QkMsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLFVBQVUsRUFDUixvdUNBRkk7QUFHTkMsUUFBQUEsUUFBUSxFQUFFO0FBSEosT0FIZTtBQVF2QkMsTUFBQUEsSUFBSSxFQUFFO0FBUmlCLEtBQWYsQ0FGSDtBQVlQQyxJQUFBQSxXQUFXLEVBQUUsSUFaTjtBQWFQQyxJQUFBQSxXQUFXLEVBQUUsRUFiTjtBQWNQQyxJQUFBQSxPQUFPLEVBQUUsQ0FkRjtBQWVQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQUVYLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQy9CVyxRQUFBQSxLQUFLLEVBQUUsb0JBRHdCO0FBRS9CQyxRQUFBQSxNQUFNLEVBQUUsRUFGdUI7QUFHL0JDLFFBQUFBLEtBQUssRUFBRTtBQUFFQSxVQUFBQSxLQUFLLEVBQUUsRUFBVDtBQUFhQyxVQUFBQSxRQUFRLEVBQUU7QUFBdkI7QUFId0IsT0FBZjtBQURHO0FBZmhCO0FBSFgsQ0FwUGEsRUErUWI7QUFDRXBCLEVBQUFBLEdBQUcsRUFBRSxzQ0FEUDtBQUVFQyxFQUFBQSxLQUFLLEVBQUUsZUFGVDtBQUdFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLDRCQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSw0QkFEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxVQUZpQjtBQUd2QkMsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLFVBQVUsRUFDUixzc0NBRkk7QUFHTkMsUUFBQUEsUUFBUSxFQUFFO0FBSEosT0FIZTtBQVF2QkMsTUFBQUEsSUFBSSxFQUFFO0FBUmlCLEtBQWYsQ0FGSDtBQVlQQyxJQUFBQSxXQUFXLEVBQUUsSUFaTjtBQWFQQyxJQUFBQSxXQUFXLEVBQUUsRUFiTjtBQWNQQyxJQUFBQSxPQUFPLEVBQUUsQ0FkRjtBQWVQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQUVYLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQy9CVyxRQUFBQSxLQUFLLEVBQUUsb0JBRHdCO0FBRS9CQyxRQUFBQSxNQUFNLEVBQUUsRUFGdUI7QUFHL0JDLFFBQUFBLEtBQUssRUFBRTtBQUFFQSxVQUFBQSxLQUFLLEVBQUUsRUFBVDtBQUFhQyxVQUFBQSxRQUFRLEVBQUU7QUFBdkI7QUFId0IsT0FBZjtBQURHO0FBZmhCO0FBSFgsQ0EvUWEsRUEyU2I7QUFDRXBCLEVBQUFBLEdBQUcsRUFBRSwrQ0FEUDtBQUVFQyxFQUFBQSxLQUFLLEVBQUUsZUFGVDtBQUdFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLHFDQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSxxQ0FEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxVQUZpQjtBQUd2QkMsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLFVBQVUsRUFDUix5VEFGSTtBQUdOQyxRQUFBQSxRQUFRLEVBQUU7QUFISixPQUhlO0FBUXZCQyxNQUFBQSxJQUFJLEVBQUU7QUFSaUIsS0FBZixDQUZIO0FBWVBVLElBQUFBLGNBQWMsRUFBRWhCLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQzdCSCxNQUFBQSxLQUFLLEVBQUUscUNBRHNCO0FBRTdCSSxNQUFBQSxJQUFJLEVBQUUsVUFGdUI7QUFHN0JDLE1BQUFBLE1BQU0sRUFBRTtBQUNOQyxRQUFBQSxVQUFVLEVBQ1IsK0lBRkk7QUFHTkMsUUFBQUEsUUFBUSxFQUFFO0FBSEosT0FIcUI7QUFRN0JDLE1BQUFBLElBQUksRUFBRTtBQVJ1QixLQUFmLENBWlQ7QUFzQlBDLElBQUFBLFdBQVcsRUFBRSxJQXRCTjtBQXVCUEMsSUFBQUEsV0FBVyxFQUFFLEVBdkJOO0FBd0JQQyxJQUFBQSxPQUFPLEVBQUUsQ0F4QkY7QUF5QlBDLElBQUFBLHFCQUFxQixFQUFFO0FBQ3JCQyxNQUFBQSxnQkFBZ0IsRUFBRVgsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDL0JXLFFBQUFBLEtBQUssRUFBRSxvQkFEd0I7QUFFL0JDLFFBQUFBLE1BQU0sRUFBRSxFQUZ1QjtBQUcvQkMsUUFBQUEsS0FBSyxFQUFFO0FBQUVBLFVBQUFBLEtBQUssRUFBRSxFQUFUO0FBQWFDLFVBQUFBLFFBQVEsRUFBRTtBQUF2QjtBQUh3QixPQUFmO0FBREc7QUF6QmhCO0FBSFgsQ0EzU2EsRUFnVmI7QUFDRXBCLEVBQUFBLEdBQUcsRUFBRSx1REFEUDtBQUVFQyxFQUFBQSxLQUFLLEVBQUUsZUFGVDtBQUdFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLDZDQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSw2Q0FEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxVQUZpQjtBQUd2QkMsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLFVBQVUsRUFDUixtVEFGSTtBQUdOQyxRQUFBQSxRQUFRLEVBQUU7QUFISixPQUhlO0FBUXZCQyxNQUFBQSxJQUFJLEVBQUU7QUFSaUIsS0FBZixDQUZIO0FBWVBVLElBQUFBLGNBQWMsRUFBRWhCLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQzdCSCxNQUFBQSxLQUFLLEVBQUUscUNBRHNCO0FBRTdCSSxNQUFBQSxJQUFJLEVBQUUsVUFGdUI7QUFHN0JDLE1BQUFBLE1BQU0sRUFBRTtBQUNOQyxRQUFBQSxVQUFVLEVBQ1IsMklBRkk7QUFHTkMsUUFBQUEsUUFBUSxFQUFFO0FBSEosT0FIcUI7QUFRN0JDLE1BQUFBLElBQUksRUFBRTtBQVJ1QixLQUFmLENBWlQ7QUFzQlBDLElBQUFBLFdBQVcsRUFBRSxJQXRCTjtBQXVCUEMsSUFBQUEsV0FBVyxFQUFFLEVBdkJOO0FBd0JQQyxJQUFBQSxPQUFPLEVBQUUsQ0F4QkY7QUF5QlBDLElBQUFBLHFCQUFxQixFQUFFO0FBQ3JCQyxNQUFBQSxnQkFBZ0IsRUFBRVgsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDL0JXLFFBQUFBLEtBQUssRUFBRSxvQkFEd0I7QUFFL0JDLFFBQUFBLE1BQU0sRUFBRSxFQUZ1QjtBQUcvQkMsUUFBQUEsS0FBSyxFQUFFO0FBQUVBLFVBQUFBLEtBQUssRUFBRSxFQUFUO0FBQWFDLFVBQUFBLFFBQVEsRUFBRTtBQUF2QjtBQUh3QixPQUFmO0FBREc7QUF6QmhCO0FBSFgsQ0FoVmEsRUFxWGI7QUFDRXBCLEVBQUFBLEdBQUcsRUFBRSw2Q0FEUDtBQUVFQyxFQUFBQSxLQUFLLEVBQUUsZUFGVDtBQUdFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLG1DQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSxtQ0FEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxVQUZpQjtBQUd2QkMsTUFBQUEsTUFBTSxFQUFFO0FBQ05DLFFBQUFBLFVBQVUsRUFDUix3OENBRkk7QUFHTkMsUUFBQUEsUUFBUSxFQUFFO0FBSEosT0FIZTtBQVF2QkMsTUFBQUEsSUFBSSxFQUFFO0FBUmlCLEtBQWYsQ0FGSDtBQVlQQyxJQUFBQSxXQUFXLEVBQUUsSUFaTjtBQWFQQyxJQUFBQSxXQUFXLEVBQUUsRUFiTjtBQWNQQyxJQUFBQSxPQUFPLEVBQUUsQ0FkRjtBQWVQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQUVYLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQy9CVyxRQUFBQSxLQUFLLEVBQUUsb0JBRHdCO0FBRS9CQyxRQUFBQSxNQUFNLEVBQUUsRUFGdUI7QUFHL0JDLFFBQUFBLEtBQUssRUFBRTtBQUFFQSxVQUFBQSxLQUFLLEVBQUUsRUFBVDtBQUFhQyxVQUFBQSxRQUFRLEVBQUU7QUFBdkI7QUFId0IsT0FBZjtBQURHO0FBZmhCO0FBSFgsQ0FyWGEsQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXHJcbiAqIFdhenVoIGFwcCAtIENsdXN0ZXIgbW9uaXRvcmluZyB2aXN1YWxpemF0aW9uc1xyXG4gKiBDb3B5cmlnaHQgKEMpIDIwMTUtMjAyMiBXYXp1aCwgSW5jLlxyXG4gKlxyXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxyXG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxyXG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxyXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxyXG4gKlxyXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxyXG4gKi9cclxuZXhwb3J0IGRlZmF1bHQgW1xyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1TdGF0aXN0aWNzLXJlbW90ZWQtUmVjdi1ieXRlcycsXHJcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxyXG4gICAgX3NvdXJjZToge1xyXG4gICAgICB0aXRsZTogJ1dhenVoIEFwcCBTdGF0aXN0aWNzIHJlbW90ZWQgUmVjdiBieXRlcycsXHJcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyByZW1vdGVkIFJlY3YgYnl0ZXMnLFxyXG4gICAgICAgIHR5cGU6ICd0aW1lbGlvbicsXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICBleHByZXNzaW9uOlxyXG4gICAgICAgICAgICBcIi5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzpyZW1vdGVkLnJlY3ZfYnl0ZXMsIHE9JyonKS5sYWJlbChyZWN2X2J5dGVzKSwuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6cmVtb3RlZC5yZWN2X2J5dGVzLCBxPScqJykudHJlbmQoKS5sYWJlbChUcmVuZCkubGluZXMod2lkdGg9MS41KVwiLFxyXG4gICAgICAgICAgaW50ZXJ2YWw6ICc1bScsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBhZ2dzOiBbXSxcclxuICAgICAgfSksXHJcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgIGluZGV4OiAnd2F6dWgtc3RhdGlzdGljcy0qJyxcclxuICAgICAgICAgIGZpbHRlcjogW10sXHJcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxyXG4gICAgICAgIH0pLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1TdGF0aXN0aWNzLXJlbW90ZWQtZXZlbnQtY291bnQnLFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyByZW1vdGVkIGV2ZW50IGNvdW50JyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ1dhenVoIEFwcCBTdGF0aXN0aWNzIHJlbW90ZWQgZXZlbnQgY291bnQnLFxyXG4gICAgICAgIHR5cGU6ICd0aW1lbGlvbicsXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICBleHByZXNzaW9uOlxyXG4gICAgICAgICAgICBcIi5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzpyZW1vdGVkLmV2dF9jb3VudCwgcT0nKicpLmxhYmVsKGV2dF9jb3VudCksLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOnJlbW90ZWQuZXZ0X2NvdW50LCBxPScqJykudHJlbmQoKS5sYWJlbChUcmVuZCkubGluZXMod2lkdGg9MS41KVwiLFxyXG4gICAgICAgICAgaW50ZXJ2YWw6ICc1bScsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBhZ2dzOiBbXSxcclxuICAgICAgfSksXHJcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgIGluZGV4OiAnd2F6dWgtc3RhdGlzdGljcy0qJyxcclxuICAgICAgICAgIGZpbHRlcjogW10sXHJcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxyXG4gICAgICAgIH0pLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1TdGF0aXN0aWNzLXJlbW90ZWQtbWVzc2FnZXMnLFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyByZW1vdGVkIG1lc3NhZ2VzJyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ1dhenVoIEFwcCBTdGF0aXN0aWNzIHJlbW90ZWQgbWVzc2FnZXMnLFxyXG4gICAgICAgIHR5cGU6ICd0aW1lbGlvbicsXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICBleHByZXNzaW9uOlxyXG4gICAgICAgICAgICBcIi5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzpyZW1vdGVkLm1zZ19zZW50LCBxPScqJykubGFiZWwobXNnX3NlbnQpLC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzpyZW1vdGVkLmN0cmxfbXNnX2NvdW50LCBxPScqJykubGFiZWwoY3RybF9tc2dfY291bnQpLC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOnJlbW90ZWQuZGlzY2FyZGVkX2NvdW50KS5sYWJlbChkaXNjYXJkZWRfY291bnQpLC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzpyZW1vdGVkLmRlcXVldWVkX2FmdGVyX2Nsb3NlLCBxPScqJykubGFiZWwoZGVxdWV1ZWRfYWZ0ZXJfY2xvc2UpXCIsXHJcbiAgICAgICAgICBpbnRlcnZhbDogJzVtJyxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGFnZ3M6IFtdLFxyXG4gICAgICB9KSxcclxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgICAgdmVyc2lvbjogMSxcclxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XHJcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1zdGF0aXN0aWNzLSonLFxyXG4gICAgICAgICAgZmlsdGVyOiBbXSxcclxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXHJcbiAgICAgICAgfSksXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgX2lkOiAnV2F6dWgtQXBwLVN0YXRpc3RpY3MtcmVtb3RlZC10Y3Atc2Vzc2lvbnMnLFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyByZW1vdGVkIHRjcCBzZXNzaW9ucycsXHJcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyByZW1vdGVkIHRjcCBzZXNzaW9ucycsXHJcbiAgICAgICAgdHlwZTogJ3RpbWVsaW9uJyxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIGV4cHJlc3Npb246XHJcbiAgICAgICAgICAgIFwiLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9c3VtOnJlbW90ZWQudGNwX3Nlc3Npb25zLCBxPScqJykubGFiZWwodGNwX3Nlc3Npb25zKVwiLFxyXG4gICAgICAgICAgaW50ZXJ2YWw6ICc1bScsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBhZ2dzOiBbXSxcclxuICAgICAgfSksXHJcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgIGluZGV4OiAnd2F6dWgtc3RhdGlzdGljcy0qJyxcclxuICAgICAgICAgIGZpbHRlcjogW10sXHJcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxyXG4gICAgICAgIH0pLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1TdGF0aXN0aWNzLUFuYWx5c2lzZC1PdmVydmlldy1FdmVudHMtRGVjb2RlZCcsXHJcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxyXG4gICAgX3NvdXJjZToge1xyXG4gICAgICB0aXRsZTogJ1dhenVoIEFwcCBTdGF0aXN0aWNzIE92ZXJ2aWV3IGV2ZW50cyBkZWNvZGVkJyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ1dhenVoIEFwcCBTdGF0aXN0aWNzIE92ZXJ2aWV3IGV2ZW50cyBkZWNvZGUnLFxyXG4gICAgICAgIHR5cGU6ICd0aW1lbGlvbicsXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICBleHByZXNzaW9uOlxyXG4gICAgICAgICAgICBcIi5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Quc3lzY2hlY2tfZXZlbnRzX2RlY29kZWQsIHE9JyonKS5sYWJlbCgnU3lzY2hlY2sgRXZlbnRzIERlY29kZWQnKS5iYXJzKHN0YWNrPXRydWUpLCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnN5c2NoZWNrLCBxPScqJykubGFiZWwoJ1N5c2NvbGxlY3RvciBFdmVudHMgRGVjb2RlZCcpLmJhcnMoc3RhY2s9dHJ1ZSksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Qucm9vdGNoZWNrX2V2ZW50c19kZWNvZGVkLCBxPScqJykubGFiZWwoJ1Jvb3RjaGVjayBFdmVudHMgRGVjb2RlZCcpLmJhcnMoc3RhY2s9dHJ1ZSksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Quc2NhX2V2ZW50c19kZWNvZGVkLCBxPScqJykubGFiZWwoJ1NDQSBFdmVudHMgRGVjb2RlZCcpLmJhcnMoc3RhY2s9dHJ1ZSksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Qub3RoZXJfZXZlbnRzX2RlY29kZWQsIHE9JyonKS5sYWJlbCgnT3RoZXIgRXZlbnRzIERlY29kZWQnKS5iYXJzKHN0YWNrPXRydWUpLCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLmhvc3RpbmZvX2V2ZW50c19kZWNvZGVkLCBxPScqJykubGFiZWwoJ0hvc3QgSW5mbyBFdmVudHMgRGVjb2RlZCcpLmJhcnMoc3RhY2s9dHJ1ZSlcIixcclxuICAgICAgICAgIGludGVydmFsOiAnNW0nLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYWdnczogW10sXHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICBpbmRleDogJ3dhenVoLXN0YXRpc3RpY3MtKicsXHJcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxyXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcclxuICAgICAgICB9KSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBfaWQ6ICdXYXp1aC1BcHAtU3RhdGlzdGljcy1BbmFseXNpc2QtU3lzY2hlY2snLFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyBTeXNjaGVjaycsXHJcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyBTeXNjaGVjaycsXHJcbiAgICAgICAgdHlwZTogJ3RpbWVsaW9uJyxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIGV4cHJlc3Npb246XHJcbiAgICAgICAgICAgIFwiLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5zeXNjaGVja19ldmVudHNfZGVjb2RlZCwgcT0nKicpLmxhYmVsKCdTeXNjaGVjayBFdmVudHMgRGVjb2RlZCcpLCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnN5c2NoZWNrX2VkcHMsIHE9JyonKS5sYWJlbCgnU3lzY2hlY2sgRURQUycpLCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnN5c2NoZWNrX3F1ZXVlX3NpemUsIHE9JyonKS5tdWx0aXBseSggLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5zeXNjaGVja19xdWV1ZV91c2FnZSwgcT0nKicpICkubGFiZWwoJ1F1ZXVlIFVzYWdlJykuY29sb3IoJ2dyZWVuJyksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Quc3lzY2hlY2tfcXVldWVfdXNhZ2UsIHE9JyonKS5pZihndGUsIDAuNywgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5zeXNjaGVja19xdWV1ZV9zaXplLCBxPScqJykubXVsdGlwbHkoIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Quc3lzY2hlY2tfcXVldWVfdXNhZ2UsIHE9JyonKSApLCBudWxsKSAuY29sb3IoJyNGRkNDMTEnKS5sYWJlbCgnUXVldWUgVXNhZ2UgNzAlKycpLCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnN5c2NoZWNrX3F1ZXVlX3VzYWdlLCBxPScqJykuaWYoZ3RlLCAwLjksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Quc3lzY2hlY2tfcXVldWVfc2l6ZSwgcT0nKicpLm11bHRpcGx5KCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnN5c2NoZWNrX3F1ZXVlX3VzYWdlLCBxPScqJykgKSwgbnVsbCkgLmNvbG9yKCdyZWQnKS5sYWJlbCgnUXVldWUgVXNhZ2UgOTAlKycpXCIsXHJcbiAgICAgICAgICBpbnRlcnZhbDogJzVtJyxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGFnZ3M6IFtdLFxyXG4gICAgICB9KSxcclxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgICAgdmVyc2lvbjogMSxcclxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XHJcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1zdGF0aXN0aWNzLSonLFxyXG4gICAgICAgICAgZmlsdGVyOiBbXSxcclxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXHJcbiAgICAgICAgfSksXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgX2lkOiAnV2F6dWgtQXBwLVN0YXRpc3RpY3MtQW5hbHlzaXNkLVN5c2NvbGxlY3RvcicsXHJcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxyXG4gICAgX3NvdXJjZToge1xyXG4gICAgICB0aXRsZTogJ1dhenVoIEFwcCBTdGF0aXN0aWNzIFN5c2NvbGxlY3RvcicsXHJcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyBTeXNjb2xsZWN0b3InLFxyXG4gICAgICAgIHR5cGU6ICd0aW1lbGlvbicsXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICBleHByZXNzaW9uOlxyXG4gICAgICAgICAgICBcIi5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Quc3lzY29sbGVjdG9yX2V2ZW50c19kZWNvZGVkLCBxPScqJykubGFiZWwoJ3N5c2NvbGxlY3RvciBFdmVudHMgRGVjb2RlZCcpLCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnN5c2NvbGxlY3Rvcl9lZHBzLCBxPScqJykubGFiZWwoJ3N5c2NvbGxlY3RvciBFRFBTJyksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Quc3lzY29sbGVjdG9yX3F1ZXVlX3NpemUsIHE9JyonKS5tdWx0aXBseSggLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5zeXNjb2xsZWN0b3JfcXVldWVfdXNhZ2UsIHE9JyonKSApLmxhYmVsKCdRdWV1ZSBVc2FnZScpLmNvbG9yKCdncmVlbicpLCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnN5c2NvbGxlY3Rvcl9xdWV1ZV91c2FnZSwgcT0nKicpLmlmKGd0ZSwgMC43LCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnN5c2NvbGxlY3Rvcl9xdWV1ZV9zaXplLCBxPScqJykubXVsdGlwbHkoIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Quc3lzY29sbGVjdG9yX3F1ZXVlX3VzYWdlLCBxPScqJykgKSwgbnVsbCkgLmNvbG9yKCcjRkZDQzExJykubGFiZWwoJ1F1ZXVlIFVzYWdlIDcwJSsnKSwgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5zeXNjb2xsZWN0b3JfcXVldWVfdXNhZ2UsIHE9JyonKS5pZihndGUsIDAuOSwgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5zeXNjb2xsZWN0b3JfcXVldWVfc2l6ZSwgcT0nKicpLm11bHRpcGx5KCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnN5c2NvbGxlY3Rvcl9xdWV1ZV91c2FnZSwgcT0nKicpICksIG51bGwpIC5jb2xvcigncmVkJykubGFiZWwoJ1F1ZXVlIFVzYWdlIDkwJSsnKVwiLFxyXG4gICAgICAgICAgaW50ZXJ2YWw6ICc1bScsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBhZ2dzOiBbXSxcclxuICAgICAgfSksXHJcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgIGluZGV4OiAnd2F6dWgtc3RhdGlzdGljcy0qJyxcclxuICAgICAgICAgIGZpbHRlcjogW10sXHJcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxyXG4gICAgICAgIH0pLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1TdGF0aXN0aWNzLUFuYWx5c2lzZC1Sb290Y2hlY2snLFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyBSb290Y2hlY2snLFxyXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHRpdGxlOiAnV2F6dWggQXBwIFN0YXRpc3RpY3MgUm9vdGNoZWNrJyxcclxuICAgICAgICB0eXBlOiAndGltZWxpb24nLFxyXG4gICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgZXhwcmVzc2lvbjpcclxuICAgICAgICAgICAgXCIuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnJvb3RjaGVja19ldmVudHNfZGVjb2RlZCwgcT0nKicpLmxhYmVsKCdSb290Y2hlY2sgRXZlbnRzIERlY29kZWQnKSwgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5yb290Y2hlY2tfZWRwcywgcT0nKicpLmxhYmVsKCdSb290Y2hlY2sgRURQUycpLCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnJvb3RjaGVja19xdWV1ZV9zaXplLCBxPScqJykubXVsdGlwbHkoIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Qucm9vdGNoZWNrX3F1ZXVlX3VzYWdlLCBxPScqJykgKS5sYWJlbCgnUXVldWUgVXNhZ2UnKS5jb2xvcignZ3JlZW4nKSwgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5yb290Y2hlY2tfcXVldWVfdXNhZ2UsIHE9JyonKS5pZihndGUsIDAuNywgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5yb290Y2hlY2tfcXVldWVfc2l6ZSwgcT0nKicpLm11bHRpcGx5KCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnJvb3RjaGVja19xdWV1ZV91c2FnZSwgcT0nKicpICksIG51bGwpIC5jb2xvcignI0ZGQ0MxMScpLmxhYmVsKCdRdWV1ZSBVc2FnZSA3MCUrJyksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Qucm9vdGNoZWNrX3F1ZXVlX3VzYWdlLCBxPScqJykuaWYoZ3RlLCAwLjksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Qucm9vdGNoZWNrX3F1ZXVlX3NpemUsIHE9JyonKS5tdWx0aXBseSggLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5yb290Y2hlY2tfcXVldWVfdXNhZ2UpICksIG51bGwpIC5jb2xvcigncmVkJykubGFiZWwoJ1F1ZXVlIFVzYWdlIDkwJSsnKVwiLFxyXG4gICAgICAgICAgaW50ZXJ2YWw6ICc1bScsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBhZ2dzOiBbXSxcclxuICAgICAgfSksXHJcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgIGluZGV4OiAnd2F6dWgtc3RhdGlzdGljcy0qJyxcclxuICAgICAgICAgIGZpbHRlcjogW10sXHJcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxyXG4gICAgICAgIH0pLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1TdGF0aXN0aWNzLUFuYWx5c2lzZC1TQ0EnLFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyBTQ0EnLFxyXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHRpdGxlOiAnV2F6dWggQXBwIFN0YXRpc3RpY3MgU0NBJyxcclxuICAgICAgICB0eXBlOiAndGltZWxpb24nLFxyXG4gICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgZXhwcmVzc2lvbjpcclxuICAgICAgICAgICAgXCIuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnNjYV9ldmVudHNfZGVjb2RlZCwgcT0nKicpLmxhYmVsKCdTQ0EgRXZlbnRzIERlY29kZWQnKSwgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5zY2FfZWRwcywgcT0nKicpLmxhYmVsKCdTQ0EgRURQUycpLCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnNjYV9xdWV1ZV9zaXplLCBxPScqJykubXVsdGlwbHkoIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Quc2NhX3F1ZXVlX3VzYWdlLCBxPScqJykgKS5sYWJlbCgnUXVldWUgVXNhZ2UnKS5jb2xvcignZ3JlZW4nKSwgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5zY2FfcXVldWVfdXNhZ2UsIHE9JyonKS5pZihndGUsIDAuNywgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5zY2FfcXVldWVfc2l6ZSwgcT0nKicpLm11bHRpcGx5KCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnNjYV9xdWV1ZV91c2FnZSwgcT0nKicpICksIG51bGwpIC5jb2xvcignI0ZGQ0MxMScpLmxhYmVsKCdRdWV1ZSBVc2FnZSA3MCUrJyksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Quc2NhX3F1ZXVlX3VzYWdlLCBxPScqJykuaWYoZ3RlLCAwLjksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Quc2NhX3F1ZXVlX3NpemUsIHE9JyonKS5tdWx0aXBseSggLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5zY2FfcXVldWVfdXNhZ2UsIHE9JyonKSApLCBudWxsKSAuY29sb3IoJ3JlZCcpLmxhYmVsKCdRdWV1ZSBVc2FnZSA5MCUrJylcIixcclxuICAgICAgICAgIGludGVydmFsOiAnNW0nLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYWdnczogW10sXHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICBpbmRleDogJ3dhenVoLXN0YXRpc3RpY3MtKicsXHJcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxyXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcclxuICAgICAgICB9KSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBfaWQ6ICdXYXp1aC1BcHAtU3RhdGlzdGljcy1BbmFseXNpc2QtSG9zdEluZm8nLFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyBIb3N0SW5mbycsXHJcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyBIb3N0SW5mbycsXHJcbiAgICAgICAgdHlwZTogJ3RpbWVsaW9uJyxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIGV4cHJlc3Npb246XHJcbiAgICAgICAgICAgIFwiLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5ob3N0aW5mb19ldmVudHNfZGVjb2RlZCwgcT0nKicpLmxhYmVsKCdIb3N0IGluZm8gRXZlbnRzIERlY29kZWQnKSwgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5ob3N0aW5mb19lZHBzLCBxPScqJykubGFiZWwoJ0hvc3QgaW5mbyBFRFBTJyksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2QuaG9zdGluZm9fcXVldWVfc2l6ZSwgcT0nKicpLm11bHRpcGx5KCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLmhvc3RpbmZvX3F1ZXVlX3VzYWdlLCBxPScqJykgKS5sYWJlbCgnUXVldWUgVXNhZ2UnKS5jb2xvcignZ3JlZW4nKSwgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5ob3N0aW5mb19xdWV1ZV91c2FnZSwgcT0nKicpLmlmKGd0ZSwgMC43LCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLmhvc3RpbmZvX3F1ZXVlX3NpemUsIHE9JyonKS5tdWx0aXBseSggLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5ob3N0aW5mb19xdWV1ZV91c2FnZSwgcT0nKicpICksIG51bGwpIC5jb2xvcignI0ZGQ0MxMScpLmxhYmVsKCdRdWV1ZSBVc2FnZSA3MCUrJyksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2QuaG9zdGluZm9fcXVldWVfdXNhZ2UsIHE9JyonKS5pZihndGUsIDAuOSwgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5ob3N0aW5mb19xdWV1ZV9zaXplLCBxPScqJykubXVsdGlwbHkoIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2QuaG9zdGluZm9fcXVldWVfdXNhZ2UsIHE9JyonKSApLCBudWxsKSAuY29sb3IoJ3JlZCcpLmxhYmVsKCdRdWV1ZSBVc2FnZSA5MCUrJylcIixcclxuICAgICAgICAgIGludGVydmFsOiAnNW0nLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYWdnczogW10sXHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICBpbmRleDogJ3dhenVoLXN0YXRpc3RpY3MtKicsXHJcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxyXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcclxuICAgICAgICB9KSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBfaWQ6ICdXYXp1aC1BcHAtU3RhdGlzdGljcy1BbmFseXNpc2QtT3RoZXInLFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyBPdGhlcicsXHJcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyBPdGhlcicsXHJcbiAgICAgICAgdHlwZTogJ3RpbWVsaW9uJyxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIGV4cHJlc3Npb246XHJcbiAgICAgICAgICAgIFwiLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5vdGhlcl9ldmVudHNfZGVjb2RlZCwgcT0nKicpLmxhYmVsKCdIb3N0IGluZm8gRXZlbnRzIERlY29kZWQnKSwgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5vdGhlcl9lZHBzLCBxPScqJykubGFiZWwoJ0hvc3QgaW5mbyBFRFBTJyksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Qub3RoZXJfcXVldWVfc2l6ZSwgcT0nKicpLm11bHRpcGx5KCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLm90aGVyX3F1ZXVlX3VzYWdlLCBxPScqJykgKS5sYWJlbCgnUXVldWUgVXNhZ2UnKS5jb2xvcignZ3JlZW4nKSwgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5vdGhlcl9xdWV1ZV91c2FnZSwgcT0nKicpLmlmKGd0ZSwgMC43LCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLm90aGVyX3F1ZXVlX3NpemUsIHE9JyonKS5tdWx0aXBseSggLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5vdGhlcl9xdWV1ZV91c2FnZSwgcT0nKicpICksIG51bGwpIC5jb2xvcignI0ZGQ0MxMScpLmxhYmVsKCdRdWV1ZSBVc2FnZSA3MCUrJyksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Qub3RoZXJfcXVldWVfdXNhZ2UsIHE9JyonKS5pZihndGUsIDAuOSwgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5vdGhlcl9xdWV1ZV9zaXplLCBxPScqJykubXVsdGlwbHkoIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Qub3RoZXJfcXVldWVfdXNhZ2UsIHE9JyonKSApLCBudWxsKSAuY29sb3IoJ3JlZCcpLmxhYmVsKCdRdWV1ZSBVc2FnZSA5MCUrJylcIixcclxuICAgICAgICAgIGludGVydmFsOiAnNW0nLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYWdnczogW10sXHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICBpbmRleDogJ3dhenVoLXN0YXRpc3RpY3MtKicsXHJcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxyXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcclxuICAgICAgICB9KSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfSxcclxuXHJcbiAge1xyXG4gICAgX2lkOiAnV2F6dWgtQXBwLVN0YXRpc3RpY3MtQW5hbHlzaXNkLUV2ZW50cy1CeS1Ob2RlJyxcclxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXHJcbiAgICBfc291cmNlOiB7XHJcbiAgICAgIHRpdGxlOiAnV2F6dWggQXBwIFN0YXRpc3RpY3MgRXZlbnRzIGJ5IE5vZGUnLFxyXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHRpdGxlOiAnV2F6dWggQXBwIFN0YXRpc3RpY3MgRXZlbnRzIGJ5IE5vZGUnLFxyXG4gICAgICAgIHR5cGU6ICd0aW1lbGlvbicsXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICBleHByZXNzaW9uOlxyXG4gICAgICAgICAgICBcIi5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPXN1bTphbmFseXNpc2QuZXZlbnRzX3Byb2Nlc3NlZCwgcT0nKicpIC5sYWJlbCgnVG90YWwnKSwgLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9c3VtOmFuYWx5c2lzZC5ldmVudHNfcHJvY2Vzc2VkLCBxPScqJywgc3BsaXQ9bm9kZU5hbWUua2V5d29yZDo1KS5sYWJlbCgnRXZlbnRzIHByb2Nlc3NlZCBieSBOb2RlOiAkMScsJ14uKiA+IG5vZGVOYW1lLmtleXdvcmQ6KFxcXFxcXFxcUyspID4gLionKVwiLFxyXG4gICAgICAgICAgaW50ZXJ2YWw6ICc1bScsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBhZ2dzOiBbXSxcclxuICAgICAgfSksXHJcbiAgICAgIHZpc1N0YXRlQnlOb2RlOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyBFdmVudHMgYnkgTm9kZScsXHJcbiAgICAgICAgdHlwZTogJ3RpbWVsaW9uJyxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIGV4cHJlc3Npb246XHJcbiAgICAgICAgICAgIFwiLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9c3VtOmFuYWx5c2lzZC5ldmVudHNfcHJvY2Vzc2VkLCBxPScqJykgLmxhYmVsKCdFdmVudHMgcHJvY2Vzc2VkIGJ5IE5vZGU6IE5PREVfTkFNRScpXCIsXHJcbiAgICAgICAgICBpbnRlcnZhbDogJzVtJyxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGFnZ3M6IFtdLFxyXG4gICAgICB9KSxcclxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgICAgdmVyc2lvbjogMSxcclxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XHJcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1zdGF0aXN0aWNzLSonLFxyXG4gICAgICAgICAgZmlsdGVyOiBbXSxcclxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXHJcbiAgICAgICAgfSksXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgX2lkOiAnV2F6dWgtQXBwLVN0YXRpc3RpY3MtQW5hbHlzaXNkLUV2ZW50cy1Ecm9wcGVkLUJ5LU5vZGUnLFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyBFdmVudHMgRHJvcHBlZCBieSBOb2RlJyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ1dhenVoIEFwcCBTdGF0aXN0aWNzIEV2ZW50cyBEcm9wcGVkIGJ5IE5vZGUnLFxyXG4gICAgICAgIHR5cGU6ICd0aW1lbGlvbicsXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICBleHByZXNzaW9uOlxyXG4gICAgICAgICAgICBcIi5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPXN1bTphbmFseXNpc2QuZXZlbnRzX2Ryb3BwZWQsIHE9JyonKSAubGFiZWwoJ1RvdGFsJyksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPXN1bTphbmFseXNpc2QuZXZlbnRzX2Ryb3BwZWQsIHE9JyonLCBzcGxpdD1ub2RlTmFtZS5rZXl3b3JkOjUpLmxhYmVsKCdFdmVudHMgZHJvcHBlZCBieSBOb2RlOiAkMScsJ14uKiA+IG5vZGVOYW1lLmtleXdvcmQ6KFxcXFxcXFxcUyspID4gLionKVwiLFxyXG4gICAgICAgICAgaW50ZXJ2YWw6ICc1bScsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBhZ2dzOiBbXSxcclxuICAgICAgfSksXHJcbiAgICAgIHZpc1N0YXRlQnlOb2RlOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdGl0bGU6ICdXYXp1aCBBcHAgU3RhdGlzdGljcyBFdmVudHMgYnkgTm9kZScsXHJcbiAgICAgICAgdHlwZTogJ3RpbWVsaW9uJyxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIGV4cHJlc3Npb246XHJcbiAgICAgICAgICAgIFwiLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9c3VtOmFuYWx5c2lzZC5ldmVudHNfZHJvcHBlZCwgcT0nKicpIC5sYWJlbCgnRXZlbnRzIGRyb3BwZWQgYnkgTm9kZTogTk9ERV9OQU1FJylcIixcclxuICAgICAgICAgIGludGVydmFsOiAnNW0nLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYWdnczogW10sXHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICBpbmRleDogJ3dhenVoLXN0YXRpc3RpY3MtKicsXHJcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxyXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcclxuICAgICAgICB9KSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBfaWQ6ICdXYXp1aC1BcHAtU3RhdGlzdGljcy1BbmFseXNpc2QtUXVldWVzLVVzYWdlJyxcclxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXHJcbiAgICBfc291cmNlOiB7XHJcbiAgICAgIHRpdGxlOiAnV2F6dWggQXBwIFN0YXRpc3RpY3MgUXVldWVzIFVzYWdlJyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ1dhenVoIEFwcCBTdGF0aXN0aWNzIFF1ZXVlcyBVc2FnZScsXHJcbiAgICAgICAgdHlwZTogJ3RpbWVsaW9uJyxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIGV4cHJlc3Npb246XHJcbiAgICAgICAgICAgIFwiLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5ldmVudF9xdWV1ZV9zaXplLCBxPScqJykubXVsdGlwbHkoIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2QuZXZlbnRfcXVldWVfdXNhZ2UsIHE9JyonKSApLmxhYmVsKCdFdmVudCBxdWV1ZSB1c2FnZScpLCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnJ1bGVfbWF0Y2hpbmdfcXVldWVfc2l6ZSwgcT0nKicpLm11bHRpcGx5KCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnJ1bGVfbWF0Y2hpbmdfcXVldWVfdXNhZ2UsIHE9JyonKSApLmxhYmVsKCdSdWxlIG1hdGNoaW5nIHF1ZXVlIHVzYWdlJyksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2QuYWxlcnRzX3F1ZXVlX3NpemUsIHE9JyonKS5tdWx0aXBseSggLmVzKGluZGV4PXdhenVoLXN0YXRpc3RpY3MtKiwgdGltZWZpZWxkPXRpbWVzdGFtcCxtZXRyaWM9YXZnOmFuYWx5c2lzZC5hbGVydHNfcXVldWVfdXNhZ2UsIHE9JyonKSApLmxhYmVsKCdBbGVydHMgbG9nIHF1ZXVlIHVzYWdlJyksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2QuZmlyZXdhbGxfcXVldWVfc2l6ZSwgcT0nKicpLm11bHRpcGx5KCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLmZpcmV3YWxsX3F1ZXVlX3VzYWdlLCBxPScqJykgKS5sYWJlbCgnRmlyZXdhbGwgbG9nIHF1ZXVlIHVzYWdlJyksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2Quc3RhdGlzdGljYWxfcXVldWVfc2l6ZSwgcT0nKicpLm11bHRpcGx5KCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLnN0YXRpc3RpY2FsX3F1ZXVlX3VzYWdlLCBxPScqJykgKS5sYWJlbCgnU3RhdGlzdGljYWwgbG9nIHF1ZXVlIHVzYWdlJyksIC5lcyhpbmRleD13YXp1aC1zdGF0aXN0aWNzLSosIHRpbWVmaWVsZD10aW1lc3RhbXAsbWV0cmljPWF2ZzphbmFseXNpc2QuYXJjaGl2ZXNfcXVldWVfc2l6ZSwgcT0nKicpLm11bHRpcGx5KCAuZXMoaW5kZXg9d2F6dWgtc3RhdGlzdGljcy0qLCB0aW1lZmllbGQ9dGltZXN0YW1wLG1ldHJpYz1hdmc6YW5hbHlzaXNkLmFyY2hpdmVzX3F1ZXVlX3VzYWdlLCBxPScqJykgKS5sYWJlbCgnU3RhdGlzdGljYWwgbG9nIHF1ZXVlIHVzYWdlJylcIixcclxuICAgICAgICAgIGludGVydmFsOiAnNW0nLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYWdnczogW10sXHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICBpbmRleDogJ3dhenVoLXN0YXRpc3RpY3MtKicsXHJcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxyXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcclxuICAgICAgICB9KSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfSxcclxuXTtcclxuIl19