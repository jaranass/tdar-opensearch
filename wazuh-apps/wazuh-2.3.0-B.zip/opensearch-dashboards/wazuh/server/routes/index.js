"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.setupRoutes = void 0;

var _wazuhApi = require("./wazuh-api");

var _wazuhElastic = require("./wazuh-elastic");

var _wazuhHosts = require("./wazuh-hosts");

var _wazuhUtils = require("./wazuh-utils");

var _wazuhReporting = require("./wazuh-reporting");

const setupRoutes = router => {
  (0, _wazuhApi.WazuhApiRoutes)(router);
  (0, _wazuhElastic.WazuhElasticRoutes)(router);
  (0, _wazuhHosts.WazuhHostsRoutes)(router);
  (0, _wazuhUtils.WazuhUtilsRoutes)(router);
  (0, _wazuhReporting.WazuhReportingRoutes)(router);
  (0, _wazuhUtils.UiLogsRoutes)(router);
};

exports.setupRoutes = setupRoutes;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbInNldHVwUm91dGVzIiwicm91dGVyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBRU8sTUFBTUEsV0FBVyxHQUFJQyxNQUFELElBQXFCO0FBQzVDLGdDQUFlQSxNQUFmO0FBQ0Esd0NBQW1CQSxNQUFuQjtBQUNBLG9DQUFpQkEsTUFBakI7QUFDQSxvQ0FBaUJBLE1BQWpCO0FBQ0EsNENBQXFCQSxNQUFyQjtBQUNBLGdDQUFhQSxNQUFiO0FBQ0gsQ0FQTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElSb3V0ZXIgfSBmcm9tICdvcGVuc2VhcmNoX2Rhc2hib2FyZHMvc2VydmVyJztcclxuaW1wb3J0IHsgV2F6dWhBcGlSb3V0ZXMgfSBmcm9tICcuL3dhenVoLWFwaSc7XHJcbmltcG9ydCB7IFdhenVoRWxhc3RpY1JvdXRlcyB9IGZyb20gXCIuL3dhenVoLWVsYXN0aWNcIjtcclxuaW1wb3J0IHsgV2F6dWhIb3N0c1JvdXRlcyB9IGZyb20gXCIuL3dhenVoLWhvc3RzXCI7XHJcbmltcG9ydCB7IFdhenVoVXRpbHNSb3V0ZXMsIFVpTG9nc1JvdXRlcyB9IGZyb20gJy4vd2F6dWgtdXRpbHMnXHJcbmltcG9ydCB7IFdhenVoUmVwb3J0aW5nUm91dGVzIH0gZnJvbSBcIi4vd2F6dWgtcmVwb3J0aW5nXCI7XHJcblxyXG5leHBvcnQgY29uc3Qgc2V0dXBSb3V0ZXMgPSAocm91dGVyOiBJUm91dGVyKSA9PiB7XHJcbiAgICBXYXp1aEFwaVJvdXRlcyhyb3V0ZXIpO1xyXG4gICAgV2F6dWhFbGFzdGljUm91dGVzKHJvdXRlcik7XHJcbiAgICBXYXp1aEhvc3RzUm91dGVzKHJvdXRlcik7XHJcbiAgICBXYXp1aFV0aWxzUm91dGVzKHJvdXRlcik7XHJcbiAgICBXYXp1aFJlcG9ydGluZ1JvdXRlcyhyb3V0ZXIpO1xyXG4gICAgVWlMb2dzUm91dGVzKHJvdXRlcik7XHJcbn07XHJcbiJdfQ==