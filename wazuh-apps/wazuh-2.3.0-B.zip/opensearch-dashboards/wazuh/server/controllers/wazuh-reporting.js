"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhReportingCtrl = void 0;

var _path = _interopRequireDefault(require("path"));

var _fs = _interopRequireDefault(require("fs"));

var _wazuhModules = require("../../common/wazuh-modules");

var TimSort = _interopRequireWildcard(require("timsort"));

var _errorResponse = require("../lib/error-response");

var VulnerabilityRequest = _interopRequireWildcard(require("../lib/reporting/vulnerability-request"));

var OverviewRequest = _interopRequireWildcard(require("../lib/reporting/overview-request"));

var RootcheckRequest = _interopRequireWildcard(require("../lib/reporting/rootcheck-request"));

var PCIRequest = _interopRequireWildcard(require("../lib/reporting/pci-request"));

var GDPRRequest = _interopRequireWildcard(require("../lib/reporting/gdpr-request"));

var TSCRequest = _interopRequireWildcard(require("../lib/reporting/tsc-request"));

var AuditRequest = _interopRequireWildcard(require("../lib/reporting/audit-request"));

var SyscheckRequest = _interopRequireWildcard(require("../lib/reporting/syscheck-request"));

var _pciRequirementsPdfmake = _interopRequireDefault(require("../integration-files/pci-requirements-pdfmake"));

var _gdprRequirementsPdfmake = _interopRequireDefault(require("../integration-files/gdpr-requirements-pdfmake"));

var _tscRequirementsPdfmake = _interopRequireDefault(require("../integration-files/tsc-requirements-pdfmake"));

var _processStateEquivalence = _interopRequireDefault(require("../lib/process-state-equivalence"));

var _csvKeyEquivalence = require("../../common/csv-key-equivalence");

var _agentConfiguration = require("../lib/reporting/agent-configuration");

var _printer = require("../lib/reporting/printer");

var _logger = require("../lib/logger");

var _constants = require("../../common/constants");

var _filesystem = require("../lib/filesystem");

var _moment = _interopRequireDefault(require("moment"));

var _wz_agent_status = require("../../common/services/wz_agent_status");

function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class WazuhReportingCtrl {
  constructor() {
    _defineProperty(this, "createReportsModules", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        (0, _logger.log)('reporting:createReportsModules', `Report started`, 'info');
        const {
          array,
          agents,
          browserTimezone,
          searchBar,
          filters,
          time,
          tables,
          section,
          indexPatternTitle,
          apiId
        } = request.body;
        const {
          moduleID
        } = request.params;
        const {
          from,
          to
        } = time || {}; // Init

        const printer = new _printer.ReportPrinter();
        (0, _filesystem.createDataDirectoryIfNotExists)();
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, context.wazuhEndpointParams.hashUsername));
        await this.renderHeader(context, printer, section, moduleID, agents, apiId);
        const [sanitizedFilters, agentsFilter] = filters ? this.sanitizeKibanaFilters(filters, searchBar) : [false, false];

        if (time && sanitizedFilters) {
          printer.addTimeRangeAndFilters(from, to, sanitizedFilters, browserTimezone);
        }

        if (time) {
          await this.extendedInformation(context, printer, section, moduleID, apiId, new Date(from).getTime(), new Date(to).getTime(), sanitizedFilters, indexPatternTitle, agents);
        }

        printer.addVisualizations(array, agents, moduleID);

        if (tables) {
          printer.addTables(tables);
        } //add authorized agents


        if (agentsFilter) {
          printer.addAgentsFilters(agentsFilter);
        }

        await printer.print(context.wazuhEndpointParams.pathFilename);
        return response.ok({
          body: {
            success: true,
            message: `Report ${context.wazuhEndpointParams.filename} was created`
          }
        });
      } catch (error) {
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
      }
    }, ({
      body: {
        agents
      },
      params: {
        moduleID
      }
    }) => `wazuh-module-${agents ? `agents-${agents}` : 'overview'}-${moduleID}-${this.generateReportTimestamp()}.pdf`));

    _defineProperty(this, "createReportsGroups", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        (0, _logger.log)('reporting:createReportsGroups', `Report started`, 'info');
        const {
          components,
          apiId
        } = request.body;
        const {
          groupID
        } = request.params; // Init

        const printer = new _printer.ReportPrinter();
        (0, _filesystem.createDataDirectoryIfNotExists)();
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, context.wazuhEndpointParams.hashUsername));
        let tables = [];
        const equivalences = {
          localfile: 'Local files',
          osquery: 'Osquery',
          command: 'Command',
          syscheck: 'Syscheck',
          'open-scap': 'OpenSCAP',
          'cis-cat': 'CIS-CAT',
          syscollector: 'Syscollector',
          rootcheck: 'Rootcheck',
          labels: 'Labels',
          sca: 'Security configuration assessment'
        };
        printer.addContent({
          text: `Group ${groupID} configuration`,
          style: 'h1'
        }); // Group configuration

        if (components['0']) {
          const {
            data: {
              data: configuration
            }
          } = await context.wazuh.api.client.asCurrentUser.request('GET', `/groups/${groupID}/configuration`, {}, {
            apiHostID: apiId
          });

          if (configuration.affected_items.length > 0 && Object.keys(configuration.affected_items[0].config).length) {
            printer.addContent({
              text: 'Configurations',
              style: {
                fontSize: 14,
                color: '#000'
              },
              margin: [0, 10, 0, 15]
            });
            const section = {
              labels: [],
              isGroupConfig: true
            };

            for (let config of configuration.affected_items) {
              let filterTitle = '';
              let index = 0;

              for (let filter of Object.keys(config.filters)) {
                filterTitle = filterTitle.concat(`${filter}: ${config.filters[filter]}`);

                if (index < Object.keys(config.filters).length - 1) {
                  filterTitle = filterTitle.concat(' | ');
                }

                index++;
              }

              printer.addContent({
                text: filterTitle,
                style: 'h4',
                margin: [0, 0, 0, 10]
              });
              let idx = 0;
              section.tabs = [];

              for (let _d of Object.keys(config.config)) {
                for (let c of _agentConfiguration.AgentConfiguration.configurations) {
                  for (let s of c.sections) {
                    section.opts = s.opts || {};

                    for (let cn of s.config || []) {
                      if (cn.configuration === _d) {
                        section.labels = s.labels || [[]];
                      }
                    }

                    for (let wo of s.wodle || []) {
                      if (wo.name === _d) {
                        section.labels = s.labels || [[]];
                      }
                    }
                  }
                }

                section.labels[0]['pack'] = 'Packs';
                section.labels[0]['content'] = 'Evaluations';
                section.labels[0]['7'] = 'Scan listening netwotk ports';
                section.tabs.push(equivalences[_d]);

                if (Array.isArray(config.config[_d])) {
                  /* LOG COLLECTOR */
                  if (_d === 'localfile') {
                    let groups = [];

                    config.config[_d].forEach(obj => {
                      if (!groups[obj.logformat]) {
                        groups[obj.logformat] = [];
                      }

                      groups[obj.logformat].push(obj);
                    });

                    Object.keys(groups).forEach(group => {
                      let saveidx = 0;
                      groups[group].forEach((x, i) => {
                        if (Object.keys(x).length > Object.keys(groups[group][saveidx]).length) {
                          saveidx = i;
                        }
                      });
                      const columns = Object.keys(groups[group][saveidx]);
                      const rows = groups[group].map(x => {
                        let row = [];
                        columns.forEach(key => {
                          row.push(typeof x[key] !== 'object' ? x[key] : Array.isArray(x[key]) ? x[key].map(x => {
                            return x + '\n';
                          }) : JSON.stringify(x[key]));
                        });
                        return row;
                      });
                      columns.forEach((col, i) => {
                        columns[i] = col[0].toUpperCase() + col.slice(1);
                      });
                      tables.push({
                        title: 'Local files',
                        type: 'table',
                        columns,
                        rows
                      });
                    });
                  } else if (_d === 'labels') {
                    const obj = config.config[_d][0].label;
                    const columns = Object.keys(obj[0]);

                    if (!columns.includes('hidden')) {
                      columns.push('hidden');
                    }

                    const rows = obj.map(x => {
                      let row = [];
                      columns.forEach(key => {
                        row.push(x[key]);
                      });
                      return row;
                    });
                    columns.forEach((col, i) => {
                      columns[i] = col[0].toUpperCase() + col.slice(1);
                    });
                    tables.push({
                      title: 'Labels',
                      type: 'table',
                      columns,
                      rows
                    });
                  } else {
                    for (let _d2 of config.config[_d]) {
                      tables.push(...this.getConfigTables(_d2, section, idx));
                    }
                  }
                } else {
                  /*INTEGRITY MONITORING MONITORED DIRECTORIES */
                  if (config.config[_d].directories) {
                    const directories = config.config[_d].directories;
                    delete config.config[_d].directories;
                    tables.push(...this.getConfigTables(config.config[_d], section, idx));
                    let diffOpts = [];
                    Object.keys(section.opts).forEach(x => {
                      diffOpts.push(x);
                    });
                    const columns = ['', ...diffOpts.filter(x => x !== 'check_all' && x !== 'check_sum')];
                    let rows = [];
                    directories.forEach(x => {
                      let row = [];
                      row.push(x.path);
                      columns.forEach(y => {
                        if (y !== '') {
                          y = y !== 'check_whodata' ? y : 'whodata';
                          row.push(x[y] ? x[y] : 'no');
                        }
                      });
                      row.push(x.recursion_level);
                      rows.push(row);
                    });
                    columns.forEach((x, idx) => {
                      columns[idx] = section.opts[x];
                    });
                    columns.push('RL');
                    tables.push({
                      title: 'Monitored directories',
                      type: 'table',
                      columns,
                      rows
                    });
                  } else {
                    tables.push(...this.getConfigTables(config.config[_d], section, idx));
                  }
                }

                for (const table of tables) {
                  printer.addConfigTables([table]);
                }

                idx++;
                tables = [];
              }

              tables = [];
            }
          } else {
            printer.addContent({
              text: 'A configuration for this group has not yet been set up.',
              style: {
                fontSize: 12,
                color: '#000'
              },
              margin: [0, 10, 0, 15]
            });
          }
        } // Agents in group


        if (components['1']) {
          await this.renderHeader(context, printer, 'groupConfig', groupID, [], apiId);
        }

        await printer.print(context.wazuhEndpointParams.pathFilename);
        return response.ok({
          body: {
            success: true,
            message: `Report ${context.wazuhEndpointParams.filename} was created`
          }
        });
      } catch (error) {
        (0, _logger.log)('reporting:createReportsGroups', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
      }
    }, ({
      params: {
        groupID
      }
    }) => `wazuh-group-configuration-${groupID}-${this.generateReportTimestamp()}.pdf`));

    _defineProperty(this, "createReportsAgentsConfiguration", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        (0, _logger.log)('reporting:createReportsAgentsConfiguration', `Report started`, 'info');
        const {
          components,
          apiId
        } = request.body;
        const {
          agentID
        } = request.params;
        const printer = new _printer.ReportPrinter();
        (0, _filesystem.createDataDirectoryIfNotExists)();
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, context.wazuhEndpointParams.hashUsername));
        let wmodulesResponse = {};
        let tables = [];

        try {
          wmodulesResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents/${agentID}/config/wmodules/wmodules`, {}, {
            apiHostID: apiId
          });
        } catch (error) {
          (0, _logger.log)('reporting:report', error.message || error, 'debug');
        }

        await this.renderHeader(context, printer, 'agentConfig', 'agentConfig', agentID, apiId);
        let idxComponent = 0;

        for (let config of _agentConfiguration.AgentConfiguration.configurations) {
          let titleOfSection = false;
          (0, _logger.log)('reporting:createReportsAgentsConfiguration', `Iterate over ${config.sections.length} configuration sections`, 'debug');

          for (let section of config.sections) {
            let titleOfSubsection = false;

            if (components[idxComponent] && (section.config || section.wodle)) {
              let idx = 0;
              const configs = (section.config || []).concat(section.wodle || []);
              (0, _logger.log)('reporting:createReportsAgentsConfiguration', `Iterate over ${configs.length} configuration blocks`, 'debug');

              for (let conf of configs) {
                let agentConfigResponse = {};

                try {
                  if (!conf['name']) {
                    agentConfigResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents/${agentID}/config/${conf.component}/${conf.configuration}`, {}, {
                      apiHostID: apiId
                    });
                  } else {
                    for (let wodle of wmodulesResponse.data.data['wmodules']) {
                      if (Object.keys(wodle)[0] === conf['name']) {
                        agentConfigResponse.data = {
                          data: wodle
                        };
                      }
                    }
                  }

                  const agentConfig = agentConfigResponse && agentConfigResponse.data && agentConfigResponse.data.data;

                  if (!titleOfSection) {
                    printer.addContent({
                      text: config.title,
                      style: 'h1',
                      margin: [0, 0, 0, 15]
                    });
                    titleOfSection = true;
                  }

                  if (!titleOfSubsection) {
                    printer.addContent({
                      text: section.subtitle,
                      style: 'h4'
                    });
                    printer.addContent({
                      text: section.desc,
                      style: {
                        fontSize: 12,
                        color: '#000'
                      },
                      margin: [0, 0, 0, 10]
                    });
                    titleOfSubsection = true;
                  }

                  if (agentConfig) {
                    for (let agentConfigKey of Object.keys(agentConfig)) {
                      if (Array.isArray(agentConfig[agentConfigKey])) {
                        /* LOG COLLECTOR */
                        if (conf.filterBy) {
                          let groups = [];
                          agentConfig[agentConfigKey].forEach(obj => {
                            if (!groups[obj.logformat]) {
                              groups[obj.logformat] = [];
                            }

                            groups[obj.logformat].push(obj);
                          });
                          Object.keys(groups).forEach(group => {
                            let saveidx = 0;
                            groups[group].forEach((x, i) => {
                              if (Object.keys(x).length > Object.keys(groups[group][saveidx]).length) {
                                saveidx = i;
                              }
                            });
                            const columns = Object.keys(groups[group][saveidx]);
                            const rows = groups[group].map(x => {
                              let row = [];
                              columns.forEach(key => {
                                row.push(typeof x[key] !== 'object' ? x[key] : Array.isArray(x[key]) ? x[key].map(x => {
                                  return x + '\n';
                                }) : JSON.stringify(x[key]));
                              });
                              return row;
                            });
                            columns.forEach((col, i) => {
                              columns[i] = col[0].toUpperCase() + col.slice(1);
                            });
                            tables.push({
                              title: section.labels[0][group],
                              type: 'table',
                              columns,
                              rows
                            });
                          });
                        } else if (agentConfigKey.configuration !== 'socket') {
                          tables.push(...this.getConfigTables(agentConfig[agentConfigKey], section, idx));
                        } else {
                          for (let _d2 of agentConfig[agentConfigKey]) {
                            tables.push(...this.getConfigTables(_d2, section, idx));
                          }
                        }
                      } else {
                        /*INTEGRITY MONITORING MONITORED DIRECTORIES */
                        if (conf.matrix) {
                          const {
                            directories,
                            diff,
                            synchronization,
                            file_limit,
                            ...rest
                          } = agentConfig[agentConfigKey];
                          tables.push(...this.getConfigTables(rest, section, idx), ...(diff && diff.disk_quota ? this.getConfigTables(diff.disk_quota, {
                            tabs: ['Disk quota']
                          }, 0) : []), ...(diff && diff.file_size ? this.getConfigTables(diff.file_size, {
                            tabs: ['File size']
                          }, 0) : []), ...(synchronization ? this.getConfigTables(synchronization, {
                            tabs: ['Synchronization']
                          }, 0) : []), ...(file_limit ? this.getConfigTables(file_limit, {
                            tabs: ['File limit']
                          }, 0) : []));
                          let diffOpts = [];
                          Object.keys(section.opts).forEach(x => {
                            diffOpts.push(x);
                          });
                          const columns = ['', ...diffOpts.filter(x => x !== 'check_all' && x !== 'check_sum')];
                          let rows = [];
                          directories.forEach(x => {
                            let row = [];
                            row.push(x.dir);
                            columns.forEach(y => {
                              if (y !== '') {
                                row.push(x.opts.indexOf(y) > -1 ? 'yes' : 'no');
                              }
                            });
                            row.push(x.recursion_level);
                            rows.push(row);
                          });
                          columns.forEach((x, idx) => {
                            columns[idx] = section.opts[x];
                          });
                          columns.push('RL');
                          tables.push({
                            title: 'Monitored directories',
                            type: 'table',
                            columns,
                            rows
                          });
                        } else {
                          tables.push(...this.getConfigTables(agentConfig[agentConfigKey], section, idx));
                        }
                      }
                    }
                  } else {
                    // Print no configured module and link to the documentation
                    printer.addContent({
                      text: ['This module is not configured. Please take a look on how to configure it in ', {
                        text: `${section.subtitle.toLowerCase()} configuration.`,
                        link: section.docuLink,
                        style: {
                          fontSize: 12,
                          color: '#1a0dab'
                        }
                      }],
                      margin: [0, 0, 0, 20]
                    });
                  }
                } catch (error) {
                  (0, _logger.log)('reporting:report', error.message || error, 'debug');
                }

                idx++;
              }

              for (const table of tables) {
                printer.addConfigTables([table]);
              }
            }

            idxComponent++;
            tables = [];
          }
        }

        await printer.print(context.wazuhEndpointParams.pathFilename);
        return response.ok({
          body: {
            success: true,
            message: `Report ${context.wazuhEndpointParams.filename} was created`
          }
        });
      } catch (error) {
        (0, _logger.log)('reporting:createReportsAgentsConfiguration', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
      }
    }, ({
      params: {
        agentID
      }
    }) => `wazuh-agent-configuration-${agentID}-${this.generateReportTimestamp()}.pdf`));

    _defineProperty(this, "createReportsAgentsInventory", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        (0, _logger.log)('reporting:createReportsAgentsInventory', `Report started`, 'info');
        const {
          searchBar,
          filters,
          time,
          indexPatternTitle,
          apiId
        } = request.body;
        const {
          agentID
        } = request.params;
        const {
          from,
          to
        } = time || {}; // Init

        const printer = new _printer.ReportPrinter();
        const {
          hashUsername
        } = await context.wazuh.security.getCurrentUser(request, context);
        (0, _filesystem.createDataDirectoryIfNotExists)();
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, hashUsername));
        (0, _logger.log)('reporting:createReportsAgentsInventory', `Syscollector report`, 'debug');
        const sanitizedFilters = filters ? this.sanitizeKibanaFilters(filters, searchBar) : false; // Get the agent OS

        let agentOs = '';

        try {
          const agentResponse = await context.wazuh.api.client.asCurrentUser.request('GET', '/agents', {
            params: {
              q: `id=${agentID}`
            }
          }, {
            apiHostID: apiId
          });
          agentOs = agentResponse.data.data.affected_items[0].os.platform;
        } catch (error) {
          (0, _logger.log)('reporting:createReportsAgentsInventory', error.message || error, 'debug');
        } // Add title


        printer.addContentWithNewLine({
          text: 'Inventory data report',
          style: 'h1'
        }); // Add table with the agent info

        await this.buildAgentsTable(context, printer, [agentID], apiId); // Get syscollector packages and processes

        const agentRequestsInventory = [{
          endpoint: `/syscollector/${agentID}/packages`,
          loggerMessage: `Fetching packages for agent ${agentID}`,
          table: {
            title: 'Packages',
            columns: agentOs === 'windows' ? [{
              id: 'name',
              label: 'Name'
            }, {
              id: 'architecture',
              label: 'Architecture'
            }, {
              id: 'version',
              label: 'Version'
            }, {
              id: 'vendor',
              label: 'Vendor'
            }] : [{
              id: 'name',
              label: 'Name'
            }, {
              id: 'architecture',
              label: 'Architecture'
            }, {
              id: 'version',
              label: 'Version'
            }, {
              id: 'vendor',
              label: 'Vendor'
            }, {
              id: 'description',
              label: 'Description'
            }]
          }
        }, {
          endpoint: `/syscollector/${agentID}/processes`,
          loggerMessage: `Fetching processes for agent ${agentID}`,
          table: {
            title: 'Processes',
            columns: agentOs === 'windows' ? [{
              id: 'name',
              label: 'Name'
            }, {
              id: 'cmd',
              label: 'CMD'
            }, {
              id: 'priority',
              label: 'Priority'
            }, {
              id: 'nlwp',
              label: 'NLWP'
            }] : [{
              id: 'name',
              label: 'Name'
            }, {
              id: 'euser',
              label: 'Effective user'
            }, {
              id: 'nice',
              label: 'Priority'
            }, {
              id: 'state',
              label: 'State'
            }]
          },
          mapResponseItems: item => agentOs === 'windows' ? item : { ...item,
            state: _processStateEquivalence.default[item.state]
          }
        }, {
          endpoint: `/syscollector/${agentID}/ports`,
          loggerMessage: `Fetching ports for agent ${agentID}`,
          table: {
            title: 'Network ports',
            columns: agentOs === 'windows' ? [{
              id: 'local_ip',
              label: 'Local IP'
            }, {
              id: 'local_port',
              label: 'Local port'
            }, {
              id: 'process',
              label: 'Process'
            }, {
              id: 'state',
              label: 'State'
            }, {
              id: 'protocol',
              label: 'Protocol'
            }] : [{
              id: 'local_ip',
              label: 'Local IP'
            }, {
              id: 'local_port',
              label: 'Local port'
            }, {
              id: 'state',
              label: 'State'
            }, {
              id: 'protocol',
              label: 'Protocol'
            }]
          },
          mapResponseItems: item => ({ ...item,
            local_ip: item.local.ip,
            local_port: item.local.port
          })
        }, {
          endpoint: `/syscollector/${agentID}/netiface`,
          loggerMessage: `Fetching netiface for agent ${agentID}`,
          table: {
            title: 'Network interfaces',
            columns: [{
              id: 'name',
              label: 'Name'
            }, {
              id: 'mac',
              label: 'Mac'
            }, {
              id: 'state',
              label: 'State'
            }, {
              id: 'mtu',
              label: 'MTU'
            }, {
              id: 'type',
              label: 'Type'
            }]
          }
        }, {
          endpoint: `/syscollector/${agentID}/netaddr`,
          loggerMessage: `Fetching netaddr for agent ${agentID}`,
          table: {
            title: 'Network settings',
            columns: [{
              id: 'iface',
              label: 'Interface'
            }, {
              id: 'address',
              label: 'address'
            }, {
              id: 'netmask',
              label: 'Netmask'
            }, {
              id: 'proto',
              label: 'Protocol'
            }, {
              id: 'broadcast',
              label: 'Broadcast'
            }]
          }
        }];
        agentOs === 'windows' && agentRequestsInventory.push({
          endpoint: `/syscollector/${agentID}/hotfixes`,
          loggerMessage: `Fetching hotfixes for agent ${agentID}`,
          table: {
            title: 'Windows updates',
            columns: [{
              id: 'hotfix',
              label: 'Update code'
            }]
          }
        });

        const requestInventory = async agentRequestInventory => {
          try {
            (0, _logger.log)('reporting:createReportsAgentsInventory', agentRequestInventory.loggerMessage, 'debug');
            const inventoryResponse = await context.wazuh.api.client.asCurrentUser.request('GET', agentRequestInventory.endpoint, {}, {
              apiHostID: apiId
            });
            const inventory = inventoryResponse && inventoryResponse.data && inventoryResponse.data.data && inventoryResponse.data.data.affected_items;

            if (inventory) {
              return { ...agentRequestInventory.table,
                items: agentRequestInventory.mapResponseItems ? inventory.map(agentRequestInventory.mapResponseItems) : inventory
              };
            }
          } catch (error) {
            (0, _logger.log)('reporting:createReportsAgentsInventory', error.message || error, 'debug');
          }
        };

        if (time) {
          await this.extendedInformation(context, printer, 'agents', 'syscollector', apiId, from, to, sanitizedFilters + ' AND rule.groups: "vulnerability-detector"', indexPatternTitle, agentID);
        } // Add inventory tables


        (await Promise.all(agentRequestsInventory.map(requestInventory))).filter(table => table).forEach(table => printer.addSimpleTable(table)); // Print the document

        await printer.print(context.wazuhEndpointParams.pathFilename);
        return response.ok({
          body: {
            success: true,
            message: `Report ${context.wazuhEndpointParams.filename} was created`
          }
        });
      } catch (error) {
        (0, _logger.log)('reporting:createReportsAgents', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
      }
    }, ({
      params: {
        agentID
      }
    }) => `wazuh-agent-inventory-${agentID}-${this.generateReportTimestamp()}.pdf`));

    _defineProperty(this, "getReportByName", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        (0, _logger.log)('reporting:getReportByName', `Getting ${context.wazuhEndpointParams.pathFilename} report`, 'debug');

        const reportFileBuffer = _fs.default.readFileSync(context.wazuhEndpointParams.pathFilename);

        return response.ok({
          headers: {
            'Content-Type': 'application/pdf'
          },
          body: reportFileBuffer
        });
      } catch (error) {
        (0, _logger.log)('reporting:getReportByName', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5030, 500, response);
      }
    }, request => request.params.name));

    _defineProperty(this, "deleteReportByName", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        (0, _logger.log)('reporting:deleteReportByName', `Deleting ${context.wazuhEndpointParams.pathFilename} report`, 'debug');

        _fs.default.unlinkSync(context.wazuhEndpointParams.pathFilename);

        (0, _logger.log)('reporting:deleteReportByName', `${context.wazuhEndpointParams.pathFilename} report was deleted`, 'info');
        return response.ok({
          body: {
            error: 0
          }
        });
      } catch (error) {
        (0, _logger.log)('reporting:deleteReportByName', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5032, 500, response);
      }
    }, request => request.params.name));
  }
  /**
   * This do format to filters
   * @param {String} filters E.g: cluster.name: wazuh AND rule.groups: vulnerability
   * @param {String} searchBar search term
   */


  sanitizeKibanaFilters(filters, searchBar) {
    (0, _logger.log)('reporting:sanitizeKibanaFilters', `Started to sanitize filters`, 'info');
    (0, _logger.log)('reporting:sanitizeKibanaFilters', `filters: ${filters.length}, searchBar: ${searchBar}`, 'debug');
    let str = '';
    const agentsFilter = []; //separate agents filter

    filters = filters.filter(filter => {
      if (filter.meta.controlledBy === _constants.AUTHORIZED_AGENTS) {
        agentsFilter.push(filter);
        return false;
      }

      return filter;
    });
    const len = filters.length;

    for (let i = 0; i < len; i++) {
      const {
        negate,
        key,
        value,
        params,
        type
      } = filters[i].meta;
      str += `${negate ? 'NOT ' : ''}`;
      str += `${key}: `;
      str += `${type === 'range' ? `${params.gte}-${params.lt}` : type === 'phrases' ? '(' + params.join(" OR ") + ')' : type === 'exists' ? '*' : !!value ? value : (params || {}).query}`;
      str += `${i === len - 1 ? '' : ' AND '}`;
    }

    if (searchBar) {
      str += ` AND (${searchBar})`;
    }

    const agentsFilterStr = agentsFilter.map(filter => filter.meta.value).join(',');
    (0, _logger.log)('reporting:sanitizeKibanaFilters', `str: ${str}, agentsFilterStr: ${agentsFilterStr}`, 'debug');
    return [str, agentsFilterStr];
  }
  /**
   * This performs the rendering of given header
   * @param {String} printer section target
   * @param {String} section section target
   * @param {Object} tab tab target
   * @param {Boolean} isAgents is agents section
   * @param {String} apiId ID of API
   */


  async renderHeader(context, printer, section, tab, isAgents, apiId) {
    try {
      (0, _logger.log)('reporting:renderHeader', `section: ${section}, tab: ${tab}, isAgents: ${isAgents}, apiId: ${apiId}`, 'debug');

      if (section && typeof section === 'string') {
        if (!['agentConfig', 'groupConfig'].includes(section)) {
          printer.addContent({
            text: _wazuhModules.WAZUH_MODULES[tab].title + ' report',
            style: 'h1'
          });
        } else if (section === 'agentConfig') {
          printer.addContent({
            text: `Agent ${isAgents} configuration`,
            style: 'h1'
          });
        } else if (section === 'groupConfig') {
          printer.addContent({
            text: 'Agents in group',
            style: 'h1'
          });
        }

        printer.addNewLine();
      }

      if (isAgents && typeof isAgents === 'object') {
        await this.buildAgentsTable(context, printer, isAgents, apiId, section === 'groupConfig' ? tab : '');
      }

      if (isAgents && typeof isAgents === 'string') {
        const agentResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents`, {
          params: {
            agents_list: isAgents
          }
        }, {
          apiHostID: apiId
        });
        const agentData = agentResponse.data.data.affected_items[0];

        if (agentData && agentData.status !== _constants.API_NAME_AGENT_STATUS.ACTIVE) {
          printer.addContentWithNewLine({
            text: `Warning. Agent is ${(0, _wz_agent_status.agentStatusLabelByAgentStatus)(agentData.status).toLowerCase()}`,
            style: 'standard'
          });
        }

        await this.buildAgentsTable(context, printer, [isAgents], apiId);

        if (agentData && agentData.group) {
          const agentGroups = agentData.group.join(', ');
          printer.addContentWithNewLine({
            text: `Group${agentData.group.length > 1 ? 's' : ''}: ${agentGroups}`,
            style: 'standard'
          });
        }
      }

      if (_wazuhModules.WAZUH_MODULES[tab] && _wazuhModules.WAZUH_MODULES[tab].description) {
        printer.addContentWithNewLine({
          text: _wazuhModules.WAZUH_MODULES[tab].description,
          style: 'standard'
        });
      }
    } catch (error) {
      (0, _logger.log)('reporting:renderHeader', error.message || error);
      return Promise.reject(error);
    }
  }
  /**
   * This build the agents table
   * @param {Array<Strings>} ids ids of agents
   * @param {String} apiId API id
   */


  async buildAgentsTable(context, printer, agentIDs, apiId, groupID = '') {
    const dateFormat = await context.core.uiSettings.client.get('dateFormat');
    if ((!agentIDs || !agentIDs.length) && !groupID) return;
    (0, _logger.log)('reporting:buildAgentsTable', `${agentIDs.length} agents for API ${apiId}`, 'info');

    try {
      let agentsData = [];

      if (groupID) {
        let totalAgentsInGroup = null;

        do {
          const {
            data: {
              data: {
                affected_items,
                total_affected_items
              }
            }
          } = await context.wazuh.api.client.asCurrentUser.request('GET', `/groups/${groupID}/agents`, {
            params: {
              offset: agentsData.length,
              select: 'dateAdd,id,ip,lastKeepAlive,manager,name,os.name,os.version,version'
            }
          }, {
            apiHostID: apiId
          });
          !totalAgentsInGroup && (totalAgentsInGroup = total_affected_items);
          agentsData = [...agentsData, ...affected_items];
        } while (agentsData.length < totalAgentsInGroup);
      } else {
        for (const agentID of agentIDs) {
          try {
            const {
              data: {
                data: {
                  affected_items: [agent]
                }
              }
            } = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents`, {
              params: {
                q: `id=${agentID}`,
                select: 'dateAdd,id,ip,lastKeepAlive,manager,name,os.name,os.version,version'
              }
            }, {
              apiHostID: apiId
            });
            agentsData.push(agent);
          } catch (error) {
            (0, _logger.log)('reporting:buildAgentsTable', `Skip agent due to: ${error.message || error}`, 'debug');
          }
        }
      }

      if (agentsData.length) {
        // Print a table with agent/s information
        printer.addSimpleTable({
          columns: [{
            id: 'id',
            label: 'ID'
          }, {
            id: 'name',
            label: 'Name'
          }, {
            id: 'ip',
            label: 'IP'
          }, {
            id: 'version',
            label: 'Version'
          }, {
            id: 'manager',
            label: 'Manager'
          }, {
            id: 'os',
            label: 'OS'
          }, {
            id: 'dateAdd',
            label: 'Registration date'
          }, {
            id: 'lastKeepAlive',
            label: 'Last keep alive'
          }],
          items: agentsData.map(agent => {
            return { ...agent,
              os: agent.os && agent.os.name && agent.os.version ? `${agent.os.name} ${agent.os.version}` : '',
              lastKeepAlive: (0, _moment.default)(agent.lastKeepAlive).format(dateFormat),
              dateAdd: (0, _moment.default)(agent.dateAdd).format(dateFormat)
            };
          })
        });
      } else if (!agentsData.length && groupID) {
        // For group reports when there is no agents in the group
        printer.addContent({
          text: 'There are no agents in this group.',
          style: {
            fontSize: 12,
            color: '#000'
          }
        });
      }
    } catch (error) {
      (0, _logger.log)('reporting:buildAgentsTable', error.message || error);
      return Promise.reject(error);
    }
  }
  /**
   * This load more information
   * @param {*} context Endpoint context
   * @param {*} printer printer instance
   * @param {String} section section target
   * @param {Object} tab tab target
   * @param {String} apiId ID of API
   * @param {Number} from Timestamp (ms) from
   * @param {Number} to Timestamp (ms) to
   * @param {String} filters E.g: cluster.name: wazuh AND rule.groups: vulnerability
   * @param {String} pattern
   * @param {Object} agent agent target
   * @returns {Object} Extended information
   */


  async extendedInformation(context, printer, section, tab, apiId, from, to, filters, pattern = _constants.WAZUH_ALERTS_PATTERN, agent = null) {
    try {
      (0, _logger.log)('reporting:extendedInformation', `Section ${section} and tab ${tab}, API is ${apiId}. From ${from} to ${to}. Filters ${filters}. Index pattern ${pattern}`, 'info');

      if (section === 'agents' && !agent) {
        throw new Error('Reporting for specific agent needs an agent ID in order to work properly');
      }

      const agents = await context.wazuh.api.client.asCurrentUser.request('GET', '/agents', {
        params: {
          limit: 1
        }
      }, {
        apiHostID: apiId
      });
      const totalAgents = agents.data.data.total_affected_items;

      if (section === 'overview' && tab === 'vuls') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching overview vulnerability detector metrics', 'debug');
        const vulnerabilitiesLevels = ['Low', 'Medium', 'High', 'Critical'];
        const vulnerabilitiesResponsesCount = (await Promise.all(vulnerabilitiesLevels.map(async vulnerabilitiesLevel => {
          try {
            const count = await VulnerabilityRequest.uniqueSeverityCount(context, from, to, vulnerabilitiesLevel, filters, pattern);
            return count ? `${count} of ${totalAgents} agents have ${vulnerabilitiesLevel.toLocaleLowerCase()} vulnerabilities.` : undefined;
          } catch (error) {}
        }))).filter(vulnerabilitiesResponse => vulnerabilitiesResponse);
        printer.addList({
          title: {
            text: 'Summary',
            style: 'h2'
          },
          list: vulnerabilitiesResponsesCount
        });
        (0, _logger.log)('reporting:extendedInformation', 'Fetching overview vulnerability detector top 3 agents by category', 'debug');
        const lowRank = await VulnerabilityRequest.topAgentCount(context, from, to, 'Low', filters, pattern);
        const mediumRank = await VulnerabilityRequest.topAgentCount(context, from, to, 'Medium', filters, pattern);
        const highRank = await VulnerabilityRequest.topAgentCount(context, from, to, 'High', filters, pattern);
        const criticalRank = await VulnerabilityRequest.topAgentCount(context, from, to, 'Critical', filters, pattern);
        (0, _logger.log)('reporting:extendedInformation', 'Adding overview vulnerability detector top 3 agents by category', 'debug');

        if (criticalRank && criticalRank.length) {
          printer.addContentWithNewLine({
            text: 'Top 3 agents with critical severity vulnerabilities',
            style: 'h3'
          });
          await this.buildAgentsTable(context, printer, criticalRank, apiId);
          printer.addNewLine();
        }

        if (highRank && highRank.length) {
          printer.addContentWithNewLine({
            text: 'Top 3 agents with high severity vulnerabilities',
            style: 'h3'
          });
          await this.buildAgentsTable(context, printer, highRank, apiId);
          printer.addNewLine();
        }

        if (mediumRank && mediumRank.length) {
          printer.addContentWithNewLine({
            text: 'Top 3 agents with medium severity vulnerabilities',
            style: 'h3'
          });
          await this.buildAgentsTable(context, printer, mediumRank, apiId);
          printer.addNewLine();
        }

        if (lowRank && lowRank.length) {
          printer.addContentWithNewLine({
            text: 'Top 3 agents with low severity vulnerabilities',
            style: 'h3'
          });
          await this.buildAgentsTable(context, printer, lowRank, apiId);
          printer.addNewLine();
        }

        (0, _logger.log)('reporting:extendedInformation', 'Fetching overview vulnerability detector top 3 CVEs', 'debug');
        const cveRank = await VulnerabilityRequest.topCVECount(context, from, to, filters, pattern);
        (0, _logger.log)('reporting:extendedInformation', 'Adding overview vulnerability detector top 3 CVEs', 'debug');

        if (cveRank && cveRank.length) {
          printer.addSimpleTable({
            title: {
              text: 'Top 3 CVE',
              style: 'h2'
            },
            columns: [{
              id: 'top',
              label: 'Top'
            }, {
              id: 'cve',
              label: 'CVE'
            }],
            items: cveRank.map(item => ({
              top: cveRank.indexOf(item) + 1,
              cve: item
            }))
          });
        }
      }

      if (section === 'overview' && tab === 'general') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching top 3 agents with level 15 alerts', 'debug');
        const level15Rank = await OverviewRequest.topLevel15(context, from, to, filters, pattern);
        (0, _logger.log)('reporting:extendedInformation', 'Adding top 3 agents with level 15 alerts', 'debug');

        if (level15Rank.length) {
          printer.addContent({
            text: 'Top 3 agents with level 15 alerts',
            style: 'h2'
          });
          await this.buildAgentsTable(context, printer, level15Rank, apiId);
        }
      }

      if (section === 'overview' && tab === 'pm') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching most common rootkits', 'debug');
        const top5RootkitsRank = await RootcheckRequest.top5RootkitsDetected(context, from, to, filters, pattern);
        (0, _logger.log)('reporting:extendedInformation', 'Adding most common rootkits', 'debug');

        if (top5RootkitsRank && top5RootkitsRank.length) {
          printer.addContentWithNewLine({
            text: 'Most common rootkits found among your agents',
            style: 'h2'
          }).addContentWithNewLine({
            text: 'Rootkits are a set of software tools that enable an unauthorized user to gain control of a computer system without being detected.',
            style: 'standard'
          }).addSimpleTable({
            items: top5RootkitsRank.map(item => {
              return {
                top: top5RootkitsRank.indexOf(item) + 1,
                name: item
              };
            }),
            columns: [{
              id: 'top',
              label: 'Top'
            }, {
              id: 'name',
              label: 'Rootkit'
            }]
          });
        }

        (0, _logger.log)('reporting:extendedInformation', 'Fetching hidden pids', 'debug');
        const hiddenPids = await RootcheckRequest.agentsWithHiddenPids(context, from, to, filters, pattern);
        hiddenPids && printer.addContent({
          text: `${hiddenPids} of ${totalAgents} agents have hidden processes`,
          style: 'h3'
        });
        !hiddenPids && printer.addContentWithNewLine({
          text: `No agents have hidden processes`,
          style: 'h3'
        });
        const hiddenPorts = await RootcheckRequest.agentsWithHiddenPorts(context, from, to, filters, pattern);
        hiddenPorts && printer.addContent({
          text: `${hiddenPorts} of ${totalAgents} agents have hidden ports`,
          style: 'h3'
        });
        !hiddenPorts && printer.addContent({
          text: `No agents have hidden ports`,
          style: 'h3'
        });
        printer.addNewLine();
      }

      if (['overview', 'agents'].includes(section) && tab === 'pci') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching top PCI DSS requirements', 'debug');
        const topPciRequirements = await PCIRequest.topPCIRequirements(context, from, to, filters, pattern);
        printer.addContentWithNewLine({
          text: 'Most common PCI DSS requirements alerts found',
          style: 'h2'
        });

        for (const item of topPciRequirements) {
          const rules = await PCIRequest.getRulesByRequirement(context, from, to, filters, item, pattern);
          printer.addContentWithNewLine({
            text: `Requirement ${item}`,
            style: 'h3'
          });

          if (_pciRequirementsPdfmake.default[item]) {
            const content = typeof _pciRequirementsPdfmake.default[item] === 'string' ? {
              text: _pciRequirementsPdfmake.default[item],
              style: 'standard'
            } : _pciRequirementsPdfmake.default[item];
            printer.addContentWithNewLine(content);
          }

          rules && rules.length && printer.addSimpleTable({
            columns: [{
              id: 'ruleID',
              label: 'Rule ID'
            }, {
              id: 'ruleDescription',
              label: 'Description'
            }],
            items: rules,
            title: `Top rules for ${item} requirement`
          });
        }
      }

      if (['overview', 'agents'].includes(section) && tab === 'tsc') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching top TSC requirements', 'debug');
        const topTSCRequirements = await TSCRequest.topTSCRequirements(context, from, to, filters, pattern);
        printer.addContentWithNewLine({
          text: 'Most common TSC requirements alerts found',
          style: 'h2'
        });

        for (const item of topTSCRequirements) {
          const rules = await TSCRequest.getRulesByRequirement(context, from, to, filters, item, pattern);
          printer.addContentWithNewLine({
            text: `Requirement ${item}`,
            style: 'h3'
          });

          if (_tscRequirementsPdfmake.default[item]) {
            const content = typeof _tscRequirementsPdfmake.default[item] === 'string' ? {
              text: _tscRequirementsPdfmake.default[item],
              style: 'standard'
            } : _tscRequirementsPdfmake.default[item];
            printer.addContentWithNewLine(content);
          }

          rules && rules.length && printer.addSimpleTable({
            columns: [{
              id: 'ruleID',
              label: 'Rule ID'
            }, {
              id: 'ruleDescription',
              label: 'Description'
            }],
            items: rules,
            title: `Top rules for ${item} requirement`
          });
        }
      }

      if (['overview', 'agents'].includes(section) && tab === 'gdpr') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching top GDPR requirements', 'debug');
        const topGdprRequirements = await GDPRRequest.topGDPRRequirements(context, from, to, filters, pattern);
        printer.addContentWithNewLine({
          text: 'Most common GDPR requirements alerts found',
          style: 'h2'
        });

        for (const item of topGdprRequirements) {
          const rules = await GDPRRequest.getRulesByRequirement(context, from, to, filters, item, pattern);
          printer.addContentWithNewLine({
            text: `Requirement ${item}`,
            style: 'h3'
          });

          if (_gdprRequirementsPdfmake.default && _gdprRequirementsPdfmake.default[item]) {
            const content = typeof _gdprRequirementsPdfmake.default[item] === 'string' ? {
              text: _gdprRequirementsPdfmake.default[item],
              style: 'standard'
            } : _gdprRequirementsPdfmake.default[item];
            printer.addContentWithNewLine(content);
          }

          rules && rules.length && printer.addSimpleTable({
            columns: [{
              id: 'ruleID',
              label: 'Rule ID'
            }, {
              id: 'ruleDescription',
              label: 'Description'
            }],
            items: rules,
            title: `Top rules for ${item} requirement`
          });
        }

        printer.addNewLine();
      }

      if (section === 'overview' && tab === 'audit') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching agents with high number of failed sudo commands', 'debug');
        const auditAgentsNonSuccess = await AuditRequest.getTop3AgentsSudoNonSuccessful(context, from, to, filters, pattern);

        if (auditAgentsNonSuccess && auditAgentsNonSuccess.length) {
          printer.addContent({
            text: 'Agents with high number of failed sudo commands',
            style: 'h2'
          });
          await this.buildAgentsTable(context, printer, auditAgentsNonSuccess, apiId);
        }

        const auditAgentsFailedSyscall = await AuditRequest.getTop3AgentsFailedSyscalls(context, from, to, filters, pattern);

        if (auditAgentsFailedSyscall && auditAgentsFailedSyscall.length) {
          printer.addSimpleTable({
            columns: [{
              id: 'agent',
              label: 'Agent ID'
            }, {
              id: 'syscall_id',
              label: 'Syscall ID'
            }, {
              id: 'syscall_syscall',
              label: 'Syscall'
            }],
            items: auditAgentsFailedSyscall.map(item => ({
              agent: item.agent,
              syscall_id: item.syscall.id,
              syscall_syscall: item.syscall.syscall
            })),
            title: {
              text: 'Most common failing syscalls',
              style: 'h2'
            }
          });
        }
      }

      if (section === 'overview' && tab === 'fim') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching top 3 rules for FIM', 'debug');
        const rules = await SyscheckRequest.top3Rules(context, from, to, filters, pattern);

        if (rules && rules.length) {
          printer.addContentWithNewLine({
            text: 'Top 3 FIM rules',
            style: 'h2'
          }).addSimpleTable({
            columns: [{
              id: 'ruleID',
              label: 'Rule ID'
            }, {
              id: 'ruleDescription',
              label: 'Description'
            }],
            items: rules,
            title: {
              text: 'Top 3 rules that are generating most alerts.',
              style: 'standard'
            }
          });
        }

        (0, _logger.log)('reporting:extendedInformation', 'Fetching top 3 agents for FIM', 'debug');
        const agents = await SyscheckRequest.top3agents(context, from, to, filters, pattern);

        if (agents && agents.length) {
          printer.addContentWithNewLine({
            text: 'Agents with suspicious FIM activity',
            style: 'h2'
          });
          printer.addContentWithNewLine({
            text: 'Top 3 agents that have most FIM alerts from level 7 to level 15. Take care about them.',
            style: 'standard'
          });
          await this.buildAgentsTable(context, printer, agents, apiId);
        }
      }

      if (section === 'agents' && tab === 'audit') {
        (0, _logger.log)('reporting:extendedInformation', `Fetching most common failed syscalls`, 'debug');
        const auditFailedSyscall = await AuditRequest.getTopFailedSyscalls(context, from, to, filters, pattern);
        auditFailedSyscall && auditFailedSyscall.length && printer.addSimpleTable({
          columns: [{
            id: 'id',
            label: 'id'
          }, {
            id: 'syscall',
            label: 'Syscall'
          }],
          items: auditFailedSyscall,
          title: 'Most common failing syscalls'
        });
      }

      if (section === 'agents' && tab === 'fim') {
        (0, _logger.log)('reporting:extendedInformation', `Fetching syscheck database for agent ${agent}`, 'debug');
        const lastScanResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/syscheck/${agent}/last_scan`, {}, {
          apiHostID: apiId
        });

        if (lastScanResponse && lastScanResponse.data) {
          const lastScanData = lastScanResponse.data.data.affected_items[0];

          if (lastScanData.start && lastScanData.end) {
            printer.addContent({
              text: `Last file integrity monitoring scan was executed from ${lastScanData.start} to ${lastScanData.end}.`
            });
          } else if (lastScanData.start) {
            printer.addContent({
              text: `File integrity monitoring scan is currently in progress for this agent (started on ${lastScanData.start}).`
            });
          } else {
            printer.addContent({
              text: `File integrity monitoring scan is currently in progress for this agent.`
            });
          }

          printer.addNewLine();
        }

        (0, _logger.log)('reporting:extendedInformation', `Fetching last 10 deleted files for FIM`, 'debug');
        const lastTenDeleted = await SyscheckRequest.lastTenDeletedFiles(context, from, to, filters, pattern);
        lastTenDeleted && lastTenDeleted.length && printer.addSimpleTable({
          columns: [{
            id: 'path',
            label: 'Path'
          }, {
            id: 'date',
            label: 'Date'
          }],
          items: lastTenDeleted,
          title: 'Last 10 deleted files'
        });
        (0, _logger.log)('reporting:extendedInformation', `Fetching last 10 modified files`, 'debug');
        const lastTenModified = await SyscheckRequest.lastTenModifiedFiles(context, from, to, filters, pattern);
        lastTenModified && lastTenModified.length && printer.addSimpleTable({
          columns: [{
            id: 'path',
            label: 'Path'
          }, {
            id: 'date',
            label: 'Date'
          }],
          items: lastTenModified,
          title: 'Last 10 modified files'
        });
      }

      if (section === 'agents' && tab === 'syscollector') {
        (0, _logger.log)('reporting:extendedInformation', `Fetching hardware information for agent ${agent}`, 'debug');
        const requestsSyscollectorLists = [{
          endpoint: `/syscollector/${agent}/hardware`,
          loggerMessage: `Fetching Hardware information for agent ${agent}`,
          list: {
            title: {
              text: 'Hardware information',
              style: 'h2'
            }
          },
          mapResponse: hardware => [hardware.cpu && hardware.cpu.cores && `${hardware.cpu.cores} cores`, hardware.cpu && hardware.cpu.name, hardware.ram && hardware.ram.total && `${Number(hardware.ram.total / 1024 / 1024).toFixed(2)}GB RAM`]
        }, {
          endpoint: `/syscollector/${agent}/os`,
          loggerMessage: `Fetching OS information for agent ${agent}`,
          list: {
            title: {
              text: 'OS information',
              style: 'h2'
            }
          },
          mapResponse: osData => [osData.sysname, osData.version, osData.architecture, osData.release, osData.os && osData.os.name && osData.os.version && `${osData.os.name} ${osData.os.version}`]
        }];
        const syscollectorLists = await Promise.all(requestsSyscollectorLists.map(async requestSyscollector => {
          try {
            (0, _logger.log)('reporting:extendedInformation', requestSyscollector.loggerMessage, 'debug');
            const responseSyscollector = await context.wazuh.api.client.asCurrentUser.request('GET', requestSyscollector.endpoint, {}, {
              apiHostID: apiId
            });
            const [data] = responseSyscollector && responseSyscollector.data && responseSyscollector.data.data && responseSyscollector.data.data.affected_items || [];

            if (data) {
              return { ...requestSyscollector.list,
                list: requestSyscollector.mapResponse(data)
              };
            }
          } catch (error) {
            (0, _logger.log)('reporting:extendedInformation', error.message || error);
          }
        }));

        if (syscollectorLists) {
          syscollectorLists.filter(syscollectorList => syscollectorList).forEach(syscollectorList => printer.addList(syscollectorList));
        }

        const vulnerabilitiesRequests = ['Critical', 'High'];
        const vulnerabilitiesResponsesItems = (await Promise.all(vulnerabilitiesRequests.map(async vulnerabilitiesLevel => {
          try {
            (0, _logger.log)('reporting:extendedInformation', `Fetching top ${vulnerabilitiesLevel} packages`, 'debug');
            return await VulnerabilityRequest.topPackages(context, from, to, vulnerabilitiesLevel, filters, pattern);
          } catch (error) {
            (0, _logger.log)('reporting:extendedInformation', error.message || error);
          }
        }))).filter(vulnerabilitiesResponse => vulnerabilitiesResponse).flat();

        if (vulnerabilitiesResponsesItems && vulnerabilitiesResponsesItems.length) {
          printer.addSimpleTable({
            title: {
              text: 'Vulnerable packages found (last 24 hours)',
              style: 'h2'
            },
            columns: [{
              id: 'package',
              label: 'Package'
            }, {
              id: 'severity',
              label: 'Severity'
            }],
            items: vulnerabilitiesResponsesItems
          });
        }
      }

      if (section === 'agents' && tab === 'vuls') {
        const topCriticalPackages = await VulnerabilityRequest.topPackagesWithCVE(context, from, to, 'Critical', filters, pattern);

        if (topCriticalPackages && topCriticalPackages.length) {
          printer.addContentWithNewLine({
            text: 'Critical severity',
            style: 'h2'
          });
          printer.addContentWithNewLine({
            text: 'These vulnerabilties are critical, please review your agent. Click on each link to read more about each found vulnerability.',
            style: 'standard'
          });
          const customul = [];

          for (const critical of topCriticalPackages) {
            customul.push({
              text: critical.package,
              style: 'standard'
            });
            customul.push({
              ul: critical.references.map(item => ({
                text: item.substring(0, 80) + '...',
                link: item,
                color: '#1EA5C8'
              }))
            });
          }

          printer.addContentWithNewLine({
            ul: customul
          });
        }

        const topHighPackages = await VulnerabilityRequest.topPackagesWithCVE(context, from, to, 'High', filters, pattern);

        if (topHighPackages && topHighPackages.length) {
          printer.addContentWithNewLine({
            text: 'High severity',
            style: 'h2'
          });
          printer.addContentWithNewLine({
            text: 'Click on each link to read more about each found vulnerability.',
            style: 'standard'
          });
          const customul = [];

          for (const critical of topHighPackages) {
            customul.push({
              text: critical.package,
              style: 'standard'
            });
            customul.push({
              ul: critical.references.map(item => ({
                text: item,
                color: '#1EA5C8'
              }))
            });
          }

          customul && customul.length && printer.addContent({
            ul: customul
          });
          printer.addNewLine();
        }
      }

      return false;
    } catch (error) {
      (0, _logger.log)('reporting:extendedInformation', error.message || error);
      return Promise.reject(error);
    }
  }

  getConfigRows(data, labels) {
    (0, _logger.log)('reporting:getConfigRows', `Building configuration rows`, 'info');
    const result = [];

    for (let prop in data || []) {
      if (Array.isArray(data[prop])) {
        data[prop].forEach((x, idx) => {
          if (typeof x === 'object') data[prop][idx] = JSON.stringify(x);
        });
      }

      result.push([(labels || {})[prop] || _csvKeyEquivalence.KeyEquivalence[prop] || prop, data[prop] || '-']);
    }

    return result;
  }

  getConfigTables(data, section, tab, array = []) {
    (0, _logger.log)('reporting:getConfigTables', `Building configuration tables`, 'info');
    let plainData = {};
    const nestedData = [];
    const tableData = [];

    if (data.length === 1 && Array.isArray(data)) {
      tableData[section.config[tab].configuration] = data;
    } else {
      for (let key in data) {
        if (typeof data[key] !== 'object' && !Array.isArray(data[key]) || Array.isArray(data[key]) && typeof data[key][0] !== 'object') {
          plainData[key] = Array.isArray(data[key]) && typeof data[key][0] !== 'object' ? data[key].map(x => {
            return typeof x === 'object' ? JSON.stringify(x) : x + '\n';
          }) : data[key];
        } else if (Array.isArray(data[key]) && typeof data[key][0] === 'object') {
          tableData[key] = data[key];
        } else {
          if (section.isGroupConfig && ['pack', 'content'].includes(key)) {
            tableData[key] = [data[key]];
          } else {
            nestedData.push(data[key]);
          }
        }
      }
    }

    array.push({
      title: (section.options || {}).hideHeader ? '' : (section.tabs || [])[tab] || (section.isGroupConfig ? ((section.labels || [])[0] || [])[tab] : ''),
      columns: ['', ''],
      type: 'config',
      rows: this.getConfigRows(plainData, (section.labels || [])[0])
    });

    for (let key in tableData) {
      const columns = Object.keys(tableData[key][0]);
      columns.forEach((col, i) => {
        columns[i] = col[0].toUpperCase() + col.slice(1);
      });
      const rows = tableData[key].map(x => {
        let row = [];

        for (let key in x) {
          row.push(typeof x[key] !== 'object' ? x[key] : Array.isArray(x[key]) ? x[key].map(x => {
            return x + '\n';
          }) : JSON.stringify(x[key]));
        }

        while (row.length < columns.length) {
          row.push('-');
        }

        return row;
      });
      array.push({
        title: ((section.labels || [])[0] || [])[key] || '',
        type: 'table',
        columns,
        rows
      });
    }

    nestedData.forEach(nest => {
      this.getConfigTables(nest, section, tab + 1, array);
    });
    return array;
  }
  /**
   * Create a report for the modules
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {*} reports list or ErrorResponse
   */


  /**
   * Fetch the reports list
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Array<Object>} reports list or ErrorResponse
   */
  async getReports(context, request, response) {
    try {
      (0, _logger.log)('reporting:getReports', `Fetching created reports`, 'info');
      const {
        hashUsername
      } = await context.wazuh.security.getCurrentUser(request, context);
      (0, _filesystem.createDataDirectoryIfNotExists)();
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);

      const userReportsDirectoryPath = _path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, hashUsername);

      (0, _filesystem.createDirectoryIfNotExists)(userReportsDirectoryPath);
      (0, _logger.log)('reporting:getReports', `Directory: ${userReportsDirectoryPath}`, 'debug');

      const sortReportsByDate = (a, b) => a.date < b.date ? 1 : a.date > b.date ? -1 : 0;

      const reports = _fs.default.readdirSync(userReportsDirectoryPath).map(file => {
        const stats = _fs.default.statSync(userReportsDirectoryPath + '/' + file); // Get the file creation time (bithtime). It returns the first value that is a truthy value of next file stats: birthtime, mtime, ctime and atime.
        // This solves some OSs can have the bithtimeMs equal to 0 and returns the date like 1970-01-01


        const birthTimeField = ['birthtime', 'mtime', 'ctime', 'atime'].find(time => stats[`${time}Ms`]);
        return {
          name: file,
          size: stats.size,
          date: stats[birthTimeField]
        };
      });

      (0, _logger.log)('reporting:getReports', `Using TimSort for sorting ${reports.length} items`, 'debug');
      TimSort.sort(reports, sortReportsByDate);
      (0, _logger.log)('reporting:getReports', `Total reports: ${reports.length}`, 'debug');
      return response.ok({
        body: {
          reports
        }
      });
    } catch (error) {
      (0, _logger.log)('reporting:getReports', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 5031, 500, response);
    }
  }
  /**
   * Fetch specific report
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} report or ErrorResponse
   */


  checkReportsUserDirectoryIsValidRouteDecorator(routeHandler, reportFileNameAccessor) {
    return async (context, request, response) => {
      try {
        const {
          username,
          hashUsername
        } = await context.wazuh.security.getCurrentUser(request, context);

        const userReportsDirectoryPath = _path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, hashUsername);

        const filename = reportFileNameAccessor(request);

        const pathFilename = _path.default.join(userReportsDirectoryPath, filename);

        (0, _logger.log)('reporting:checkReportsUserDirectoryIsValidRouteDecorator', `Checking the user ${username}(${hashUsername}) can do actions in the reports file: ${pathFilename}`, 'debug');

        if (!pathFilename.startsWith(userReportsDirectoryPath) || pathFilename.includes('../')) {
          (0, _logger.log)('security:reporting:checkReportsUserDirectoryIsValidRouteDecorator', `User ${username}(${hashUsername}) tried to access to a non user report file: ${pathFilename}`, 'warn');
          return response.badRequest({
            body: {
              message: '5040 - You shall not pass!'
            }
          });
        }

        ;
        (0, _logger.log)('reporting:checkReportsUserDirectoryIsValidRouteDecorator', 'Checking the user can do actions in the reports file', 'debug');
        return await routeHandler.bind(this)({ ...context,
          wazuhEndpointParams: {
            hashUsername,
            filename,
            pathFilename
          }
        }, request, response);
      } catch (error) {
        (0, _logger.log)('reporting:checkReportsUserDirectoryIsValidRouteDecorator', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5040, 500, response);
      }
    };
  }

  generateReportTimestamp() {
    return `${Date.now() / 1000 | 0}`;
  }

}

exports.WazuhReportingCtrl = WazuhReportingCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhenVoLXJlcG9ydGluZy50cyJdLCJuYW1lcyI6WyJXYXp1aFJlcG9ydGluZ0N0cmwiLCJjb25zdHJ1Y3RvciIsImNoZWNrUmVwb3J0c1VzZXJEaXJlY3RvcnlJc1ZhbGlkUm91dGVEZWNvcmF0b3IiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwiYXJyYXkiLCJhZ2VudHMiLCJicm93c2VyVGltZXpvbmUiLCJzZWFyY2hCYXIiLCJmaWx0ZXJzIiwidGltZSIsInRhYmxlcyIsInNlY3Rpb24iLCJpbmRleFBhdHRlcm5UaXRsZSIsImFwaUlkIiwiYm9keSIsIm1vZHVsZUlEIiwicGFyYW1zIiwiZnJvbSIsInRvIiwicHJpbnRlciIsIlJlcG9ydFByaW50ZXIiLCJXQVpVSF9EQVRBX0RPV05MT0FEU19ESVJFQ1RPUllfUEFUSCIsIldBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgiLCJwYXRoIiwiam9pbiIsIndhenVoRW5kcG9pbnRQYXJhbXMiLCJoYXNoVXNlcm5hbWUiLCJyZW5kZXJIZWFkZXIiLCJzYW5pdGl6ZWRGaWx0ZXJzIiwiYWdlbnRzRmlsdGVyIiwic2FuaXRpemVLaWJhbmFGaWx0ZXJzIiwiYWRkVGltZVJhbmdlQW5kRmlsdGVycyIsImV4dGVuZGVkSW5mb3JtYXRpb24iLCJEYXRlIiwiZ2V0VGltZSIsImFkZFZpc3VhbGl6YXRpb25zIiwiYWRkVGFibGVzIiwiYWRkQWdlbnRzRmlsdGVycyIsInByaW50IiwicGF0aEZpbGVuYW1lIiwib2siLCJzdWNjZXNzIiwibWVzc2FnZSIsImZpbGVuYW1lIiwiZXJyb3IiLCJnZW5lcmF0ZVJlcG9ydFRpbWVzdGFtcCIsImNvbXBvbmVudHMiLCJncm91cElEIiwiZXF1aXZhbGVuY2VzIiwibG9jYWxmaWxlIiwib3NxdWVyeSIsImNvbW1hbmQiLCJzeXNjaGVjayIsInN5c2NvbGxlY3RvciIsInJvb3RjaGVjayIsImxhYmVscyIsInNjYSIsImFkZENvbnRlbnQiLCJ0ZXh0Iiwic3R5bGUiLCJkYXRhIiwiY29uZmlndXJhdGlvbiIsIndhenVoIiwiYXBpIiwiY2xpZW50IiwiYXNDdXJyZW50VXNlciIsImFwaUhvc3RJRCIsImFmZmVjdGVkX2l0ZW1zIiwibGVuZ3RoIiwiT2JqZWN0Iiwia2V5cyIsImNvbmZpZyIsImZvbnRTaXplIiwiY29sb3IiLCJtYXJnaW4iLCJpc0dyb3VwQ29uZmlnIiwiZmlsdGVyVGl0bGUiLCJpbmRleCIsImZpbHRlciIsImNvbmNhdCIsImlkeCIsInRhYnMiLCJfZCIsImMiLCJBZ2VudENvbmZpZ3VyYXRpb24iLCJjb25maWd1cmF0aW9ucyIsInMiLCJzZWN0aW9ucyIsIm9wdHMiLCJjbiIsIndvIiwid29kbGUiLCJuYW1lIiwicHVzaCIsIkFycmF5IiwiaXNBcnJheSIsImdyb3VwcyIsImZvckVhY2giLCJvYmoiLCJsb2dmb3JtYXQiLCJncm91cCIsInNhdmVpZHgiLCJ4IiwiaSIsImNvbHVtbnMiLCJyb3dzIiwibWFwIiwicm93Iiwia2V5IiwiSlNPTiIsInN0cmluZ2lmeSIsImNvbCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJ0aXRsZSIsInR5cGUiLCJsYWJlbCIsImluY2x1ZGVzIiwiX2QyIiwiZ2V0Q29uZmlnVGFibGVzIiwiZGlyZWN0b3JpZXMiLCJkaWZmT3B0cyIsInkiLCJyZWN1cnNpb25fbGV2ZWwiLCJ0YWJsZSIsImFkZENvbmZpZ1RhYmxlcyIsImFnZW50SUQiLCJ3bW9kdWxlc1Jlc3BvbnNlIiwiaWR4Q29tcG9uZW50IiwidGl0bGVPZlNlY3Rpb24iLCJ0aXRsZU9mU3Vic2VjdGlvbiIsImNvbmZpZ3MiLCJjb25mIiwiYWdlbnRDb25maWdSZXNwb25zZSIsImNvbXBvbmVudCIsImFnZW50Q29uZmlnIiwic3VidGl0bGUiLCJkZXNjIiwiYWdlbnRDb25maWdLZXkiLCJmaWx0ZXJCeSIsIm1hdHJpeCIsImRpZmYiLCJzeW5jaHJvbml6YXRpb24iLCJmaWxlX2xpbWl0IiwicmVzdCIsImRpc2tfcXVvdGEiLCJmaWxlX3NpemUiLCJkaXIiLCJpbmRleE9mIiwidG9Mb3dlckNhc2UiLCJsaW5rIiwiZG9jdUxpbmsiLCJzZWN1cml0eSIsImdldEN1cnJlbnRVc2VyIiwiYWdlbnRPcyIsImFnZW50UmVzcG9uc2UiLCJxIiwib3MiLCJwbGF0Zm9ybSIsImFkZENvbnRlbnRXaXRoTmV3TGluZSIsImJ1aWxkQWdlbnRzVGFibGUiLCJhZ2VudFJlcXVlc3RzSW52ZW50b3J5IiwiZW5kcG9pbnQiLCJsb2dnZXJNZXNzYWdlIiwiaWQiLCJtYXBSZXNwb25zZUl0ZW1zIiwiaXRlbSIsInN0YXRlIiwiUHJvY2Vzc0VxdWl2YWxlbmNlIiwibG9jYWxfaXAiLCJsb2NhbCIsImlwIiwibG9jYWxfcG9ydCIsInBvcnQiLCJyZXF1ZXN0SW52ZW50b3J5IiwiYWdlbnRSZXF1ZXN0SW52ZW50b3J5IiwiaW52ZW50b3J5UmVzcG9uc2UiLCJpbnZlbnRvcnkiLCJpdGVtcyIsIlByb21pc2UiLCJhbGwiLCJhZGRTaW1wbGVUYWJsZSIsInJlcG9ydEZpbGVCdWZmZXIiLCJmcyIsInJlYWRGaWxlU3luYyIsImhlYWRlcnMiLCJ1bmxpbmtTeW5jIiwic3RyIiwibWV0YSIsImNvbnRyb2xsZWRCeSIsIkFVVEhPUklaRURfQUdFTlRTIiwibGVuIiwibmVnYXRlIiwidmFsdWUiLCJndGUiLCJsdCIsInF1ZXJ5IiwiYWdlbnRzRmlsdGVyU3RyIiwidGFiIiwiaXNBZ2VudHMiLCJXQVpVSF9NT0RVTEVTIiwiYWRkTmV3TGluZSIsImFnZW50c19saXN0IiwiYWdlbnREYXRhIiwic3RhdHVzIiwiQVBJX05BTUVfQUdFTlRfU1RBVFVTIiwiQUNUSVZFIiwiYWdlbnRHcm91cHMiLCJkZXNjcmlwdGlvbiIsInJlamVjdCIsImFnZW50SURzIiwiZGF0ZUZvcm1hdCIsImNvcmUiLCJ1aVNldHRpbmdzIiwiZ2V0IiwiYWdlbnRzRGF0YSIsInRvdGFsQWdlbnRzSW5Hcm91cCIsInRvdGFsX2FmZmVjdGVkX2l0ZW1zIiwib2Zmc2V0Iiwic2VsZWN0IiwiYWdlbnQiLCJ2ZXJzaW9uIiwibGFzdEtlZXBBbGl2ZSIsImZvcm1hdCIsImRhdGVBZGQiLCJwYXR0ZXJuIiwiV0FaVUhfQUxFUlRTX1BBVFRFUk4iLCJFcnJvciIsImxpbWl0IiwidG90YWxBZ2VudHMiLCJ2dWxuZXJhYmlsaXRpZXNMZXZlbHMiLCJ2dWxuZXJhYmlsaXRpZXNSZXNwb25zZXNDb3VudCIsInZ1bG5lcmFiaWxpdGllc0xldmVsIiwiY291bnQiLCJWdWxuZXJhYmlsaXR5UmVxdWVzdCIsInVuaXF1ZVNldmVyaXR5Q291bnQiLCJ0b0xvY2FsZUxvd2VyQ2FzZSIsInVuZGVmaW5lZCIsInZ1bG5lcmFiaWxpdGllc1Jlc3BvbnNlIiwiYWRkTGlzdCIsImxpc3QiLCJsb3dSYW5rIiwidG9wQWdlbnRDb3VudCIsIm1lZGl1bVJhbmsiLCJoaWdoUmFuayIsImNyaXRpY2FsUmFuayIsImN2ZVJhbmsiLCJ0b3BDVkVDb3VudCIsInRvcCIsImN2ZSIsImxldmVsMTVSYW5rIiwiT3ZlcnZpZXdSZXF1ZXN0IiwidG9wTGV2ZWwxNSIsInRvcDVSb290a2l0c1JhbmsiLCJSb290Y2hlY2tSZXF1ZXN0IiwidG9wNVJvb3RraXRzRGV0ZWN0ZWQiLCJoaWRkZW5QaWRzIiwiYWdlbnRzV2l0aEhpZGRlblBpZHMiLCJoaWRkZW5Qb3J0cyIsImFnZW50c1dpdGhIaWRkZW5Qb3J0cyIsInRvcFBjaVJlcXVpcmVtZW50cyIsIlBDSVJlcXVlc3QiLCJ0b3BQQ0lSZXF1aXJlbWVudHMiLCJydWxlcyIsImdldFJ1bGVzQnlSZXF1aXJlbWVudCIsIlBDSSIsImNvbnRlbnQiLCJ0b3BUU0NSZXF1aXJlbWVudHMiLCJUU0NSZXF1ZXN0IiwiVFNDIiwidG9wR2RwclJlcXVpcmVtZW50cyIsIkdEUFJSZXF1ZXN0IiwidG9wR0RQUlJlcXVpcmVtZW50cyIsIkdEUFIiLCJhdWRpdEFnZW50c05vblN1Y2Nlc3MiLCJBdWRpdFJlcXVlc3QiLCJnZXRUb3AzQWdlbnRzU3Vkb05vblN1Y2Nlc3NmdWwiLCJhdWRpdEFnZW50c0ZhaWxlZFN5c2NhbGwiLCJnZXRUb3AzQWdlbnRzRmFpbGVkU3lzY2FsbHMiLCJzeXNjYWxsX2lkIiwic3lzY2FsbCIsInN5c2NhbGxfc3lzY2FsbCIsIlN5c2NoZWNrUmVxdWVzdCIsInRvcDNSdWxlcyIsInRvcDNhZ2VudHMiLCJhdWRpdEZhaWxlZFN5c2NhbGwiLCJnZXRUb3BGYWlsZWRTeXNjYWxscyIsImxhc3RTY2FuUmVzcG9uc2UiLCJsYXN0U2NhbkRhdGEiLCJzdGFydCIsImVuZCIsImxhc3RUZW5EZWxldGVkIiwibGFzdFRlbkRlbGV0ZWRGaWxlcyIsImxhc3RUZW5Nb2RpZmllZCIsImxhc3RUZW5Nb2RpZmllZEZpbGVzIiwicmVxdWVzdHNTeXNjb2xsZWN0b3JMaXN0cyIsIm1hcFJlc3BvbnNlIiwiaGFyZHdhcmUiLCJjcHUiLCJjb3JlcyIsInJhbSIsInRvdGFsIiwiTnVtYmVyIiwidG9GaXhlZCIsIm9zRGF0YSIsInN5c25hbWUiLCJhcmNoaXRlY3R1cmUiLCJyZWxlYXNlIiwic3lzY29sbGVjdG9yTGlzdHMiLCJyZXF1ZXN0U3lzY29sbGVjdG9yIiwicmVzcG9uc2VTeXNjb2xsZWN0b3IiLCJzeXNjb2xsZWN0b3JMaXN0IiwidnVsbmVyYWJpbGl0aWVzUmVxdWVzdHMiLCJ2dWxuZXJhYmlsaXRpZXNSZXNwb25zZXNJdGVtcyIsInRvcFBhY2thZ2VzIiwiZmxhdCIsInRvcENyaXRpY2FsUGFja2FnZXMiLCJ0b3BQYWNrYWdlc1dpdGhDVkUiLCJjdXN0b211bCIsImNyaXRpY2FsIiwicGFja2FnZSIsInVsIiwicmVmZXJlbmNlcyIsInN1YnN0cmluZyIsInRvcEhpZ2hQYWNrYWdlcyIsImdldENvbmZpZ1Jvd3MiLCJyZXN1bHQiLCJwcm9wIiwiS2V5RXF1aXZhbGVuY2UiLCJwbGFpbkRhdGEiLCJuZXN0ZWREYXRhIiwidGFibGVEYXRhIiwib3B0aW9ucyIsImhpZGVIZWFkZXIiLCJuZXN0IiwiZ2V0UmVwb3J0cyIsInVzZXJSZXBvcnRzRGlyZWN0b3J5UGF0aCIsInNvcnRSZXBvcnRzQnlEYXRlIiwiYSIsImIiLCJkYXRlIiwicmVwb3J0cyIsInJlYWRkaXJTeW5jIiwiZmlsZSIsInN0YXRzIiwic3RhdFN5bmMiLCJiaXJ0aFRpbWVGaWVsZCIsImZpbmQiLCJzaXplIiwiVGltU29ydCIsInNvcnQiLCJyb3V0ZUhhbmRsZXIiLCJyZXBvcnRGaWxlTmFtZUFjY2Vzc29yIiwidXNlcm5hbWUiLCJzdGFydHNXaXRoIiwiYmFkUmVxdWVzdCIsImJpbmQiLCJub3ciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFXQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFFQTs7QUFDQTs7QUFDQTs7QUFPQTs7QUFDQTs7QUFDQTs7Ozs7Ozs7OztBQUVPLE1BQU1BLGtCQUFOLENBQXlCO0FBQzlCQyxFQUFBQSxXQUFXLEdBQUc7QUFBQSxrREF5akNTLEtBQUtDLDhDQUFMLENBQW9ELE9BQ3pFQyxPQUR5RSxFQUV6RUMsT0FGeUUsRUFHekVDLFFBSHlFLEtBSXRFO0FBQ0gsVUFBSTtBQUNGLHlCQUFJLGdDQUFKLEVBQXVDLGdCQUF2QyxFQUF3RCxNQUF4RDtBQUNBLGNBQU07QUFDSkMsVUFBQUEsS0FESTtBQUVKQyxVQUFBQSxNQUZJO0FBR0pDLFVBQUFBLGVBSEk7QUFJSkMsVUFBQUEsU0FKSTtBQUtKQyxVQUFBQSxPQUxJO0FBTUpDLFVBQUFBLElBTkk7QUFPSkMsVUFBQUEsTUFQSTtBQVFKQyxVQUFBQSxPQVJJO0FBU0pDLFVBQUFBLGlCQVRJO0FBVUpDLFVBQUFBO0FBVkksWUFXRlgsT0FBTyxDQUFDWSxJQVhaO0FBWUEsY0FBTTtBQUFFQyxVQUFBQTtBQUFGLFlBQWViLE9BQU8sQ0FBQ2MsTUFBN0I7QUFDQSxjQUFNO0FBQUVDLFVBQUFBLElBQUY7QUFBUUMsVUFBQUE7QUFBUixZQUFlVCxJQUFJLElBQUksRUFBN0IsQ0FmRSxDQWdCRjs7QUFDQSxjQUFNVSxPQUFPLEdBQUcsSUFBSUMsc0JBQUosRUFBaEI7QUFFQTtBQUNBLG9EQUEyQkMsOENBQTNCO0FBQ0Esb0RBQTJCQyxzREFBM0I7QUFDQSxvREFBMkJDLGNBQUtDLElBQUwsQ0FBVUYsc0RBQVYsRUFBdURyQixPQUFPLENBQUN3QixtQkFBUixDQUE0QkMsWUFBbkYsQ0FBM0I7QUFFQSxjQUFNLEtBQUtDLFlBQUwsQ0FBa0IxQixPQUFsQixFQUEyQmtCLE9BQTNCLEVBQW9DUixPQUFwQyxFQUE2Q0ksUUFBN0MsRUFBdURWLE1BQXZELEVBQStEUSxLQUEvRCxDQUFOO0FBRUEsY0FBTSxDQUFDZSxnQkFBRCxFQUFtQkMsWUFBbkIsSUFBbUNyQixPQUFPLEdBQzVDLEtBQUtzQixxQkFBTCxDQUEyQnRCLE9BQTNCLEVBQW9DRCxTQUFwQyxDQUQ0QyxHQUU1QyxDQUFDLEtBQUQsRUFBUSxLQUFSLENBRko7O0FBSUEsWUFBSUUsSUFBSSxJQUFJbUIsZ0JBQVosRUFBOEI7QUFDNUJULFVBQUFBLE9BQU8sQ0FBQ1ksc0JBQVIsQ0FBK0JkLElBQS9CLEVBQXFDQyxFQUFyQyxFQUF5Q1UsZ0JBQXpDLEVBQTJEdEIsZUFBM0Q7QUFDRDs7QUFFRCxZQUFJRyxJQUFKLEVBQVU7QUFDUixnQkFBTSxLQUFLdUIsbUJBQUwsQ0FDSi9CLE9BREksRUFFSmtCLE9BRkksRUFHSlIsT0FISSxFQUlKSSxRQUpJLEVBS0pGLEtBTEksRUFNSixJQUFJb0IsSUFBSixDQUFTaEIsSUFBVCxFQUFlaUIsT0FBZixFQU5JLEVBT0osSUFBSUQsSUFBSixDQUFTZixFQUFULEVBQWFnQixPQUFiLEVBUEksRUFRSk4sZ0JBUkksRUFTSmhCLGlCQVRJLEVBVUpQLE1BVkksQ0FBTjtBQVlEOztBQUVEYyxRQUFBQSxPQUFPLENBQUNnQixpQkFBUixDQUEwQi9CLEtBQTFCLEVBQWlDQyxNQUFqQyxFQUF5Q1UsUUFBekM7O0FBRUEsWUFBSUwsTUFBSixFQUFZO0FBQ1ZTLFVBQUFBLE9BQU8sQ0FBQ2lCLFNBQVIsQ0FBa0IxQixNQUFsQjtBQUNELFNBckRDLENBdURGOzs7QUFDQSxZQUFJbUIsWUFBSixFQUFrQjtBQUNoQlYsVUFBQUEsT0FBTyxDQUFDa0IsZ0JBQVIsQ0FBeUJSLFlBQXpCO0FBQ0Q7O0FBRUQsY0FBTVYsT0FBTyxDQUFDbUIsS0FBUixDQUFjckMsT0FBTyxDQUFDd0IsbUJBQVIsQ0FBNEJjLFlBQTFDLENBQU47QUFFQSxlQUFPcEMsUUFBUSxDQUFDcUMsRUFBVCxDQUFZO0FBQ2pCMUIsVUFBQUEsSUFBSSxFQUFFO0FBQ0oyQixZQUFBQSxPQUFPLEVBQUUsSUFETDtBQUVKQyxZQUFBQSxPQUFPLEVBQUcsVUFBU3pDLE9BQU8sQ0FBQ3dCLG1CQUFSLENBQTRCa0IsUUFBUztBQUZwRDtBQURXLFNBQVosQ0FBUDtBQU1ELE9BcEVELENBb0VFLE9BQU9DLEtBQVAsRUFBYztBQUNkLGVBQU8sa0NBQWNBLEtBQUssQ0FBQ0YsT0FBTixJQUFpQkUsS0FBL0IsRUFBc0MsSUFBdEMsRUFBNEMsR0FBNUMsRUFBaUR6QyxRQUFqRCxDQUFQO0FBQ0Q7QUFDRixLQTVFc0IsRUE0RXJCLENBQUM7QUFBQ1csTUFBQUEsSUFBSSxFQUFDO0FBQUVULFFBQUFBO0FBQUYsT0FBTjtBQUFrQlcsTUFBQUEsTUFBTSxFQUFFO0FBQUVELFFBQUFBO0FBQUY7QUFBMUIsS0FBRCxLQUE4QyxnQkFBZVYsTUFBTSxHQUFJLFVBQVNBLE1BQU8sRUFBcEIsR0FBd0IsVUFBVyxJQUFHVSxRQUFTLElBQUcsS0FBSzhCLHVCQUFMLEVBQStCLE1BNUUvSCxDQXpqQ1Q7O0FBQUEsaURBOG9DUSxLQUFLN0MsOENBQUwsQ0FBb0QsT0FDeEVDLE9BRHdFLEVBRXhFQyxPQUZ3RSxFQUd4RUMsUUFId0UsS0FJckU7QUFDSCxVQUFJO0FBQ0YseUJBQUksK0JBQUosRUFBc0MsZ0JBQXRDLEVBQXVELE1BQXZEO0FBQ0EsY0FBTTtBQUFFMkMsVUFBQUEsVUFBRjtBQUFjakMsVUFBQUE7QUFBZCxZQUF3QlgsT0FBTyxDQUFDWSxJQUF0QztBQUNBLGNBQU07QUFBRWlDLFVBQUFBO0FBQUYsWUFBYzdDLE9BQU8sQ0FBQ2MsTUFBNUIsQ0FIRSxDQUlGOztBQUNBLGNBQU1HLE9BQU8sR0FBRyxJQUFJQyxzQkFBSixFQUFoQjtBQUVBO0FBQ0Esb0RBQTJCQyw4Q0FBM0I7QUFDQSxvREFBMkJDLHNEQUEzQjtBQUNBLG9EQUEyQkMsY0FBS0MsSUFBTCxDQUFVRixzREFBVixFQUF1RHJCLE9BQU8sQ0FBQ3dCLG1CQUFSLENBQTRCQyxZQUFuRixDQUEzQjtBQUVBLFlBQUloQixNQUFNLEdBQUcsRUFBYjtBQUNBLGNBQU1zQyxZQUFZLEdBQUc7QUFDbkJDLFVBQUFBLFNBQVMsRUFBRSxhQURRO0FBRW5CQyxVQUFBQSxPQUFPLEVBQUUsU0FGVTtBQUduQkMsVUFBQUEsT0FBTyxFQUFFLFNBSFU7QUFJbkJDLFVBQUFBLFFBQVEsRUFBRSxVQUpTO0FBS25CLHVCQUFhLFVBTE07QUFNbkIscUJBQVcsU0FOUTtBQU9uQkMsVUFBQUEsWUFBWSxFQUFFLGNBUEs7QUFRbkJDLFVBQUFBLFNBQVMsRUFBRSxXQVJRO0FBU25CQyxVQUFBQSxNQUFNLEVBQUUsUUFUVztBQVVuQkMsVUFBQUEsR0FBRyxFQUFFO0FBVmMsU0FBckI7QUFZQXJDLFFBQUFBLE9BQU8sQ0FBQ3NDLFVBQVIsQ0FBbUI7QUFDakJDLFVBQUFBLElBQUksRUFBRyxTQUFRWCxPQUFRLGdCQUROO0FBRWpCWSxVQUFBQSxLQUFLLEVBQUU7QUFGVSxTQUFuQixFQXpCRSxDQThCRjs7QUFDQSxZQUFJYixVQUFVLENBQUMsR0FBRCxDQUFkLEVBQXFCO0FBRW5CLGdCQUFNO0FBQUVjLFlBQUFBLElBQUksRUFBRTtBQUFFQSxjQUFBQSxJQUFJLEVBQUVDO0FBQVI7QUFBUixjQUFvQyxNQUFNNUQsT0FBTyxDQUFDNkQsS0FBUixDQUFjQyxHQUFkLENBQWtCQyxNQUFsQixDQUF5QkMsYUFBekIsQ0FBdUMvRCxPQUF2QyxDQUM5QyxLQUQ4QyxFQUU3QyxXQUFVNkMsT0FBUSxnQkFGMkIsRUFHOUMsRUFIOEMsRUFJOUM7QUFBRW1CLFlBQUFBLFNBQVMsRUFBRXJEO0FBQWIsV0FKOEMsQ0FBaEQ7O0FBT0EsY0FDRWdELGFBQWEsQ0FBQ00sY0FBZCxDQUE2QkMsTUFBN0IsR0FBc0MsQ0FBdEMsSUFDQUMsTUFBTSxDQUFDQyxJQUFQLENBQVlULGFBQWEsQ0FBQ00sY0FBZCxDQUE2QixDQUE3QixFQUFnQ0ksTUFBNUMsRUFBb0RILE1BRnRELEVBR0U7QUFDQWpELFlBQUFBLE9BQU8sQ0FBQ3NDLFVBQVIsQ0FBbUI7QUFDakJDLGNBQUFBLElBQUksRUFBRSxnQkFEVztBQUVqQkMsY0FBQUEsS0FBSyxFQUFFO0FBQUVhLGdCQUFBQSxRQUFRLEVBQUUsRUFBWjtBQUFnQkMsZ0JBQUFBLEtBQUssRUFBRTtBQUF2QixlQUZVO0FBR2pCQyxjQUFBQSxNQUFNLEVBQUUsQ0FBQyxDQUFELEVBQUksRUFBSixFQUFRLENBQVIsRUFBVyxFQUFYO0FBSFMsYUFBbkI7QUFLQSxrQkFBTS9ELE9BQU8sR0FBRztBQUNkNEMsY0FBQUEsTUFBTSxFQUFFLEVBRE07QUFFZG9CLGNBQUFBLGFBQWEsRUFBRTtBQUZELGFBQWhCOztBQUlBLGlCQUFLLElBQUlKLE1BQVQsSUFBbUJWLGFBQWEsQ0FBQ00sY0FBakMsRUFBaUQ7QUFDL0Msa0JBQUlTLFdBQVcsR0FBRyxFQUFsQjtBQUNBLGtCQUFJQyxLQUFLLEdBQUcsQ0FBWjs7QUFDQSxtQkFBSyxJQUFJQyxNQUFULElBQW1CVCxNQUFNLENBQUNDLElBQVAsQ0FBWUMsTUFBTSxDQUFDL0QsT0FBbkIsQ0FBbkIsRUFBZ0Q7QUFDOUNvRSxnQkFBQUEsV0FBVyxHQUFHQSxXQUFXLENBQUNHLE1BQVosQ0FBb0IsR0FBRUQsTUFBTyxLQUFJUCxNQUFNLENBQUMvRCxPQUFQLENBQWVzRSxNQUFmLENBQXVCLEVBQXhELENBQWQ7O0FBQ0Esb0JBQUlELEtBQUssR0FBR1IsTUFBTSxDQUFDQyxJQUFQLENBQVlDLE1BQU0sQ0FBQy9ELE9BQW5CLEVBQTRCNEQsTUFBNUIsR0FBcUMsQ0FBakQsRUFBb0Q7QUFDbERRLGtCQUFBQSxXQUFXLEdBQUdBLFdBQVcsQ0FBQ0csTUFBWixDQUFtQixLQUFuQixDQUFkO0FBQ0Q7O0FBQ0RGLGdCQUFBQSxLQUFLO0FBQ047O0FBQ0QxRCxjQUFBQSxPQUFPLENBQUNzQyxVQUFSLENBQW1CO0FBQ2pCQyxnQkFBQUEsSUFBSSxFQUFFa0IsV0FEVztBQUVqQmpCLGdCQUFBQSxLQUFLLEVBQUUsSUFGVTtBQUdqQmUsZ0JBQUFBLE1BQU0sRUFBRSxDQUFDLENBQUQsRUFBSSxDQUFKLEVBQU8sQ0FBUCxFQUFVLEVBQVY7QUFIUyxlQUFuQjtBQUtBLGtCQUFJTSxHQUFHLEdBQUcsQ0FBVjtBQUNBckUsY0FBQUEsT0FBTyxDQUFDc0UsSUFBUixHQUFlLEVBQWY7O0FBQ0EsbUJBQUssSUFBSUMsRUFBVCxJQUFlYixNQUFNLENBQUNDLElBQVAsQ0FBWUMsTUFBTSxDQUFDQSxNQUFuQixDQUFmLEVBQTJDO0FBQ3pDLHFCQUFLLElBQUlZLENBQVQsSUFBY0MsdUNBQW1CQyxjQUFqQyxFQUFpRDtBQUMvQyx1QkFBSyxJQUFJQyxDQUFULElBQWNILENBQUMsQ0FBQ0ksUUFBaEIsRUFBMEI7QUFDeEI1RSxvQkFBQUEsT0FBTyxDQUFDNkUsSUFBUixHQUFlRixDQUFDLENBQUNFLElBQUYsSUFBVSxFQUF6Qjs7QUFDQSx5QkFBSyxJQUFJQyxFQUFULElBQWVILENBQUMsQ0FBQ2YsTUFBRixJQUFZLEVBQTNCLEVBQStCO0FBQzdCLDBCQUFJa0IsRUFBRSxDQUFDNUIsYUFBSCxLQUFxQnFCLEVBQXpCLEVBQTZCO0FBQzNCdkUsd0JBQUFBLE9BQU8sQ0FBQzRDLE1BQVIsR0FBaUIrQixDQUFDLENBQUMvQixNQUFGLElBQVksQ0FBQyxFQUFELENBQTdCO0FBQ0Q7QUFDRjs7QUFDRCx5QkFBSyxJQUFJbUMsRUFBVCxJQUFlSixDQUFDLENBQUNLLEtBQUYsSUFBVyxFQUExQixFQUE4QjtBQUM1QiwwQkFBSUQsRUFBRSxDQUFDRSxJQUFILEtBQVlWLEVBQWhCLEVBQW9CO0FBQ2xCdkUsd0JBQUFBLE9BQU8sQ0FBQzRDLE1BQVIsR0FBaUIrQixDQUFDLENBQUMvQixNQUFGLElBQVksQ0FBQyxFQUFELENBQTdCO0FBQ0Q7QUFDRjtBQUNGO0FBQ0Y7O0FBQ0Q1QyxnQkFBQUEsT0FBTyxDQUFDNEMsTUFBUixDQUFlLENBQWYsRUFBa0IsTUFBbEIsSUFBNEIsT0FBNUI7QUFDQTVDLGdCQUFBQSxPQUFPLENBQUM0QyxNQUFSLENBQWUsQ0FBZixFQUFrQixTQUFsQixJQUErQixhQUEvQjtBQUNBNUMsZ0JBQUFBLE9BQU8sQ0FBQzRDLE1BQVIsQ0FBZSxDQUFmLEVBQWtCLEdBQWxCLElBQXlCLDhCQUF6QjtBQUNBNUMsZ0JBQUFBLE9BQU8sQ0FBQ3NFLElBQVIsQ0FBYVksSUFBYixDQUFrQjdDLFlBQVksQ0FBQ2tDLEVBQUQsQ0FBOUI7O0FBRUEsb0JBQUlZLEtBQUssQ0FBQ0MsT0FBTixDQUFjeEIsTUFBTSxDQUFDQSxNQUFQLENBQWNXLEVBQWQsQ0FBZCxDQUFKLEVBQXNDO0FBQ3BDO0FBQ0Esc0JBQUlBLEVBQUUsS0FBSyxXQUFYLEVBQXdCO0FBQ3RCLHdCQUFJYyxNQUFNLEdBQUcsRUFBYjs7QUFDQXpCLG9CQUFBQSxNQUFNLENBQUNBLE1BQVAsQ0FBY1csRUFBZCxFQUFrQmUsT0FBbEIsQ0FBMkJDLEdBQUQsSUFBUztBQUNqQywwQkFBSSxDQUFDRixNQUFNLENBQUNFLEdBQUcsQ0FBQ0MsU0FBTCxDQUFYLEVBQTRCO0FBQzFCSCx3QkFBQUEsTUFBTSxDQUFDRSxHQUFHLENBQUNDLFNBQUwsQ0FBTixHQUF3QixFQUF4QjtBQUNEOztBQUNESCxzQkFBQUEsTUFBTSxDQUFDRSxHQUFHLENBQUNDLFNBQUwsQ0FBTixDQUFzQk4sSUFBdEIsQ0FBMkJLLEdBQTNCO0FBQ0QscUJBTEQ7O0FBTUE3QixvQkFBQUEsTUFBTSxDQUFDQyxJQUFQLENBQVkwQixNQUFaLEVBQW9CQyxPQUFwQixDQUE2QkcsS0FBRCxJQUFXO0FBQ3JDLDBCQUFJQyxPQUFPLEdBQUcsQ0FBZDtBQUNBTCxzQkFBQUEsTUFBTSxDQUFDSSxLQUFELENBQU4sQ0FBY0gsT0FBZCxDQUFzQixDQUFDSyxDQUFELEVBQUlDLENBQUosS0FBVTtBQUM5Qiw0QkFBSWxDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZZ0MsQ0FBWixFQUFlbEMsTUFBZixHQUF3QkMsTUFBTSxDQUFDQyxJQUFQLENBQVkwQixNQUFNLENBQUNJLEtBQUQsQ0FBTixDQUFjQyxPQUFkLENBQVosRUFBb0NqQyxNQUFoRSxFQUF3RTtBQUN0RWlDLDBCQUFBQSxPQUFPLEdBQUdFLENBQVY7QUFDRDtBQUNGLHVCQUpEO0FBS0EsNEJBQU1DLE9BQU8sR0FBR25DLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZMEIsTUFBTSxDQUFDSSxLQUFELENBQU4sQ0FBY0MsT0FBZCxDQUFaLENBQWhCO0FBQ0EsNEJBQU1JLElBQUksR0FBR1QsTUFBTSxDQUFDSSxLQUFELENBQU4sQ0FBY00sR0FBZCxDQUFtQkosQ0FBRCxJQUFPO0FBQ3BDLDRCQUFJSyxHQUFHLEdBQUcsRUFBVjtBQUNBSCx3QkFBQUEsT0FBTyxDQUFDUCxPQUFSLENBQWlCVyxHQUFELElBQVM7QUFDdkJELDBCQUFBQSxHQUFHLENBQUNkLElBQUosQ0FDRSxPQUFPUyxDQUFDLENBQUNNLEdBQUQsQ0FBUixLQUFrQixRQUFsQixHQUNJTixDQUFDLENBQUNNLEdBQUQsQ0FETCxHQUVJZCxLQUFLLENBQUNDLE9BQU4sQ0FBY08sQ0FBQyxDQUFDTSxHQUFELENBQWYsSUFDQU4sQ0FBQyxDQUFDTSxHQUFELENBQUQsQ0FBT0YsR0FBUCxDQUFZSixDQUFELElBQU87QUFDaEIsbUNBQU9BLENBQUMsR0FBRyxJQUFYO0FBQ0QsMkJBRkQsQ0FEQSxHQUlBTyxJQUFJLENBQUNDLFNBQUwsQ0FBZVIsQ0FBQyxDQUFDTSxHQUFELENBQWhCLENBUE47QUFTRCx5QkFWRDtBQVdBLCtCQUFPRCxHQUFQO0FBQ0QsdUJBZFksQ0FBYjtBQWVBSCxzQkFBQUEsT0FBTyxDQUFDUCxPQUFSLENBQWdCLENBQUNjLEdBQUQsRUFBTVIsQ0FBTixLQUFZO0FBQzFCQyx3QkFBQUEsT0FBTyxDQUFDRCxDQUFELENBQVAsR0FBYVEsR0FBRyxDQUFDLENBQUQsQ0FBSCxDQUFPQyxXQUFQLEtBQXVCRCxHQUFHLENBQUNFLEtBQUosQ0FBVSxDQUFWLENBQXBDO0FBQ0QsdUJBRkQ7QUFHQXZHLHNCQUFBQSxNQUFNLENBQUNtRixJQUFQLENBQVk7QUFDVnFCLHdCQUFBQSxLQUFLLEVBQUUsYUFERztBQUVWQyx3QkFBQUEsSUFBSSxFQUFFLE9BRkk7QUFHVlgsd0JBQUFBLE9BSFU7QUFJVkMsd0JBQUFBO0FBSlUsdUJBQVo7QUFNRCxxQkFoQ0Q7QUFpQ0QsbUJBekNELE1BeUNPLElBQUl2QixFQUFFLEtBQUssUUFBWCxFQUFxQjtBQUMxQiwwQkFBTWdCLEdBQUcsR0FBRzNCLE1BQU0sQ0FBQ0EsTUFBUCxDQUFjVyxFQUFkLEVBQWtCLENBQWxCLEVBQXFCa0MsS0FBakM7QUFDQSwwQkFBTVosT0FBTyxHQUFHbkMsTUFBTSxDQUFDQyxJQUFQLENBQVk0QixHQUFHLENBQUMsQ0FBRCxDQUFmLENBQWhCOztBQUNBLHdCQUFJLENBQUNNLE9BQU8sQ0FBQ2EsUUFBUixDQUFpQixRQUFqQixDQUFMLEVBQWlDO0FBQy9CYixzQkFBQUEsT0FBTyxDQUFDWCxJQUFSLENBQWEsUUFBYjtBQUNEOztBQUNELDBCQUFNWSxJQUFJLEdBQUdQLEdBQUcsQ0FBQ1EsR0FBSixDQUFTSixDQUFELElBQU87QUFDMUIsMEJBQUlLLEdBQUcsR0FBRyxFQUFWO0FBQ0FILHNCQUFBQSxPQUFPLENBQUNQLE9BQVIsQ0FBaUJXLEdBQUQsSUFBUztBQUN2QkQsd0JBQUFBLEdBQUcsQ0FBQ2QsSUFBSixDQUFTUyxDQUFDLENBQUNNLEdBQUQsQ0FBVjtBQUNELHVCQUZEO0FBR0EsNkJBQU9ELEdBQVA7QUFDRCxxQkFOWSxDQUFiO0FBT0FILG9CQUFBQSxPQUFPLENBQUNQLE9BQVIsQ0FBZ0IsQ0FBQ2MsR0FBRCxFQUFNUixDQUFOLEtBQVk7QUFDMUJDLHNCQUFBQSxPQUFPLENBQUNELENBQUQsQ0FBUCxHQUFhUSxHQUFHLENBQUMsQ0FBRCxDQUFILENBQU9DLFdBQVAsS0FBdUJELEdBQUcsQ0FBQ0UsS0FBSixDQUFVLENBQVYsQ0FBcEM7QUFDRCxxQkFGRDtBQUdBdkcsb0JBQUFBLE1BQU0sQ0FBQ21GLElBQVAsQ0FBWTtBQUNWcUIsc0JBQUFBLEtBQUssRUFBRSxRQURHO0FBRVZDLHNCQUFBQSxJQUFJLEVBQUUsT0FGSTtBQUdWWCxzQkFBQUEsT0FIVTtBQUlWQyxzQkFBQUE7QUFKVSxxQkFBWjtBQU1ELG1CQXRCTSxNQXNCQTtBQUNMLHlCQUFLLElBQUlhLEdBQVQsSUFBZ0IvQyxNQUFNLENBQUNBLE1BQVAsQ0FBY1csRUFBZCxDQUFoQixFQUFtQztBQUNqQ3hFLHNCQUFBQSxNQUFNLENBQUNtRixJQUFQLENBQVksR0FBRyxLQUFLMEIsZUFBTCxDQUFxQkQsR0FBckIsRUFBMEIzRyxPQUExQixFQUFtQ3FFLEdBQW5DLENBQWY7QUFDRDtBQUNGO0FBQ0YsaUJBdEVELE1Bc0VPO0FBQ0w7QUFDQSxzQkFBSVQsTUFBTSxDQUFDQSxNQUFQLENBQWNXLEVBQWQsRUFBa0JzQyxXQUF0QixFQUFtQztBQUNqQywwQkFBTUEsV0FBVyxHQUFHakQsTUFBTSxDQUFDQSxNQUFQLENBQWNXLEVBQWQsRUFBa0JzQyxXQUF0QztBQUNBLDJCQUFPakQsTUFBTSxDQUFDQSxNQUFQLENBQWNXLEVBQWQsRUFBa0JzQyxXQUF6QjtBQUNBOUcsb0JBQUFBLE1BQU0sQ0FBQ21GLElBQVAsQ0FBWSxHQUFHLEtBQUswQixlQUFMLENBQXFCaEQsTUFBTSxDQUFDQSxNQUFQLENBQWNXLEVBQWQsQ0FBckIsRUFBd0N2RSxPQUF4QyxFQUFpRHFFLEdBQWpELENBQWY7QUFDQSx3QkFBSXlDLFFBQVEsR0FBRyxFQUFmO0FBQ0FwRCxvQkFBQUEsTUFBTSxDQUFDQyxJQUFQLENBQVkzRCxPQUFPLENBQUM2RSxJQUFwQixFQUEwQlMsT0FBMUIsQ0FBbUNLLENBQUQsSUFBTztBQUN2Q21CLHNCQUFBQSxRQUFRLENBQUM1QixJQUFULENBQWNTLENBQWQ7QUFDRCxxQkFGRDtBQUdBLDBCQUFNRSxPQUFPLEdBQUcsQ0FDZCxFQURjLEVBRWQsR0FBR2lCLFFBQVEsQ0FBQzNDLE1BQVQsQ0FBaUJ3QixDQUFELElBQU9BLENBQUMsS0FBSyxXQUFOLElBQXFCQSxDQUFDLEtBQUssV0FBbEQsQ0FGVyxDQUFoQjtBQUlBLHdCQUFJRyxJQUFJLEdBQUcsRUFBWDtBQUNBZSxvQkFBQUEsV0FBVyxDQUFDdkIsT0FBWixDQUFxQkssQ0FBRCxJQUFPO0FBQ3pCLDBCQUFJSyxHQUFHLEdBQUcsRUFBVjtBQUNBQSxzQkFBQUEsR0FBRyxDQUFDZCxJQUFKLENBQVNTLENBQUMsQ0FBQy9FLElBQVg7QUFDQWlGLHNCQUFBQSxPQUFPLENBQUNQLE9BQVIsQ0FBaUJ5QixDQUFELElBQU87QUFDckIsNEJBQUlBLENBQUMsS0FBSyxFQUFWLEVBQWM7QUFDWkEsMEJBQUFBLENBQUMsR0FBR0EsQ0FBQyxLQUFLLGVBQU4sR0FBd0JBLENBQXhCLEdBQTRCLFNBQWhDO0FBQ0FmLDBCQUFBQSxHQUFHLENBQUNkLElBQUosQ0FBU1MsQ0FBQyxDQUFDb0IsQ0FBRCxDQUFELEdBQU9wQixDQUFDLENBQUNvQixDQUFELENBQVIsR0FBYyxJQUF2QjtBQUNEO0FBQ0YsdUJBTEQ7QUFNQWYsc0JBQUFBLEdBQUcsQ0FBQ2QsSUFBSixDQUFTUyxDQUFDLENBQUNxQixlQUFYO0FBQ0FsQixzQkFBQUEsSUFBSSxDQUFDWixJQUFMLENBQVVjLEdBQVY7QUFDRCxxQkFYRDtBQVlBSCxvQkFBQUEsT0FBTyxDQUFDUCxPQUFSLENBQWdCLENBQUNLLENBQUQsRUFBSXRCLEdBQUosS0FBWTtBQUMxQndCLHNCQUFBQSxPQUFPLENBQUN4QixHQUFELENBQVAsR0FBZXJFLE9BQU8sQ0FBQzZFLElBQVIsQ0FBYWMsQ0FBYixDQUFmO0FBQ0QscUJBRkQ7QUFHQUUsb0JBQUFBLE9BQU8sQ0FBQ1gsSUFBUixDQUFhLElBQWI7QUFDQW5GLG9CQUFBQSxNQUFNLENBQUNtRixJQUFQLENBQVk7QUFDVnFCLHNCQUFBQSxLQUFLLEVBQUUsdUJBREc7QUFFVkMsc0JBQUFBLElBQUksRUFBRSxPQUZJO0FBR1ZYLHNCQUFBQSxPQUhVO0FBSVZDLHNCQUFBQTtBQUpVLHFCQUFaO0FBTUQsbUJBbkNELE1BbUNPO0FBQ0wvRixvQkFBQUEsTUFBTSxDQUFDbUYsSUFBUCxDQUFZLEdBQUcsS0FBSzBCLGVBQUwsQ0FBcUJoRCxNQUFNLENBQUNBLE1BQVAsQ0FBY1csRUFBZCxDQUFyQixFQUF3Q3ZFLE9BQXhDLEVBQWlEcUUsR0FBakQsQ0FBZjtBQUNEO0FBQ0Y7O0FBQ0QscUJBQUssTUFBTTRDLEtBQVgsSUFBb0JsSCxNQUFwQixFQUE0QjtBQUMxQlMsa0JBQUFBLE9BQU8sQ0FBQzBHLGVBQVIsQ0FBd0IsQ0FBQ0QsS0FBRCxDQUF4QjtBQUNEOztBQUNENUMsZ0JBQUFBLEdBQUc7QUFDSHRFLGdCQUFBQSxNQUFNLEdBQUcsRUFBVDtBQUNEOztBQUNEQSxjQUFBQSxNQUFNLEdBQUcsRUFBVDtBQUNEO0FBQ0YsV0ExS0QsTUEwS087QUFDTFMsWUFBQUEsT0FBTyxDQUFDc0MsVUFBUixDQUFtQjtBQUNqQkMsY0FBQUEsSUFBSSxFQUFFLHlEQURXO0FBRWpCQyxjQUFBQSxLQUFLLEVBQUU7QUFBRWEsZ0JBQUFBLFFBQVEsRUFBRSxFQUFaO0FBQWdCQyxnQkFBQUEsS0FBSyxFQUFFO0FBQXZCLGVBRlU7QUFHakJDLGNBQUFBLE1BQU0sRUFBRSxDQUFDLENBQUQsRUFBSSxFQUFKLEVBQVEsQ0FBUixFQUFXLEVBQVg7QUFIUyxhQUFuQjtBQUtEO0FBQ0YsU0F6TkMsQ0EyTkY7OztBQUNBLFlBQUk1QixVQUFVLENBQUMsR0FBRCxDQUFkLEVBQXFCO0FBQ25CLGdCQUFNLEtBQUtuQixZQUFMLENBQ0oxQixPQURJLEVBRUprQixPQUZJLEVBR0osYUFISSxFQUlKNEIsT0FKSSxFQUtKLEVBTEksRUFNSmxDLEtBTkksQ0FBTjtBQVFEOztBQUVELGNBQU1NLE9BQU8sQ0FBQ21CLEtBQVIsQ0FBY3JDLE9BQU8sQ0FBQ3dCLG1CQUFSLENBQTRCYyxZQUExQyxDQUFOO0FBRUEsZUFBT3BDLFFBQVEsQ0FBQ3FDLEVBQVQsQ0FBWTtBQUNqQjFCLFVBQUFBLElBQUksRUFBRTtBQUNKMkIsWUFBQUEsT0FBTyxFQUFFLElBREw7QUFFSkMsWUFBQUEsT0FBTyxFQUFHLFVBQVN6QyxPQUFPLENBQUN3QixtQkFBUixDQUE0QmtCLFFBQVM7QUFGcEQ7QUFEVyxTQUFaLENBQVA7QUFNRCxPQS9PRCxDQStPRSxPQUFPQyxLQUFQLEVBQWM7QUFDZCx5QkFBSSwrQkFBSixFQUFxQ0EsS0FBSyxDQUFDRixPQUFOLElBQWlCRSxLQUF0RDtBQUNBLGVBQU8sa0NBQWNBLEtBQUssQ0FBQ0YsT0FBTixJQUFpQkUsS0FBL0IsRUFBc0MsSUFBdEMsRUFBNEMsR0FBNUMsRUFBaUR6QyxRQUFqRCxDQUFQO0FBQ0Q7QUFDRixLQXhQcUIsRUF3UG5CLENBQUM7QUFBQ2EsTUFBQUEsTUFBTSxFQUFFO0FBQUUrQixRQUFBQTtBQUFGO0FBQVQsS0FBRCxLQUE0Qiw2QkFBNEJBLE9BQVEsSUFBRyxLQUFLRix1QkFBTCxFQUErQixNQXhQL0UsQ0E5b0NSOztBQUFBLDhEQSs0Q3FCLEtBQUs3Qyw4Q0FBTCxDQUFxRCxPQUN0RkMsT0FEc0YsRUFFdEZDLE9BRnNGLEVBR3RGQyxRQUhzRixLQUluRjtBQUNILFVBQUk7QUFDRix5QkFBSSw0Q0FBSixFQUFtRCxnQkFBbkQsRUFBb0UsTUFBcEU7QUFDQSxjQUFNO0FBQUUyQyxVQUFBQSxVQUFGO0FBQWNqQyxVQUFBQTtBQUFkLFlBQXdCWCxPQUFPLENBQUNZLElBQXRDO0FBQ0EsY0FBTTtBQUFFZ0gsVUFBQUE7QUFBRixZQUFjNUgsT0FBTyxDQUFDYyxNQUE1QjtBQUVBLGNBQU1HLE9BQU8sR0FBRyxJQUFJQyxzQkFBSixFQUFoQjtBQUNBO0FBQ0Esb0RBQTJCQyw4Q0FBM0I7QUFDQSxvREFBMkJDLHNEQUEzQjtBQUNBLG9EQUEyQkMsY0FBS0MsSUFBTCxDQUFVRixzREFBVixFQUF1RHJCLE9BQU8sQ0FBQ3dCLG1CQUFSLENBQTRCQyxZQUFuRixDQUEzQjtBQUVBLFlBQUlxRyxnQkFBZ0IsR0FBRyxFQUF2QjtBQUNBLFlBQUlySCxNQUFNLEdBQUcsRUFBYjs7QUFDQSxZQUFJO0FBQ0ZxSCxVQUFBQSxnQkFBZ0IsR0FBRyxNQUFNOUgsT0FBTyxDQUFDNkQsS0FBUixDQUFjQyxHQUFkLENBQWtCQyxNQUFsQixDQUF5QkMsYUFBekIsQ0FBdUMvRCxPQUF2QyxDQUN2QixLQUR1QixFQUV0QixXQUFVNEgsT0FBUSwyQkFGSSxFQUd2QixFQUh1QixFQUl2QjtBQUFFNUQsWUFBQUEsU0FBUyxFQUFFckQ7QUFBYixXQUp1QixDQUF6QjtBQU1ELFNBUEQsQ0FPRSxPQUFPK0IsS0FBUCxFQUFjO0FBQ2QsMkJBQUksa0JBQUosRUFBd0JBLEtBQUssQ0FBQ0YsT0FBTixJQUFpQkUsS0FBekMsRUFBZ0QsT0FBaEQ7QUFDRDs7QUFFRCxjQUFNLEtBQUtqQixZQUFMLENBQWtCMUIsT0FBbEIsRUFBMkJrQixPQUEzQixFQUFvQyxhQUFwQyxFQUFtRCxhQUFuRCxFQUFrRTJHLE9BQWxFLEVBQTJFakgsS0FBM0UsQ0FBTjtBQUVBLFlBQUltSCxZQUFZLEdBQUcsQ0FBbkI7O0FBQ0EsYUFBSyxJQUFJekQsTUFBVCxJQUFtQmEsdUNBQW1CQyxjQUF0QyxFQUFzRDtBQUNwRCxjQUFJNEMsY0FBYyxHQUFHLEtBQXJCO0FBQ0EsMkJBQ0UsNENBREYsRUFFRyxnQkFBZTFELE1BQU0sQ0FBQ2dCLFFBQVAsQ0FBZ0JuQixNQUFPLHlCQUZ6QyxFQUdFLE9BSEY7O0FBS0EsZUFBSyxJQUFJekQsT0FBVCxJQUFvQjRELE1BQU0sQ0FBQ2dCLFFBQTNCLEVBQXFDO0FBQ25DLGdCQUFJMkMsaUJBQWlCLEdBQUcsS0FBeEI7O0FBQ0EsZ0JBQ0VwRixVQUFVLENBQUNrRixZQUFELENBQVYsS0FDQ3JILE9BQU8sQ0FBQzRELE1BQVIsSUFBa0I1RCxPQUFPLENBQUNnRixLQUQzQixDQURGLEVBR0U7QUFDQSxrQkFBSVgsR0FBRyxHQUFHLENBQVY7QUFDQSxvQkFBTW1ELE9BQU8sR0FBRyxDQUFDeEgsT0FBTyxDQUFDNEQsTUFBUixJQUFrQixFQUFuQixFQUF1QlEsTUFBdkIsQ0FBOEJwRSxPQUFPLENBQUNnRixLQUFSLElBQWlCLEVBQS9DLENBQWhCO0FBQ0EsK0JBQ0UsNENBREYsRUFFRyxnQkFBZXdDLE9BQU8sQ0FBQy9ELE1BQU8sdUJBRmpDLEVBR0UsT0FIRjs7QUFLQSxtQkFBSyxJQUFJZ0UsSUFBVCxJQUFpQkQsT0FBakIsRUFBMEI7QUFDeEIsb0JBQUlFLG1CQUFtQixHQUFHLEVBQTFCOztBQUNBLG9CQUFJO0FBQ0Ysc0JBQUksQ0FBQ0QsSUFBSSxDQUFDLE1BQUQsQ0FBVCxFQUFtQjtBQUNqQkMsb0JBQUFBLG1CQUFtQixHQUFHLE1BQU1wSSxPQUFPLENBQUM2RCxLQUFSLENBQWNDLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCQyxhQUF6QixDQUF1Qy9ELE9BQXZDLENBQzFCLEtBRDBCLEVBRXpCLFdBQVU0SCxPQUFRLFdBQVVNLElBQUksQ0FBQ0UsU0FBVSxJQUFHRixJQUFJLENBQUN2RSxhQUFjLEVBRnhDLEVBRzFCLEVBSDBCLEVBSTFCO0FBQUVLLHNCQUFBQSxTQUFTLEVBQUVyRDtBQUFiLHFCQUowQixDQUE1QjtBQU1ELG1CQVBELE1BT087QUFDTCx5QkFBSyxJQUFJOEUsS0FBVCxJQUFrQm9DLGdCQUFnQixDQUFDbkUsSUFBakIsQ0FBc0JBLElBQXRCLENBQTJCLFVBQTNCLENBQWxCLEVBQTBEO0FBQ3hELDBCQUFJUyxNQUFNLENBQUNDLElBQVAsQ0FBWXFCLEtBQVosRUFBbUIsQ0FBbkIsTUFBMEJ5QyxJQUFJLENBQUMsTUFBRCxDQUFsQyxFQUE0QztBQUMxQ0Msd0JBQUFBLG1CQUFtQixDQUFDekUsSUFBcEIsR0FBMkI7QUFDekJBLDBCQUFBQSxJQUFJLEVBQUUrQjtBQURtQix5QkFBM0I7QUFHRDtBQUNGO0FBQ0Y7O0FBRUQsd0JBQU00QyxXQUFXLEdBQ2ZGLG1CQUFtQixJQUFJQSxtQkFBbUIsQ0FBQ3pFLElBQTNDLElBQW1EeUUsbUJBQW1CLENBQUN6RSxJQUFwQixDQUF5QkEsSUFEOUU7O0FBRUEsc0JBQUksQ0FBQ3FFLGNBQUwsRUFBcUI7QUFDbkI5RyxvQkFBQUEsT0FBTyxDQUFDc0MsVUFBUixDQUFtQjtBQUNqQkMsc0JBQUFBLElBQUksRUFBRWEsTUFBTSxDQUFDMkMsS0FESTtBQUVqQnZELHNCQUFBQSxLQUFLLEVBQUUsSUFGVTtBQUdqQmUsc0JBQUFBLE1BQU0sRUFBRSxDQUFDLENBQUQsRUFBSSxDQUFKLEVBQU8sQ0FBUCxFQUFVLEVBQVY7QUFIUyxxQkFBbkI7QUFLQXVELG9CQUFBQSxjQUFjLEdBQUcsSUFBakI7QUFDRDs7QUFDRCxzQkFBSSxDQUFDQyxpQkFBTCxFQUF3QjtBQUN0Qi9HLG9CQUFBQSxPQUFPLENBQUNzQyxVQUFSLENBQW1CO0FBQ2pCQyxzQkFBQUEsSUFBSSxFQUFFL0MsT0FBTyxDQUFDNkgsUUFERztBQUVqQjdFLHNCQUFBQSxLQUFLLEVBQUU7QUFGVSxxQkFBbkI7QUFJQXhDLG9CQUFBQSxPQUFPLENBQUNzQyxVQUFSLENBQW1CO0FBQ2pCQyxzQkFBQUEsSUFBSSxFQUFFL0MsT0FBTyxDQUFDOEgsSUFERztBQUVqQjlFLHNCQUFBQSxLQUFLLEVBQUU7QUFBRWEsd0JBQUFBLFFBQVEsRUFBRSxFQUFaO0FBQWdCQyx3QkFBQUEsS0FBSyxFQUFFO0FBQXZCLHVCQUZVO0FBR2pCQyxzQkFBQUEsTUFBTSxFQUFFLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsRUFBVjtBQUhTLHFCQUFuQjtBQUtBd0Qsb0JBQUFBLGlCQUFpQixHQUFHLElBQXBCO0FBQ0Q7O0FBQ0Qsc0JBQUlLLFdBQUosRUFBaUI7QUFDZix5QkFBSyxJQUFJRyxjQUFULElBQTJCckUsTUFBTSxDQUFDQyxJQUFQLENBQVlpRSxXQUFaLENBQTNCLEVBQXFEO0FBQ25ELDBCQUFJekMsS0FBSyxDQUFDQyxPQUFOLENBQWN3QyxXQUFXLENBQUNHLGNBQUQsQ0FBekIsQ0FBSixFQUFnRDtBQUM5QztBQUNBLDRCQUFJTixJQUFJLENBQUNPLFFBQVQsRUFBbUI7QUFDakIsOEJBQUkzQyxNQUFNLEdBQUcsRUFBYjtBQUNBdUMsMEJBQUFBLFdBQVcsQ0FBQ0csY0FBRCxDQUFYLENBQTRCekMsT0FBNUIsQ0FBcUNDLEdBQUQsSUFBUztBQUMzQyxnQ0FBSSxDQUFDRixNQUFNLENBQUNFLEdBQUcsQ0FBQ0MsU0FBTCxDQUFYLEVBQTRCO0FBQzFCSCw4QkFBQUEsTUFBTSxDQUFDRSxHQUFHLENBQUNDLFNBQUwsQ0FBTixHQUF3QixFQUF4QjtBQUNEOztBQUNESCw0QkFBQUEsTUFBTSxDQUFDRSxHQUFHLENBQUNDLFNBQUwsQ0FBTixDQUFzQk4sSUFBdEIsQ0FBMkJLLEdBQTNCO0FBQ0QsMkJBTEQ7QUFNQTdCLDBCQUFBQSxNQUFNLENBQUNDLElBQVAsQ0FBWTBCLE1BQVosRUFBb0JDLE9BQXBCLENBQTZCRyxLQUFELElBQVc7QUFDckMsZ0NBQUlDLE9BQU8sR0FBRyxDQUFkO0FBQ0FMLDRCQUFBQSxNQUFNLENBQUNJLEtBQUQsQ0FBTixDQUFjSCxPQUFkLENBQXNCLENBQUNLLENBQUQsRUFBSUMsQ0FBSixLQUFVO0FBQzlCLGtDQUNFbEMsTUFBTSxDQUFDQyxJQUFQLENBQVlnQyxDQUFaLEVBQWVsQyxNQUFmLEdBQXdCQyxNQUFNLENBQUNDLElBQVAsQ0FBWTBCLE1BQU0sQ0FBQ0ksS0FBRCxDQUFOLENBQWNDLE9BQWQsQ0FBWixFQUFvQ2pDLE1BRDlELEVBRUU7QUFDQWlDLGdDQUFBQSxPQUFPLEdBQUdFLENBQVY7QUFDRDtBQUNGLDZCQU5EO0FBT0Esa0NBQU1DLE9BQU8sR0FBR25DLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZMEIsTUFBTSxDQUFDSSxLQUFELENBQU4sQ0FBY0MsT0FBZCxDQUFaLENBQWhCO0FBQ0Esa0NBQU1JLElBQUksR0FBR1QsTUFBTSxDQUFDSSxLQUFELENBQU4sQ0FBY00sR0FBZCxDQUFtQkosQ0FBRCxJQUFPO0FBQ3BDLGtDQUFJSyxHQUFHLEdBQUcsRUFBVjtBQUNBSCw4QkFBQUEsT0FBTyxDQUFDUCxPQUFSLENBQWlCVyxHQUFELElBQVM7QUFDdkJELGdDQUFBQSxHQUFHLENBQUNkLElBQUosQ0FDRSxPQUFPUyxDQUFDLENBQUNNLEdBQUQsQ0FBUixLQUFrQixRQUFsQixHQUNJTixDQUFDLENBQUNNLEdBQUQsQ0FETCxHQUVJZCxLQUFLLENBQUNDLE9BQU4sQ0FBY08sQ0FBQyxDQUFDTSxHQUFELENBQWYsSUFDQU4sQ0FBQyxDQUFDTSxHQUFELENBQUQsQ0FBT0YsR0FBUCxDQUFZSixDQUFELElBQU87QUFDaEIseUNBQU9BLENBQUMsR0FBRyxJQUFYO0FBQ0QsaUNBRkQsQ0FEQSxHQUlBTyxJQUFJLENBQUNDLFNBQUwsQ0FBZVIsQ0FBQyxDQUFDTSxHQUFELENBQWhCLENBUE47QUFTRCwrQkFWRDtBQVdBLHFDQUFPRCxHQUFQO0FBQ0QsNkJBZFksQ0FBYjtBQWVBSCw0QkFBQUEsT0FBTyxDQUFDUCxPQUFSLENBQWdCLENBQUNjLEdBQUQsRUFBTVIsQ0FBTixLQUFZO0FBQzFCQyw4QkFBQUEsT0FBTyxDQUFDRCxDQUFELENBQVAsR0FBYVEsR0FBRyxDQUFDLENBQUQsQ0FBSCxDQUFPQyxXQUFQLEtBQXVCRCxHQUFHLENBQUNFLEtBQUosQ0FBVSxDQUFWLENBQXBDO0FBQ0QsNkJBRkQ7QUFHQXZHLDRCQUFBQSxNQUFNLENBQUNtRixJQUFQLENBQVk7QUFDVnFCLDhCQUFBQSxLQUFLLEVBQUV2RyxPQUFPLENBQUM0QyxNQUFSLENBQWUsQ0FBZixFQUFrQjZDLEtBQWxCLENBREc7QUFFVmUsOEJBQUFBLElBQUksRUFBRSxPQUZJO0FBR1ZYLDhCQUFBQSxPQUhVO0FBSVZDLDhCQUFBQTtBQUpVLDZCQUFaO0FBTUQsMkJBbENEO0FBbUNELHlCQTNDRCxNQTJDTyxJQUFJaUMsY0FBYyxDQUFDN0UsYUFBZixLQUFpQyxRQUFyQyxFQUErQztBQUNwRG5ELDBCQUFBQSxNQUFNLENBQUNtRixJQUFQLENBQ0UsR0FBRyxLQUFLMEIsZUFBTCxDQUFxQmdCLFdBQVcsQ0FBQ0csY0FBRCxDQUFoQyxFQUFrRC9ILE9BQWxELEVBQTJEcUUsR0FBM0QsQ0FETDtBQUdELHlCQUpNLE1BSUE7QUFDTCwrQkFBSyxJQUFJc0MsR0FBVCxJQUFnQmlCLFdBQVcsQ0FBQ0csY0FBRCxDQUEzQixFQUE2QztBQUMzQ2hJLDRCQUFBQSxNQUFNLENBQUNtRixJQUFQLENBQVksR0FBRyxLQUFLMEIsZUFBTCxDQUFxQkQsR0FBckIsRUFBMEIzRyxPQUExQixFQUFtQ3FFLEdBQW5DLENBQWY7QUFDRDtBQUNGO0FBQ0YsdUJBdERELE1Bc0RPO0FBQ0w7QUFDQSw0QkFBSW9ELElBQUksQ0FBQ1EsTUFBVCxFQUFpQjtBQUNmLGdDQUFNO0FBQUNwQiw0QkFBQUEsV0FBRDtBQUFhcUIsNEJBQUFBLElBQWI7QUFBa0JDLDRCQUFBQSxlQUFsQjtBQUFrQ0MsNEJBQUFBLFVBQWxDO0FBQTZDLCtCQUFHQztBQUFoRCw4QkFBd0RULFdBQVcsQ0FBQ0csY0FBRCxDQUF6RTtBQUNBaEksMEJBQUFBLE1BQU0sQ0FBQ21GLElBQVAsQ0FDRSxHQUFHLEtBQUswQixlQUFMLENBQXFCeUIsSUFBckIsRUFBMkJySSxPQUEzQixFQUFvQ3FFLEdBQXBDLENBREwsRUFFRSxJQUFJNkQsSUFBSSxJQUFJQSxJQUFJLENBQUNJLFVBQWIsR0FBMEIsS0FBSzFCLGVBQUwsQ0FBcUJzQixJQUFJLENBQUNJLFVBQTFCLEVBQXNDO0FBQUNoRSw0QkFBQUEsSUFBSSxFQUFDLENBQUMsWUFBRDtBQUFOLDJCQUF0QyxFQUE2RCxDQUE3RCxDQUExQixHQUE0RixFQUFoRyxDQUZGLEVBR0UsSUFBSTRELElBQUksSUFBSUEsSUFBSSxDQUFDSyxTQUFiLEdBQXlCLEtBQUszQixlQUFMLENBQXFCc0IsSUFBSSxDQUFDSyxTQUExQixFQUFxQztBQUFDakUsNEJBQUFBLElBQUksRUFBQyxDQUFDLFdBQUQ7QUFBTiwyQkFBckMsRUFBMkQsQ0FBM0QsQ0FBekIsR0FBeUYsRUFBN0YsQ0FIRixFQUlFLElBQUk2RCxlQUFlLEdBQUcsS0FBS3ZCLGVBQUwsQ0FBcUJ1QixlQUFyQixFQUFzQztBQUFDN0QsNEJBQUFBLElBQUksRUFBQyxDQUFDLGlCQUFEO0FBQU4sMkJBQXRDLEVBQWtFLENBQWxFLENBQUgsR0FBMEUsRUFBN0YsQ0FKRixFQUtFLElBQUk4RCxVQUFVLEdBQUcsS0FBS3hCLGVBQUwsQ0FBcUJ3QixVQUFyQixFQUFpQztBQUFDOUQsNEJBQUFBLElBQUksRUFBQyxDQUFDLFlBQUQ7QUFBTiwyQkFBakMsRUFBd0QsQ0FBeEQsQ0FBSCxHQUFnRSxFQUE5RSxDQUxGO0FBT0EsOEJBQUl3QyxRQUFRLEdBQUcsRUFBZjtBQUNBcEQsMEJBQUFBLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZM0QsT0FBTyxDQUFDNkUsSUFBcEIsRUFBMEJTLE9BQTFCLENBQW1DSyxDQUFELElBQU87QUFDdkNtQiw0QkFBQUEsUUFBUSxDQUFDNUIsSUFBVCxDQUFjUyxDQUFkO0FBQ0QsMkJBRkQ7QUFHQSxnQ0FBTUUsT0FBTyxHQUFHLENBQ2QsRUFEYyxFQUVkLEdBQUdpQixRQUFRLENBQUMzQyxNQUFULENBQWlCd0IsQ0FBRCxJQUFPQSxDQUFDLEtBQUssV0FBTixJQUFxQkEsQ0FBQyxLQUFLLFdBQWxELENBRlcsQ0FBaEI7QUFJQSw4QkFBSUcsSUFBSSxHQUFHLEVBQVg7QUFDQWUsMEJBQUFBLFdBQVcsQ0FBQ3ZCLE9BQVosQ0FBcUJLLENBQUQsSUFBTztBQUN6QixnQ0FBSUssR0FBRyxHQUFHLEVBQVY7QUFDQUEsNEJBQUFBLEdBQUcsQ0FBQ2QsSUFBSixDQUFTUyxDQUFDLENBQUM2QyxHQUFYO0FBQ0EzQyw0QkFBQUEsT0FBTyxDQUFDUCxPQUFSLENBQWlCeUIsQ0FBRCxJQUFPO0FBQ3JCLGtDQUFJQSxDQUFDLEtBQUssRUFBVixFQUFjO0FBQ1pmLGdDQUFBQSxHQUFHLENBQUNkLElBQUosQ0FBU1MsQ0FBQyxDQUFDZCxJQUFGLENBQU80RCxPQUFQLENBQWUxQixDQUFmLElBQW9CLENBQUMsQ0FBckIsR0FBeUIsS0FBekIsR0FBaUMsSUFBMUM7QUFDRDtBQUNGLDZCQUpEO0FBS0FmLDRCQUFBQSxHQUFHLENBQUNkLElBQUosQ0FBU1MsQ0FBQyxDQUFDcUIsZUFBWDtBQUNBbEIsNEJBQUFBLElBQUksQ0FBQ1osSUFBTCxDQUFVYyxHQUFWO0FBQ0QsMkJBVkQ7QUFXQUgsMEJBQUFBLE9BQU8sQ0FBQ1AsT0FBUixDQUFnQixDQUFDSyxDQUFELEVBQUl0QixHQUFKLEtBQVk7QUFDMUJ3Qiw0QkFBQUEsT0FBTyxDQUFDeEIsR0FBRCxDQUFQLEdBQWVyRSxPQUFPLENBQUM2RSxJQUFSLENBQWFjLENBQWIsQ0FBZjtBQUNELDJCQUZEO0FBR0FFLDBCQUFBQSxPQUFPLENBQUNYLElBQVIsQ0FBYSxJQUFiO0FBQ0FuRiwwQkFBQUEsTUFBTSxDQUFDbUYsSUFBUCxDQUFZO0FBQ1ZxQiw0QkFBQUEsS0FBSyxFQUFFLHVCQURHO0FBRVZDLDRCQUFBQSxJQUFJLEVBQUUsT0FGSTtBQUdWWCw0QkFBQUEsT0FIVTtBQUlWQyw0QkFBQUE7QUFKVSwyQkFBWjtBQU1ELHlCQXZDRCxNQXVDTztBQUNML0YsMEJBQUFBLE1BQU0sQ0FBQ21GLElBQVAsQ0FDRSxHQUFHLEtBQUswQixlQUFMLENBQXFCZ0IsV0FBVyxDQUFDRyxjQUFELENBQWhDLEVBQWtEL0gsT0FBbEQsRUFBMkRxRSxHQUEzRCxDQURMO0FBR0Q7QUFDRjtBQUNGO0FBQ0YsbUJBeEdELE1Bd0dPO0FBQ0w7QUFDQTdELG9CQUFBQSxPQUFPLENBQUNzQyxVQUFSLENBQW1CO0FBQ2pCQyxzQkFBQUEsSUFBSSxFQUFFLENBQ0osOEVBREksRUFFSjtBQUNFQSx3QkFBQUEsSUFBSSxFQUFHLEdBQUUvQyxPQUFPLENBQUM2SCxRQUFSLENBQWlCYSxXQUFqQixFQUErQixpQkFEMUM7QUFFRUMsd0JBQUFBLElBQUksRUFBRTNJLE9BQU8sQ0FBQzRJLFFBRmhCO0FBR0U1Rix3QkFBQUEsS0FBSyxFQUFFO0FBQUVhLDBCQUFBQSxRQUFRLEVBQUUsRUFBWjtBQUFnQkMsMEJBQUFBLEtBQUssRUFBRTtBQUF2QjtBQUhULHVCQUZJLENBRFc7QUFTakJDLHNCQUFBQSxNQUFNLEVBQUUsQ0FBQyxDQUFELEVBQUksQ0FBSixFQUFPLENBQVAsRUFBVSxFQUFWO0FBVFMscUJBQW5CO0FBV0Q7QUFDRixpQkE5SkQsQ0E4SkUsT0FBTzlCLEtBQVAsRUFBYztBQUNkLG1DQUFJLGtCQUFKLEVBQXdCQSxLQUFLLENBQUNGLE9BQU4sSUFBaUJFLEtBQXpDLEVBQWdELE9BQWhEO0FBQ0Q7O0FBQ0RvQyxnQkFBQUEsR0FBRztBQUNKOztBQUNELG1CQUFLLE1BQU00QyxLQUFYLElBQW9CbEgsTUFBcEIsRUFBNEI7QUFDMUJTLGdCQUFBQSxPQUFPLENBQUMwRyxlQUFSLENBQXdCLENBQUNELEtBQUQsQ0FBeEI7QUFDRDtBQUNGOztBQUNESSxZQUFBQSxZQUFZO0FBQ1p0SCxZQUFBQSxNQUFNLEdBQUcsRUFBVDtBQUNEO0FBQ0Y7O0FBRUQsY0FBTVMsT0FBTyxDQUFDbUIsS0FBUixDQUFjckMsT0FBTyxDQUFDd0IsbUJBQVIsQ0FBNEJjLFlBQTFDLENBQU47QUFFQSxlQUFPcEMsUUFBUSxDQUFDcUMsRUFBVCxDQUFZO0FBQ2pCMUIsVUFBQUEsSUFBSSxFQUFFO0FBQ0oyQixZQUFBQSxPQUFPLEVBQUUsSUFETDtBQUVKQyxZQUFBQSxPQUFPLEVBQUcsVUFBU3pDLE9BQU8sQ0FBQ3dCLG1CQUFSLENBQTRCa0IsUUFBUztBQUZwRDtBQURXLFNBQVosQ0FBUDtBQU1ELE9Bck9ELENBcU9FLE9BQU9DLEtBQVAsRUFBYztBQUNkLHlCQUFJLDRDQUFKLEVBQWtEQSxLQUFLLENBQUNGLE9BQU4sSUFBaUJFLEtBQW5FO0FBQ0EsZUFBTyxrQ0FBY0EsS0FBSyxDQUFDRixPQUFOLElBQWlCRSxLQUEvQixFQUFzQyxJQUF0QyxFQUE0QyxHQUE1QyxFQUFpRHpDLFFBQWpELENBQVA7QUFDRDtBQUNGLEtBOU9rQyxFQThPaEMsQ0FBQztBQUFFYSxNQUFBQSxNQUFNLEVBQUU7QUFBRThHLFFBQUFBO0FBQUY7QUFBVixLQUFELEtBQTZCLDZCQUE0QkEsT0FBUSxJQUFHLEtBQUtqRix1QkFBTCxFQUErQixNQTlPbkUsQ0EvNENyQjs7QUFBQSwwREFzb0RpQixLQUFLN0MsOENBQUwsQ0FBcUQsT0FDbEZDLE9BRGtGLEVBRWxGQyxPQUZrRixFQUdsRkMsUUFIa0YsS0FJL0U7QUFDSCxVQUFJO0FBQ0YseUJBQUksd0NBQUosRUFBK0MsZ0JBQS9DLEVBQWdFLE1BQWhFO0FBQ0EsY0FBTTtBQUFFSSxVQUFBQSxTQUFGO0FBQWFDLFVBQUFBLE9BQWI7QUFBc0JDLFVBQUFBLElBQXRCO0FBQTRCRyxVQUFBQSxpQkFBNUI7QUFBK0NDLFVBQUFBO0FBQS9DLFlBQXlEWCxPQUFPLENBQUNZLElBQXZFO0FBQ0EsY0FBTTtBQUFFZ0gsVUFBQUE7QUFBRixZQUFjNUgsT0FBTyxDQUFDYyxNQUE1QjtBQUNBLGNBQU07QUFBRUMsVUFBQUEsSUFBRjtBQUFRQyxVQUFBQTtBQUFSLFlBQWVULElBQUksSUFBSSxFQUE3QixDQUpFLENBS0Y7O0FBQ0EsY0FBTVUsT0FBTyxHQUFHLElBQUlDLHNCQUFKLEVBQWhCO0FBRUEsY0FBTTtBQUFFTSxVQUFBQTtBQUFGLFlBQW1CLE1BQU16QixPQUFPLENBQUM2RCxLQUFSLENBQWMwRixRQUFkLENBQXVCQyxjQUF2QixDQUFzQ3ZKLE9BQXRDLEVBQStDRCxPQUEvQyxDQUEvQjtBQUNBO0FBQ0Esb0RBQTJCb0IsOENBQTNCO0FBQ0Esb0RBQTJCQyxzREFBM0I7QUFDQSxvREFBMkJDLGNBQUtDLElBQUwsQ0FBVUYsc0RBQVYsRUFBdURJLFlBQXZELENBQTNCO0FBRUEseUJBQUksd0NBQUosRUFBK0MscUJBQS9DLEVBQXFFLE9BQXJFO0FBQ0EsY0FBTUUsZ0JBQWdCLEdBQUdwQixPQUFPLEdBQUcsS0FBS3NCLHFCQUFMLENBQTJCdEIsT0FBM0IsRUFBb0NELFNBQXBDLENBQUgsR0FBb0QsS0FBcEYsQ0FmRSxDQWlCRjs7QUFDQSxZQUFJbUosT0FBTyxHQUFHLEVBQWQ7O0FBQ0EsWUFBSTtBQUNGLGdCQUFNQyxhQUFhLEdBQUcsTUFBTTFKLE9BQU8sQ0FBQzZELEtBQVIsQ0FBY0MsR0FBZCxDQUFrQkMsTUFBbEIsQ0FBeUJDLGFBQXpCLENBQXVDL0QsT0FBdkMsQ0FDMUIsS0FEMEIsRUFFMUIsU0FGMEIsRUFHMUI7QUFBRWMsWUFBQUEsTUFBTSxFQUFFO0FBQUU0SSxjQUFBQSxDQUFDLEVBQUcsTUFBSzlCLE9BQVE7QUFBbkI7QUFBVixXQUgwQixFQUkxQjtBQUFFNUQsWUFBQUEsU0FBUyxFQUFFckQ7QUFBYixXQUowQixDQUE1QjtBQU1BNkksVUFBQUEsT0FBTyxHQUFHQyxhQUFhLENBQUMvRixJQUFkLENBQW1CQSxJQUFuQixDQUF3Qk8sY0FBeEIsQ0FBdUMsQ0FBdkMsRUFBMEMwRixFQUExQyxDQUE2Q0MsUUFBdkQ7QUFDRCxTQVJELENBUUUsT0FBT2xILEtBQVAsRUFBYztBQUNkLDJCQUFJLHdDQUFKLEVBQThDQSxLQUFLLENBQUNGLE9BQU4sSUFBaUJFLEtBQS9ELEVBQXNFLE9BQXRFO0FBQ0QsU0E3QkMsQ0ErQkY7OztBQUNBekIsUUFBQUEsT0FBTyxDQUFDNEkscUJBQVIsQ0FBOEI7QUFDNUJyRyxVQUFBQSxJQUFJLEVBQUUsdUJBRHNCO0FBRTVCQyxVQUFBQSxLQUFLLEVBQUU7QUFGcUIsU0FBOUIsRUFoQ0UsQ0FxQ0Y7O0FBQ0EsY0FBTSxLQUFLcUcsZ0JBQUwsQ0FBc0IvSixPQUF0QixFQUErQmtCLE9BQS9CLEVBQXdDLENBQUMyRyxPQUFELENBQXhDLEVBQW1EakgsS0FBbkQsQ0FBTixDQXRDRSxDQXdDRjs7QUFDQSxjQUFNb0osc0JBQXNCLEdBQUcsQ0FDN0I7QUFDRUMsVUFBQUEsUUFBUSxFQUFHLGlCQUFnQnBDLE9BQVEsV0FEckM7QUFFRXFDLFVBQUFBLGFBQWEsRUFBRywrQkFBOEJyQyxPQUFRLEVBRnhEO0FBR0VGLFVBQUFBLEtBQUssRUFBRTtBQUNMVixZQUFBQSxLQUFLLEVBQUUsVUFERjtBQUVMVixZQUFBQSxPQUFPLEVBQ0xrRCxPQUFPLEtBQUssU0FBWixHQUNJLENBQ0U7QUFBRVUsY0FBQUEsRUFBRSxFQUFFLE1BQU47QUFBY2hELGNBQUFBLEtBQUssRUFBRTtBQUFyQixhQURGLEVBRUU7QUFBRWdELGNBQUFBLEVBQUUsRUFBRSxjQUFOO0FBQXNCaEQsY0FBQUEsS0FBSyxFQUFFO0FBQTdCLGFBRkYsRUFHRTtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLFNBQU47QUFBaUJoRCxjQUFBQSxLQUFLLEVBQUU7QUFBeEIsYUFIRixFQUlFO0FBQUVnRCxjQUFBQSxFQUFFLEVBQUUsUUFBTjtBQUFnQmhELGNBQUFBLEtBQUssRUFBRTtBQUF2QixhQUpGLENBREosR0FPSSxDQUNFO0FBQUVnRCxjQUFBQSxFQUFFLEVBQUUsTUFBTjtBQUFjaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXJCLGFBREYsRUFFRTtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLGNBQU47QUFBc0JoRCxjQUFBQSxLQUFLLEVBQUU7QUFBN0IsYUFGRixFQUdFO0FBQUVnRCxjQUFBQSxFQUFFLEVBQUUsU0FBTjtBQUFpQmhELGNBQUFBLEtBQUssRUFBRTtBQUF4QixhQUhGLEVBSUU7QUFBRWdELGNBQUFBLEVBQUUsRUFBRSxRQUFOO0FBQWdCaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXZCLGFBSkYsRUFLRTtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLGFBQU47QUFBcUJoRCxjQUFBQSxLQUFLLEVBQUU7QUFBNUIsYUFMRjtBQVZEO0FBSFQsU0FENkIsRUF1QjdCO0FBQ0U4QyxVQUFBQSxRQUFRLEVBQUcsaUJBQWdCcEMsT0FBUSxZQURyQztBQUVFcUMsVUFBQUEsYUFBYSxFQUFHLGdDQUErQnJDLE9BQVEsRUFGekQ7QUFHRUYsVUFBQUEsS0FBSyxFQUFFO0FBQ0xWLFlBQUFBLEtBQUssRUFBRSxXQURGO0FBRUxWLFlBQUFBLE9BQU8sRUFDTGtELE9BQU8sS0FBSyxTQUFaLEdBQ0ksQ0FDRTtBQUFFVSxjQUFBQSxFQUFFLEVBQUUsTUFBTjtBQUFjaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXJCLGFBREYsRUFFRTtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLEtBQU47QUFBYWhELGNBQUFBLEtBQUssRUFBRTtBQUFwQixhQUZGLEVBR0U7QUFBRWdELGNBQUFBLEVBQUUsRUFBRSxVQUFOO0FBQWtCaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXpCLGFBSEYsRUFJRTtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLE1BQU47QUFBY2hELGNBQUFBLEtBQUssRUFBRTtBQUFyQixhQUpGLENBREosR0FPSSxDQUNFO0FBQUVnRCxjQUFBQSxFQUFFLEVBQUUsTUFBTjtBQUFjaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXJCLGFBREYsRUFFRTtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLE9BQU47QUFBZWhELGNBQUFBLEtBQUssRUFBRTtBQUF0QixhQUZGLEVBR0U7QUFBRWdELGNBQUFBLEVBQUUsRUFBRSxNQUFOO0FBQWNoRCxjQUFBQSxLQUFLLEVBQUU7QUFBckIsYUFIRixFQUlFO0FBQUVnRCxjQUFBQSxFQUFFLEVBQUUsT0FBTjtBQUFlaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXRCLGFBSkY7QUFWRCxXQUhUO0FBb0JFaUQsVUFBQUEsZ0JBQWdCLEVBQUdDLElBQUQsSUFDaEJaLE9BQU8sS0FBSyxTQUFaLEdBQXdCWSxJQUF4QixHQUErQixFQUFFLEdBQUdBLElBQUw7QUFBV0MsWUFBQUEsS0FBSyxFQUFFQyxpQ0FBbUJGLElBQUksQ0FBQ0MsS0FBeEI7QUFBbEI7QUFyQm5DLFNBdkI2QixFQThDN0I7QUFDRUwsVUFBQUEsUUFBUSxFQUFHLGlCQUFnQnBDLE9BQVEsUUFEckM7QUFFRXFDLFVBQUFBLGFBQWEsRUFBRyw0QkFBMkJyQyxPQUFRLEVBRnJEO0FBR0VGLFVBQUFBLEtBQUssRUFBRTtBQUNMVixZQUFBQSxLQUFLLEVBQUUsZUFERjtBQUVMVixZQUFBQSxPQUFPLEVBQ0xrRCxPQUFPLEtBQUssU0FBWixHQUNJLENBQ0U7QUFBRVUsY0FBQUEsRUFBRSxFQUFFLFVBQU47QUFBa0JoRCxjQUFBQSxLQUFLLEVBQUU7QUFBekIsYUFERixFQUVFO0FBQUVnRCxjQUFBQSxFQUFFLEVBQUUsWUFBTjtBQUFvQmhELGNBQUFBLEtBQUssRUFBRTtBQUEzQixhQUZGLEVBR0U7QUFBRWdELGNBQUFBLEVBQUUsRUFBRSxTQUFOO0FBQWlCaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXhCLGFBSEYsRUFJRTtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLE9BQU47QUFBZWhELGNBQUFBLEtBQUssRUFBRTtBQUF0QixhQUpGLEVBS0U7QUFBRWdELGNBQUFBLEVBQUUsRUFBRSxVQUFOO0FBQWtCaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXpCLGFBTEYsQ0FESixHQVFJLENBQ0U7QUFBRWdELGNBQUFBLEVBQUUsRUFBRSxVQUFOO0FBQWtCaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXpCLGFBREYsRUFFRTtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLFlBQU47QUFBb0JoRCxjQUFBQSxLQUFLLEVBQUU7QUFBM0IsYUFGRixFQUdFO0FBQUVnRCxjQUFBQSxFQUFFLEVBQUUsT0FBTjtBQUFlaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXRCLGFBSEYsRUFJRTtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLFVBQU47QUFBa0JoRCxjQUFBQSxLQUFLLEVBQUU7QUFBekIsYUFKRjtBQVhELFdBSFQ7QUFxQkVpRCxVQUFBQSxnQkFBZ0IsRUFBR0MsSUFBRCxLQUFXLEVBQzNCLEdBQUdBLElBRHdCO0FBRTNCRyxZQUFBQSxRQUFRLEVBQUVILElBQUksQ0FBQ0ksS0FBTCxDQUFXQyxFQUZNO0FBRzNCQyxZQUFBQSxVQUFVLEVBQUVOLElBQUksQ0FBQ0ksS0FBTCxDQUFXRztBQUhJLFdBQVg7QUFyQnBCLFNBOUM2QixFQXlFN0I7QUFDRVgsVUFBQUEsUUFBUSxFQUFHLGlCQUFnQnBDLE9BQVEsV0FEckM7QUFFRXFDLFVBQUFBLGFBQWEsRUFBRywrQkFBOEJyQyxPQUFRLEVBRnhEO0FBR0VGLFVBQUFBLEtBQUssRUFBRTtBQUNMVixZQUFBQSxLQUFLLEVBQUUsb0JBREY7QUFFTFYsWUFBQUEsT0FBTyxFQUFFLENBQ1A7QUFBRTRELGNBQUFBLEVBQUUsRUFBRSxNQUFOO0FBQWNoRCxjQUFBQSxLQUFLLEVBQUU7QUFBckIsYUFETyxFQUVQO0FBQUVnRCxjQUFBQSxFQUFFLEVBQUUsS0FBTjtBQUFhaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXBCLGFBRk8sRUFHUDtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLE9BQU47QUFBZWhELGNBQUFBLEtBQUssRUFBRTtBQUF0QixhQUhPLEVBSVA7QUFBRWdELGNBQUFBLEVBQUUsRUFBRSxLQUFOO0FBQWFoRCxjQUFBQSxLQUFLLEVBQUU7QUFBcEIsYUFKTyxFQUtQO0FBQUVnRCxjQUFBQSxFQUFFLEVBQUUsTUFBTjtBQUFjaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXJCLGFBTE87QUFGSjtBQUhULFNBekU2QixFQXVGN0I7QUFDRThDLFVBQUFBLFFBQVEsRUFBRyxpQkFBZ0JwQyxPQUFRLFVBRHJDO0FBRUVxQyxVQUFBQSxhQUFhLEVBQUcsOEJBQTZCckMsT0FBUSxFQUZ2RDtBQUdFRixVQUFBQSxLQUFLLEVBQUU7QUFDTFYsWUFBQUEsS0FBSyxFQUFFLGtCQURGO0FBRUxWLFlBQUFBLE9BQU8sRUFBRSxDQUNQO0FBQUU0RCxjQUFBQSxFQUFFLEVBQUUsT0FBTjtBQUFlaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXRCLGFBRE8sRUFFUDtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLFNBQU47QUFBaUJoRCxjQUFBQSxLQUFLLEVBQUU7QUFBeEIsYUFGTyxFQUdQO0FBQUVnRCxjQUFBQSxFQUFFLEVBQUUsU0FBTjtBQUFpQmhELGNBQUFBLEtBQUssRUFBRTtBQUF4QixhQUhPLEVBSVA7QUFBRWdELGNBQUFBLEVBQUUsRUFBRSxPQUFOO0FBQWVoRCxjQUFBQSxLQUFLLEVBQUU7QUFBdEIsYUFKTyxFQUtQO0FBQUVnRCxjQUFBQSxFQUFFLEVBQUUsV0FBTjtBQUFtQmhELGNBQUFBLEtBQUssRUFBRTtBQUExQixhQUxPO0FBRko7QUFIVCxTQXZGNkIsQ0FBL0I7QUF1R0FzQyxRQUFBQSxPQUFPLEtBQUssU0FBWixJQUNFTyxzQkFBc0IsQ0FBQ3BFLElBQXZCLENBQTRCO0FBQzFCcUUsVUFBQUEsUUFBUSxFQUFHLGlCQUFnQnBDLE9BQVEsV0FEVDtBQUUxQnFDLFVBQUFBLGFBQWEsRUFBRywrQkFBOEJyQyxPQUFRLEVBRjVCO0FBRzFCRixVQUFBQSxLQUFLLEVBQUU7QUFDTFYsWUFBQUEsS0FBSyxFQUFFLGlCQURGO0FBRUxWLFlBQUFBLE9BQU8sRUFBRSxDQUFDO0FBQUU0RCxjQUFBQSxFQUFFLEVBQUUsUUFBTjtBQUFnQmhELGNBQUFBLEtBQUssRUFBRTtBQUF2QixhQUFEO0FBRko7QUFIbUIsU0FBNUIsQ0FERjs7QUFVQSxjQUFNMEQsZ0JBQWdCLEdBQUcsTUFBT0MscUJBQVAsSUFBaUM7QUFDeEQsY0FBSTtBQUNGLDZCQUNFLHdDQURGLEVBRUVBLHFCQUFxQixDQUFDWixhQUZ4QixFQUdFLE9BSEY7QUFNQSxrQkFBTWEsaUJBQWlCLEdBQUcsTUFBTS9LLE9BQU8sQ0FBQzZELEtBQVIsQ0FBY0MsR0FBZCxDQUFrQkMsTUFBbEIsQ0FBeUJDLGFBQXpCLENBQXVDL0QsT0FBdkMsQ0FDOUIsS0FEOEIsRUFFOUI2SyxxQkFBcUIsQ0FBQ2IsUUFGUSxFQUc5QixFQUg4QixFQUk5QjtBQUFFaEcsY0FBQUEsU0FBUyxFQUFFckQ7QUFBYixhQUo4QixDQUFoQztBQU9BLGtCQUFNb0ssU0FBUyxHQUNiRCxpQkFBaUIsSUFDakJBLGlCQUFpQixDQUFDcEgsSUFEbEIsSUFFQW9ILGlCQUFpQixDQUFDcEgsSUFBbEIsQ0FBdUJBLElBRnZCLElBR0FvSCxpQkFBaUIsQ0FBQ3BILElBQWxCLENBQXVCQSxJQUF2QixDQUE0Qk8sY0FKOUI7O0FBS0EsZ0JBQUk4RyxTQUFKLEVBQWU7QUFDYixxQkFBTyxFQUNMLEdBQUdGLHFCQUFxQixDQUFDbkQsS0FEcEI7QUFFTHNELGdCQUFBQSxLQUFLLEVBQUVILHFCQUFxQixDQUFDVixnQkFBdEIsR0FDSFksU0FBUyxDQUFDdkUsR0FBVixDQUFjcUUscUJBQXFCLENBQUNWLGdCQUFwQyxDQURHLEdBRUhZO0FBSkMsZUFBUDtBQU1EO0FBQ0YsV0EzQkQsQ0EyQkUsT0FBT3JJLEtBQVAsRUFBYztBQUNkLDZCQUFJLHdDQUFKLEVBQThDQSxLQUFLLENBQUNGLE9BQU4sSUFBaUJFLEtBQS9ELEVBQXNFLE9BQXRFO0FBQ0Q7QUFDRixTQS9CRDs7QUFpQ0EsWUFBSW5DLElBQUosRUFBVTtBQUNSLGdCQUFNLEtBQUt1QixtQkFBTCxDQUNKL0IsT0FESSxFQUVKa0IsT0FGSSxFQUdKLFFBSEksRUFJSixjQUpJLEVBS0pOLEtBTEksRUFNSkksSUFOSSxFQU9KQyxFQVBJLEVBUUpVLGdCQUFnQixHQUFHLDRDQVJmLEVBU0poQixpQkFUSSxFQVVKa0gsT0FWSSxDQUFOO0FBWUQsU0F4TUMsQ0EwTUY7OztBQUNBLFNBQUMsTUFBTXFELE9BQU8sQ0FBQ0MsR0FBUixDQUFZbkIsc0JBQXNCLENBQUN2RCxHQUF2QixDQUEyQm9FLGdCQUEzQixDQUFaLENBQVAsRUFDR2hHLE1BREgsQ0FDVzhDLEtBQUQsSUFBV0EsS0FEckIsRUFFRzNCLE9BRkgsQ0FFWTJCLEtBQUQsSUFBV3pHLE9BQU8sQ0FBQ2tLLGNBQVIsQ0FBdUJ6RCxLQUF2QixDQUZ0QixFQTNNRSxDQStNRjs7QUFDQSxjQUFNekcsT0FBTyxDQUFDbUIsS0FBUixDQUFjckMsT0FBTyxDQUFDd0IsbUJBQVIsQ0FBNEJjLFlBQTFDLENBQU47QUFFQSxlQUFPcEMsUUFBUSxDQUFDcUMsRUFBVCxDQUFZO0FBQ2pCMUIsVUFBQUEsSUFBSSxFQUFFO0FBQ0oyQixZQUFBQSxPQUFPLEVBQUUsSUFETDtBQUVKQyxZQUFBQSxPQUFPLEVBQUcsVUFBU3pDLE9BQU8sQ0FBQ3dCLG1CQUFSLENBQTRCa0IsUUFBUztBQUZwRDtBQURXLFNBQVosQ0FBUDtBQU1ELE9BeE5ELENBd05FLE9BQU9DLEtBQVAsRUFBYztBQUNkLHlCQUFJLCtCQUFKLEVBQXFDQSxLQUFLLENBQUNGLE9BQU4sSUFBaUJFLEtBQXREO0FBQ0EsZUFBTyxrQ0FBY0EsS0FBSyxDQUFDRixPQUFOLElBQWlCRSxLQUEvQixFQUFzQyxJQUF0QyxFQUE0QyxHQUE1QyxFQUFpRHpDLFFBQWpELENBQVA7QUFDRDtBQUNGLEtBak84QixFQWlPNUIsQ0FBQztBQUFDYSxNQUFBQSxNQUFNLEVBQUU7QUFBRThHLFFBQUFBO0FBQUY7QUFBVCxLQUFELEtBQTRCLHlCQUF3QkEsT0FBUSxJQUFHLEtBQUtqRix1QkFBTCxFQUErQixNQWpPbEUsQ0F0b0RqQjs7QUFBQSw2Q0FpNkRJLEtBQUs3Qyw4Q0FBTCxDQUFvRCxPQUNwRUMsT0FEb0UsRUFFcEVDLE9BRm9FLEVBR3BFQyxRQUhvRSxLQUlqRTtBQUNILFVBQUk7QUFDRix5QkFBSSwyQkFBSixFQUFrQyxXQUFVRixPQUFPLENBQUN3QixtQkFBUixDQUE0QmMsWUFBYSxTQUFyRixFQUErRixPQUEvRjs7QUFDQSxjQUFNK0ksZ0JBQWdCLEdBQUdDLFlBQUdDLFlBQUgsQ0FBZ0J2TCxPQUFPLENBQUN3QixtQkFBUixDQUE0QmMsWUFBNUMsQ0FBekI7O0FBQ0EsZUFBT3BDLFFBQVEsQ0FBQ3FDLEVBQVQsQ0FBWTtBQUNqQmlKLFVBQUFBLE9BQU8sRUFBRTtBQUFFLDRCQUFnQjtBQUFsQixXQURRO0FBRWpCM0ssVUFBQUEsSUFBSSxFQUFFd0s7QUFGVyxTQUFaLENBQVA7QUFJRCxPQVBELENBT0UsT0FBTzFJLEtBQVAsRUFBYztBQUNkLHlCQUFJLDJCQUFKLEVBQWlDQSxLQUFLLENBQUNGLE9BQU4sSUFBaUJFLEtBQWxEO0FBQ0EsZUFBTyxrQ0FBY0EsS0FBSyxDQUFDRixPQUFOLElBQWlCRSxLQUEvQixFQUFzQyxJQUF0QyxFQUE0QyxHQUE1QyxFQUFpRHpDLFFBQWpELENBQVA7QUFDRDtBQUNGLEtBaEJpQixFQWdCZEQsT0FBRCxJQUFhQSxPQUFPLENBQUNjLE1BQVIsQ0FBZTRFLElBaEJiLENBajZESjs7QUFBQSxnREEwN0RPLEtBQUs1Riw4Q0FBTCxDQUFvRCxPQUN2RUMsT0FEdUUsRUFFdkVDLE9BRnVFLEVBR3ZFQyxRQUh1RSxLQUlwRTtBQUNILFVBQUk7QUFDRix5QkFBSSw4QkFBSixFQUFxQyxZQUFXRixPQUFPLENBQUN3QixtQkFBUixDQUE0QmMsWUFBYSxTQUF6RixFQUFtRyxPQUFuRzs7QUFDQWdKLG9CQUFHRyxVQUFILENBQWN6TCxPQUFPLENBQUN3QixtQkFBUixDQUE0QmMsWUFBMUM7O0FBQ0EseUJBQUksOEJBQUosRUFBcUMsR0FBRXRDLE9BQU8sQ0FBQ3dCLG1CQUFSLENBQTRCYyxZQUFhLHFCQUFoRixFQUFzRyxNQUF0RztBQUNBLGVBQU9wQyxRQUFRLENBQUNxQyxFQUFULENBQVk7QUFDakIxQixVQUFBQSxJQUFJLEVBQUU7QUFBRThCLFlBQUFBLEtBQUssRUFBRTtBQUFUO0FBRFcsU0FBWixDQUFQO0FBR0QsT0FQRCxDQU9FLE9BQU9BLEtBQVAsRUFBYztBQUNkLHlCQUFJLDhCQUFKLEVBQW9DQSxLQUFLLENBQUNGLE9BQU4sSUFBaUJFLEtBQXJEO0FBQ0EsZUFBTyxrQ0FBY0EsS0FBSyxDQUFDRixPQUFOLElBQWlCRSxLQUEvQixFQUFzQyxJQUF0QyxFQUE0QyxHQUE1QyxFQUFpRHpDLFFBQWpELENBQVA7QUFDRDtBQUNGLEtBaEJvQixFQWdCbEJELE9BQUQsSUFBYUEsT0FBTyxDQUFDYyxNQUFSLENBQWU0RSxJQWhCVCxDQTE3RFA7QUFBRTtBQUVoQjtBQUNGO0FBQ0E7QUFDQTtBQUNBOzs7QUFDVTlELEVBQUFBLHFCQUFxQixDQUFDdEIsT0FBRCxFQUFlRCxTQUFmLEVBQXFEO0FBQ2hGLHFCQUFJLGlDQUFKLEVBQXdDLDZCQUF4QyxFQUFzRSxNQUF0RTtBQUNBLHFCQUNFLGlDQURGLEVBRUcsWUFBV0MsT0FBTyxDQUFDNEQsTUFBTyxnQkFBZTdELFNBQVUsRUFGdEQsRUFHRSxPQUhGO0FBS0EsUUFBSW9MLEdBQUcsR0FBRyxFQUFWO0FBRUEsVUFBTTlKLFlBQWlCLEdBQUcsRUFBMUIsQ0FUZ0YsQ0FXaEY7O0FBQ0FyQixJQUFBQSxPQUFPLEdBQUdBLE9BQU8sQ0FBQ3NFLE1BQVIsQ0FBZ0JBLE1BQUQsSUFBWTtBQUNuQyxVQUFJQSxNQUFNLENBQUM4RyxJQUFQLENBQVlDLFlBQVosS0FBNkJDLDRCQUFqQyxFQUFvRDtBQUNsRGpLLFFBQUFBLFlBQVksQ0FBQ2dFLElBQWIsQ0FBa0JmLE1BQWxCO0FBQ0EsZUFBTyxLQUFQO0FBQ0Q7O0FBQ0QsYUFBT0EsTUFBUDtBQUNELEtBTlMsQ0FBVjtBQVFBLFVBQU1pSCxHQUFHLEdBQUd2TCxPQUFPLENBQUM0RCxNQUFwQjs7QUFFQSxTQUFLLElBQUltQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHd0YsR0FBcEIsRUFBeUJ4RixDQUFDLEVBQTFCLEVBQThCO0FBQzVCLFlBQU07QUFBRXlGLFFBQUFBLE1BQUY7QUFBVXBGLFFBQUFBLEdBQVY7QUFBZXFGLFFBQUFBLEtBQWY7QUFBc0JqTCxRQUFBQSxNQUF0QjtBQUE4Qm1HLFFBQUFBO0FBQTlCLFVBQXVDM0csT0FBTyxDQUFDK0YsQ0FBRCxDQUFQLENBQVdxRixJQUF4RDtBQUNBRCxNQUFBQSxHQUFHLElBQUssR0FBRUssTUFBTSxHQUFHLE1BQUgsR0FBWSxFQUFHLEVBQS9CO0FBQ0FMLE1BQUFBLEdBQUcsSUFBSyxHQUFFL0UsR0FBSSxJQUFkO0FBQ0ErRSxNQUFBQSxHQUFHLElBQUssR0FDTnhFLElBQUksS0FBSyxPQUFULEdBQ0ssR0FBRW5HLE1BQU0sQ0FBQ2tMLEdBQUksSUFBR2xMLE1BQU0sQ0FBQ21MLEVBQUcsRUFEL0IsR0FFSWhGLElBQUksS0FBSyxTQUFULEdBQ0UsTUFBTW5HLE1BQU0sQ0FBQ1EsSUFBUCxDQUFZLE1BQVosQ0FBTixHQUE0QixHQUQ5QixHQUVFMkYsSUFBSSxLQUFLLFFBQVQsR0FDRSxHQURGLEdBRUUsQ0FBQyxDQUFDOEUsS0FBRixHQUNKQSxLQURJLEdBRUosQ0FBQ2pMLE1BQU0sSUFBSSxFQUFYLEVBQWVvTCxLQUNwQixFQVZEO0FBV0FULE1BQUFBLEdBQUcsSUFBSyxHQUFFcEYsQ0FBQyxLQUFLd0YsR0FBRyxHQUFHLENBQVosR0FBZ0IsRUFBaEIsR0FBcUIsT0FBUSxFQUF2QztBQUNEOztBQUVELFFBQUl4TCxTQUFKLEVBQWU7QUFDYm9MLE1BQUFBLEdBQUcsSUFBSyxTQUFTcEwsU0FBVSxHQUEzQjtBQUNEOztBQUVELFVBQU04TCxlQUFlLEdBQUd4SyxZQUFZLENBQUM2RSxHQUFiLENBQWtCNUIsTUFBRCxJQUFZQSxNQUFNLENBQUM4RyxJQUFQLENBQVlLLEtBQXpDLEVBQWdEekssSUFBaEQsQ0FBcUQsR0FBckQsQ0FBeEI7QUFFQSxxQkFDRSxpQ0FERixFQUVHLFFBQU9tSyxHQUFJLHNCQUFxQlUsZUFBZ0IsRUFGbkQsRUFHRSxPQUhGO0FBTUEsV0FBTyxDQUFDVixHQUFELEVBQU1VLGVBQU4sQ0FBUDtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQzRCLFFBQVoxSyxZQUFZLENBQUMxQixPQUFELEVBQVVrQixPQUFWLEVBQW1CUixPQUFuQixFQUE0QjJMLEdBQTVCLEVBQWlDQyxRQUFqQyxFQUEyQzFMLEtBQTNDLEVBQWtEO0FBQzFFLFFBQUk7QUFDRix1QkFDRSx3QkFERixFQUVHLFlBQVdGLE9BQVEsVUFBUzJMLEdBQUksZUFBY0MsUUFBUyxZQUFXMUwsS0FBTSxFQUYzRSxFQUdFLE9BSEY7O0FBS0EsVUFBSUYsT0FBTyxJQUFJLE9BQU9BLE9BQVAsS0FBbUIsUUFBbEMsRUFBNEM7QUFDMUMsWUFBSSxDQUFDLENBQUMsYUFBRCxFQUFnQixhQUFoQixFQUErQjBHLFFBQS9CLENBQXdDMUcsT0FBeEMsQ0FBTCxFQUF1RDtBQUNyRFEsVUFBQUEsT0FBTyxDQUFDc0MsVUFBUixDQUFtQjtBQUNqQkMsWUFBQUEsSUFBSSxFQUFFOEksNEJBQWNGLEdBQWQsRUFBbUJwRixLQUFuQixHQUEyQixTQURoQjtBQUVqQnZELFlBQUFBLEtBQUssRUFBRTtBQUZVLFdBQW5CO0FBSUQsU0FMRCxNQUtPLElBQUloRCxPQUFPLEtBQUssYUFBaEIsRUFBK0I7QUFDcENRLFVBQUFBLE9BQU8sQ0FBQ3NDLFVBQVIsQ0FBbUI7QUFDakJDLFlBQUFBLElBQUksRUFBRyxTQUFRNkksUUFBUyxnQkFEUDtBQUVqQjVJLFlBQUFBLEtBQUssRUFBRTtBQUZVLFdBQW5CO0FBSUQsU0FMTSxNQUtBLElBQUloRCxPQUFPLEtBQUssYUFBaEIsRUFBK0I7QUFDcENRLFVBQUFBLE9BQU8sQ0FBQ3NDLFVBQVIsQ0FBbUI7QUFDakJDLFlBQUFBLElBQUksRUFBRSxpQkFEVztBQUVqQkMsWUFBQUEsS0FBSyxFQUFFO0FBRlUsV0FBbkI7QUFJRDs7QUFDRHhDLFFBQUFBLE9BQU8sQ0FBQ3NMLFVBQVI7QUFDRDs7QUFFRCxVQUFJRixRQUFRLElBQUksT0FBT0EsUUFBUCxLQUFvQixRQUFwQyxFQUE4QztBQUM1QyxjQUFNLEtBQUt2QyxnQkFBTCxDQUNKL0osT0FESSxFQUVKa0IsT0FGSSxFQUdKb0wsUUFISSxFQUlKMUwsS0FKSSxFQUtKRixPQUFPLEtBQUssYUFBWixHQUE0QjJMLEdBQTVCLEdBQWtDLEVBTDlCLENBQU47QUFPRDs7QUFFRCxVQUFJQyxRQUFRLElBQUksT0FBT0EsUUFBUCxLQUFvQixRQUFwQyxFQUE4QztBQUM1QyxjQUFNNUMsYUFBYSxHQUFHLE1BQU0xSixPQUFPLENBQUM2RCxLQUFSLENBQWNDLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCQyxhQUF6QixDQUF1Qy9ELE9BQXZDLENBQzFCLEtBRDBCLEVBRXpCLFNBRnlCLEVBRzFCO0FBQUVjLFVBQUFBLE1BQU0sRUFBRTtBQUFFMEwsWUFBQUEsV0FBVyxFQUFFSDtBQUFmO0FBQVYsU0FIMEIsRUFJMUI7QUFBRXJJLFVBQUFBLFNBQVMsRUFBRXJEO0FBQWIsU0FKMEIsQ0FBNUI7QUFNQSxjQUFNOEwsU0FBUyxHQUFHaEQsYUFBYSxDQUFDL0YsSUFBZCxDQUFtQkEsSUFBbkIsQ0FBd0JPLGNBQXhCLENBQXVDLENBQXZDLENBQWxCOztBQUNBLFlBQUl3SSxTQUFTLElBQUlBLFNBQVMsQ0FBQ0MsTUFBVixLQUFxQkMsaUNBQXNCQyxNQUE1RCxFQUFvRTtBQUNsRTNMLFVBQUFBLE9BQU8sQ0FBQzRJLHFCQUFSLENBQThCO0FBQzVCckcsWUFBQUEsSUFBSSxFQUFHLHFCQUFvQixvREFBOEJpSixTQUFTLENBQUNDLE1BQXhDLEVBQWdEdkQsV0FBaEQsRUFBOEQsRUFEN0Q7QUFFNUIxRixZQUFBQSxLQUFLLEVBQUU7QUFGcUIsV0FBOUI7QUFJRDs7QUFDRCxjQUFNLEtBQUtxRyxnQkFBTCxDQUFzQi9KLE9BQXRCLEVBQStCa0IsT0FBL0IsRUFBd0MsQ0FBQ29MLFFBQUQsQ0FBeEMsRUFBb0QxTCxLQUFwRCxDQUFOOztBQUVBLFlBQUk4TCxTQUFTLElBQUlBLFNBQVMsQ0FBQ3ZHLEtBQTNCLEVBQWtDO0FBQ2hDLGdCQUFNMkcsV0FBVyxHQUFHSixTQUFTLENBQUN2RyxLQUFWLENBQWdCNUUsSUFBaEIsQ0FBcUIsSUFBckIsQ0FBcEI7QUFDQUwsVUFBQUEsT0FBTyxDQUFDNEkscUJBQVIsQ0FBOEI7QUFDNUJyRyxZQUFBQSxJQUFJLEVBQUcsUUFBT2lKLFNBQVMsQ0FBQ3ZHLEtBQVYsQ0FBZ0JoQyxNQUFoQixHQUF5QixDQUF6QixHQUE2QixHQUE3QixHQUFtQyxFQUFHLEtBQUkySSxXQUFZLEVBRHhDO0FBRTVCcEosWUFBQUEsS0FBSyxFQUFFO0FBRnFCLFdBQTlCO0FBSUQ7QUFDRjs7QUFDRCxVQUFJNkksNEJBQWNGLEdBQWQsS0FBc0JFLDRCQUFjRixHQUFkLEVBQW1CVSxXQUE3QyxFQUEwRDtBQUN4RDdMLFFBQUFBLE9BQU8sQ0FBQzRJLHFCQUFSLENBQThCO0FBQzVCckcsVUFBQUEsSUFBSSxFQUFFOEksNEJBQWNGLEdBQWQsRUFBbUJVLFdBREc7QUFFNUJySixVQUFBQSxLQUFLLEVBQUU7QUFGcUIsU0FBOUI7QUFJRDtBQUNGLEtBbEVELENBa0VFLE9BQU9mLEtBQVAsRUFBYztBQUNkLHVCQUFJLHdCQUFKLEVBQThCQSxLQUFLLENBQUNGLE9BQU4sSUFBaUJFLEtBQS9DO0FBQ0EsYUFBT3VJLE9BQU8sQ0FBQzhCLE1BQVIsQ0FBZXJLLEtBQWYsQ0FBUDtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBOzs7QUFDZ0MsUUFBaEJvSCxnQkFBZ0IsQ0FBQy9KLE9BQUQsRUFBVWtCLE9BQVYsRUFBa0MrTCxRQUFsQyxFQUFzRHJNLEtBQXRELEVBQXFFa0MsT0FBZSxHQUFHLEVBQXZGLEVBQTJGO0FBQ3ZILFVBQU1vSyxVQUFVLEdBQUcsTUFBTWxOLE9BQU8sQ0FBQ21OLElBQVIsQ0FBYUMsVUFBYixDQUF3QnJKLE1BQXhCLENBQStCc0osR0FBL0IsQ0FBbUMsWUFBbkMsQ0FBekI7QUFDQSxRQUFJLENBQUMsQ0FBQ0osUUFBRCxJQUFhLENBQUNBLFFBQVEsQ0FBQzlJLE1BQXhCLEtBQW1DLENBQUNyQixPQUF4QyxFQUFpRDtBQUNqRCxxQkFBSSw0QkFBSixFQUFtQyxHQUFFbUssUUFBUSxDQUFDOUksTUFBTyxtQkFBa0J2RCxLQUFNLEVBQTdFLEVBQWdGLE1BQWhGOztBQUNBLFFBQUk7QUFDRixVQUFJME0sVUFBVSxHQUFHLEVBQWpCOztBQUNBLFVBQUl4SyxPQUFKLEVBQWE7QUFDWCxZQUFJeUssa0JBQWtCLEdBQUcsSUFBekI7O0FBQ0EsV0FBRTtBQUNBLGdCQUFNO0FBQUU1SixZQUFBQSxJQUFJLEVBQUU7QUFBRUEsY0FBQUEsSUFBSSxFQUFFO0FBQUVPLGdCQUFBQSxjQUFGO0FBQWtCc0osZ0JBQUFBO0FBQWxCO0FBQVI7QUFBUixjQUErRCxNQUFNeE4sT0FBTyxDQUFDNkQsS0FBUixDQUFjQyxHQUFkLENBQWtCQyxNQUFsQixDQUF5QkMsYUFBekIsQ0FBdUMvRCxPQUF2QyxDQUN6RSxLQUR5RSxFQUV4RSxXQUFVNkMsT0FBUSxTQUZzRCxFQUd6RTtBQUNFL0IsWUFBQUEsTUFBTSxFQUFFO0FBQ04wTSxjQUFBQSxNQUFNLEVBQUVILFVBQVUsQ0FBQ25KLE1BRGI7QUFFTnVKLGNBQUFBLE1BQU0sRUFBRTtBQUZGO0FBRFYsV0FIeUUsRUFTekU7QUFBRXpKLFlBQUFBLFNBQVMsRUFBRXJEO0FBQWIsV0FUeUUsQ0FBM0U7QUFXQSxXQUFDMk0sa0JBQUQsS0FBd0JBLGtCQUFrQixHQUFHQyxvQkFBN0M7QUFDQUYsVUFBQUEsVUFBVSxHQUFHLENBQUMsR0FBR0EsVUFBSixFQUFnQixHQUFHcEosY0FBbkIsQ0FBYjtBQUNELFNBZEQsUUFjT29KLFVBQVUsQ0FBQ25KLE1BQVgsR0FBb0JvSixrQkFkM0I7QUFlRCxPQWpCRCxNQWlCTztBQUNMLGFBQUssTUFBTTFGLE9BQVgsSUFBc0JvRixRQUF0QixFQUFnQztBQUM5QixjQUFJO0FBQ0Ysa0JBQU07QUFBRXRKLGNBQUFBLElBQUksRUFBRTtBQUFFQSxnQkFBQUEsSUFBSSxFQUFFO0FBQUVPLGtCQUFBQSxjQUFjLEVBQUUsQ0FBQ3lKLEtBQUQ7QUFBbEI7QUFBUjtBQUFSLGdCQUFrRCxNQUFNM04sT0FBTyxDQUFDNkQsS0FBUixDQUFjQyxHQUFkLENBQWtCQyxNQUFsQixDQUF5QkMsYUFBekIsQ0FBdUMvRCxPQUF2QyxDQUM1RCxLQUQ0RCxFQUUzRCxTQUYyRCxFQUc1RDtBQUNFYyxjQUFBQSxNQUFNLEVBQUU7QUFDTjRJLGdCQUFBQSxDQUFDLEVBQUcsTUFBSzlCLE9BQVEsRUFEWDtBQUVONkYsZ0JBQUFBLE1BQU0sRUFBRTtBQUZGO0FBRFYsYUFINEQsRUFTNUQ7QUFBRXpKLGNBQUFBLFNBQVMsRUFBRXJEO0FBQWIsYUFUNEQsQ0FBOUQ7QUFXQTBNLFlBQUFBLFVBQVUsQ0FBQzFILElBQVgsQ0FBZ0IrSCxLQUFoQjtBQUNELFdBYkQsQ0FhRSxPQUFPaEwsS0FBUCxFQUFjO0FBQ2QsNkJBQ0UsNEJBREYsRUFFRyxzQkFBcUJBLEtBQUssQ0FBQ0YsT0FBTixJQUFpQkUsS0FBTSxFQUYvQyxFQUdFLE9BSEY7QUFLRDtBQUNGO0FBQ0Y7O0FBRUQsVUFBRzJLLFVBQVUsQ0FBQ25KLE1BQWQsRUFBcUI7QUFDbkI7QUFDQWpELFFBQUFBLE9BQU8sQ0FBQ2tLLGNBQVIsQ0FBdUI7QUFDckI3RSxVQUFBQSxPQUFPLEVBQUUsQ0FDUDtBQUFFNEQsWUFBQUEsRUFBRSxFQUFFLElBQU47QUFBWWhELFlBQUFBLEtBQUssRUFBRTtBQUFuQixXQURPLEVBRVA7QUFBRWdELFlBQUFBLEVBQUUsRUFBRSxNQUFOO0FBQWNoRCxZQUFBQSxLQUFLLEVBQUU7QUFBckIsV0FGTyxFQUdQO0FBQUVnRCxZQUFBQSxFQUFFLEVBQUUsSUFBTjtBQUFZaEQsWUFBQUEsS0FBSyxFQUFFO0FBQW5CLFdBSE8sRUFJUDtBQUFFZ0QsWUFBQUEsRUFBRSxFQUFFLFNBQU47QUFBaUJoRCxZQUFBQSxLQUFLLEVBQUU7QUFBeEIsV0FKTyxFQUtQO0FBQUVnRCxZQUFBQSxFQUFFLEVBQUUsU0FBTjtBQUFpQmhELFlBQUFBLEtBQUssRUFBRTtBQUF4QixXQUxPLEVBTVA7QUFBRWdELFlBQUFBLEVBQUUsRUFBRSxJQUFOO0FBQVloRCxZQUFBQSxLQUFLLEVBQUU7QUFBbkIsV0FOTyxFQU9QO0FBQUVnRCxZQUFBQSxFQUFFLEVBQUUsU0FBTjtBQUFpQmhELFlBQUFBLEtBQUssRUFBRTtBQUF4QixXQVBPLEVBUVA7QUFBRWdELFlBQUFBLEVBQUUsRUFBRSxlQUFOO0FBQXVCaEQsWUFBQUEsS0FBSyxFQUFFO0FBQTlCLFdBUk8sQ0FEWTtBQVdyQjhELFVBQUFBLEtBQUssRUFBRXFDLFVBQVUsQ0FBQzdHLEdBQVgsQ0FBZ0JrSCxLQUFELElBQVc7QUFDL0IsbUJBQU8sRUFDTCxHQUFHQSxLQURFO0FBRUwvRCxjQUFBQSxFQUFFLEVBQUcrRCxLQUFLLENBQUMvRCxFQUFOLElBQVkrRCxLQUFLLENBQUMvRCxFQUFOLENBQVNqRSxJQUFyQixJQUE2QmdJLEtBQUssQ0FBQy9ELEVBQU4sQ0FBU2dFLE9BQXZDLEdBQW1ELEdBQUVELEtBQUssQ0FBQy9ELEVBQU4sQ0FBU2pFLElBQUssSUFBR2dJLEtBQUssQ0FBQy9ELEVBQU4sQ0FBU2dFLE9BQVEsRUFBdkYsR0FBMkYsRUFGMUY7QUFHTEMsY0FBQUEsYUFBYSxFQUFFLHFCQUFPRixLQUFLLENBQUNFLGFBQWIsRUFBNEJDLE1BQTVCLENBQW1DWixVQUFuQyxDQUhWO0FBSUxhLGNBQUFBLE9BQU8sRUFBRSxxQkFBT0osS0FBSyxDQUFDSSxPQUFiLEVBQXNCRCxNQUF0QixDQUE2QlosVUFBN0I7QUFKSixhQUFQO0FBTUQsV0FQTTtBQVhjLFNBQXZCO0FBb0JELE9BdEJELE1Bc0JNLElBQUcsQ0FBQ0ksVUFBVSxDQUFDbkosTUFBWixJQUFzQnJCLE9BQXpCLEVBQWlDO0FBQ3JDO0FBQ0E1QixRQUFBQSxPQUFPLENBQUNzQyxVQUFSLENBQW1CO0FBQ2pCQyxVQUFBQSxJQUFJLEVBQUUsb0NBRFc7QUFFakJDLFVBQUFBLEtBQUssRUFBRTtBQUFFYSxZQUFBQSxRQUFRLEVBQUUsRUFBWjtBQUFnQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXZCO0FBRlUsU0FBbkI7QUFJRDtBQUVGLEtBMUVELENBMEVFLE9BQU83QixLQUFQLEVBQWM7QUFDZCx1QkFBSSw0QkFBSixFQUFrQ0EsS0FBSyxDQUFDRixPQUFOLElBQWlCRSxLQUFuRDtBQUNBLGFBQU91SSxPQUFPLENBQUM4QixNQUFSLENBQWVySyxLQUFmLENBQVA7QUFDRDtBQUNGO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ21DLFFBQW5CWixtQkFBbUIsQ0FDL0IvQixPQUQrQixFQUUvQmtCLE9BRitCLEVBRy9CUixPQUgrQixFQUkvQjJMLEdBSitCLEVBSy9CekwsS0FMK0IsRUFNL0JJLElBTitCLEVBTy9CQyxFQVArQixFQVEvQlYsT0FSK0IsRUFTL0J5TixPQUFPLEdBQUdDLCtCQVRxQixFQVUvQk4sS0FBSyxHQUFHLElBVnVCLEVBVy9CO0FBQ0EsUUFBSTtBQUNGLHVCQUNFLCtCQURGLEVBRUcsV0FBVWpOLE9BQVEsWUFBVzJMLEdBQUksWUFBV3pMLEtBQU0sVUFBU0ksSUFBSyxPQUFNQyxFQUFHLGFBQVlWLE9BQVEsbUJBQWtCeU4sT0FBUSxFQUYxSCxFQUdFLE1BSEY7O0FBS0EsVUFBSXROLE9BQU8sS0FBSyxRQUFaLElBQXdCLENBQUNpTixLQUE3QixFQUFvQztBQUNsQyxjQUFNLElBQUlPLEtBQUosQ0FBVSwwRUFBVixDQUFOO0FBQ0Q7O0FBRUQsWUFBTTlOLE1BQU0sR0FBRyxNQUFNSixPQUFPLENBQUM2RCxLQUFSLENBQWNDLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCQyxhQUF6QixDQUF1Qy9ELE9BQXZDLENBQ25CLEtBRG1CLEVBRW5CLFNBRm1CLEVBR25CO0FBQUVjLFFBQUFBLE1BQU0sRUFBRTtBQUFFb04sVUFBQUEsS0FBSyxFQUFFO0FBQVQ7QUFBVixPQUhtQixFQUluQjtBQUFFbEssUUFBQUEsU0FBUyxFQUFFckQ7QUFBYixPQUptQixDQUFyQjtBQU9BLFlBQU13TixXQUFXLEdBQUdoTyxNQUFNLENBQUN1RCxJQUFQLENBQVlBLElBQVosQ0FBaUI2SixvQkFBckM7O0FBRUEsVUFBSTlNLE9BQU8sS0FBSyxVQUFaLElBQTBCMkwsR0FBRyxLQUFLLE1BQXRDLEVBQThDO0FBQzVDLHlCQUNFLCtCQURGLEVBRUUsa0RBRkYsRUFHRSxPQUhGO0FBS0EsY0FBTWdDLHFCQUFxQixHQUFHLENBQUMsS0FBRCxFQUFRLFFBQVIsRUFBa0IsTUFBbEIsRUFBMEIsVUFBMUIsQ0FBOUI7QUFFQSxjQUFNQyw2QkFBNkIsR0FBRyxDQUNwQyxNQUFNcEQsT0FBTyxDQUFDQyxHQUFSLENBQ0prRCxxQkFBcUIsQ0FBQzVILEdBQXRCLENBQTBCLE1BQU84SCxvQkFBUCxJQUFnQztBQUN4RCxjQUFJO0FBQ0Ysa0JBQU1DLEtBQUssR0FBRyxNQUFNQyxvQkFBb0IsQ0FBQ0MsbUJBQXJCLENBQ2xCMU8sT0FEa0IsRUFFbEJnQixJQUZrQixFQUdsQkMsRUFIa0IsRUFJbEJzTixvQkFKa0IsRUFLbEJoTyxPQUxrQixFQU1sQnlOLE9BTmtCLENBQXBCO0FBUUEsbUJBQU9RLEtBQUssR0FDUCxHQUFFQSxLQUFNLE9BQU1KLFdBQVksZ0JBQWVHLG9CQUFvQixDQUFDSSxpQkFBckIsRUFBeUMsbUJBRDNFLEdBRVJDLFNBRko7QUFHRCxXQVpELENBWUUsT0FBT2pNLEtBQVAsRUFBYyxDQUFFO0FBQ25CLFNBZEQsQ0FESSxDQUQ4QixFQWtCcENrQyxNQWxCb0MsQ0FrQjVCZ0ssdUJBQUQsSUFBNkJBLHVCQWxCQSxDQUF0QztBQW9CQTNOLFFBQUFBLE9BQU8sQ0FBQzROLE9BQVIsQ0FBZ0I7QUFDZDdILFVBQUFBLEtBQUssRUFBRTtBQUFFeEQsWUFBQUEsSUFBSSxFQUFFLFNBQVI7QUFBbUJDLFlBQUFBLEtBQUssRUFBRTtBQUExQixXQURPO0FBRWRxTCxVQUFBQSxJQUFJLEVBQUVUO0FBRlEsU0FBaEI7QUFLQSx5QkFDRSwrQkFERixFQUVFLG1FQUZGLEVBR0UsT0FIRjtBQUtBLGNBQU1VLE9BQU8sR0FBRyxNQUFNUCxvQkFBb0IsQ0FBQ1EsYUFBckIsQ0FDcEJqUCxPQURvQixFQUVwQmdCLElBRm9CLEVBR3BCQyxFQUhvQixFQUlwQixLQUpvQixFQUtwQlYsT0FMb0IsRUFNcEJ5TixPQU5vQixDQUF0QjtBQVFBLGNBQU1rQixVQUFVLEdBQUcsTUFBTVQsb0JBQW9CLENBQUNRLGFBQXJCLENBQ3ZCalAsT0FEdUIsRUFFdkJnQixJQUZ1QixFQUd2QkMsRUFIdUIsRUFJdkIsUUFKdUIsRUFLdkJWLE9BTHVCLEVBTXZCeU4sT0FOdUIsQ0FBekI7QUFRQSxjQUFNbUIsUUFBUSxHQUFHLE1BQU1WLG9CQUFvQixDQUFDUSxhQUFyQixDQUNyQmpQLE9BRHFCLEVBRXJCZ0IsSUFGcUIsRUFHckJDLEVBSHFCLEVBSXJCLE1BSnFCLEVBS3JCVixPQUxxQixFQU1yQnlOLE9BTnFCLENBQXZCO0FBUUEsY0FBTW9CLFlBQVksR0FBRyxNQUFNWCxvQkFBb0IsQ0FBQ1EsYUFBckIsQ0FDekJqUCxPQUR5QixFQUV6QmdCLElBRnlCLEVBR3pCQyxFQUh5QixFQUl6QixVQUp5QixFQUt6QlYsT0FMeUIsRUFNekJ5TixPQU55QixDQUEzQjtBQVFBLHlCQUNFLCtCQURGLEVBRUUsaUVBRkYsRUFHRSxPQUhGOztBQUtBLFlBQUlvQixZQUFZLElBQUlBLFlBQVksQ0FBQ2pMLE1BQWpDLEVBQXlDO0FBQ3ZDakQsVUFBQUEsT0FBTyxDQUFDNEkscUJBQVIsQ0FBOEI7QUFDNUJyRyxZQUFBQSxJQUFJLEVBQUUscURBRHNCO0FBRTVCQyxZQUFBQSxLQUFLLEVBQUU7QUFGcUIsV0FBOUI7QUFJQSxnQkFBTSxLQUFLcUcsZ0JBQUwsQ0FBc0IvSixPQUF0QixFQUErQmtCLE9BQS9CLEVBQXdDa08sWUFBeEMsRUFBc0R4TyxLQUF0RCxDQUFOO0FBQ0FNLFVBQUFBLE9BQU8sQ0FBQ3NMLFVBQVI7QUFDRDs7QUFFRCxZQUFJMkMsUUFBUSxJQUFJQSxRQUFRLENBQUNoTCxNQUF6QixFQUFpQztBQUMvQmpELFVBQUFBLE9BQU8sQ0FBQzRJLHFCQUFSLENBQThCO0FBQzVCckcsWUFBQUEsSUFBSSxFQUFFLGlEQURzQjtBQUU1QkMsWUFBQUEsS0FBSyxFQUFFO0FBRnFCLFdBQTlCO0FBSUEsZ0JBQU0sS0FBS3FHLGdCQUFMLENBQXNCL0osT0FBdEIsRUFBK0JrQixPQUEvQixFQUF3Q2lPLFFBQXhDLEVBQWtEdk8sS0FBbEQsQ0FBTjtBQUNBTSxVQUFBQSxPQUFPLENBQUNzTCxVQUFSO0FBQ0Q7O0FBRUQsWUFBSTBDLFVBQVUsSUFBSUEsVUFBVSxDQUFDL0ssTUFBN0IsRUFBcUM7QUFDbkNqRCxVQUFBQSxPQUFPLENBQUM0SSxxQkFBUixDQUE4QjtBQUM1QnJHLFlBQUFBLElBQUksRUFBRSxtREFEc0I7QUFFNUJDLFlBQUFBLEtBQUssRUFBRTtBQUZxQixXQUE5QjtBQUlBLGdCQUFNLEtBQUtxRyxnQkFBTCxDQUFzQi9KLE9BQXRCLEVBQStCa0IsT0FBL0IsRUFBd0NnTyxVQUF4QyxFQUFvRHRPLEtBQXBELENBQU47QUFDQU0sVUFBQUEsT0FBTyxDQUFDc0wsVUFBUjtBQUNEOztBQUVELFlBQUl3QyxPQUFPLElBQUlBLE9BQU8sQ0FBQzdLLE1BQXZCLEVBQStCO0FBQzdCakQsVUFBQUEsT0FBTyxDQUFDNEkscUJBQVIsQ0FBOEI7QUFDNUJyRyxZQUFBQSxJQUFJLEVBQUUsZ0RBRHNCO0FBRTVCQyxZQUFBQSxLQUFLLEVBQUU7QUFGcUIsV0FBOUI7QUFJQSxnQkFBTSxLQUFLcUcsZ0JBQUwsQ0FBc0IvSixPQUF0QixFQUErQmtCLE9BQS9CLEVBQXdDOE4sT0FBeEMsRUFBaURwTyxLQUFqRCxDQUFOO0FBQ0FNLFVBQUFBLE9BQU8sQ0FBQ3NMLFVBQVI7QUFDRDs7QUFFRCx5QkFDRSwrQkFERixFQUVFLHFEQUZGLEVBR0UsT0FIRjtBQUtBLGNBQU02QyxPQUFPLEdBQUcsTUFBTVosb0JBQW9CLENBQUNhLFdBQXJCLENBQWlDdFAsT0FBakMsRUFBMENnQixJQUExQyxFQUFnREMsRUFBaEQsRUFBb0RWLE9BQXBELEVBQTZEeU4sT0FBN0QsQ0FBdEI7QUFDQSx5QkFDRSwrQkFERixFQUVFLG1EQUZGLEVBR0UsT0FIRjs7QUFLQSxZQUFJcUIsT0FBTyxJQUFJQSxPQUFPLENBQUNsTCxNQUF2QixFQUErQjtBQUM3QmpELFVBQUFBLE9BQU8sQ0FBQ2tLLGNBQVIsQ0FBdUI7QUFDckJuRSxZQUFBQSxLQUFLLEVBQUU7QUFBRXhELGNBQUFBLElBQUksRUFBRSxXQUFSO0FBQXFCQyxjQUFBQSxLQUFLLEVBQUU7QUFBNUIsYUFEYztBQUVyQjZDLFlBQUFBLE9BQU8sRUFBRSxDQUNQO0FBQUU0RCxjQUFBQSxFQUFFLEVBQUUsS0FBTjtBQUFhaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXBCLGFBRE8sRUFFUDtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLEtBQU47QUFBYWhELGNBQUFBLEtBQUssRUFBRTtBQUFwQixhQUZPLENBRlk7QUFNckI4RCxZQUFBQSxLQUFLLEVBQUVvRSxPQUFPLENBQUM1SSxHQUFSLENBQWE0RCxJQUFELEtBQVc7QUFBRWtGLGNBQUFBLEdBQUcsRUFBRUYsT0FBTyxDQUFDbEcsT0FBUixDQUFnQmtCLElBQWhCLElBQXdCLENBQS9CO0FBQWtDbUYsY0FBQUEsR0FBRyxFQUFFbkY7QUFBdkMsYUFBWCxDQUFaO0FBTmMsV0FBdkI7QUFRRDtBQUNGOztBQUVELFVBQUkzSixPQUFPLEtBQUssVUFBWixJQUEwQjJMLEdBQUcsS0FBSyxTQUF0QyxFQUFpRDtBQUMvQyx5QkFBSSwrQkFBSixFQUFxQyw0Q0FBckMsRUFBbUYsT0FBbkY7QUFFQSxjQUFNb0QsV0FBVyxHQUFHLE1BQU1DLGVBQWUsQ0FBQ0MsVUFBaEIsQ0FBMkIzUCxPQUEzQixFQUFvQ2dCLElBQXBDLEVBQTBDQyxFQUExQyxFQUE4Q1YsT0FBOUMsRUFBdUR5TixPQUF2RCxDQUExQjtBQUVBLHlCQUFJLCtCQUFKLEVBQXFDLDBDQUFyQyxFQUFpRixPQUFqRjs7QUFDQSxZQUFJeUIsV0FBVyxDQUFDdEwsTUFBaEIsRUFBd0I7QUFDdEJqRCxVQUFBQSxPQUFPLENBQUNzQyxVQUFSLENBQW1CO0FBQ2pCQyxZQUFBQSxJQUFJLEVBQUUsbUNBRFc7QUFFakJDLFlBQUFBLEtBQUssRUFBRTtBQUZVLFdBQW5CO0FBSUEsZ0JBQU0sS0FBS3FHLGdCQUFMLENBQXNCL0osT0FBdEIsRUFBK0JrQixPQUEvQixFQUF3Q3VPLFdBQXhDLEVBQXFEN08sS0FBckQsQ0FBTjtBQUNEO0FBQ0Y7O0FBRUQsVUFBSUYsT0FBTyxLQUFLLFVBQVosSUFBMEIyTCxHQUFHLEtBQUssSUFBdEMsRUFBNEM7QUFDMUMseUJBQUksK0JBQUosRUFBcUMsK0JBQXJDLEVBQXNFLE9BQXRFO0FBQ0EsY0FBTXVELGdCQUFnQixHQUFHLE1BQU1DLGdCQUFnQixDQUFDQyxvQkFBakIsQ0FDN0I5UCxPQUQ2QixFQUU3QmdCLElBRjZCLEVBRzdCQyxFQUg2QixFQUk3QlYsT0FKNkIsRUFLN0J5TixPQUw2QixDQUEvQjtBQU9BLHlCQUFJLCtCQUFKLEVBQXFDLDZCQUFyQyxFQUFvRSxPQUFwRTs7QUFDQSxZQUFJNEIsZ0JBQWdCLElBQUlBLGdCQUFnQixDQUFDekwsTUFBekMsRUFBaUQ7QUFDL0NqRCxVQUFBQSxPQUFPLENBQ0o0SSxxQkFESCxDQUN5QjtBQUNyQnJHLFlBQUFBLElBQUksRUFBRSw4Q0FEZTtBQUVyQkMsWUFBQUEsS0FBSyxFQUFFO0FBRmMsV0FEekIsRUFLR29HLHFCQUxILENBS3lCO0FBQ3JCckcsWUFBQUEsSUFBSSxFQUNGLG9JQUZtQjtBQUdyQkMsWUFBQUEsS0FBSyxFQUFFO0FBSGMsV0FMekIsRUFVRzBILGNBVkgsQ0FVa0I7QUFDZEgsWUFBQUEsS0FBSyxFQUFFMkUsZ0JBQWdCLENBQUNuSixHQUFqQixDQUFzQjRELElBQUQsSUFBVTtBQUNwQyxxQkFBTztBQUFFa0YsZ0JBQUFBLEdBQUcsRUFBRUssZ0JBQWdCLENBQUN6RyxPQUFqQixDQUF5QmtCLElBQXpCLElBQWlDLENBQXhDO0FBQTJDMUUsZ0JBQUFBLElBQUksRUFBRTBFO0FBQWpELGVBQVA7QUFDRCxhQUZNLENBRE87QUFJZDlELFlBQUFBLE9BQU8sRUFBRSxDQUNQO0FBQUU0RCxjQUFBQSxFQUFFLEVBQUUsS0FBTjtBQUFhaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXBCLGFBRE8sRUFFUDtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLE1BQU47QUFBY2hELGNBQUFBLEtBQUssRUFBRTtBQUFyQixhQUZPO0FBSkssV0FWbEI7QUFtQkQ7O0FBQ0QseUJBQUksK0JBQUosRUFBcUMsc0JBQXJDLEVBQTZELE9BQTdEO0FBQ0EsY0FBTTRJLFVBQVUsR0FBRyxNQUFNRixnQkFBZ0IsQ0FBQ0csb0JBQWpCLENBQ3ZCaFEsT0FEdUIsRUFFdkJnQixJQUZ1QixFQUd2QkMsRUFIdUIsRUFJdkJWLE9BSnVCLEVBS3ZCeU4sT0FMdUIsQ0FBekI7QUFPQStCLFFBQUFBLFVBQVUsSUFDUjdPLE9BQU8sQ0FBQ3NDLFVBQVIsQ0FBbUI7QUFDakJDLFVBQUFBLElBQUksRUFBRyxHQUFFc00sVUFBVyxPQUFNM0IsV0FBWSwrQkFEckI7QUFFakIxSyxVQUFBQSxLQUFLLEVBQUU7QUFGVSxTQUFuQixDQURGO0FBS0EsU0FBQ3FNLFVBQUQsSUFDRTdPLE9BQU8sQ0FBQzRJLHFCQUFSLENBQThCO0FBQzVCckcsVUFBQUEsSUFBSSxFQUFHLGlDQURxQjtBQUU1QkMsVUFBQUEsS0FBSyxFQUFFO0FBRnFCLFNBQTlCLENBREY7QUFNQSxjQUFNdU0sV0FBVyxHQUFHLE1BQU1KLGdCQUFnQixDQUFDSyxxQkFBakIsQ0FDeEJsUSxPQUR3QixFQUV4QmdCLElBRndCLEVBR3hCQyxFQUh3QixFQUl4QlYsT0FKd0IsRUFLeEJ5TixPQUx3QixDQUExQjtBQU9BaUMsUUFBQUEsV0FBVyxJQUNUL08sT0FBTyxDQUFDc0MsVUFBUixDQUFtQjtBQUNqQkMsVUFBQUEsSUFBSSxFQUFHLEdBQUV3TSxXQUFZLE9BQU03QixXQUFZLDJCQUR0QjtBQUVqQjFLLFVBQUFBLEtBQUssRUFBRTtBQUZVLFNBQW5CLENBREY7QUFLQSxTQUFDdU0sV0FBRCxJQUNFL08sT0FBTyxDQUFDc0MsVUFBUixDQUFtQjtBQUNqQkMsVUFBQUEsSUFBSSxFQUFHLDZCQURVO0FBRWpCQyxVQUFBQSxLQUFLLEVBQUU7QUFGVSxTQUFuQixDQURGO0FBS0F4QyxRQUFBQSxPQUFPLENBQUNzTCxVQUFSO0FBQ0Q7O0FBRUQsVUFBSSxDQUFDLFVBQUQsRUFBYSxRQUFiLEVBQXVCcEYsUUFBdkIsQ0FBZ0MxRyxPQUFoQyxLQUE0QzJMLEdBQUcsS0FBSyxLQUF4RCxFQUErRDtBQUM3RCx5QkFBSSwrQkFBSixFQUFxQyxtQ0FBckMsRUFBMEUsT0FBMUU7QUFDQSxjQUFNOEQsa0JBQWtCLEdBQUcsTUFBTUMsVUFBVSxDQUFDQyxrQkFBWCxDQUMvQnJRLE9BRCtCLEVBRS9CZ0IsSUFGK0IsRUFHL0JDLEVBSCtCLEVBSS9CVixPQUorQixFQUsvQnlOLE9BTCtCLENBQWpDO0FBT0E5TSxRQUFBQSxPQUFPLENBQUM0SSxxQkFBUixDQUE4QjtBQUM1QnJHLFVBQUFBLElBQUksRUFBRSwrQ0FEc0I7QUFFNUJDLFVBQUFBLEtBQUssRUFBRTtBQUZxQixTQUE5Qjs7QUFJQSxhQUFLLE1BQU0yRyxJQUFYLElBQW1COEYsa0JBQW5CLEVBQXVDO0FBQ3JDLGdCQUFNRyxLQUFLLEdBQUcsTUFBTUYsVUFBVSxDQUFDRyxxQkFBWCxDQUNsQnZRLE9BRGtCLEVBRWxCZ0IsSUFGa0IsRUFHbEJDLEVBSGtCLEVBSWxCVixPQUprQixFQUtsQjhKLElBTGtCLEVBTWxCMkQsT0FOa0IsQ0FBcEI7QUFRQTlNLFVBQUFBLE9BQU8sQ0FBQzRJLHFCQUFSLENBQThCO0FBQUVyRyxZQUFBQSxJQUFJLEVBQUcsZUFBYzRHLElBQUssRUFBNUI7QUFBK0IzRyxZQUFBQSxLQUFLLEVBQUU7QUFBdEMsV0FBOUI7O0FBRUEsY0FBSThNLGdDQUFJbkcsSUFBSixDQUFKLEVBQWU7QUFDYixrQkFBTW9HLE9BQU8sR0FDWCxPQUFPRCxnQ0FBSW5HLElBQUosQ0FBUCxLQUFxQixRQUFyQixHQUFnQztBQUFFNUcsY0FBQUEsSUFBSSxFQUFFK00sZ0NBQUluRyxJQUFKLENBQVI7QUFBbUIzRyxjQUFBQSxLQUFLLEVBQUU7QUFBMUIsYUFBaEMsR0FBeUU4TSxnQ0FBSW5HLElBQUosQ0FEM0U7QUFFQW5KLFlBQUFBLE9BQU8sQ0FBQzRJLHFCQUFSLENBQThCMkcsT0FBOUI7QUFDRDs7QUFFREgsVUFBQUEsS0FBSyxJQUNIQSxLQUFLLENBQUNuTSxNQURSLElBRUVqRCxPQUFPLENBQUNrSyxjQUFSLENBQXVCO0FBQ3JCN0UsWUFBQUEsT0FBTyxFQUFFLENBQ1A7QUFBRTRELGNBQUFBLEVBQUUsRUFBRSxRQUFOO0FBQWdCaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXZCLGFBRE8sRUFFUDtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLGlCQUFOO0FBQXlCaEQsY0FBQUEsS0FBSyxFQUFFO0FBQWhDLGFBRk8sQ0FEWTtBQUtyQjhELFlBQUFBLEtBQUssRUFBRXFGLEtBTGM7QUFNckJySixZQUFBQSxLQUFLLEVBQUcsaUJBQWdCb0QsSUFBSztBQU5SLFdBQXZCLENBRkY7QUFVRDtBQUNGOztBQUVELFVBQUksQ0FBQyxVQUFELEVBQWEsUUFBYixFQUF1QmpELFFBQXZCLENBQWdDMUcsT0FBaEMsS0FBNEMyTCxHQUFHLEtBQUssS0FBeEQsRUFBK0Q7QUFDN0QseUJBQUksK0JBQUosRUFBcUMsK0JBQXJDLEVBQXNFLE9BQXRFO0FBQ0EsY0FBTXFFLGtCQUFrQixHQUFHLE1BQU1DLFVBQVUsQ0FBQ0Qsa0JBQVgsQ0FDL0IxUSxPQUQrQixFQUUvQmdCLElBRitCLEVBRy9CQyxFQUgrQixFQUkvQlYsT0FKK0IsRUFLL0J5TixPQUwrQixDQUFqQztBQU9BOU0sUUFBQUEsT0FBTyxDQUFDNEkscUJBQVIsQ0FBOEI7QUFDNUJyRyxVQUFBQSxJQUFJLEVBQUUsMkNBRHNCO0FBRTVCQyxVQUFBQSxLQUFLLEVBQUU7QUFGcUIsU0FBOUI7O0FBSUEsYUFBSyxNQUFNMkcsSUFBWCxJQUFtQnFHLGtCQUFuQixFQUF1QztBQUNyQyxnQkFBTUosS0FBSyxHQUFHLE1BQU1LLFVBQVUsQ0FBQ0oscUJBQVgsQ0FDbEJ2USxPQURrQixFQUVsQmdCLElBRmtCLEVBR2xCQyxFQUhrQixFQUlsQlYsT0FKa0IsRUFLbEI4SixJQUxrQixFQU1sQjJELE9BTmtCLENBQXBCO0FBUUE5TSxVQUFBQSxPQUFPLENBQUM0SSxxQkFBUixDQUE4QjtBQUFFckcsWUFBQUEsSUFBSSxFQUFHLGVBQWM0RyxJQUFLLEVBQTVCO0FBQStCM0csWUFBQUEsS0FBSyxFQUFFO0FBQXRDLFdBQTlCOztBQUVBLGNBQUlrTixnQ0FBSXZHLElBQUosQ0FBSixFQUFlO0FBQ2Isa0JBQU1vRyxPQUFPLEdBQ1gsT0FBT0csZ0NBQUl2RyxJQUFKLENBQVAsS0FBcUIsUUFBckIsR0FBZ0M7QUFBRTVHLGNBQUFBLElBQUksRUFBRW1OLGdDQUFJdkcsSUFBSixDQUFSO0FBQW1CM0csY0FBQUEsS0FBSyxFQUFFO0FBQTFCLGFBQWhDLEdBQXlFa04sZ0NBQUl2RyxJQUFKLENBRDNFO0FBRUFuSixZQUFBQSxPQUFPLENBQUM0SSxxQkFBUixDQUE4QjJHLE9BQTlCO0FBQ0Q7O0FBRURILFVBQUFBLEtBQUssSUFDSEEsS0FBSyxDQUFDbk0sTUFEUixJQUVFakQsT0FBTyxDQUFDa0ssY0FBUixDQUF1QjtBQUNyQjdFLFlBQUFBLE9BQU8sRUFBRSxDQUNQO0FBQUU0RCxjQUFBQSxFQUFFLEVBQUUsUUFBTjtBQUFnQmhELGNBQUFBLEtBQUssRUFBRTtBQUF2QixhQURPLEVBRVA7QUFBRWdELGNBQUFBLEVBQUUsRUFBRSxpQkFBTjtBQUF5QmhELGNBQUFBLEtBQUssRUFBRTtBQUFoQyxhQUZPLENBRFk7QUFLckI4RCxZQUFBQSxLQUFLLEVBQUVxRixLQUxjO0FBTXJCckosWUFBQUEsS0FBSyxFQUFHLGlCQUFnQm9ELElBQUs7QUFOUixXQUF2QixDQUZGO0FBVUQ7QUFDRjs7QUFFRCxVQUFJLENBQUMsVUFBRCxFQUFhLFFBQWIsRUFBdUJqRCxRQUF2QixDQUFnQzFHLE9BQWhDLEtBQTRDMkwsR0FBRyxLQUFLLE1BQXhELEVBQWdFO0FBQzlELHlCQUFJLCtCQUFKLEVBQXFDLGdDQUFyQyxFQUF1RSxPQUF2RTtBQUNBLGNBQU13RSxtQkFBbUIsR0FBRyxNQUFNQyxXQUFXLENBQUNDLG1CQUFaLENBQ2hDL1EsT0FEZ0MsRUFFaENnQixJQUZnQyxFQUdoQ0MsRUFIZ0MsRUFJaENWLE9BSmdDLEVBS2hDeU4sT0FMZ0MsQ0FBbEM7QUFPQTlNLFFBQUFBLE9BQU8sQ0FBQzRJLHFCQUFSLENBQThCO0FBQzVCckcsVUFBQUEsSUFBSSxFQUFFLDRDQURzQjtBQUU1QkMsVUFBQUEsS0FBSyxFQUFFO0FBRnFCLFNBQTlCOztBQUlBLGFBQUssTUFBTTJHLElBQVgsSUFBbUJ3RyxtQkFBbkIsRUFBd0M7QUFDdEMsZ0JBQU1QLEtBQUssR0FBRyxNQUFNUSxXQUFXLENBQUNQLHFCQUFaLENBQ2xCdlEsT0FEa0IsRUFFbEJnQixJQUZrQixFQUdsQkMsRUFIa0IsRUFJbEJWLE9BSmtCLEVBS2xCOEosSUFMa0IsRUFNbEIyRCxPQU5rQixDQUFwQjtBQVFBOU0sVUFBQUEsT0FBTyxDQUFDNEkscUJBQVIsQ0FBOEI7QUFBRXJHLFlBQUFBLElBQUksRUFBRyxlQUFjNEcsSUFBSyxFQUE1QjtBQUErQjNHLFlBQUFBLEtBQUssRUFBRTtBQUF0QyxXQUE5Qjs7QUFFQSxjQUFJc04sb0NBQVFBLGlDQUFLM0csSUFBTCxDQUFaLEVBQXdCO0FBQ3RCLGtCQUFNb0csT0FBTyxHQUNYLE9BQU9PLGlDQUFLM0csSUFBTCxDQUFQLEtBQXNCLFFBQXRCLEdBQWlDO0FBQUU1RyxjQUFBQSxJQUFJLEVBQUV1TixpQ0FBSzNHLElBQUwsQ0FBUjtBQUFvQjNHLGNBQUFBLEtBQUssRUFBRTtBQUEzQixhQUFqQyxHQUEyRXNOLGlDQUFLM0csSUFBTCxDQUQ3RTtBQUVBbkosWUFBQUEsT0FBTyxDQUFDNEkscUJBQVIsQ0FBOEIyRyxPQUE5QjtBQUNEOztBQUVESCxVQUFBQSxLQUFLLElBQ0hBLEtBQUssQ0FBQ25NLE1BRFIsSUFFRWpELE9BQU8sQ0FBQ2tLLGNBQVIsQ0FBdUI7QUFDckI3RSxZQUFBQSxPQUFPLEVBQUUsQ0FDUDtBQUFFNEQsY0FBQUEsRUFBRSxFQUFFLFFBQU47QUFBZ0JoRCxjQUFBQSxLQUFLLEVBQUU7QUFBdkIsYUFETyxFQUVQO0FBQUVnRCxjQUFBQSxFQUFFLEVBQUUsaUJBQU47QUFBeUJoRCxjQUFBQSxLQUFLLEVBQUU7QUFBaEMsYUFGTyxDQURZO0FBS3JCOEQsWUFBQUEsS0FBSyxFQUFFcUYsS0FMYztBQU1yQnJKLFlBQUFBLEtBQUssRUFBRyxpQkFBZ0JvRCxJQUFLO0FBTlIsV0FBdkIsQ0FGRjtBQVVEOztBQUNEbkosUUFBQUEsT0FBTyxDQUFDc0wsVUFBUjtBQUNEOztBQUVELFVBQUk5TCxPQUFPLEtBQUssVUFBWixJQUEwQjJMLEdBQUcsS0FBSyxPQUF0QyxFQUErQztBQUM3Qyx5QkFDRSwrQkFERixFQUVFLDBEQUZGLEVBR0UsT0FIRjtBQUtBLGNBQU00RSxxQkFBcUIsR0FBRyxNQUFNQyxZQUFZLENBQUNDLDhCQUFiLENBQ2xDblIsT0FEa0MsRUFFbENnQixJQUZrQyxFQUdsQ0MsRUFIa0MsRUFJbENWLE9BSmtDLEVBS2xDeU4sT0FMa0MsQ0FBcEM7O0FBT0EsWUFBSWlELHFCQUFxQixJQUFJQSxxQkFBcUIsQ0FBQzlNLE1BQW5ELEVBQTJEO0FBQ3pEakQsVUFBQUEsT0FBTyxDQUFDc0MsVUFBUixDQUFtQjtBQUNqQkMsWUFBQUEsSUFBSSxFQUFFLGlEQURXO0FBRWpCQyxZQUFBQSxLQUFLLEVBQUU7QUFGVSxXQUFuQjtBQUlBLGdCQUFNLEtBQUtxRyxnQkFBTCxDQUFzQi9KLE9BQXRCLEVBQStCa0IsT0FBL0IsRUFBd0MrUCxxQkFBeEMsRUFBK0RyUSxLQUEvRCxDQUFOO0FBQ0Q7O0FBQ0QsY0FBTXdRLHdCQUF3QixHQUFHLE1BQU1GLFlBQVksQ0FBQ0csMkJBQWIsQ0FDckNyUixPQURxQyxFQUVyQ2dCLElBRnFDLEVBR3JDQyxFQUhxQyxFQUlyQ1YsT0FKcUMsRUFLckN5TixPQUxxQyxDQUF2Qzs7QUFPQSxZQUFJb0Qsd0JBQXdCLElBQUlBLHdCQUF3QixDQUFDak4sTUFBekQsRUFBaUU7QUFDL0RqRCxVQUFBQSxPQUFPLENBQUNrSyxjQUFSLENBQXVCO0FBQ3JCN0UsWUFBQUEsT0FBTyxFQUFFLENBQ1A7QUFBRTRELGNBQUFBLEVBQUUsRUFBRSxPQUFOO0FBQWVoRCxjQUFBQSxLQUFLLEVBQUU7QUFBdEIsYUFETyxFQUVQO0FBQUVnRCxjQUFBQSxFQUFFLEVBQUUsWUFBTjtBQUFvQmhELGNBQUFBLEtBQUssRUFBRTtBQUEzQixhQUZPLEVBR1A7QUFBRWdELGNBQUFBLEVBQUUsRUFBRSxpQkFBTjtBQUF5QmhELGNBQUFBLEtBQUssRUFBRTtBQUFoQyxhQUhPLENBRFk7QUFNckI4RCxZQUFBQSxLQUFLLEVBQUVtRyx3QkFBd0IsQ0FBQzNLLEdBQXpCLENBQThCNEQsSUFBRCxLQUFXO0FBQzdDc0QsY0FBQUEsS0FBSyxFQUFFdEQsSUFBSSxDQUFDc0QsS0FEaUM7QUFFN0MyRCxjQUFBQSxVQUFVLEVBQUVqSCxJQUFJLENBQUNrSCxPQUFMLENBQWFwSCxFQUZvQjtBQUc3Q3FILGNBQUFBLGVBQWUsRUFBRW5ILElBQUksQ0FBQ2tILE9BQUwsQ0FBYUE7QUFIZSxhQUFYLENBQTdCLENBTmM7QUFXckJ0SyxZQUFBQSxLQUFLLEVBQUU7QUFDTHhELGNBQUFBLElBQUksRUFBRSw4QkFERDtBQUVMQyxjQUFBQSxLQUFLLEVBQUU7QUFGRjtBQVhjLFdBQXZCO0FBZ0JEO0FBQ0Y7O0FBRUQsVUFBSWhELE9BQU8sS0FBSyxVQUFaLElBQTBCMkwsR0FBRyxLQUFLLEtBQXRDLEVBQTZDO0FBQzNDLHlCQUFJLCtCQUFKLEVBQXFDLDhCQUFyQyxFQUFxRSxPQUFyRTtBQUNBLGNBQU1pRSxLQUFLLEdBQUcsTUFBTW1CLGVBQWUsQ0FBQ0MsU0FBaEIsQ0FBMEIxUixPQUExQixFQUFtQ2dCLElBQW5DLEVBQXlDQyxFQUF6QyxFQUE2Q1YsT0FBN0MsRUFBc0R5TixPQUF0RCxDQUFwQjs7QUFFQSxZQUFJc0MsS0FBSyxJQUFJQSxLQUFLLENBQUNuTSxNQUFuQixFQUEyQjtBQUN6QmpELFVBQUFBLE9BQU8sQ0FBQzRJLHFCQUFSLENBQThCO0FBQUVyRyxZQUFBQSxJQUFJLEVBQUUsaUJBQVI7QUFBMkJDLFlBQUFBLEtBQUssRUFBRTtBQUFsQyxXQUE5QixFQUF3RTBILGNBQXhFLENBQXVGO0FBQ3JGN0UsWUFBQUEsT0FBTyxFQUFFLENBQ1A7QUFBRTRELGNBQUFBLEVBQUUsRUFBRSxRQUFOO0FBQWdCaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXZCLGFBRE8sRUFFUDtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLGlCQUFOO0FBQXlCaEQsY0FBQUEsS0FBSyxFQUFFO0FBQWhDLGFBRk8sQ0FENEU7QUFLckY4RCxZQUFBQSxLQUFLLEVBQUVxRixLQUw4RTtBQU1yRnJKLFlBQUFBLEtBQUssRUFBRTtBQUNMeEQsY0FBQUEsSUFBSSxFQUFFLDhDQUREO0FBRUxDLGNBQUFBLEtBQUssRUFBRTtBQUZGO0FBTjhFLFdBQXZGO0FBV0Q7O0FBRUQseUJBQUksK0JBQUosRUFBcUMsK0JBQXJDLEVBQXNFLE9BQXRFO0FBQ0EsY0FBTXRELE1BQU0sR0FBRyxNQUFNcVIsZUFBZSxDQUFDRSxVQUFoQixDQUEyQjNSLE9BQTNCLEVBQW9DZ0IsSUFBcEMsRUFBMENDLEVBQTFDLEVBQThDVixPQUE5QyxFQUF1RHlOLE9BQXZELENBQXJCOztBQUVBLFlBQUk1TixNQUFNLElBQUlBLE1BQU0sQ0FBQytELE1BQXJCLEVBQTZCO0FBQzNCakQsVUFBQUEsT0FBTyxDQUFDNEkscUJBQVIsQ0FBOEI7QUFDNUJyRyxZQUFBQSxJQUFJLEVBQUUscUNBRHNCO0FBRTVCQyxZQUFBQSxLQUFLLEVBQUU7QUFGcUIsV0FBOUI7QUFJQXhDLFVBQUFBLE9BQU8sQ0FBQzRJLHFCQUFSLENBQThCO0FBQzVCckcsWUFBQUEsSUFBSSxFQUNGLHdGQUYwQjtBQUc1QkMsWUFBQUEsS0FBSyxFQUFFO0FBSHFCLFdBQTlCO0FBS0EsZ0JBQU0sS0FBS3FHLGdCQUFMLENBQXNCL0osT0FBdEIsRUFBK0JrQixPQUEvQixFQUF3Q2QsTUFBeEMsRUFBZ0RRLEtBQWhELENBQU47QUFDRDtBQUNGOztBQUVELFVBQUlGLE9BQU8sS0FBSyxRQUFaLElBQXdCMkwsR0FBRyxLQUFLLE9BQXBDLEVBQTZDO0FBQzNDLHlCQUFJLCtCQUFKLEVBQXNDLHNDQUF0QyxFQUE2RSxPQUE3RTtBQUNBLGNBQU11RixrQkFBa0IsR0FBRyxNQUFNVixZQUFZLENBQUNXLG9CQUFiLENBQy9CN1IsT0FEK0IsRUFFL0JnQixJQUYrQixFQUcvQkMsRUFIK0IsRUFJL0JWLE9BSitCLEVBSy9CeU4sT0FMK0IsQ0FBakM7QUFPQTRELFFBQUFBLGtCQUFrQixJQUNoQkEsa0JBQWtCLENBQUN6TixNQURyQixJQUVFakQsT0FBTyxDQUFDa0ssY0FBUixDQUF1QjtBQUNyQjdFLFVBQUFBLE9BQU8sRUFBRSxDQUNQO0FBQUU0RCxZQUFBQSxFQUFFLEVBQUUsSUFBTjtBQUFZaEQsWUFBQUEsS0FBSyxFQUFFO0FBQW5CLFdBRE8sRUFFUDtBQUFFZ0QsWUFBQUEsRUFBRSxFQUFFLFNBQU47QUFBaUJoRCxZQUFBQSxLQUFLLEVBQUU7QUFBeEIsV0FGTyxDQURZO0FBS3JCOEQsVUFBQUEsS0FBSyxFQUFFMkcsa0JBTGM7QUFNckIzSyxVQUFBQSxLQUFLLEVBQUU7QUFOYyxTQUF2QixDQUZGO0FBVUQ7O0FBRUQsVUFBSXZHLE9BQU8sS0FBSyxRQUFaLElBQXdCMkwsR0FBRyxLQUFLLEtBQXBDLEVBQTJDO0FBQ3pDLHlCQUNFLCtCQURGLEVBRUcsd0NBQXVDc0IsS0FBTSxFQUZoRCxFQUdFLE9BSEY7QUFNQSxjQUFNbUUsZ0JBQWdCLEdBQUcsTUFBTTlSLE9BQU8sQ0FBQzZELEtBQVIsQ0FBY0MsR0FBZCxDQUFrQkMsTUFBbEIsQ0FBeUJDLGFBQXpCLENBQXVDL0QsT0FBdkMsQ0FDN0IsS0FENkIsRUFFNUIsYUFBWTBOLEtBQU0sWUFGVSxFQUc3QixFQUg2QixFQUk3QjtBQUFFMUosVUFBQUEsU0FBUyxFQUFFckQ7QUFBYixTQUo2QixDQUEvQjs7QUFPQSxZQUFJa1IsZ0JBQWdCLElBQUlBLGdCQUFnQixDQUFDbk8sSUFBekMsRUFBK0M7QUFDN0MsZ0JBQU1vTyxZQUFZLEdBQUdELGdCQUFnQixDQUFDbk8sSUFBakIsQ0FBc0JBLElBQXRCLENBQTJCTyxjQUEzQixDQUEwQyxDQUExQyxDQUFyQjs7QUFDQSxjQUFJNk4sWUFBWSxDQUFDQyxLQUFiLElBQXNCRCxZQUFZLENBQUNFLEdBQXZDLEVBQTRDO0FBQzFDL1EsWUFBQUEsT0FBTyxDQUFDc0MsVUFBUixDQUFtQjtBQUNqQkMsY0FBQUEsSUFBSSxFQUFHLHlEQUF3RHNPLFlBQVksQ0FBQ0MsS0FBTSxPQUFNRCxZQUFZLENBQUNFLEdBQUk7QUFEeEYsYUFBbkI7QUFHRCxXQUpELE1BSU8sSUFBSUYsWUFBWSxDQUFDQyxLQUFqQixFQUF3QjtBQUM3QjlRLFlBQUFBLE9BQU8sQ0FBQ3NDLFVBQVIsQ0FBbUI7QUFDakJDLGNBQUFBLElBQUksRUFBRyxzRkFBcUZzTyxZQUFZLENBQUNDLEtBQU07QUFEOUYsYUFBbkI7QUFHRCxXQUpNLE1BSUE7QUFDTDlRLFlBQUFBLE9BQU8sQ0FBQ3NDLFVBQVIsQ0FBbUI7QUFDakJDLGNBQUFBLElBQUksRUFBRztBQURVLGFBQW5CO0FBR0Q7O0FBQ0R2QyxVQUFBQSxPQUFPLENBQUNzTCxVQUFSO0FBQ0Q7O0FBRUQseUJBQUksK0JBQUosRUFBc0Msd0NBQXRDLEVBQStFLE9BQS9FO0FBQ0EsY0FBTTBGLGNBQWMsR0FBRyxNQUFNVCxlQUFlLENBQUNVLG1CQUFoQixDQUMzQm5TLE9BRDJCLEVBRTNCZ0IsSUFGMkIsRUFHM0JDLEVBSDJCLEVBSTNCVixPQUoyQixFQUszQnlOLE9BTDJCLENBQTdCO0FBUUFrRSxRQUFBQSxjQUFjLElBQ1pBLGNBQWMsQ0FBQy9OLE1BRGpCLElBRUVqRCxPQUFPLENBQUNrSyxjQUFSLENBQXVCO0FBQ3JCN0UsVUFBQUEsT0FBTyxFQUFFLENBQ1A7QUFBRTRELFlBQUFBLEVBQUUsRUFBRSxNQUFOO0FBQWNoRCxZQUFBQSxLQUFLLEVBQUU7QUFBckIsV0FETyxFQUVQO0FBQUVnRCxZQUFBQSxFQUFFLEVBQUUsTUFBTjtBQUFjaEQsWUFBQUEsS0FBSyxFQUFFO0FBQXJCLFdBRk8sQ0FEWTtBQUtyQjhELFVBQUFBLEtBQUssRUFBRWlILGNBTGM7QUFNckJqTCxVQUFBQSxLQUFLLEVBQUU7QUFOYyxTQUF2QixDQUZGO0FBV0EseUJBQUksK0JBQUosRUFBc0MsaUNBQXRDLEVBQXdFLE9BQXhFO0FBQ0EsY0FBTW1MLGVBQWUsR0FBRyxNQUFNWCxlQUFlLENBQUNZLG9CQUFoQixDQUM1QnJTLE9BRDRCLEVBRTVCZ0IsSUFGNEIsRUFHNUJDLEVBSDRCLEVBSTVCVixPQUo0QixFQUs1QnlOLE9BTDRCLENBQTlCO0FBUUFvRSxRQUFBQSxlQUFlLElBQ2JBLGVBQWUsQ0FBQ2pPLE1BRGxCLElBRUVqRCxPQUFPLENBQUNrSyxjQUFSLENBQXVCO0FBQ3JCN0UsVUFBQUEsT0FBTyxFQUFFLENBQ1A7QUFBRTRELFlBQUFBLEVBQUUsRUFBRSxNQUFOO0FBQWNoRCxZQUFBQSxLQUFLLEVBQUU7QUFBckIsV0FETyxFQUVQO0FBQUVnRCxZQUFBQSxFQUFFLEVBQUUsTUFBTjtBQUFjaEQsWUFBQUEsS0FBSyxFQUFFO0FBQXJCLFdBRk8sQ0FEWTtBQUtyQjhELFVBQUFBLEtBQUssRUFBRW1ILGVBTGM7QUFNckJuTCxVQUFBQSxLQUFLLEVBQUU7QUFOYyxTQUF2QixDQUZGO0FBVUQ7O0FBRUQsVUFBSXZHLE9BQU8sS0FBSyxRQUFaLElBQXdCMkwsR0FBRyxLQUFLLGNBQXBDLEVBQW9EO0FBQ2xELHlCQUNFLCtCQURGLEVBRUcsMkNBQTBDc0IsS0FBTSxFQUZuRCxFQUdFLE9BSEY7QUFLQSxjQUFNMkUseUJBQXlCLEdBQUcsQ0FDaEM7QUFDRXJJLFVBQUFBLFFBQVEsRUFBRyxpQkFBZ0IwRCxLQUFNLFdBRG5DO0FBRUV6RCxVQUFBQSxhQUFhLEVBQUcsMkNBQTBDeUQsS0FBTSxFQUZsRTtBQUdFb0IsVUFBQUEsSUFBSSxFQUFFO0FBQ0o5SCxZQUFBQSxLQUFLLEVBQUU7QUFBRXhELGNBQUFBLElBQUksRUFBRSxzQkFBUjtBQUFnQ0MsY0FBQUEsS0FBSyxFQUFFO0FBQXZDO0FBREgsV0FIUjtBQU1FNk8sVUFBQUEsV0FBVyxFQUFHQyxRQUFELElBQWMsQ0FDekJBLFFBQVEsQ0FBQ0MsR0FBVCxJQUFnQkQsUUFBUSxDQUFDQyxHQUFULENBQWFDLEtBQTdCLElBQXVDLEdBQUVGLFFBQVEsQ0FBQ0MsR0FBVCxDQUFhQyxLQUFNLFFBRG5DLEVBRXpCRixRQUFRLENBQUNDLEdBQVQsSUFBZ0JELFFBQVEsQ0FBQ0MsR0FBVCxDQUFhOU0sSUFGSixFQUd6QjZNLFFBQVEsQ0FBQ0csR0FBVCxJQUNFSCxRQUFRLENBQUNHLEdBQVQsQ0FBYUMsS0FEZixJQUVHLEdBQUVDLE1BQU0sQ0FBQ0wsUUFBUSxDQUFDRyxHQUFULENBQWFDLEtBQWIsR0FBcUIsSUFBckIsR0FBNEIsSUFBN0IsQ0FBTixDQUF5Q0UsT0FBekMsQ0FBaUQsQ0FBakQsQ0FBb0QsUUFMaEM7QUFON0IsU0FEZ0MsRUFlaEM7QUFDRTdJLFVBQUFBLFFBQVEsRUFBRyxpQkFBZ0IwRCxLQUFNLEtBRG5DO0FBRUV6RCxVQUFBQSxhQUFhLEVBQUcscUNBQW9DeUQsS0FBTSxFQUY1RDtBQUdFb0IsVUFBQUEsSUFBSSxFQUFFO0FBQ0o5SCxZQUFBQSxLQUFLLEVBQUU7QUFBRXhELGNBQUFBLElBQUksRUFBRSxnQkFBUjtBQUEwQkMsY0FBQUEsS0FBSyxFQUFFO0FBQWpDO0FBREgsV0FIUjtBQU1FNk8sVUFBQUEsV0FBVyxFQUFHUSxNQUFELElBQVksQ0FDdkJBLE1BQU0sQ0FBQ0MsT0FEZ0IsRUFFdkJELE1BQU0sQ0FBQ25GLE9BRmdCLEVBR3ZCbUYsTUFBTSxDQUFDRSxZQUhnQixFQUl2QkYsTUFBTSxDQUFDRyxPQUpnQixFQUt2QkgsTUFBTSxDQUFDbkosRUFBUCxJQUNFbUosTUFBTSxDQUFDbkosRUFBUCxDQUFVakUsSUFEWixJQUVFb04sTUFBTSxDQUFDbkosRUFBUCxDQUFVZ0UsT0FGWixJQUdHLEdBQUVtRixNQUFNLENBQUNuSixFQUFQLENBQVVqRSxJQUFLLElBQUdvTixNQUFNLENBQUNuSixFQUFQLENBQVVnRSxPQUFRLEVBUmxCO0FBTjNCLFNBZmdDLENBQWxDO0FBa0NBLGNBQU11RixpQkFBaUIsR0FBRyxNQUFNakksT0FBTyxDQUFDQyxHQUFSLENBQzlCbUgseUJBQXlCLENBQUM3TCxHQUExQixDQUE4QixNQUFPMk0sbUJBQVAsSUFBK0I7QUFDM0QsY0FBSTtBQUNGLDZCQUFJLCtCQUFKLEVBQXFDQSxtQkFBbUIsQ0FBQ2xKLGFBQXpELEVBQXdFLE9BQXhFO0FBQ0Esa0JBQU1tSixvQkFBb0IsR0FBRyxNQUFNclQsT0FBTyxDQUFDNkQsS0FBUixDQUFjQyxHQUFkLENBQWtCQyxNQUFsQixDQUF5QkMsYUFBekIsQ0FBdUMvRCxPQUF2QyxDQUNqQyxLQURpQyxFQUVqQ21ULG1CQUFtQixDQUFDbkosUUFGYSxFQUdqQyxFQUhpQyxFQUlqQztBQUFFaEcsY0FBQUEsU0FBUyxFQUFFckQ7QUFBYixhQUppQyxDQUFuQztBQU1BLGtCQUFNLENBQUMrQyxJQUFELElBQ0gwUCxvQkFBb0IsSUFDbkJBLG9CQUFvQixDQUFDMVAsSUFEdEIsSUFFQzBQLG9CQUFvQixDQUFDMVAsSUFBckIsQ0FBMEJBLElBRjNCLElBR0MwUCxvQkFBb0IsQ0FBQzFQLElBQXJCLENBQTBCQSxJQUExQixDQUErQk8sY0FIakMsSUFJQSxFQUxGOztBQU1BLGdCQUFJUCxJQUFKLEVBQVU7QUFDUixxQkFBTyxFQUNMLEdBQUd5UCxtQkFBbUIsQ0FBQ3JFLElBRGxCO0FBRUxBLGdCQUFBQSxJQUFJLEVBQUVxRSxtQkFBbUIsQ0FBQ2IsV0FBcEIsQ0FBZ0M1TyxJQUFoQztBQUZELGVBQVA7QUFJRDtBQUNGLFdBcEJELENBb0JFLE9BQU9oQixLQUFQLEVBQWM7QUFDZCw2QkFBSSwrQkFBSixFQUFxQ0EsS0FBSyxDQUFDRixPQUFOLElBQWlCRSxLQUF0RDtBQUNEO0FBQ0YsU0F4QkQsQ0FEOEIsQ0FBaEM7O0FBNEJBLFlBQUl3USxpQkFBSixFQUF1QjtBQUNyQkEsVUFBQUEsaUJBQWlCLENBQ2R0TyxNQURILENBQ1d5TyxnQkFBRCxJQUFzQkEsZ0JBRGhDLEVBRUd0TixPQUZILENBRVlzTixnQkFBRCxJQUFzQnBTLE9BQU8sQ0FBQzROLE9BQVIsQ0FBZ0J3RSxnQkFBaEIsQ0FGakM7QUFHRDs7QUFFRCxjQUFNQyx1QkFBdUIsR0FBRyxDQUFDLFVBQUQsRUFBYSxNQUFiLENBQWhDO0FBRUEsY0FBTUMsNkJBQTZCLEdBQUcsQ0FDcEMsTUFBTXRJLE9BQU8sQ0FBQ0MsR0FBUixDQUNKb0ksdUJBQXVCLENBQUM5TSxHQUF4QixDQUE0QixNQUFPOEgsb0JBQVAsSUFBZ0M7QUFDMUQsY0FBSTtBQUNGLDZCQUNFLCtCQURGLEVBRUcsZ0JBQWVBLG9CQUFxQixXQUZ2QyxFQUdFLE9BSEY7QUFNQSxtQkFBTyxNQUFNRSxvQkFBb0IsQ0FBQ2dGLFdBQXJCLENBQ1h6VCxPQURXLEVBRVhnQixJQUZXLEVBR1hDLEVBSFcsRUFJWHNOLG9CQUpXLEVBS1hoTyxPQUxXLEVBTVh5TixPQU5XLENBQWI7QUFRRCxXQWZELENBZUUsT0FBT3JMLEtBQVAsRUFBYztBQUNkLDZCQUFJLCtCQUFKLEVBQXFDQSxLQUFLLENBQUNGLE9BQU4sSUFBaUJFLEtBQXREO0FBQ0Q7QUFDRixTQW5CRCxDQURJLENBRDhCLEVBd0JuQ2tDLE1BeEJtQyxDQXdCM0JnSyx1QkFBRCxJQUE2QkEsdUJBeEJELEVBeUJuQzZFLElBekJtQyxFQUF0Qzs7QUEyQkEsWUFBSUYsNkJBQTZCLElBQUlBLDZCQUE2QixDQUFDclAsTUFBbkUsRUFBMkU7QUFDekVqRCxVQUFBQSxPQUFPLENBQUNrSyxjQUFSLENBQXVCO0FBQ3JCbkUsWUFBQUEsS0FBSyxFQUFFO0FBQUV4RCxjQUFBQSxJQUFJLEVBQUUsMkNBQVI7QUFBcURDLGNBQUFBLEtBQUssRUFBRTtBQUE1RCxhQURjO0FBRXJCNkMsWUFBQUEsT0FBTyxFQUFFLENBQ1A7QUFBRTRELGNBQUFBLEVBQUUsRUFBRSxTQUFOO0FBQWlCaEQsY0FBQUEsS0FBSyxFQUFFO0FBQXhCLGFBRE8sRUFFUDtBQUFFZ0QsY0FBQUEsRUFBRSxFQUFFLFVBQU47QUFBa0JoRCxjQUFBQSxLQUFLLEVBQUU7QUFBekIsYUFGTyxDQUZZO0FBTXJCOEQsWUFBQUEsS0FBSyxFQUFFdUk7QUFOYyxXQUF2QjtBQVFEO0FBQ0Y7O0FBRUQsVUFBSTlTLE9BQU8sS0FBSyxRQUFaLElBQXdCMkwsR0FBRyxLQUFLLE1BQXBDLEVBQTRDO0FBQzFDLGNBQU1zSCxtQkFBbUIsR0FBRyxNQUFNbEYsb0JBQW9CLENBQUNtRixrQkFBckIsQ0FDaEM1VCxPQURnQyxFQUVoQ2dCLElBRmdDLEVBR2hDQyxFQUhnQyxFQUloQyxVQUpnQyxFQUtoQ1YsT0FMZ0MsRUFNaEN5TixPQU5nQyxDQUFsQzs7QUFRQSxZQUFJMkYsbUJBQW1CLElBQUlBLG1CQUFtQixDQUFDeFAsTUFBL0MsRUFBdUQ7QUFDckRqRCxVQUFBQSxPQUFPLENBQUM0SSxxQkFBUixDQUE4QjtBQUFFckcsWUFBQUEsSUFBSSxFQUFFLG1CQUFSO0FBQTZCQyxZQUFBQSxLQUFLLEVBQUU7QUFBcEMsV0FBOUI7QUFDQXhDLFVBQUFBLE9BQU8sQ0FBQzRJLHFCQUFSLENBQThCO0FBQzVCckcsWUFBQUEsSUFBSSxFQUNGLDhIQUYwQjtBQUc1QkMsWUFBQUEsS0FBSyxFQUFFO0FBSHFCLFdBQTlCO0FBS0EsZ0JBQU1tUSxRQUFRLEdBQUcsRUFBakI7O0FBQ0EsZUFBSyxNQUFNQyxRQUFYLElBQXVCSCxtQkFBdkIsRUFBNEM7QUFDMUNFLFlBQUFBLFFBQVEsQ0FBQ2pPLElBQVQsQ0FBYztBQUFFbkMsY0FBQUEsSUFBSSxFQUFFcVEsUUFBUSxDQUFDQyxPQUFqQjtBQUEwQnJRLGNBQUFBLEtBQUssRUFBRTtBQUFqQyxhQUFkO0FBQ0FtUSxZQUFBQSxRQUFRLENBQUNqTyxJQUFULENBQWM7QUFDWm9PLGNBQUFBLEVBQUUsRUFBRUYsUUFBUSxDQUFDRyxVQUFULENBQW9CeE4sR0FBcEIsQ0FBeUI0RCxJQUFELEtBQVc7QUFDckM1RyxnQkFBQUEsSUFBSSxFQUFFNEcsSUFBSSxDQUFDNkosU0FBTCxDQUFlLENBQWYsRUFBa0IsRUFBbEIsSUFBd0IsS0FETztBQUVyQzdLLGdCQUFBQSxJQUFJLEVBQUVnQixJQUYrQjtBQUdyQzdGLGdCQUFBQSxLQUFLLEVBQUU7QUFIOEIsZUFBWCxDQUF4QjtBQURRLGFBQWQ7QUFPRDs7QUFDRHRELFVBQUFBLE9BQU8sQ0FBQzRJLHFCQUFSLENBQThCO0FBQUVrSyxZQUFBQSxFQUFFLEVBQUVIO0FBQU4sV0FBOUI7QUFDRDs7QUFFRCxjQUFNTSxlQUFlLEdBQUcsTUFBTTFGLG9CQUFvQixDQUFDbUYsa0JBQXJCLENBQzVCNVQsT0FENEIsRUFFNUJnQixJQUY0QixFQUc1QkMsRUFINEIsRUFJNUIsTUFKNEIsRUFLNUJWLE9BTDRCLEVBTTVCeU4sT0FONEIsQ0FBOUI7O0FBUUEsWUFBSW1HLGVBQWUsSUFBSUEsZUFBZSxDQUFDaFEsTUFBdkMsRUFBK0M7QUFDN0NqRCxVQUFBQSxPQUFPLENBQUM0SSxxQkFBUixDQUE4QjtBQUFFckcsWUFBQUEsSUFBSSxFQUFFLGVBQVI7QUFBeUJDLFlBQUFBLEtBQUssRUFBRTtBQUFoQyxXQUE5QjtBQUNBeEMsVUFBQUEsT0FBTyxDQUFDNEkscUJBQVIsQ0FBOEI7QUFDNUJyRyxZQUFBQSxJQUFJLEVBQUUsaUVBRHNCO0FBRTVCQyxZQUFBQSxLQUFLLEVBQUU7QUFGcUIsV0FBOUI7QUFJQSxnQkFBTW1RLFFBQVEsR0FBRyxFQUFqQjs7QUFDQSxlQUFLLE1BQU1DLFFBQVgsSUFBdUJLLGVBQXZCLEVBQXdDO0FBQ3RDTixZQUFBQSxRQUFRLENBQUNqTyxJQUFULENBQWM7QUFBRW5DLGNBQUFBLElBQUksRUFBRXFRLFFBQVEsQ0FBQ0MsT0FBakI7QUFBMEJyUSxjQUFBQSxLQUFLLEVBQUU7QUFBakMsYUFBZDtBQUNBbVEsWUFBQUEsUUFBUSxDQUFDak8sSUFBVCxDQUFjO0FBQ1pvTyxjQUFBQSxFQUFFLEVBQUVGLFFBQVEsQ0FBQ0csVUFBVCxDQUFvQnhOLEdBQXBCLENBQXlCNEQsSUFBRCxLQUFXO0FBQ3JDNUcsZ0JBQUFBLElBQUksRUFBRTRHLElBRCtCO0FBRXJDN0YsZ0JBQUFBLEtBQUssRUFBRTtBQUY4QixlQUFYLENBQXhCO0FBRFEsYUFBZDtBQU1EOztBQUNEcVAsVUFBQUEsUUFBUSxJQUFJQSxRQUFRLENBQUMxUCxNQUFyQixJQUErQmpELE9BQU8sQ0FBQ3NDLFVBQVIsQ0FBbUI7QUFBRXdRLFlBQUFBLEVBQUUsRUFBRUg7QUFBTixXQUFuQixDQUEvQjtBQUNBM1MsVUFBQUEsT0FBTyxDQUFDc0wsVUFBUjtBQUNEO0FBQ0Y7O0FBRUQsYUFBTyxLQUFQO0FBQ0QsS0Evc0JELENBK3NCRSxPQUFPN0osS0FBUCxFQUFjO0FBQ2QsdUJBQUksK0JBQUosRUFBcUNBLEtBQUssQ0FBQ0YsT0FBTixJQUFpQkUsS0FBdEQ7QUFDQSxhQUFPdUksT0FBTyxDQUFDOEIsTUFBUixDQUFlckssS0FBZixDQUFQO0FBQ0Q7QUFDRjs7QUFFT3lSLEVBQUFBLGFBQWEsQ0FBQ3pRLElBQUQsRUFBT0wsTUFBUCxFQUFlO0FBQ2xDLHFCQUFJLHlCQUFKLEVBQWdDLDZCQUFoQyxFQUE4RCxNQUE5RDtBQUNBLFVBQU0rUSxNQUFNLEdBQUcsRUFBZjs7QUFDQSxTQUFLLElBQUlDLElBQVQsSUFBaUIzUSxJQUFJLElBQUksRUFBekIsRUFBNkI7QUFDM0IsVUFBSWtDLEtBQUssQ0FBQ0MsT0FBTixDQUFjbkMsSUFBSSxDQUFDMlEsSUFBRCxDQUFsQixDQUFKLEVBQStCO0FBQzdCM1EsUUFBQUEsSUFBSSxDQUFDMlEsSUFBRCxDQUFKLENBQVd0TyxPQUFYLENBQW1CLENBQUNLLENBQUQsRUFBSXRCLEdBQUosS0FBWTtBQUM3QixjQUFJLE9BQU9zQixDQUFQLEtBQWEsUUFBakIsRUFBMkIxQyxJQUFJLENBQUMyUSxJQUFELENBQUosQ0FBV3ZQLEdBQVgsSUFBa0I2QixJQUFJLENBQUNDLFNBQUwsQ0FBZVIsQ0FBZixDQUFsQjtBQUM1QixTQUZEO0FBR0Q7O0FBQ0RnTyxNQUFBQSxNQUFNLENBQUN6TyxJQUFQLENBQVksQ0FBQyxDQUFDdEMsTUFBTSxJQUFJLEVBQVgsRUFBZWdSLElBQWYsS0FBd0JDLGtDQUFlRCxJQUFmLENBQXhCLElBQWdEQSxJQUFqRCxFQUF1RDNRLElBQUksQ0FBQzJRLElBQUQsQ0FBSixJQUFjLEdBQXJFLENBQVo7QUFDRDs7QUFDRCxXQUFPRCxNQUFQO0FBQ0Q7O0FBRU8vTSxFQUFBQSxlQUFlLENBQUMzRCxJQUFELEVBQU9qRCxPQUFQLEVBQWdCMkwsR0FBaEIsRUFBcUJsTSxLQUFLLEdBQUcsRUFBN0IsRUFBaUM7QUFDdEQscUJBQUksMkJBQUosRUFBa0MsK0JBQWxDLEVBQWtFLE1BQWxFO0FBQ0EsUUFBSXFVLFNBQVMsR0FBRyxFQUFoQjtBQUNBLFVBQU1DLFVBQVUsR0FBRyxFQUFuQjtBQUNBLFVBQU1DLFNBQVMsR0FBRyxFQUFsQjs7QUFFQSxRQUFJL1EsSUFBSSxDQUFDUSxNQUFMLEtBQWdCLENBQWhCLElBQXFCMEIsS0FBSyxDQUFDQyxPQUFOLENBQWNuQyxJQUFkLENBQXpCLEVBQThDO0FBQzVDK1EsTUFBQUEsU0FBUyxDQUFDaFUsT0FBTyxDQUFDNEQsTUFBUixDQUFlK0gsR0FBZixFQUFvQnpJLGFBQXJCLENBQVQsR0FBK0NELElBQS9DO0FBQ0QsS0FGRCxNQUVPO0FBQ0wsV0FBSyxJQUFJZ0QsR0FBVCxJQUFnQmhELElBQWhCLEVBQXNCO0FBQ3BCLFlBQ0csT0FBT0EsSUFBSSxDQUFDZ0QsR0FBRCxDQUFYLEtBQXFCLFFBQXJCLElBQWlDLENBQUNkLEtBQUssQ0FBQ0MsT0FBTixDQUFjbkMsSUFBSSxDQUFDZ0QsR0FBRCxDQUFsQixDQUFuQyxJQUNDZCxLQUFLLENBQUNDLE9BQU4sQ0FBY25DLElBQUksQ0FBQ2dELEdBQUQsQ0FBbEIsS0FBNEIsT0FBT2hELElBQUksQ0FBQ2dELEdBQUQsQ0FBSixDQUFVLENBQVYsQ0FBUCxLQUF3QixRQUZ2RCxFQUdFO0FBQ0E2TixVQUFBQSxTQUFTLENBQUM3TixHQUFELENBQVQsR0FDRWQsS0FBSyxDQUFDQyxPQUFOLENBQWNuQyxJQUFJLENBQUNnRCxHQUFELENBQWxCLEtBQTRCLE9BQU9oRCxJQUFJLENBQUNnRCxHQUFELENBQUosQ0FBVSxDQUFWLENBQVAsS0FBd0IsUUFBcEQsR0FDSWhELElBQUksQ0FBQ2dELEdBQUQsQ0FBSixDQUFVRixHQUFWLENBQWVKLENBQUQsSUFBTztBQUNuQixtQkFBTyxPQUFPQSxDQUFQLEtBQWEsUUFBYixHQUF3Qk8sSUFBSSxDQUFDQyxTQUFMLENBQWVSLENBQWYsQ0FBeEIsR0FBNENBLENBQUMsR0FBRyxJQUF2RDtBQUNELFdBRkQsQ0FESixHQUlJMUMsSUFBSSxDQUFDZ0QsR0FBRCxDQUxWO0FBTUQsU0FWRCxNQVVPLElBQUlkLEtBQUssQ0FBQ0MsT0FBTixDQUFjbkMsSUFBSSxDQUFDZ0QsR0FBRCxDQUFsQixLQUE0QixPQUFPaEQsSUFBSSxDQUFDZ0QsR0FBRCxDQUFKLENBQVUsQ0FBVixDQUFQLEtBQXdCLFFBQXhELEVBQWtFO0FBQ3ZFK04sVUFBQUEsU0FBUyxDQUFDL04sR0FBRCxDQUFULEdBQWlCaEQsSUFBSSxDQUFDZ0QsR0FBRCxDQUFyQjtBQUNELFNBRk0sTUFFQTtBQUNMLGNBQUlqRyxPQUFPLENBQUNnRSxhQUFSLElBQXlCLENBQUMsTUFBRCxFQUFTLFNBQVQsRUFBb0IwQyxRQUFwQixDQUE2QlQsR0FBN0IsQ0FBN0IsRUFBZ0U7QUFDOUQrTixZQUFBQSxTQUFTLENBQUMvTixHQUFELENBQVQsR0FBaUIsQ0FBQ2hELElBQUksQ0FBQ2dELEdBQUQsQ0FBTCxDQUFqQjtBQUNELFdBRkQsTUFFTztBQUNMOE4sWUFBQUEsVUFBVSxDQUFDN08sSUFBWCxDQUFnQmpDLElBQUksQ0FBQ2dELEdBQUQsQ0FBcEI7QUFDRDtBQUNGO0FBQ0Y7QUFDRjs7QUFDRHhHLElBQUFBLEtBQUssQ0FBQ3lGLElBQU4sQ0FBVztBQUNUcUIsTUFBQUEsS0FBSyxFQUFFLENBQUN2RyxPQUFPLENBQUNpVSxPQUFSLElBQW1CLEVBQXBCLEVBQXdCQyxVQUF4QixHQUNILEVBREcsR0FFSCxDQUFDbFUsT0FBTyxDQUFDc0UsSUFBUixJQUFnQixFQUFqQixFQUFxQnFILEdBQXJCLE1BQ0MzTCxPQUFPLENBQUNnRSxhQUFSLEdBQXdCLENBQUMsQ0FBQ2hFLE9BQU8sQ0FBQzRDLE1BQVIsSUFBa0IsRUFBbkIsRUFBdUIsQ0FBdkIsS0FBNkIsRUFBOUIsRUFBa0MrSSxHQUFsQyxDQUF4QixHQUFpRSxFQURsRSxDQUhLO0FBS1Q5RixNQUFBQSxPQUFPLEVBQUUsQ0FBQyxFQUFELEVBQUssRUFBTCxDQUxBO0FBTVRXLE1BQUFBLElBQUksRUFBRSxRQU5HO0FBT1RWLE1BQUFBLElBQUksRUFBRSxLQUFLNE4sYUFBTCxDQUFtQkksU0FBbkIsRUFBOEIsQ0FBQzlULE9BQU8sQ0FBQzRDLE1BQVIsSUFBa0IsRUFBbkIsRUFBdUIsQ0FBdkIsQ0FBOUI7QUFQRyxLQUFYOztBQVNBLFNBQUssSUFBSXFELEdBQVQsSUFBZ0IrTixTQUFoQixFQUEyQjtBQUN6QixZQUFNbk8sT0FBTyxHQUFHbkMsTUFBTSxDQUFDQyxJQUFQLENBQVlxUSxTQUFTLENBQUMvTixHQUFELENBQVQsQ0FBZSxDQUFmLENBQVosQ0FBaEI7QUFDQUosTUFBQUEsT0FBTyxDQUFDUCxPQUFSLENBQWdCLENBQUNjLEdBQUQsRUFBTVIsQ0FBTixLQUFZO0FBQzFCQyxRQUFBQSxPQUFPLENBQUNELENBQUQsQ0FBUCxHQUFhUSxHQUFHLENBQUMsQ0FBRCxDQUFILENBQU9DLFdBQVAsS0FBdUJELEdBQUcsQ0FBQ0UsS0FBSixDQUFVLENBQVYsQ0FBcEM7QUFDRCxPQUZEO0FBSUEsWUFBTVIsSUFBSSxHQUFHa08sU0FBUyxDQUFDL04sR0FBRCxDQUFULENBQWVGLEdBQWYsQ0FBb0JKLENBQUQsSUFBTztBQUNyQyxZQUFJSyxHQUFHLEdBQUcsRUFBVjs7QUFDQSxhQUFLLElBQUlDLEdBQVQsSUFBZ0JOLENBQWhCLEVBQW1CO0FBQ2pCSyxVQUFBQSxHQUFHLENBQUNkLElBQUosQ0FDRSxPQUFPUyxDQUFDLENBQUNNLEdBQUQsQ0FBUixLQUFrQixRQUFsQixHQUNJTixDQUFDLENBQUNNLEdBQUQsQ0FETCxHQUVJZCxLQUFLLENBQUNDLE9BQU4sQ0FBY08sQ0FBQyxDQUFDTSxHQUFELENBQWYsSUFDQU4sQ0FBQyxDQUFDTSxHQUFELENBQUQsQ0FBT0YsR0FBUCxDQUFZSixDQUFELElBQU87QUFDaEIsbUJBQU9BLENBQUMsR0FBRyxJQUFYO0FBQ0QsV0FGRCxDQURBLEdBSUFPLElBQUksQ0FBQ0MsU0FBTCxDQUFlUixDQUFDLENBQUNNLEdBQUQsQ0FBaEIsQ0FQTjtBQVNEOztBQUNELGVBQU9ELEdBQUcsQ0FBQ3ZDLE1BQUosR0FBYW9DLE9BQU8sQ0FBQ3BDLE1BQTVCLEVBQW9DO0FBQ2xDdUMsVUFBQUEsR0FBRyxDQUFDZCxJQUFKLENBQVMsR0FBVDtBQUNEOztBQUNELGVBQU9jLEdBQVA7QUFDRCxPQWpCWSxDQUFiO0FBa0JBdkcsTUFBQUEsS0FBSyxDQUFDeUYsSUFBTixDQUFXO0FBQ1RxQixRQUFBQSxLQUFLLEVBQUUsQ0FBQyxDQUFDdkcsT0FBTyxDQUFDNEMsTUFBUixJQUFrQixFQUFuQixFQUF1QixDQUF2QixLQUE2QixFQUE5QixFQUFrQ3FELEdBQWxDLEtBQTBDLEVBRHhDO0FBRVRPLFFBQUFBLElBQUksRUFBRSxPQUZHO0FBR1RYLFFBQUFBLE9BSFM7QUFJVEMsUUFBQUE7QUFKUyxPQUFYO0FBTUQ7O0FBQ0RpTyxJQUFBQSxVQUFVLENBQUN6TyxPQUFYLENBQW1CNk8sSUFBSSxJQUFJO0FBQ3pCLFdBQUt2TixlQUFMLENBQXFCdU4sSUFBckIsRUFBMkJuVSxPQUEzQixFQUFvQzJMLEdBQUcsR0FBRyxDQUExQyxFQUE2Q2xNLEtBQTdDO0FBQ0QsS0FGRDtBQUdBLFdBQU9BLEtBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFpekJFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ2tCLFFBQVYyVSxVQUFVLENBQ2Q5VSxPQURjLEVBRWRDLE9BRmMsRUFHZEMsUUFIYyxFQUlkO0FBQ0EsUUFBSTtBQUNGLHVCQUFJLHNCQUFKLEVBQTZCLDBCQUE3QixFQUF3RCxNQUF4RDtBQUNBLFlBQU07QUFBRXVCLFFBQUFBO0FBQUYsVUFBbUIsTUFBTXpCLE9BQU8sQ0FBQzZELEtBQVIsQ0FBYzBGLFFBQWQsQ0FBdUJDLGNBQXZCLENBQXNDdkosT0FBdEMsRUFBK0NELE9BQS9DLENBQS9CO0FBQ0E7QUFDQSxrREFBMkJvQiw4Q0FBM0I7QUFDQSxrREFBMkJDLHNEQUEzQjs7QUFDQSxZQUFNMFQsd0JBQXdCLEdBQUd6VCxjQUFLQyxJQUFMLENBQVVGLHNEQUFWLEVBQXVESSxZQUF2RCxDQUFqQzs7QUFDQSxrREFBMkJzVCx3QkFBM0I7QUFDQSx1QkFBSSxzQkFBSixFQUE2QixjQUFhQSx3QkFBeUIsRUFBbkUsRUFBc0UsT0FBdEU7O0FBRUEsWUFBTUMsaUJBQWlCLEdBQUcsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLEtBQVdELENBQUMsQ0FBQ0UsSUFBRixHQUFTRCxDQUFDLENBQUNDLElBQVgsR0FBa0IsQ0FBbEIsR0FBc0JGLENBQUMsQ0FBQ0UsSUFBRixHQUFTRCxDQUFDLENBQUNDLElBQVgsR0FBa0IsQ0FBQyxDQUFuQixHQUF1QixDQUFsRjs7QUFFQSxZQUFNQyxPQUFPLEdBQUc5SixZQUFHK0osV0FBSCxDQUFlTix3QkFBZixFQUF5Q3RPLEdBQXpDLENBQThDNk8sSUFBRCxJQUFVO0FBQ3JFLGNBQU1DLEtBQUssR0FBR2pLLFlBQUdrSyxRQUFILENBQVlULHdCQUF3QixHQUFHLEdBQTNCLEdBQWlDTyxJQUE3QyxDQUFkLENBRHFFLENBRXJFO0FBQ0E7OztBQUNBLGNBQU1HLGNBQWMsR0FBRyxDQUFDLFdBQUQsRUFBYyxPQUFkLEVBQXVCLE9BQXZCLEVBQWdDLE9BQWhDLEVBQXlDQyxJQUF6QyxDQUNwQmxWLElBQUQsSUFBVStVLEtBQUssQ0FBRSxHQUFFL1UsSUFBSyxJQUFULENBRE0sQ0FBdkI7QUFHQSxlQUFPO0FBQ0xtRixVQUFBQSxJQUFJLEVBQUUyUCxJQUREO0FBRUxLLFVBQUFBLElBQUksRUFBRUosS0FBSyxDQUFDSSxJQUZQO0FBR0xSLFVBQUFBLElBQUksRUFBRUksS0FBSyxDQUFDRSxjQUFEO0FBSE4sU0FBUDtBQUtELE9BWmUsQ0FBaEI7O0FBYUEsdUJBQUksc0JBQUosRUFBNkIsNkJBQTRCTCxPQUFPLENBQUNqUixNQUFPLFFBQXhFLEVBQWlGLE9BQWpGO0FBQ0F5UixNQUFBQSxPQUFPLENBQUNDLElBQVIsQ0FBYVQsT0FBYixFQUFzQkosaUJBQXRCO0FBQ0EsdUJBQUksc0JBQUosRUFBNkIsa0JBQWlCSSxPQUFPLENBQUNqUixNQUFPLEVBQTdELEVBQWdFLE9BQWhFO0FBQ0EsYUFBT2pFLFFBQVEsQ0FBQ3FDLEVBQVQsQ0FBWTtBQUNqQjFCLFFBQUFBLElBQUksRUFBRTtBQUFFdVUsVUFBQUE7QUFBRjtBQURXLE9BQVosQ0FBUDtBQUdELEtBL0JELENBK0JFLE9BQU96UyxLQUFQLEVBQWM7QUFDZCx1QkFBSSxzQkFBSixFQUE0QkEsS0FBSyxDQUFDRixPQUFOLElBQWlCRSxLQUE3QztBQUNBLGFBQU8sa0NBQWNBLEtBQUssQ0FBQ0YsT0FBTixJQUFpQkUsS0FBL0IsRUFBc0MsSUFBdEMsRUFBNEMsR0FBNUMsRUFBaUR6QyxRQUFqRCxDQUFQO0FBQ0Q7QUFDRjtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUE0Q0VILEVBQUFBLDhDQUE4QyxDQUFDK1YsWUFBRCxFQUFlQyxzQkFBZixFQUFzQztBQUNsRixXQUFRLE9BQ04vVixPQURNLEVBRU5DLE9BRk0sRUFHTkMsUUFITSxLQUlIO0FBQ0gsVUFBRztBQUNELGNBQU07QUFBRThWLFVBQUFBLFFBQUY7QUFBWXZVLFVBQUFBO0FBQVosWUFBNkIsTUFBTXpCLE9BQU8sQ0FBQzZELEtBQVIsQ0FBYzBGLFFBQWQsQ0FBdUJDLGNBQXZCLENBQXNDdkosT0FBdEMsRUFBK0NELE9BQS9DLENBQXpDOztBQUNBLGNBQU0rVSx3QkFBd0IsR0FBR3pULGNBQUtDLElBQUwsQ0FBVUYsc0RBQVYsRUFBdURJLFlBQXZELENBQWpDOztBQUNBLGNBQU1pQixRQUFRLEdBQUdxVCxzQkFBc0IsQ0FBQzlWLE9BQUQsQ0FBdkM7O0FBQ0EsY0FBTXFDLFlBQVksR0FBR2hCLGNBQUtDLElBQUwsQ0FBVXdULHdCQUFWLEVBQW9DclMsUUFBcEMsQ0FBckI7O0FBQ0EseUJBQUksMERBQUosRUFBaUUscUJBQW9Cc1QsUUFBUyxJQUFHdlUsWUFBYSx5Q0FBd0NhLFlBQWEsRUFBbkssRUFBc0ssT0FBdEs7O0FBQ0EsWUFBRyxDQUFDQSxZQUFZLENBQUMyVCxVQUFiLENBQXdCbEIsd0JBQXhCLENBQUQsSUFBc0R6UyxZQUFZLENBQUM4RSxRQUFiLENBQXNCLEtBQXRCLENBQXpELEVBQXNGO0FBQ3BGLDJCQUFJLG1FQUFKLEVBQTBFLFFBQU80TyxRQUFTLElBQUd2VSxZQUFhLGdEQUErQ2EsWUFBYSxFQUF0SyxFQUF5SyxNQUF6SztBQUNBLGlCQUFPcEMsUUFBUSxDQUFDZ1csVUFBVCxDQUFvQjtBQUN6QnJWLFlBQUFBLElBQUksRUFBRTtBQUNKNEIsY0FBQUEsT0FBTyxFQUFFO0FBREw7QUFEbUIsV0FBcEIsQ0FBUDtBQUtEOztBQUFBO0FBQ0QseUJBQUksMERBQUosRUFBZ0Usc0RBQWhFLEVBQXdILE9BQXhIO0FBQ0EsZUFBTyxNQUFNcVQsWUFBWSxDQUFDSyxJQUFiLENBQWtCLElBQWxCLEVBQXdCLEVBQUMsR0FBR25XLE9BQUo7QUFBYXdCLFVBQUFBLG1CQUFtQixFQUFFO0FBQUVDLFlBQUFBLFlBQUY7QUFBZ0JpQixZQUFBQSxRQUFoQjtBQUEwQkosWUFBQUE7QUFBMUI7QUFBbEMsU0FBeEIsRUFBcUdyQyxPQUFyRyxFQUE4R0MsUUFBOUcsQ0FBYjtBQUNELE9BaEJELENBZ0JDLE9BQU15QyxLQUFOLEVBQVk7QUFDWCx5QkFBSSwwREFBSixFQUFnRUEsS0FBSyxDQUFDRixPQUFOLElBQWlCRSxLQUFqRjtBQUNBLGVBQU8sa0NBQWNBLEtBQUssQ0FBQ0YsT0FBTixJQUFpQkUsS0FBL0IsRUFBc0MsSUFBdEMsRUFBNEMsR0FBNUMsRUFBaUR6QyxRQUFqRCxDQUFQO0FBQ0Q7QUFDRixLQXpCRDtBQTBCRDs7QUFFTzBDLEVBQUFBLHVCQUF1QixHQUFFO0FBQy9CLFdBQVEsR0FBR1osSUFBSSxDQUFDb1UsR0FBTCxLQUFhLElBQWQsR0FBc0IsQ0FBRSxFQUFsQztBQUNEOztBQTUrRDZCIiwic291cmNlc0NvbnRlbnQiOlsiLypcclxuICogV2F6dWggYXBwIC0gQ2xhc3MgZm9yIFdhenVoIHJlcG9ydGluZyBjb250cm9sbGVyXHJcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXHJcbiAqXHJcbiAqIFRoaXMgcHJvZ3JhbSBpcyBmcmVlIHNvZnR3YXJlOyB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XHJcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XHJcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXHJcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXHJcbiAqXHJcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXHJcbiAqL1xyXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJztcclxuaW1wb3J0IGZzIGZyb20gJ2ZzJztcclxuaW1wb3J0IHsgV0FaVUhfTU9EVUxFUyB9IGZyb20gJy4uLy4uL2NvbW1vbi93YXp1aC1tb2R1bGVzJztcclxuaW1wb3J0ICogYXMgVGltU29ydCBmcm9tICd0aW1zb3J0JztcclxuaW1wb3J0IHsgRXJyb3JSZXNwb25zZSB9IGZyb20gJy4uL2xpYi9lcnJvci1yZXNwb25zZSc7XHJcbmltcG9ydCAqIGFzIFZ1bG5lcmFiaWxpdHlSZXF1ZXN0IGZyb20gJy4uL2xpYi9yZXBvcnRpbmcvdnVsbmVyYWJpbGl0eS1yZXF1ZXN0JztcclxuaW1wb3J0ICogYXMgT3ZlcnZpZXdSZXF1ZXN0IGZyb20gJy4uL2xpYi9yZXBvcnRpbmcvb3ZlcnZpZXctcmVxdWVzdCc7XHJcbmltcG9ydCAqIGFzIFJvb3RjaGVja1JlcXVlc3QgZnJvbSAnLi4vbGliL3JlcG9ydGluZy9yb290Y2hlY2stcmVxdWVzdCc7XHJcbmltcG9ydCAqIGFzIFBDSVJlcXVlc3QgZnJvbSAnLi4vbGliL3JlcG9ydGluZy9wY2ktcmVxdWVzdCc7XHJcbmltcG9ydCAqIGFzIEdEUFJSZXF1ZXN0IGZyb20gJy4uL2xpYi9yZXBvcnRpbmcvZ2Rwci1yZXF1ZXN0JztcclxuaW1wb3J0ICogYXMgVFNDUmVxdWVzdCBmcm9tICcuLi9saWIvcmVwb3J0aW5nL3RzYy1yZXF1ZXN0JztcclxuaW1wb3J0ICogYXMgQXVkaXRSZXF1ZXN0IGZyb20gJy4uL2xpYi9yZXBvcnRpbmcvYXVkaXQtcmVxdWVzdCc7XHJcbmltcG9ydCAqIGFzIFN5c2NoZWNrUmVxdWVzdCBmcm9tICcuLi9saWIvcmVwb3J0aW5nL3N5c2NoZWNrLXJlcXVlc3QnO1xyXG5pbXBvcnQgUENJIGZyb20gJy4uL2ludGVncmF0aW9uLWZpbGVzL3BjaS1yZXF1aXJlbWVudHMtcGRmbWFrZSc7XHJcbmltcG9ydCBHRFBSIGZyb20gJy4uL2ludGVncmF0aW9uLWZpbGVzL2dkcHItcmVxdWlyZW1lbnRzLXBkZm1ha2UnO1xyXG5pbXBvcnQgVFNDIGZyb20gJy4uL2ludGVncmF0aW9uLWZpbGVzL3RzYy1yZXF1aXJlbWVudHMtcGRmbWFrZSc7XHJcbmltcG9ydCBQcm9jZXNzRXF1aXZhbGVuY2UgZnJvbSAnLi4vbGliL3Byb2Nlc3Mtc3RhdGUtZXF1aXZhbGVuY2UnO1xyXG5pbXBvcnQgeyBLZXlFcXVpdmFsZW5jZSB9IGZyb20gJy4uLy4uL2NvbW1vbi9jc3Yta2V5LWVxdWl2YWxlbmNlJztcclxuaW1wb3J0IHsgQWdlbnRDb25maWd1cmF0aW9uIH0gZnJvbSAnLi4vbGliL3JlcG9ydGluZy9hZ2VudC1jb25maWd1cmF0aW9uJztcclxuaW1wb3J0IHsgT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5IH0gZnJvbSAnc3JjL2NvcmUvc2VydmVyJztcclxuaW1wb3J0IHsgUmVwb3J0UHJpbnRlciB9IGZyb20gJy4uL2xpYi9yZXBvcnRpbmcvcHJpbnRlcic7XHJcbmltcG9ydCB7IGxvZyB9IGZyb20gJy4uL2xpYi9sb2dnZXInO1xyXG5pbXBvcnQge1xyXG4gIFdBWlVIX0FMRVJUU19QQVRURVJOLFxyXG4gIFdBWlVIX0RBVEFfRE9XTkxPQURTX0RJUkVDVE9SWV9QQVRILFxyXG4gIFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgsXHJcbiAgQVVUSE9SSVpFRF9BR0VOVFMsXHJcbiAgQVBJX05BTUVfQUdFTlRfU1RBVFVTLFxyXG59IGZyb20gJy4uLy4uL2NvbW1vbi9jb25zdGFudHMnO1xyXG5pbXBvcnQgeyBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cywgY3JlYXRlRGF0YURpcmVjdG9yeUlmTm90RXhpc3RzIH0gZnJvbSAnLi4vbGliL2ZpbGVzeXN0ZW0nO1xyXG5pbXBvcnQgbW9tZW50IGZyb20gJ21vbWVudCc7XHJcbmltcG9ydCB7IGFnZW50U3RhdHVzTGFiZWxCeUFnZW50U3RhdHVzIH0gZnJvbSAnLi4vLi4vY29tbW9uL3NlcnZpY2VzL3d6X2FnZW50X3N0YXR1cyc7XHJcblxyXG5leHBvcnQgY2xhc3MgV2F6dWhSZXBvcnRpbmdDdHJsIHtcclxuICBjb25zdHJ1Y3RvcigpIHt9XHJcblxyXG4gIC8qKlxyXG4gICAqIFRoaXMgZG8gZm9ybWF0IHRvIGZpbHRlcnNcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gZmlsdGVycyBFLmc6IGNsdXN0ZXIubmFtZTogd2F6dWggQU5EIHJ1bGUuZ3JvdXBzOiB2dWxuZXJhYmlsaXR5XHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHNlYXJjaEJhciBzZWFyY2ggdGVybVxyXG4gICAqL1xyXG4gIHByaXZhdGUgc2FuaXRpemVLaWJhbmFGaWx0ZXJzKGZpbHRlcnM6IGFueSwgc2VhcmNoQmFyPzogc3RyaW5nKTogW3N0cmluZywgc3RyaW5nXSB7XHJcbiAgICBsb2coJ3JlcG9ydGluZzpzYW5pdGl6ZUtpYmFuYUZpbHRlcnMnLCBgU3RhcnRlZCB0byBzYW5pdGl6ZSBmaWx0ZXJzYCwgJ2luZm8nKTtcclxuICAgIGxvZyhcclxuICAgICAgJ3JlcG9ydGluZzpzYW5pdGl6ZUtpYmFuYUZpbHRlcnMnLFxyXG4gICAgICBgZmlsdGVyczogJHtmaWx0ZXJzLmxlbmd0aH0sIHNlYXJjaEJhcjogJHtzZWFyY2hCYXJ9YCxcclxuICAgICAgJ2RlYnVnJ1xyXG4gICAgKTtcclxuICAgIGxldCBzdHIgPSAnJztcclxuXHJcbiAgICBjb25zdCBhZ2VudHNGaWx0ZXI6IGFueSA9IFtdO1xyXG5cclxuICAgIC8vc2VwYXJhdGUgYWdlbnRzIGZpbHRlclxyXG4gICAgZmlsdGVycyA9IGZpbHRlcnMuZmlsdGVyKChmaWx0ZXIpID0+IHtcclxuICAgICAgaWYgKGZpbHRlci5tZXRhLmNvbnRyb2xsZWRCeSA9PT0gQVVUSE9SSVpFRF9BR0VOVFMpIHtcclxuICAgICAgICBhZ2VudHNGaWx0ZXIucHVzaChmaWx0ZXIpO1xyXG4gICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gZmlsdGVyO1xyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgbGVuID0gZmlsdGVycy5sZW5ndGg7XHJcblxyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkrKykge1xyXG4gICAgICBjb25zdCB7IG5lZ2F0ZSwga2V5LCB2YWx1ZSwgcGFyYW1zLCB0eXBlIH0gPSBmaWx0ZXJzW2ldLm1ldGE7XHJcbiAgICAgIHN0ciArPSBgJHtuZWdhdGUgPyAnTk9UICcgOiAnJ31gO1xyXG4gICAgICBzdHIgKz0gYCR7a2V5fTogYDtcclxuICAgICAgc3RyICs9IGAke1xyXG4gICAgICAgIHR5cGUgPT09ICdyYW5nZSdcclxuICAgICAgICAgID8gYCR7cGFyYW1zLmd0ZX0tJHtwYXJhbXMubHR9YFxyXG4gICAgICAgICAgOiB0eXBlID09PSAncGhyYXNlcydcclxuICAgICAgICAgICAgPyAnKCcgKyBwYXJhbXMuam9pbihcIiBPUiBcIikgKyAnKSdcclxuICAgICAgICAgICAgOiB0eXBlID09PSAnZXhpc3RzJ1xyXG4gICAgICAgICAgICAgID8gJyonXHJcbiAgICAgICAgICAgICAgOiAhIXZhbHVlXHJcbiAgICAgICAgICA/IHZhbHVlXHJcbiAgICAgICAgICA6IChwYXJhbXMgfHwge30pLnF1ZXJ5XHJcbiAgICAgIH1gO1xyXG4gICAgICBzdHIgKz0gYCR7aSA9PT0gbGVuIC0gMSA/ICcnIDogJyBBTkQgJ31gO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChzZWFyY2hCYXIpIHtcclxuICAgICAgc3RyICs9IGAgQU5EICgkeyBzZWFyY2hCYXJ9KWA7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgYWdlbnRzRmlsdGVyU3RyID0gYWdlbnRzRmlsdGVyLm1hcCgoZmlsdGVyKSA9PiBmaWx0ZXIubWV0YS52YWx1ZSkuam9pbignLCcpO1xyXG5cclxuICAgIGxvZyhcclxuICAgICAgJ3JlcG9ydGluZzpzYW5pdGl6ZUtpYmFuYUZpbHRlcnMnLFxyXG4gICAgICBgc3RyOiAke3N0cn0sIGFnZW50c0ZpbHRlclN0cjogJHthZ2VudHNGaWx0ZXJTdHJ9YCxcclxuICAgICAgJ2RlYnVnJ1xyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gW3N0ciwgYWdlbnRzRmlsdGVyU3RyXTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFRoaXMgcGVyZm9ybXMgdGhlIHJlbmRlcmluZyBvZiBnaXZlbiBoZWFkZXJcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gcHJpbnRlciBzZWN0aW9uIHRhcmdldFxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBzZWN0aW9uIHNlY3Rpb24gdGFyZ2V0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHRhYiB0YWIgdGFyZ2V0XHJcbiAgICogQHBhcmFtIHtCb29sZWFufSBpc0FnZW50cyBpcyBhZ2VudHMgc2VjdGlvblxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBhcGlJZCBJRCBvZiBBUElcclxuICAgKi9cclxuICBwcml2YXRlIGFzeW5jIHJlbmRlckhlYWRlcihjb250ZXh0LCBwcmludGVyLCBzZWN0aW9uLCB0YWIsIGlzQWdlbnRzLCBhcGlJZCkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgbG9nKFxyXG4gICAgICAgICdyZXBvcnRpbmc6cmVuZGVySGVhZGVyJyxcclxuICAgICAgICBgc2VjdGlvbjogJHtzZWN0aW9ufSwgdGFiOiAke3RhYn0sIGlzQWdlbnRzOiAke2lzQWdlbnRzfSwgYXBpSWQ6ICR7YXBpSWR9YCxcclxuICAgICAgICAnZGVidWcnXHJcbiAgICAgICk7XHJcbiAgICAgIGlmIChzZWN0aW9uICYmIHR5cGVvZiBzZWN0aW9uID09PSAnc3RyaW5nJykge1xyXG4gICAgICAgIGlmICghWydhZ2VudENvbmZpZycsICdncm91cENvbmZpZyddLmluY2x1ZGVzKHNlY3Rpb24pKSB7XHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xyXG4gICAgICAgICAgICB0ZXh0OiBXQVpVSF9NT0RVTEVTW3RhYl0udGl0bGUgKyAnIHJlcG9ydCcsXHJcbiAgICAgICAgICAgIHN0eWxlOiAnaDEnLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChzZWN0aW9uID09PSAnYWdlbnRDb25maWcnKSB7XHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xyXG4gICAgICAgICAgICB0ZXh0OiBgQWdlbnQgJHtpc0FnZW50c30gY29uZmlndXJhdGlvbmAsXHJcbiAgICAgICAgICAgIHN0eWxlOiAnaDEnLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIGlmIChzZWN0aW9uID09PSAnZ3JvdXBDb25maWcnKSB7XHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xyXG4gICAgICAgICAgICB0ZXh0OiAnQWdlbnRzIGluIGdyb3VwJyxcclxuICAgICAgICAgICAgc3R5bGU6ICdoMScsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcHJpbnRlci5hZGROZXdMaW5lKCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChpc0FnZW50cyAmJiB0eXBlb2YgaXNBZ2VudHMgPT09ICdvYmplY3QnKSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5idWlsZEFnZW50c1RhYmxlKFxyXG4gICAgICAgICAgY29udGV4dCxcclxuICAgICAgICAgIHByaW50ZXIsXHJcbiAgICAgICAgICBpc0FnZW50cyxcclxuICAgICAgICAgIGFwaUlkLFxyXG4gICAgICAgICAgc2VjdGlvbiA9PT0gJ2dyb3VwQ29uZmlnJyA/IHRhYiA6ICcnXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKGlzQWdlbnRzICYmIHR5cGVvZiBpc0FnZW50cyA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgICBjb25zdCBhZ2VudFJlc3BvbnNlID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdChcclxuICAgICAgICAgICdHRVQnLFxyXG4gICAgICAgICAgYC9hZ2VudHNgLFxyXG4gICAgICAgICAgeyBwYXJhbXM6IHsgYWdlbnRzX2xpc3Q6IGlzQWdlbnRzIH0gfSxcclxuICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9XHJcbiAgICAgICAgKTtcclxuICAgICAgICBjb25zdCBhZ2VudERhdGEgPSBhZ2VudFJlc3BvbnNlLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc1swXTtcclxuICAgICAgICBpZiAoYWdlbnREYXRhICYmIGFnZW50RGF0YS5zdGF0dXMgIT09IEFQSV9OQU1FX0FHRU5UX1NUQVRVUy5BQ1RJVkUpIHtcclxuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcclxuICAgICAgICAgICAgdGV4dDogYFdhcm5pbmcuIEFnZW50IGlzICR7YWdlbnRTdGF0dXNMYWJlbEJ5QWdlbnRTdGF0dXMoYWdlbnREYXRhLnN0YXR1cykudG9Mb3dlckNhc2UoKX1gLFxyXG4gICAgICAgICAgICBzdHlsZTogJ3N0YW5kYXJkJyxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBhd2FpdCB0aGlzLmJ1aWxkQWdlbnRzVGFibGUoY29udGV4dCwgcHJpbnRlciwgW2lzQWdlbnRzXSwgYXBpSWQpO1xyXG5cclxuICAgICAgICBpZiAoYWdlbnREYXRhICYmIGFnZW50RGF0YS5ncm91cCkge1xyXG4gICAgICAgICAgY29uc3QgYWdlbnRHcm91cHMgPSBhZ2VudERhdGEuZ3JvdXAuam9pbignLCAnKTtcclxuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcclxuICAgICAgICAgICAgdGV4dDogYEdyb3VwJHthZ2VudERhdGEuZ3JvdXAubGVuZ3RoID4gMSA/ICdzJyA6ICcnfTogJHthZ2VudEdyb3Vwc31gLFxyXG4gICAgICAgICAgICBzdHlsZTogJ3N0YW5kYXJkJyxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBpZiAoV0FaVUhfTU9EVUxFU1t0YWJdICYmIFdBWlVIX01PRFVMRVNbdGFiXS5kZXNjcmlwdGlvbikge1xyXG4gICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcclxuICAgICAgICAgIHRleHQ6IFdBWlVIX01PRFVMRVNbdGFiXS5kZXNjcmlwdGlvbixcclxuICAgICAgICAgIHN0eWxlOiAnc3RhbmRhcmQnLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3JlcG9ydGluZzpyZW5kZXJIZWFkZXInLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFRoaXMgYnVpbGQgdGhlIGFnZW50cyB0YWJsZVxyXG4gICAqIEBwYXJhbSB7QXJyYXk8U3RyaW5ncz59IGlkcyBpZHMgb2YgYWdlbnRzXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGFwaUlkIEFQSSBpZFxyXG4gICAqL1xyXG4gIHByaXZhdGUgYXN5bmMgYnVpbGRBZ2VudHNUYWJsZShjb250ZXh0LCBwcmludGVyOiBSZXBvcnRQcmludGVyLCBhZ2VudElEczogc3RyaW5nW10sIGFwaUlkOiBzdHJpbmcsIGdyb3VwSUQ6IHN0cmluZyA9ICcnKSB7XHJcbiAgICBjb25zdCBkYXRlRm9ybWF0ID0gYXdhaXQgY29udGV4dC5jb3JlLnVpU2V0dGluZ3MuY2xpZW50LmdldCgnZGF0ZUZvcm1hdCcpO1xyXG4gICAgaWYgKCghYWdlbnRJRHMgfHwgIWFnZW50SURzLmxlbmd0aCkgJiYgIWdyb3VwSUQpIHJldHVybjtcclxuICAgIGxvZygncmVwb3J0aW5nOmJ1aWxkQWdlbnRzVGFibGUnLCBgJHthZ2VudElEcy5sZW5ndGh9IGFnZW50cyBmb3IgQVBJICR7YXBpSWR9YCwgJ2luZm8nKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCBhZ2VudHNEYXRhID0gW107XHJcbiAgICAgIGlmIChncm91cElEKSB7XHJcbiAgICAgICAgbGV0IHRvdGFsQWdlbnRzSW5Hcm91cCA9IG51bGw7XHJcbiAgICAgICAgZG97XHJcbiAgICAgICAgICBjb25zdCB7IGRhdGE6IHsgZGF0YTogeyBhZmZlY3RlZF9pdGVtcywgdG90YWxfYWZmZWN0ZWRfaXRlbXMgfSB9IH0gPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxyXG4gICAgICAgICAgICAnR0VUJyxcclxuICAgICAgICAgICAgYC9ncm91cHMvJHtncm91cElEfS9hZ2VudHNgLFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICBvZmZzZXQ6IGFnZW50c0RhdGEubGVuZ3RoLFxyXG4gICAgICAgICAgICAgICAgc2VsZWN0OiAnZGF0ZUFkZCxpZCxpcCxsYXN0S2VlcEFsaXZlLG1hbmFnZXIsbmFtZSxvcy5uYW1lLG9zLnZlcnNpb24sdmVyc2lvbicsXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7IGFwaUhvc3RJRDogYXBpSWQgfVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgICF0b3RhbEFnZW50c0luR3JvdXAgJiYgKHRvdGFsQWdlbnRzSW5Hcm91cCA9IHRvdGFsX2FmZmVjdGVkX2l0ZW1zKTtcclxuICAgICAgICAgIGFnZW50c0RhdGEgPSBbLi4uYWdlbnRzRGF0YSwgLi4uYWZmZWN0ZWRfaXRlbXNdO1xyXG4gICAgICAgIH13aGlsZShhZ2VudHNEYXRhLmxlbmd0aCA8IHRvdGFsQWdlbnRzSW5Hcm91cCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgZm9yIChjb25zdCBhZ2VudElEIG9mIGFnZW50SURzKSB7XHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCB7IGRhdGE6IHsgZGF0YTogeyBhZmZlY3RlZF9pdGVtczogW2FnZW50XSB9IH0gfSA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXHJcbiAgICAgICAgICAgICAgJ0dFVCcsXHJcbiAgICAgICAgICAgICAgYC9hZ2VudHNgLFxyXG4gICAgICAgICAgICAgIHsgXHJcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICAgICAgcTogYGlkPSR7YWdlbnRJRH1gLFxyXG4gICAgICAgICAgICAgICAgICBzZWxlY3Q6ICdkYXRlQWRkLGlkLGlwLGxhc3RLZWVwQWxpdmUsbWFuYWdlcixuYW1lLG9zLm5hbWUsb3MudmVyc2lvbix2ZXJzaW9uJyxcclxuICAgICAgICAgICAgICAgIH0gXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB7IGFwaUhvc3RJRDogYXBpSWQgfVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICBhZ2VudHNEYXRhLnB1c2goYWdlbnQpO1xyXG4gICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgbG9nKFxyXG4gICAgICAgICAgICAgICdyZXBvcnRpbmc6YnVpbGRBZ2VudHNUYWJsZScsXHJcbiAgICAgICAgICAgICAgYFNraXAgYWdlbnQgZHVlIHRvOiAke2Vycm9yLm1lc3NhZ2UgfHwgZXJyb3J9YCxcclxuICAgICAgICAgICAgICAnZGVidWcnXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBpZihhZ2VudHNEYXRhLmxlbmd0aCl7XHJcbiAgICAgICAgLy8gUHJpbnQgYSB0YWJsZSB3aXRoIGFnZW50L3MgaW5mb3JtYXRpb25cclxuICAgICAgICBwcmludGVyLmFkZFNpbXBsZVRhYmxlKHtcclxuICAgICAgICAgIGNvbHVtbnM6IFtcclxuICAgICAgICAgICAgeyBpZDogJ2lkJywgbGFiZWw6ICdJRCcgfSxcclxuICAgICAgICAgICAgeyBpZDogJ25hbWUnLCBsYWJlbDogJ05hbWUnIH0sXHJcbiAgICAgICAgICAgIHsgaWQ6ICdpcCcsIGxhYmVsOiAnSVAnIH0sXHJcbiAgICAgICAgICAgIHsgaWQ6ICd2ZXJzaW9uJywgbGFiZWw6ICdWZXJzaW9uJyB9LFxyXG4gICAgICAgICAgICB7IGlkOiAnbWFuYWdlcicsIGxhYmVsOiAnTWFuYWdlcicgfSxcclxuICAgICAgICAgICAgeyBpZDogJ29zJywgbGFiZWw6ICdPUycgfSxcclxuICAgICAgICAgICAgeyBpZDogJ2RhdGVBZGQnLCBsYWJlbDogJ1JlZ2lzdHJhdGlvbiBkYXRlJyB9LFxyXG4gICAgICAgICAgICB7IGlkOiAnbGFzdEtlZXBBbGl2ZScsIGxhYmVsOiAnTGFzdCBrZWVwIGFsaXZlJyB9LFxyXG4gICAgICAgICAgXSxcclxuICAgICAgICAgIGl0ZW1zOiBhZ2VudHNEYXRhLm1hcCgoYWdlbnQpID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAuLi5hZ2VudCxcclxuICAgICAgICAgICAgICBvczogKGFnZW50Lm9zICYmIGFnZW50Lm9zLm5hbWUgJiYgYWdlbnQub3MudmVyc2lvbikgPyBgJHthZ2VudC5vcy5uYW1lfSAke2FnZW50Lm9zLnZlcnNpb259YCA6ICcnLFxyXG4gICAgICAgICAgICAgIGxhc3RLZWVwQWxpdmU6IG1vbWVudChhZ2VudC5sYXN0S2VlcEFsaXZlKS5mb3JtYXQoZGF0ZUZvcm1hdCksXHJcbiAgICAgICAgICAgICAgZGF0ZUFkZDogbW9tZW50KGFnZW50LmRhdGVBZGQpLmZvcm1hdChkYXRlRm9ybWF0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KSxcclxuICAgICAgICB9KTtcclxuICAgICAgfWVsc2UgaWYoIWFnZW50c0RhdGEubGVuZ3RoICYmIGdyb3VwSUQpe1xyXG4gICAgICAgIC8vIEZvciBncm91cCByZXBvcnRzIHdoZW4gdGhlcmUgaXMgbm8gYWdlbnRzIGluIHRoZSBncm91cFxyXG4gICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XHJcbiAgICAgICAgICB0ZXh0OiAnVGhlcmUgYXJlIG5vIGFnZW50cyBpbiB0aGlzIGdyb3VwLicsXHJcbiAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMTIsIGNvbG9yOiAnIzAwMCcgfSxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgICBcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGxvZygncmVwb3J0aW5nOmJ1aWxkQWdlbnRzVGFibGUnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFRoaXMgbG9hZCBtb3JlIGluZm9ybWF0aW9uXHJcbiAgICogQHBhcmFtIHsqfSBjb250ZXh0IEVuZHBvaW50IGNvbnRleHRcclxuICAgKiBAcGFyYW0geyp9IHByaW50ZXIgcHJpbnRlciBpbnN0YW5jZVxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBzZWN0aW9uIHNlY3Rpb24gdGFyZ2V0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHRhYiB0YWIgdGFyZ2V0XHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGFwaUlkIElEIG9mIEFQSVxyXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBmcm9tIFRpbWVzdGFtcCAobXMpIGZyb21cclxuICAgKiBAcGFyYW0ge051bWJlcn0gdG8gVGltZXN0YW1wIChtcykgdG9cclxuICAgKiBAcGFyYW0ge1N0cmluZ30gZmlsdGVycyBFLmc6IGNsdXN0ZXIubmFtZTogd2F6dWggQU5EIHJ1bGUuZ3JvdXBzOiB2dWxuZXJhYmlsaXR5XHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHBhdHRlcm5cclxuICAgKiBAcGFyYW0ge09iamVjdH0gYWdlbnQgYWdlbnQgdGFyZ2V0XHJcbiAgICogQHJldHVybnMge09iamVjdH0gRXh0ZW5kZWQgaW5mb3JtYXRpb25cclxuICAgKi9cclxuICBwcml2YXRlIGFzeW5jIGV4dGVuZGVkSW5mb3JtYXRpb24oXHJcbiAgICBjb250ZXh0LFxyXG4gICAgcHJpbnRlcixcclxuICAgIHNlY3Rpb24sXHJcbiAgICB0YWIsXHJcbiAgICBhcGlJZCxcclxuICAgIGZyb20sXHJcbiAgICB0byxcclxuICAgIGZpbHRlcnMsXHJcbiAgICBwYXR0ZXJuID0gV0FaVUhfQUxFUlRTX1BBVFRFUk4sXHJcbiAgICBhZ2VudCA9IG51bGxcclxuICApIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGxvZyhcclxuICAgICAgICAncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLFxyXG4gICAgICAgIGBTZWN0aW9uICR7c2VjdGlvbn0gYW5kIHRhYiAke3RhYn0sIEFQSSBpcyAke2FwaUlkfS4gRnJvbSAke2Zyb219IHRvICR7dG99LiBGaWx0ZXJzICR7ZmlsdGVyc30uIEluZGV4IHBhdHRlcm4gJHtwYXR0ZXJufWAsXHJcbiAgICAgICAgJ2luZm8nXHJcbiAgICAgICk7XHJcbiAgICAgIGlmIChzZWN0aW9uID09PSAnYWdlbnRzJyAmJiAhYWdlbnQpIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1JlcG9ydGluZyBmb3Igc3BlY2lmaWMgYWdlbnQgbmVlZHMgYW4gYWdlbnQgSUQgaW4gb3JkZXIgdG8gd29yayBwcm9wZXJseScpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCBhZ2VudHMgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxyXG4gICAgICAgICdHRVQnLFxyXG4gICAgICAgICcvYWdlbnRzJyxcclxuICAgICAgICB7IHBhcmFtczogeyBsaW1pdDogMSB9IH0sXHJcbiAgICAgICAgeyBhcGlIb3N0SUQ6IGFwaUlkIH1cclxuICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IHRvdGFsQWdlbnRzID0gYWdlbnRzLmRhdGEuZGF0YS50b3RhbF9hZmZlY3RlZF9pdGVtcztcclxuXHJcbiAgICAgIGlmIChzZWN0aW9uID09PSAnb3ZlcnZpZXcnICYmIHRhYiA9PT0gJ3Z1bHMnKSB7XHJcbiAgICAgICAgbG9nKFxyXG4gICAgICAgICAgJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJyxcclxuICAgICAgICAgICdGZXRjaGluZyBvdmVydmlldyB2dWxuZXJhYmlsaXR5IGRldGVjdG9yIG1ldHJpY3MnLFxyXG4gICAgICAgICAgJ2RlYnVnJ1xyXG4gICAgICAgICk7XHJcbiAgICAgICAgY29uc3QgdnVsbmVyYWJpbGl0aWVzTGV2ZWxzID0gWydMb3cnLCAnTWVkaXVtJywgJ0hpZ2gnLCAnQ3JpdGljYWwnXTtcclxuXHJcbiAgICAgICAgY29uc3QgdnVsbmVyYWJpbGl0aWVzUmVzcG9uc2VzQ291bnQgPSAoXHJcbiAgICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChcclxuICAgICAgICAgICAgdnVsbmVyYWJpbGl0aWVzTGV2ZWxzLm1hcChhc3luYyAodnVsbmVyYWJpbGl0aWVzTGV2ZWwpID0+IHtcclxuICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgY291bnQgPSBhd2FpdCBWdWxuZXJhYmlsaXR5UmVxdWVzdC51bmlxdWVTZXZlcml0eUNvdW50KFxyXG4gICAgICAgICAgICAgICAgICBjb250ZXh0LFxyXG4gICAgICAgICAgICAgICAgICBmcm9tLFxyXG4gICAgICAgICAgICAgICAgICB0byxcclxuICAgICAgICAgICAgICAgICAgdnVsbmVyYWJpbGl0aWVzTGV2ZWwsXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlcnMsXHJcbiAgICAgICAgICAgICAgICAgIHBhdHRlcm5cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gY291bnRcclxuICAgICAgICAgICAgICAgICAgPyBgJHtjb3VudH0gb2YgJHt0b3RhbEFnZW50c30gYWdlbnRzIGhhdmUgJHt2dWxuZXJhYmlsaXRpZXNMZXZlbC50b0xvY2FsZUxvd2VyQ2FzZSgpfSB2dWxuZXJhYmlsaXRpZXMuYFxyXG4gICAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZDtcclxuICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge31cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIClcclxuICAgICAgICApLmZpbHRlcigodnVsbmVyYWJpbGl0aWVzUmVzcG9uc2UpID0+IHZ1bG5lcmFiaWxpdGllc1Jlc3BvbnNlKTtcclxuXHJcbiAgICAgICAgcHJpbnRlci5hZGRMaXN0KHtcclxuICAgICAgICAgIHRpdGxlOiB7IHRleHQ6ICdTdW1tYXJ5Jywgc3R5bGU6ICdoMicgfSxcclxuICAgICAgICAgIGxpc3Q6IHZ1bG5lcmFiaWxpdGllc1Jlc3BvbnNlc0NvdW50LFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBsb2coXHJcbiAgICAgICAgICAncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLFxyXG4gICAgICAgICAgJ0ZldGNoaW5nIG92ZXJ2aWV3IHZ1bG5lcmFiaWxpdHkgZGV0ZWN0b3IgdG9wIDMgYWdlbnRzIGJ5IGNhdGVnb3J5JyxcclxuICAgICAgICAgICdkZWJ1ZydcclxuICAgICAgICApO1xyXG4gICAgICAgIGNvbnN0IGxvd1JhbmsgPSBhd2FpdCBWdWxuZXJhYmlsaXR5UmVxdWVzdC50b3BBZ2VudENvdW50KFxyXG4gICAgICAgICAgY29udGV4dCxcclxuICAgICAgICAgIGZyb20sXHJcbiAgICAgICAgICB0byxcclxuICAgICAgICAgICdMb3cnLFxyXG4gICAgICAgICAgZmlsdGVycyxcclxuICAgICAgICAgIHBhdHRlcm5cclxuICAgICAgICApO1xyXG4gICAgICAgIGNvbnN0IG1lZGl1bVJhbmsgPSBhd2FpdCBWdWxuZXJhYmlsaXR5UmVxdWVzdC50b3BBZ2VudENvdW50KFxyXG4gICAgICAgICAgY29udGV4dCxcclxuICAgICAgICAgIGZyb20sXHJcbiAgICAgICAgICB0byxcclxuICAgICAgICAgICdNZWRpdW0nLFxyXG4gICAgICAgICAgZmlsdGVycyxcclxuICAgICAgICAgIHBhdHRlcm5cclxuICAgICAgICApO1xyXG4gICAgICAgIGNvbnN0IGhpZ2hSYW5rID0gYXdhaXQgVnVsbmVyYWJpbGl0eVJlcXVlc3QudG9wQWdlbnRDb3VudChcclxuICAgICAgICAgIGNvbnRleHQsXHJcbiAgICAgICAgICBmcm9tLFxyXG4gICAgICAgICAgdG8sXHJcbiAgICAgICAgICAnSGlnaCcsXHJcbiAgICAgICAgICBmaWx0ZXJzLFxyXG4gICAgICAgICAgcGF0dGVyblxyXG4gICAgICAgICk7XHJcbiAgICAgICAgY29uc3QgY3JpdGljYWxSYW5rID0gYXdhaXQgVnVsbmVyYWJpbGl0eVJlcXVlc3QudG9wQWdlbnRDb3VudChcclxuICAgICAgICAgIGNvbnRleHQsXHJcbiAgICAgICAgICBmcm9tLFxyXG4gICAgICAgICAgdG8sXHJcbiAgICAgICAgICAnQ3JpdGljYWwnLFxyXG4gICAgICAgICAgZmlsdGVycyxcclxuICAgICAgICAgIHBhdHRlcm5cclxuICAgICAgICApO1xyXG4gICAgICAgIGxvZyhcclxuICAgICAgICAgICdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsXHJcbiAgICAgICAgICAnQWRkaW5nIG92ZXJ2aWV3IHZ1bG5lcmFiaWxpdHkgZGV0ZWN0b3IgdG9wIDMgYWdlbnRzIGJ5IGNhdGVnb3J5JyxcclxuICAgICAgICAgICdkZWJ1ZydcclxuICAgICAgICApO1xyXG4gICAgICAgIGlmIChjcml0aWNhbFJhbmsgJiYgY3JpdGljYWxSYW5rLmxlbmd0aCkge1xyXG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50V2l0aE5ld0xpbmUoe1xyXG4gICAgICAgICAgICB0ZXh0OiAnVG9wIDMgYWdlbnRzIHdpdGggY3JpdGljYWwgc2V2ZXJpdHkgdnVsbmVyYWJpbGl0aWVzJyxcclxuICAgICAgICAgICAgc3R5bGU6ICdoMycsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIGF3YWl0IHRoaXMuYnVpbGRBZ2VudHNUYWJsZShjb250ZXh0LCBwcmludGVyLCBjcml0aWNhbFJhbmssIGFwaUlkKTtcclxuICAgICAgICAgIHByaW50ZXIuYWRkTmV3TGluZSgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGhpZ2hSYW5rICYmIGhpZ2hSYW5rLmxlbmd0aCkge1xyXG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50V2l0aE5ld0xpbmUoe1xyXG4gICAgICAgICAgICB0ZXh0OiAnVG9wIDMgYWdlbnRzIHdpdGggaGlnaCBzZXZlcml0eSB2dWxuZXJhYmlsaXRpZXMnLFxyXG4gICAgICAgICAgICBzdHlsZTogJ2gzJyxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgYXdhaXQgdGhpcy5idWlsZEFnZW50c1RhYmxlKGNvbnRleHQsIHByaW50ZXIsIGhpZ2hSYW5rLCBhcGlJZCk7XHJcbiAgICAgICAgICBwcmludGVyLmFkZE5ld0xpbmUoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChtZWRpdW1SYW5rICYmIG1lZGl1bVJhbmsubGVuZ3RoKSB7XHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7XHJcbiAgICAgICAgICAgIHRleHQ6ICdUb3AgMyBhZ2VudHMgd2l0aCBtZWRpdW0gc2V2ZXJpdHkgdnVsbmVyYWJpbGl0aWVzJyxcclxuICAgICAgICAgICAgc3R5bGU6ICdoMycsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIGF3YWl0IHRoaXMuYnVpbGRBZ2VudHNUYWJsZShjb250ZXh0LCBwcmludGVyLCBtZWRpdW1SYW5rLCBhcGlJZCk7XHJcbiAgICAgICAgICBwcmludGVyLmFkZE5ld0xpbmUoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChsb3dSYW5rICYmIGxvd1JhbmsubGVuZ3RoKSB7XHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7XHJcbiAgICAgICAgICAgIHRleHQ6ICdUb3AgMyBhZ2VudHMgd2l0aCBsb3cgc2V2ZXJpdHkgdnVsbmVyYWJpbGl0aWVzJyxcclxuICAgICAgICAgICAgc3R5bGU6ICdoMycsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIGF3YWl0IHRoaXMuYnVpbGRBZ2VudHNUYWJsZShjb250ZXh0LCBwcmludGVyLCBsb3dSYW5rLCBhcGlJZCk7XHJcbiAgICAgICAgICBwcmludGVyLmFkZE5ld0xpbmUoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxvZyhcclxuICAgICAgICAgICdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsXHJcbiAgICAgICAgICAnRmV0Y2hpbmcgb3ZlcnZpZXcgdnVsbmVyYWJpbGl0eSBkZXRlY3RvciB0b3AgMyBDVkVzJyxcclxuICAgICAgICAgICdkZWJ1ZydcclxuICAgICAgICApO1xyXG4gICAgICAgIGNvbnN0IGN2ZVJhbmsgPSBhd2FpdCBWdWxuZXJhYmlsaXR5UmVxdWVzdC50b3BDVkVDb3VudChjb250ZXh0LCBmcm9tLCB0bywgZmlsdGVycywgcGF0dGVybik7XHJcbiAgICAgICAgbG9nKFxyXG4gICAgICAgICAgJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJyxcclxuICAgICAgICAgICdBZGRpbmcgb3ZlcnZpZXcgdnVsbmVyYWJpbGl0eSBkZXRlY3RvciB0b3AgMyBDVkVzJyxcclxuICAgICAgICAgICdkZWJ1ZydcclxuICAgICAgICApO1xyXG4gICAgICAgIGlmIChjdmVSYW5rICYmIGN2ZVJhbmsubGVuZ3RoKSB7XHJcbiAgICAgICAgICBwcmludGVyLmFkZFNpbXBsZVRhYmxlKHtcclxuICAgICAgICAgICAgdGl0bGU6IHsgdGV4dDogJ1RvcCAzIENWRScsIHN0eWxlOiAnaDInIH0sXHJcbiAgICAgICAgICAgIGNvbHVtbnM6IFtcclxuICAgICAgICAgICAgICB7IGlkOiAndG9wJywgbGFiZWw6ICdUb3AnIH0sXHJcbiAgICAgICAgICAgICAgeyBpZDogJ2N2ZScsIGxhYmVsOiAnQ1ZFJyB9LFxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBpdGVtczogY3ZlUmFuay5tYXAoKGl0ZW0pID0+ICh7IHRvcDogY3ZlUmFuay5pbmRleE9mKGl0ZW0pICsgMSwgY3ZlOiBpdGVtIH0pKSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKHNlY3Rpb24gPT09ICdvdmVydmlldycgJiYgdGFiID09PSAnZ2VuZXJhbCcpIHtcclxuICAgICAgICBsb2coJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJywgJ0ZldGNoaW5nIHRvcCAzIGFnZW50cyB3aXRoIGxldmVsIDE1IGFsZXJ0cycsICdkZWJ1ZycpO1xyXG5cclxuICAgICAgICBjb25zdCBsZXZlbDE1UmFuayA9IGF3YWl0IE92ZXJ2aWV3UmVxdWVzdC50b3BMZXZlbDE1KGNvbnRleHQsIGZyb20sIHRvLCBmaWx0ZXJzLCBwYXR0ZXJuKTtcclxuXHJcbiAgICAgICAgbG9nKCdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsICdBZGRpbmcgdG9wIDMgYWdlbnRzIHdpdGggbGV2ZWwgMTUgYWxlcnRzJywgJ2RlYnVnJyk7XHJcbiAgICAgICAgaWYgKGxldmVsMTVSYW5rLmxlbmd0aCkge1xyXG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50KHtcclxuICAgICAgICAgICAgdGV4dDogJ1RvcCAzIGFnZW50cyB3aXRoIGxldmVsIDE1IGFsZXJ0cycsXHJcbiAgICAgICAgICAgIHN0eWxlOiAnaDInLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBhd2FpdCB0aGlzLmJ1aWxkQWdlbnRzVGFibGUoY29udGV4dCwgcHJpbnRlciwgbGV2ZWwxNVJhbmssIGFwaUlkKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChzZWN0aW9uID09PSAnb3ZlcnZpZXcnICYmIHRhYiA9PT0gJ3BtJykge1xyXG4gICAgICAgIGxvZygncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLCAnRmV0Y2hpbmcgbW9zdCBjb21tb24gcm9vdGtpdHMnLCAnZGVidWcnKTtcclxuICAgICAgICBjb25zdCB0b3A1Um9vdGtpdHNSYW5rID0gYXdhaXQgUm9vdGNoZWNrUmVxdWVzdC50b3A1Um9vdGtpdHNEZXRlY3RlZChcclxuICAgICAgICAgIGNvbnRleHQsXHJcbiAgICAgICAgICBmcm9tLFxyXG4gICAgICAgICAgdG8sXHJcbiAgICAgICAgICBmaWx0ZXJzLFxyXG4gICAgICAgICAgcGF0dGVyblxyXG4gICAgICAgICk7XHJcbiAgICAgICAgbG9nKCdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsICdBZGRpbmcgbW9zdCBjb21tb24gcm9vdGtpdHMnLCAnZGVidWcnKTtcclxuICAgICAgICBpZiAodG9wNVJvb3RraXRzUmFuayAmJiB0b3A1Um9vdGtpdHNSYW5rLmxlbmd0aCkge1xyXG4gICAgICAgICAgcHJpbnRlclxyXG4gICAgICAgICAgICAuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcclxuICAgICAgICAgICAgICB0ZXh0OiAnTW9zdCBjb21tb24gcm9vdGtpdHMgZm91bmQgYW1vbmcgeW91ciBhZ2VudHMnLFxyXG4gICAgICAgICAgICAgIHN0eWxlOiAnaDInLFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcclxuICAgICAgICAgICAgICB0ZXh0OlxyXG4gICAgICAgICAgICAgICAgJ1Jvb3RraXRzIGFyZSBhIHNldCBvZiBzb2Z0d2FyZSB0b29scyB0aGF0IGVuYWJsZSBhbiB1bmF1dGhvcml6ZWQgdXNlciB0byBnYWluIGNvbnRyb2wgb2YgYSBjb21wdXRlciBzeXN0ZW0gd2l0aG91dCBiZWluZyBkZXRlY3RlZC4nLFxyXG4gICAgICAgICAgICAgIHN0eWxlOiAnc3RhbmRhcmQnLFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAuYWRkU2ltcGxlVGFibGUoe1xyXG4gICAgICAgICAgICAgIGl0ZW1zOiB0b3A1Um9vdGtpdHNSYW5rLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHsgdG9wOiB0b3A1Um9vdGtpdHNSYW5rLmluZGV4T2YoaXRlbSkgKyAxLCBuYW1lOiBpdGVtIH07XHJcbiAgICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgICAgY29sdW1uczogW1xyXG4gICAgICAgICAgICAgICAgeyBpZDogJ3RvcCcsIGxhYmVsOiAnVG9wJyB9LFxyXG4gICAgICAgICAgICAgICAgeyBpZDogJ25hbWUnLCBsYWJlbDogJ1Jvb3RraXQnIH0sXHJcbiAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxvZygncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLCAnRmV0Y2hpbmcgaGlkZGVuIHBpZHMnLCAnZGVidWcnKTtcclxuICAgICAgICBjb25zdCBoaWRkZW5QaWRzID0gYXdhaXQgUm9vdGNoZWNrUmVxdWVzdC5hZ2VudHNXaXRoSGlkZGVuUGlkcyhcclxuICAgICAgICAgIGNvbnRleHQsXHJcbiAgICAgICAgICBmcm9tLFxyXG4gICAgICAgICAgdG8sXHJcbiAgICAgICAgICBmaWx0ZXJzLFxyXG4gICAgICAgICAgcGF0dGVyblxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaGlkZGVuUGlkcyAmJlxyXG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50KHtcclxuICAgICAgICAgICAgdGV4dDogYCR7aGlkZGVuUGlkc30gb2YgJHt0b3RhbEFnZW50c30gYWdlbnRzIGhhdmUgaGlkZGVuIHByb2Nlc3Nlc2AsXHJcbiAgICAgICAgICAgIHN0eWxlOiAnaDMnLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgIWhpZGRlblBpZHMgJiZcclxuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcclxuICAgICAgICAgICAgdGV4dDogYE5vIGFnZW50cyBoYXZlIGhpZGRlbiBwcm9jZXNzZXNgLFxyXG4gICAgICAgICAgICBzdHlsZTogJ2gzJyxcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCBoaWRkZW5Qb3J0cyA9IGF3YWl0IFJvb3RjaGVja1JlcXVlc3QuYWdlbnRzV2l0aEhpZGRlblBvcnRzKFxyXG4gICAgICAgICAgY29udGV4dCxcclxuICAgICAgICAgIGZyb20sXHJcbiAgICAgICAgICB0byxcclxuICAgICAgICAgIGZpbHRlcnMsXHJcbiAgICAgICAgICBwYXR0ZXJuXHJcbiAgICAgICAgKTtcclxuICAgICAgICBoaWRkZW5Qb3J0cyAmJlxyXG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50KHtcclxuICAgICAgICAgICAgdGV4dDogYCR7aGlkZGVuUG9ydHN9IG9mICR7dG90YWxBZ2VudHN9IGFnZW50cyBoYXZlIGhpZGRlbiBwb3J0c2AsXHJcbiAgICAgICAgICAgIHN0eWxlOiAnaDMnLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgIWhpZGRlblBvcnRzICYmXHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xyXG4gICAgICAgICAgICB0ZXh0OiBgTm8gYWdlbnRzIGhhdmUgaGlkZGVuIHBvcnRzYCxcclxuICAgICAgICAgICAgc3R5bGU6ICdoMycsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICBwcmludGVyLmFkZE5ld0xpbmUoKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKFsnb3ZlcnZpZXcnLCAnYWdlbnRzJ10uaW5jbHVkZXMoc2VjdGlvbikgJiYgdGFiID09PSAncGNpJykge1xyXG4gICAgICAgIGxvZygncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLCAnRmV0Y2hpbmcgdG9wIFBDSSBEU1MgcmVxdWlyZW1lbnRzJywgJ2RlYnVnJyk7XHJcbiAgICAgICAgY29uc3QgdG9wUGNpUmVxdWlyZW1lbnRzID0gYXdhaXQgUENJUmVxdWVzdC50b3BQQ0lSZXF1aXJlbWVudHMoXHJcbiAgICAgICAgICBjb250ZXh0LFxyXG4gICAgICAgICAgZnJvbSxcclxuICAgICAgICAgIHRvLFxyXG4gICAgICAgICAgZmlsdGVycyxcclxuICAgICAgICAgIHBhdHRlcm5cclxuICAgICAgICApO1xyXG4gICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcclxuICAgICAgICAgIHRleHQ6ICdNb3N0IGNvbW1vbiBQQ0kgRFNTIHJlcXVpcmVtZW50cyBhbGVydHMgZm91bmQnLFxyXG4gICAgICAgICAgc3R5bGU6ICdoMicsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgZm9yIChjb25zdCBpdGVtIG9mIHRvcFBjaVJlcXVpcmVtZW50cykge1xyXG4gICAgICAgICAgY29uc3QgcnVsZXMgPSBhd2FpdCBQQ0lSZXF1ZXN0LmdldFJ1bGVzQnlSZXF1aXJlbWVudChcclxuICAgICAgICAgICAgY29udGV4dCxcclxuICAgICAgICAgICAgZnJvbSxcclxuICAgICAgICAgICAgdG8sXHJcbiAgICAgICAgICAgIGZpbHRlcnMsXHJcbiAgICAgICAgICAgIGl0ZW0sXHJcbiAgICAgICAgICAgIHBhdHRlcm5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7IHRleHQ6IGBSZXF1aXJlbWVudCAke2l0ZW19YCwgc3R5bGU6ICdoMycgfSk7XHJcblxyXG4gICAgICAgICAgaWYgKFBDSVtpdGVtXSkge1xyXG4gICAgICAgICAgICBjb25zdCBjb250ZW50ID1cclxuICAgICAgICAgICAgICB0eXBlb2YgUENJW2l0ZW1dID09PSAnc3RyaW5nJyA/IHsgdGV4dDogUENJW2l0ZW1dLCBzdHlsZTogJ3N0YW5kYXJkJyB9IDogUENJW2l0ZW1dO1xyXG4gICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZShjb250ZW50KTtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBydWxlcyAmJlxyXG4gICAgICAgICAgICBydWxlcy5sZW5ndGggJiZcclxuICAgICAgICAgICAgcHJpbnRlci5hZGRTaW1wbGVUYWJsZSh7XHJcbiAgICAgICAgICAgICAgY29sdW1uczogW1xyXG4gICAgICAgICAgICAgICAgeyBpZDogJ3J1bGVJRCcsIGxhYmVsOiAnUnVsZSBJRCcgfSxcclxuICAgICAgICAgICAgICAgIHsgaWQ6ICdydWxlRGVzY3JpcHRpb24nLCBsYWJlbDogJ0Rlc2NyaXB0aW9uJyB9LFxyXG4gICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgaXRlbXM6IHJ1bGVzLFxyXG4gICAgICAgICAgICAgIHRpdGxlOiBgVG9wIHJ1bGVzIGZvciAke2l0ZW19IHJlcXVpcmVtZW50YCxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoWydvdmVydmlldycsICdhZ2VudHMnXS5pbmNsdWRlcyhzZWN0aW9uKSAmJiB0YWIgPT09ICd0c2MnKSB7XHJcbiAgICAgICAgbG9nKCdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsICdGZXRjaGluZyB0b3AgVFNDIHJlcXVpcmVtZW50cycsICdkZWJ1ZycpO1xyXG4gICAgICAgIGNvbnN0IHRvcFRTQ1JlcXVpcmVtZW50cyA9IGF3YWl0IFRTQ1JlcXVlc3QudG9wVFNDUmVxdWlyZW1lbnRzKFxyXG4gICAgICAgICAgY29udGV4dCxcclxuICAgICAgICAgIGZyb20sXHJcbiAgICAgICAgICB0byxcclxuICAgICAgICAgIGZpbHRlcnMsXHJcbiAgICAgICAgICBwYXR0ZXJuXHJcbiAgICAgICAgKTtcclxuICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7XHJcbiAgICAgICAgICB0ZXh0OiAnTW9zdCBjb21tb24gVFNDIHJlcXVpcmVtZW50cyBhbGVydHMgZm91bmQnLFxyXG4gICAgICAgICAgc3R5bGU6ICdoMicsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgZm9yIChjb25zdCBpdGVtIG9mIHRvcFRTQ1JlcXVpcmVtZW50cykge1xyXG4gICAgICAgICAgY29uc3QgcnVsZXMgPSBhd2FpdCBUU0NSZXF1ZXN0LmdldFJ1bGVzQnlSZXF1aXJlbWVudChcclxuICAgICAgICAgICAgY29udGV4dCxcclxuICAgICAgICAgICAgZnJvbSxcclxuICAgICAgICAgICAgdG8sXHJcbiAgICAgICAgICAgIGZpbHRlcnMsXHJcbiAgICAgICAgICAgIGl0ZW0sXHJcbiAgICAgICAgICAgIHBhdHRlcm5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7IHRleHQ6IGBSZXF1aXJlbWVudCAke2l0ZW19YCwgc3R5bGU6ICdoMycgfSk7XHJcblxyXG4gICAgICAgICAgaWYgKFRTQ1tpdGVtXSkge1xyXG4gICAgICAgICAgICBjb25zdCBjb250ZW50ID1cclxuICAgICAgICAgICAgICB0eXBlb2YgVFNDW2l0ZW1dID09PSAnc3RyaW5nJyA/IHsgdGV4dDogVFNDW2l0ZW1dLCBzdHlsZTogJ3N0YW5kYXJkJyB9IDogVFNDW2l0ZW1dO1xyXG4gICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZShjb250ZW50KTtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBydWxlcyAmJlxyXG4gICAgICAgICAgICBydWxlcy5sZW5ndGggJiZcclxuICAgICAgICAgICAgcHJpbnRlci5hZGRTaW1wbGVUYWJsZSh7XHJcbiAgICAgICAgICAgICAgY29sdW1uczogW1xyXG4gICAgICAgICAgICAgICAgeyBpZDogJ3J1bGVJRCcsIGxhYmVsOiAnUnVsZSBJRCcgfSxcclxuICAgICAgICAgICAgICAgIHsgaWQ6ICdydWxlRGVzY3JpcHRpb24nLCBsYWJlbDogJ0Rlc2NyaXB0aW9uJyB9LFxyXG4gICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgaXRlbXM6IHJ1bGVzLFxyXG4gICAgICAgICAgICAgIHRpdGxlOiBgVG9wIHJ1bGVzIGZvciAke2l0ZW19IHJlcXVpcmVtZW50YCxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoWydvdmVydmlldycsICdhZ2VudHMnXS5pbmNsdWRlcyhzZWN0aW9uKSAmJiB0YWIgPT09ICdnZHByJykge1xyXG4gICAgICAgIGxvZygncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLCAnRmV0Y2hpbmcgdG9wIEdEUFIgcmVxdWlyZW1lbnRzJywgJ2RlYnVnJyk7XHJcbiAgICAgICAgY29uc3QgdG9wR2RwclJlcXVpcmVtZW50cyA9IGF3YWl0IEdEUFJSZXF1ZXN0LnRvcEdEUFJSZXF1aXJlbWVudHMoXHJcbiAgICAgICAgICBjb250ZXh0LFxyXG4gICAgICAgICAgZnJvbSxcclxuICAgICAgICAgIHRvLFxyXG4gICAgICAgICAgZmlsdGVycyxcclxuICAgICAgICAgIHBhdHRlcm5cclxuICAgICAgICApO1xyXG4gICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcclxuICAgICAgICAgIHRleHQ6ICdNb3N0IGNvbW1vbiBHRFBSIHJlcXVpcmVtZW50cyBhbGVydHMgZm91bmQnLFxyXG4gICAgICAgICAgc3R5bGU6ICdoMicsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgZm9yIChjb25zdCBpdGVtIG9mIHRvcEdkcHJSZXF1aXJlbWVudHMpIHtcclxuICAgICAgICAgIGNvbnN0IHJ1bGVzID0gYXdhaXQgR0RQUlJlcXVlc3QuZ2V0UnVsZXNCeVJlcXVpcmVtZW50KFxyXG4gICAgICAgICAgICBjb250ZXh0LFxyXG4gICAgICAgICAgICBmcm9tLFxyXG4gICAgICAgICAgICB0byxcclxuICAgICAgICAgICAgZmlsdGVycyxcclxuICAgICAgICAgICAgaXRlbSxcclxuICAgICAgICAgICAgcGF0dGVyblxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHsgdGV4dDogYFJlcXVpcmVtZW50ICR7aXRlbX1gLCBzdHlsZTogJ2gzJyB9KTtcclxuXHJcbiAgICAgICAgICBpZiAoR0RQUiAmJiBHRFBSW2l0ZW1dKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGNvbnRlbnQgPVxyXG4gICAgICAgICAgICAgIHR5cGVvZiBHRFBSW2l0ZW1dID09PSAnc3RyaW5nJyA/IHsgdGV4dDogR0RQUltpdGVtXSwgc3R5bGU6ICdzdGFuZGFyZCcgfSA6IEdEUFJbaXRlbV07XHJcbiAgICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKGNvbnRlbnQpO1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIHJ1bGVzICYmXHJcbiAgICAgICAgICAgIHJ1bGVzLmxlbmd0aCAmJlxyXG4gICAgICAgICAgICBwcmludGVyLmFkZFNpbXBsZVRhYmxlKHtcclxuICAgICAgICAgICAgICBjb2x1bW5zOiBbXHJcbiAgICAgICAgICAgICAgICB7IGlkOiAncnVsZUlEJywgbGFiZWw6ICdSdWxlIElEJyB9LFxyXG4gICAgICAgICAgICAgICAgeyBpZDogJ3J1bGVEZXNjcmlwdGlvbicsIGxhYmVsOiAnRGVzY3JpcHRpb24nIH0sXHJcbiAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICBpdGVtczogcnVsZXMsXHJcbiAgICAgICAgICAgICAgdGl0bGU6IGBUb3AgcnVsZXMgZm9yICR7aXRlbX0gcmVxdWlyZW1lbnRgLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcHJpbnRlci5hZGROZXdMaW5lKCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChzZWN0aW9uID09PSAnb3ZlcnZpZXcnICYmIHRhYiA9PT0gJ2F1ZGl0Jykge1xyXG4gICAgICAgIGxvZyhcclxuICAgICAgICAgICdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsXHJcbiAgICAgICAgICAnRmV0Y2hpbmcgYWdlbnRzIHdpdGggaGlnaCBudW1iZXIgb2YgZmFpbGVkIHN1ZG8gY29tbWFuZHMnLFxyXG4gICAgICAgICAgJ2RlYnVnJ1xyXG4gICAgICAgICk7XHJcbiAgICAgICAgY29uc3QgYXVkaXRBZ2VudHNOb25TdWNjZXNzID0gYXdhaXQgQXVkaXRSZXF1ZXN0LmdldFRvcDNBZ2VudHNTdWRvTm9uU3VjY2Vzc2Z1bChcclxuICAgICAgICAgIGNvbnRleHQsXHJcbiAgICAgICAgICBmcm9tLFxyXG4gICAgICAgICAgdG8sXHJcbiAgICAgICAgICBmaWx0ZXJzLFxyXG4gICAgICAgICAgcGF0dGVyblxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKGF1ZGl0QWdlbnRzTm9uU3VjY2VzcyAmJiBhdWRpdEFnZW50c05vblN1Y2Nlc3MubGVuZ3RoKSB7XHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xyXG4gICAgICAgICAgICB0ZXh0OiAnQWdlbnRzIHdpdGggaGlnaCBudW1iZXIgb2YgZmFpbGVkIHN1ZG8gY29tbWFuZHMnLFxyXG4gICAgICAgICAgICBzdHlsZTogJ2gyJyxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgYXdhaXQgdGhpcy5idWlsZEFnZW50c1RhYmxlKGNvbnRleHQsIHByaW50ZXIsIGF1ZGl0QWdlbnRzTm9uU3VjY2VzcywgYXBpSWQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBhdWRpdEFnZW50c0ZhaWxlZFN5c2NhbGwgPSBhd2FpdCBBdWRpdFJlcXVlc3QuZ2V0VG9wM0FnZW50c0ZhaWxlZFN5c2NhbGxzKFxyXG4gICAgICAgICAgY29udGV4dCxcclxuICAgICAgICAgIGZyb20sXHJcbiAgICAgICAgICB0byxcclxuICAgICAgICAgIGZpbHRlcnMsXHJcbiAgICAgICAgICBwYXR0ZXJuXHJcbiAgICAgICAgKTtcclxuICAgICAgICBpZiAoYXVkaXRBZ2VudHNGYWlsZWRTeXNjYWxsICYmIGF1ZGl0QWdlbnRzRmFpbGVkU3lzY2FsbC5sZW5ndGgpIHtcclxuICAgICAgICAgIHByaW50ZXIuYWRkU2ltcGxlVGFibGUoe1xyXG4gICAgICAgICAgICBjb2x1bW5zOiBbXHJcbiAgICAgICAgICAgICAgeyBpZDogJ2FnZW50JywgbGFiZWw6ICdBZ2VudCBJRCcgfSxcclxuICAgICAgICAgICAgICB7IGlkOiAnc3lzY2FsbF9pZCcsIGxhYmVsOiAnU3lzY2FsbCBJRCcgfSxcclxuICAgICAgICAgICAgICB7IGlkOiAnc3lzY2FsbF9zeXNjYWxsJywgbGFiZWw6ICdTeXNjYWxsJyB9LFxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICBpdGVtczogYXVkaXRBZ2VudHNGYWlsZWRTeXNjYWxsLm1hcCgoaXRlbSkgPT4gKHtcclxuICAgICAgICAgICAgICBhZ2VudDogaXRlbS5hZ2VudCxcclxuICAgICAgICAgICAgICBzeXNjYWxsX2lkOiBpdGVtLnN5c2NhbGwuaWQsXHJcbiAgICAgICAgICAgICAgc3lzY2FsbF9zeXNjYWxsOiBpdGVtLnN5c2NhbGwuc3lzY2FsbCxcclxuICAgICAgICAgICAgfSkpLFxyXG4gICAgICAgICAgICB0aXRsZToge1xyXG4gICAgICAgICAgICAgIHRleHQ6ICdNb3N0IGNvbW1vbiBmYWlsaW5nIHN5c2NhbGxzJyxcclxuICAgICAgICAgICAgICBzdHlsZTogJ2gyJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKHNlY3Rpb24gPT09ICdvdmVydmlldycgJiYgdGFiID09PSAnZmltJykge1xyXG4gICAgICAgIGxvZygncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLCAnRmV0Y2hpbmcgdG9wIDMgcnVsZXMgZm9yIEZJTScsICdkZWJ1ZycpO1xyXG4gICAgICAgIGNvbnN0IHJ1bGVzID0gYXdhaXQgU3lzY2hlY2tSZXF1ZXN0LnRvcDNSdWxlcyhjb250ZXh0LCBmcm9tLCB0bywgZmlsdGVycywgcGF0dGVybik7XHJcblxyXG4gICAgICAgIGlmIChydWxlcyAmJiBydWxlcy5sZW5ndGgpIHtcclxuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHsgdGV4dDogJ1RvcCAzIEZJTSBydWxlcycsIHN0eWxlOiAnaDInIH0pLmFkZFNpbXBsZVRhYmxlKHtcclxuICAgICAgICAgICAgY29sdW1uczogW1xyXG4gICAgICAgICAgICAgIHsgaWQ6ICdydWxlSUQnLCBsYWJlbDogJ1J1bGUgSUQnIH0sXHJcbiAgICAgICAgICAgICAgeyBpZDogJ3J1bGVEZXNjcmlwdGlvbicsIGxhYmVsOiAnRGVzY3JpcHRpb24nIH0sXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIGl0ZW1zOiBydWxlcyxcclxuICAgICAgICAgICAgdGl0bGU6IHtcclxuICAgICAgICAgICAgICB0ZXh0OiAnVG9wIDMgcnVsZXMgdGhhdCBhcmUgZ2VuZXJhdGluZyBtb3N0IGFsZXJ0cy4nLFxyXG4gICAgICAgICAgICAgIHN0eWxlOiAnc3RhbmRhcmQnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsb2coJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJywgJ0ZldGNoaW5nIHRvcCAzIGFnZW50cyBmb3IgRklNJywgJ2RlYnVnJyk7XHJcbiAgICAgICAgY29uc3QgYWdlbnRzID0gYXdhaXQgU3lzY2hlY2tSZXF1ZXN0LnRvcDNhZ2VudHMoY29udGV4dCwgZnJvbSwgdG8sIGZpbHRlcnMsIHBhdHRlcm4pO1xyXG5cclxuICAgICAgICBpZiAoYWdlbnRzICYmIGFnZW50cy5sZW5ndGgpIHtcclxuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcclxuICAgICAgICAgICAgdGV4dDogJ0FnZW50cyB3aXRoIHN1c3BpY2lvdXMgRklNIGFjdGl2aXR5JyxcclxuICAgICAgICAgICAgc3R5bGU6ICdoMicsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcclxuICAgICAgICAgICAgdGV4dDpcclxuICAgICAgICAgICAgICAnVG9wIDMgYWdlbnRzIHRoYXQgaGF2ZSBtb3N0IEZJTSBhbGVydHMgZnJvbSBsZXZlbCA3IHRvIGxldmVsIDE1LiBUYWtlIGNhcmUgYWJvdXQgdGhlbS4nLFxyXG4gICAgICAgICAgICBzdHlsZTogJ3N0YW5kYXJkJyxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgYXdhaXQgdGhpcy5idWlsZEFnZW50c1RhYmxlKGNvbnRleHQsIHByaW50ZXIsIGFnZW50cywgYXBpSWQpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKHNlY3Rpb24gPT09ICdhZ2VudHMnICYmIHRhYiA9PT0gJ2F1ZGl0Jykge1xyXG4gICAgICAgIGxvZygncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLCBgRmV0Y2hpbmcgbW9zdCBjb21tb24gZmFpbGVkIHN5c2NhbGxzYCwgJ2RlYnVnJyk7XHJcbiAgICAgICAgY29uc3QgYXVkaXRGYWlsZWRTeXNjYWxsID0gYXdhaXQgQXVkaXRSZXF1ZXN0LmdldFRvcEZhaWxlZFN5c2NhbGxzKFxyXG4gICAgICAgICAgY29udGV4dCxcclxuICAgICAgICAgIGZyb20sXHJcbiAgICAgICAgICB0byxcclxuICAgICAgICAgIGZpbHRlcnMsXHJcbiAgICAgICAgICBwYXR0ZXJuXHJcbiAgICAgICAgKTtcclxuICAgICAgICBhdWRpdEZhaWxlZFN5c2NhbGwgJiZcclxuICAgICAgICAgIGF1ZGl0RmFpbGVkU3lzY2FsbC5sZW5ndGggJiZcclxuICAgICAgICAgIHByaW50ZXIuYWRkU2ltcGxlVGFibGUoe1xyXG4gICAgICAgICAgICBjb2x1bW5zOiBbXHJcbiAgICAgICAgICAgICAgeyBpZDogJ2lkJywgbGFiZWw6ICdpZCcgfSxcclxuICAgICAgICAgICAgICB7IGlkOiAnc3lzY2FsbCcsIGxhYmVsOiAnU3lzY2FsbCcgfSxcclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgaXRlbXM6IGF1ZGl0RmFpbGVkU3lzY2FsbCxcclxuICAgICAgICAgICAgdGl0bGU6ICdNb3N0IGNvbW1vbiBmYWlsaW5nIHN5c2NhbGxzJyxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoc2VjdGlvbiA9PT0gJ2FnZW50cycgJiYgdGFiID09PSAnZmltJykge1xyXG4gICAgICAgIGxvZyhcclxuICAgICAgICAgICdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsXHJcbiAgICAgICAgICBgRmV0Y2hpbmcgc3lzY2hlY2sgZGF0YWJhc2UgZm9yIGFnZW50ICR7YWdlbnR9YCxcclxuICAgICAgICAgICdkZWJ1ZydcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBjb25zdCBsYXN0U2NhblJlc3BvbnNlID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdChcclxuICAgICAgICAgICdHRVQnLFxyXG4gICAgICAgICAgYC9zeXNjaGVjay8ke2FnZW50fS9sYXN0X3NjYW5gLFxyXG4gICAgICAgICAge30sXHJcbiAgICAgICAgICB7IGFwaUhvc3RJRDogYXBpSWQgfVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGlmIChsYXN0U2NhblJlc3BvbnNlICYmIGxhc3RTY2FuUmVzcG9uc2UuZGF0YSkge1xyXG4gICAgICAgICAgY29uc3QgbGFzdFNjYW5EYXRhID0gbGFzdFNjYW5SZXNwb25zZS5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXNbMF07XHJcbiAgICAgICAgICBpZiAobGFzdFNjYW5EYXRhLnN0YXJ0ICYmIGxhc3RTY2FuRGF0YS5lbmQpIHtcclxuICAgICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50KHtcclxuICAgICAgICAgICAgICB0ZXh0OiBgTGFzdCBmaWxlIGludGVncml0eSBtb25pdG9yaW5nIHNjYW4gd2FzIGV4ZWN1dGVkIGZyb20gJHtsYXN0U2NhbkRhdGEuc3RhcnR9IHRvICR7bGFzdFNjYW5EYXRhLmVuZH0uYCxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGVsc2UgaWYgKGxhc3RTY2FuRGF0YS5zdGFydCkge1xyXG4gICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xyXG4gICAgICAgICAgICAgIHRleHQ6IGBGaWxlIGludGVncml0eSBtb25pdG9yaW5nIHNjYW4gaXMgY3VycmVudGx5IGluIHByb2dyZXNzIGZvciB0aGlzIGFnZW50IChzdGFydGVkIG9uICR7bGFzdFNjYW5EYXRhLnN0YXJ0fSkuYCxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xyXG4gICAgICAgICAgICAgIHRleHQ6IGBGaWxlIGludGVncml0eSBtb25pdG9yaW5nIHNjYW4gaXMgY3VycmVudGx5IGluIHByb2dyZXNzIGZvciB0aGlzIGFnZW50LmAsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgcHJpbnRlci5hZGROZXdMaW5lKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsb2coJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJywgYEZldGNoaW5nIGxhc3QgMTAgZGVsZXRlZCBmaWxlcyBmb3IgRklNYCwgJ2RlYnVnJyk7XHJcbiAgICAgICAgY29uc3QgbGFzdFRlbkRlbGV0ZWQgPSBhd2FpdCBTeXNjaGVja1JlcXVlc3QubGFzdFRlbkRlbGV0ZWRGaWxlcyhcclxuICAgICAgICAgIGNvbnRleHQsXHJcbiAgICAgICAgICBmcm9tLFxyXG4gICAgICAgICAgdG8sXHJcbiAgICAgICAgICBmaWx0ZXJzLFxyXG4gICAgICAgICAgcGF0dGVyblxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGxhc3RUZW5EZWxldGVkICYmXHJcbiAgICAgICAgICBsYXN0VGVuRGVsZXRlZC5sZW5ndGggJiZcclxuICAgICAgICAgIHByaW50ZXIuYWRkU2ltcGxlVGFibGUoe1xyXG4gICAgICAgICAgICBjb2x1bW5zOiBbXHJcbiAgICAgICAgICAgICAgeyBpZDogJ3BhdGgnLCBsYWJlbDogJ1BhdGgnIH0sXHJcbiAgICAgICAgICAgICAgeyBpZDogJ2RhdGUnLCBsYWJlbDogJ0RhdGUnIH0sXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIGl0ZW1zOiBsYXN0VGVuRGVsZXRlZCxcclxuICAgICAgICAgICAgdGl0bGU6ICdMYXN0IDEwIGRlbGV0ZWQgZmlsZXMnLFxyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGxvZygncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLCBgRmV0Y2hpbmcgbGFzdCAxMCBtb2RpZmllZCBmaWxlc2AsICdkZWJ1ZycpO1xyXG4gICAgICAgIGNvbnN0IGxhc3RUZW5Nb2RpZmllZCA9IGF3YWl0IFN5c2NoZWNrUmVxdWVzdC5sYXN0VGVuTW9kaWZpZWRGaWxlcyhcclxuICAgICAgICAgIGNvbnRleHQsXHJcbiAgICAgICAgICBmcm9tLFxyXG4gICAgICAgICAgdG8sXHJcbiAgICAgICAgICBmaWx0ZXJzLFxyXG4gICAgICAgICAgcGF0dGVyblxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGxhc3RUZW5Nb2RpZmllZCAmJlxyXG4gICAgICAgICAgbGFzdFRlbk1vZGlmaWVkLmxlbmd0aCAmJlxyXG4gICAgICAgICAgcHJpbnRlci5hZGRTaW1wbGVUYWJsZSh7XHJcbiAgICAgICAgICAgIGNvbHVtbnM6IFtcclxuICAgICAgICAgICAgICB7IGlkOiAncGF0aCcsIGxhYmVsOiAnUGF0aCcgfSxcclxuICAgICAgICAgICAgICB7IGlkOiAnZGF0ZScsIGxhYmVsOiAnRGF0ZScgfSxcclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgaXRlbXM6IGxhc3RUZW5Nb2RpZmllZCxcclxuICAgICAgICAgICAgdGl0bGU6ICdMYXN0IDEwIG1vZGlmaWVkIGZpbGVzJyxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoc2VjdGlvbiA9PT0gJ2FnZW50cycgJiYgdGFiID09PSAnc3lzY29sbGVjdG9yJykge1xyXG4gICAgICAgIGxvZyhcclxuICAgICAgICAgICdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsXHJcbiAgICAgICAgICBgRmV0Y2hpbmcgaGFyZHdhcmUgaW5mb3JtYXRpb24gZm9yIGFnZW50ICR7YWdlbnR9YCxcclxuICAgICAgICAgICdkZWJ1ZydcclxuICAgICAgICApO1xyXG4gICAgICAgIGNvbnN0IHJlcXVlc3RzU3lzY29sbGVjdG9yTGlzdHMgPSBbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGVuZHBvaW50OiBgL3N5c2NvbGxlY3Rvci8ke2FnZW50fS9oYXJkd2FyZWAsXHJcbiAgICAgICAgICAgIGxvZ2dlck1lc3NhZ2U6IGBGZXRjaGluZyBIYXJkd2FyZSBpbmZvcm1hdGlvbiBmb3IgYWdlbnQgJHthZ2VudH1gLFxyXG4gICAgICAgICAgICBsaXN0OiB7XHJcbiAgICAgICAgICAgICAgdGl0bGU6IHsgdGV4dDogJ0hhcmR3YXJlIGluZm9ybWF0aW9uJywgc3R5bGU6ICdoMicgfSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgbWFwUmVzcG9uc2U6IChoYXJkd2FyZSkgPT4gW1xyXG4gICAgICAgICAgICAgIGhhcmR3YXJlLmNwdSAmJiBoYXJkd2FyZS5jcHUuY29yZXMgJiYgYCR7aGFyZHdhcmUuY3B1LmNvcmVzfSBjb3Jlc2AsXHJcbiAgICAgICAgICAgICAgaGFyZHdhcmUuY3B1ICYmIGhhcmR3YXJlLmNwdS5uYW1lLFxyXG4gICAgICAgICAgICAgIGhhcmR3YXJlLnJhbSAmJlxyXG4gICAgICAgICAgICAgICAgaGFyZHdhcmUucmFtLnRvdGFsICYmXHJcbiAgICAgICAgICAgICAgICBgJHtOdW1iZXIoaGFyZHdhcmUucmFtLnRvdGFsIC8gMTAyNCAvIDEwMjQpLnRvRml4ZWQoMil9R0IgUkFNYCxcclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGVuZHBvaW50OiBgL3N5c2NvbGxlY3Rvci8ke2FnZW50fS9vc2AsXHJcbiAgICAgICAgICAgIGxvZ2dlck1lc3NhZ2U6IGBGZXRjaGluZyBPUyBpbmZvcm1hdGlvbiBmb3IgYWdlbnQgJHthZ2VudH1gLFxyXG4gICAgICAgICAgICBsaXN0OiB7XHJcbiAgICAgICAgICAgICAgdGl0bGU6IHsgdGV4dDogJ09TIGluZm9ybWF0aW9uJywgc3R5bGU6ICdoMicgfSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgbWFwUmVzcG9uc2U6IChvc0RhdGEpID0+IFtcclxuICAgICAgICAgICAgICBvc0RhdGEuc3lzbmFtZSxcclxuICAgICAgICAgICAgICBvc0RhdGEudmVyc2lvbixcclxuICAgICAgICAgICAgICBvc0RhdGEuYXJjaGl0ZWN0dXJlLFxyXG4gICAgICAgICAgICAgIG9zRGF0YS5yZWxlYXNlLFxyXG4gICAgICAgICAgICAgIG9zRGF0YS5vcyAmJlxyXG4gICAgICAgICAgICAgICAgb3NEYXRhLm9zLm5hbWUgJiZcclxuICAgICAgICAgICAgICAgIG9zRGF0YS5vcy52ZXJzaW9uICYmXHJcbiAgICAgICAgICAgICAgICBgJHtvc0RhdGEub3MubmFtZX0gJHtvc0RhdGEub3MudmVyc2lvbn1gLFxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdO1xyXG5cclxuICAgICAgICBjb25zdCBzeXNjb2xsZWN0b3JMaXN0cyA9IGF3YWl0IFByb21pc2UuYWxsKFxyXG4gICAgICAgICAgcmVxdWVzdHNTeXNjb2xsZWN0b3JMaXN0cy5tYXAoYXN5bmMgKHJlcXVlc3RTeXNjb2xsZWN0b3IpID0+IHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsb2coJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJywgcmVxdWVzdFN5c2NvbGxlY3Rvci5sb2dnZXJNZXNzYWdlLCAnZGVidWcnKTtcclxuICAgICAgICAgICAgICBjb25zdCByZXNwb25zZVN5c2NvbGxlY3RvciA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXHJcbiAgICAgICAgICAgICAgICAnR0VUJyxcclxuICAgICAgICAgICAgICAgIHJlcXVlc3RTeXNjb2xsZWN0b3IuZW5kcG9pbnQsXHJcbiAgICAgICAgICAgICAgICB7fSxcclxuICAgICAgICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICBjb25zdCBbZGF0YV0gPVxyXG4gICAgICAgICAgICAgICAgKHJlc3BvbnNlU3lzY29sbGVjdG9yICYmXHJcbiAgICAgICAgICAgICAgICAgIHJlc3BvbnNlU3lzY29sbGVjdG9yLmRhdGEgJiZcclxuICAgICAgICAgICAgICAgICAgcmVzcG9uc2VTeXNjb2xsZWN0b3IuZGF0YS5kYXRhICYmXHJcbiAgICAgICAgICAgICAgICAgIHJlc3BvbnNlU3lzY29sbGVjdG9yLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtcykgfHxcclxuICAgICAgICAgICAgICAgIFtdO1xyXG4gICAgICAgICAgICAgIGlmIChkYXRhKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAuLi5yZXF1ZXN0U3lzY29sbGVjdG9yLmxpc3QsXHJcbiAgICAgICAgICAgICAgICAgIGxpc3Q6IHJlcXVlc3RTeXNjb2xsZWN0b3IubWFwUmVzcG9uc2UoZGF0YSksXHJcbiAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgICBsb2coJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgaWYgKHN5c2NvbGxlY3Rvckxpc3RzKSB7XHJcbiAgICAgICAgICBzeXNjb2xsZWN0b3JMaXN0c1xyXG4gICAgICAgICAgICAuZmlsdGVyKChzeXNjb2xsZWN0b3JMaXN0KSA9PiBzeXNjb2xsZWN0b3JMaXN0KVxyXG4gICAgICAgICAgICAuZm9yRWFjaCgoc3lzY29sbGVjdG9yTGlzdCkgPT4gcHJpbnRlci5hZGRMaXN0KHN5c2NvbGxlY3Rvckxpc3QpKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHZ1bG5lcmFiaWxpdGllc1JlcXVlc3RzID0gWydDcml0aWNhbCcsICdIaWdoJ107XHJcblxyXG4gICAgICAgIGNvbnN0IHZ1bG5lcmFiaWxpdGllc1Jlc3BvbnNlc0l0ZW1zID0gKFxyXG4gICAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoXHJcbiAgICAgICAgICAgIHZ1bG5lcmFiaWxpdGllc1JlcXVlc3RzLm1hcChhc3luYyAodnVsbmVyYWJpbGl0aWVzTGV2ZWwpID0+IHtcclxuICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgbG9nKFxyXG4gICAgICAgICAgICAgICAgICAncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLFxyXG4gICAgICAgICAgICAgICAgICBgRmV0Y2hpbmcgdG9wICR7dnVsbmVyYWJpbGl0aWVzTGV2ZWx9IHBhY2thZ2VzYCxcclxuICAgICAgICAgICAgICAgICAgJ2RlYnVnJ1xyXG4gICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgVnVsbmVyYWJpbGl0eVJlcXVlc3QudG9wUGFja2FnZXMoXHJcbiAgICAgICAgICAgICAgICAgIGNvbnRleHQsXHJcbiAgICAgICAgICAgICAgICAgIGZyb20sXHJcbiAgICAgICAgICAgICAgICAgIHRvLFxyXG4gICAgICAgICAgICAgICAgICB2dWxuZXJhYmlsaXRpZXNMZXZlbCxcclxuICAgICAgICAgICAgICAgICAgZmlsdGVycyxcclxuICAgICAgICAgICAgICAgICAgcGF0dGVyblxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICAgICAgbG9nKCdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIClcclxuICAgICAgICApXHJcbiAgICAgICAgICAuZmlsdGVyKCh2dWxuZXJhYmlsaXRpZXNSZXNwb25zZSkgPT4gdnVsbmVyYWJpbGl0aWVzUmVzcG9uc2UpXHJcbiAgICAgICAgICAuZmxhdCgpO1xyXG5cclxuICAgICAgICBpZiAodnVsbmVyYWJpbGl0aWVzUmVzcG9uc2VzSXRlbXMgJiYgdnVsbmVyYWJpbGl0aWVzUmVzcG9uc2VzSXRlbXMubGVuZ3RoKSB7XHJcbiAgICAgICAgICBwcmludGVyLmFkZFNpbXBsZVRhYmxlKHtcclxuICAgICAgICAgICAgdGl0bGU6IHsgdGV4dDogJ1Z1bG5lcmFibGUgcGFja2FnZXMgZm91bmQgKGxhc3QgMjQgaG91cnMpJywgc3R5bGU6ICdoMicgfSxcclxuICAgICAgICAgICAgY29sdW1uczogW1xyXG4gICAgICAgICAgICAgIHsgaWQ6ICdwYWNrYWdlJywgbGFiZWw6ICdQYWNrYWdlJyB9LFxyXG4gICAgICAgICAgICAgIHsgaWQ6ICdzZXZlcml0eScsIGxhYmVsOiAnU2V2ZXJpdHknIH0sXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgIGl0ZW1zOiB2dWxuZXJhYmlsaXRpZXNSZXNwb25zZXNJdGVtcyxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKHNlY3Rpb24gPT09ICdhZ2VudHMnICYmIHRhYiA9PT0gJ3Z1bHMnKSB7XHJcbiAgICAgICAgY29uc3QgdG9wQ3JpdGljYWxQYWNrYWdlcyA9IGF3YWl0IFZ1bG5lcmFiaWxpdHlSZXF1ZXN0LnRvcFBhY2thZ2VzV2l0aENWRShcclxuICAgICAgICAgIGNvbnRleHQsXHJcbiAgICAgICAgICBmcm9tLFxyXG4gICAgICAgICAgdG8sXHJcbiAgICAgICAgICAnQ3JpdGljYWwnLFxyXG4gICAgICAgICAgZmlsdGVycyxcclxuICAgICAgICAgIHBhdHRlcm5cclxuICAgICAgICApO1xyXG4gICAgICAgIGlmICh0b3BDcml0aWNhbFBhY2thZ2VzICYmIHRvcENyaXRpY2FsUGFja2FnZXMubGVuZ3RoKSB7XHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7IHRleHQ6ICdDcml0aWNhbCBzZXZlcml0eScsIHN0eWxlOiAnaDInIH0pO1xyXG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50V2l0aE5ld0xpbmUoe1xyXG4gICAgICAgICAgICB0ZXh0OlxyXG4gICAgICAgICAgICAgICdUaGVzZSB2dWxuZXJhYmlsdGllcyBhcmUgY3JpdGljYWwsIHBsZWFzZSByZXZpZXcgeW91ciBhZ2VudC4gQ2xpY2sgb24gZWFjaCBsaW5rIHRvIHJlYWQgbW9yZSBhYm91dCBlYWNoIGZvdW5kIHZ1bG5lcmFiaWxpdHkuJyxcclxuICAgICAgICAgICAgc3R5bGU6ICdzdGFuZGFyZCcsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIGNvbnN0IGN1c3RvbXVsID0gW107XHJcbiAgICAgICAgICBmb3IgKGNvbnN0IGNyaXRpY2FsIG9mIHRvcENyaXRpY2FsUGFja2FnZXMpIHtcclxuICAgICAgICAgICAgY3VzdG9tdWwucHVzaCh7IHRleHQ6IGNyaXRpY2FsLnBhY2thZ2UsIHN0eWxlOiAnc3RhbmRhcmQnIH0pO1xyXG4gICAgICAgICAgICBjdXN0b211bC5wdXNoKHtcclxuICAgICAgICAgICAgICB1bDogY3JpdGljYWwucmVmZXJlbmNlcy5tYXAoKGl0ZW0pID0+ICh7XHJcbiAgICAgICAgICAgICAgICB0ZXh0OiBpdGVtLnN1YnN0cmluZygwLCA4MCkgKyAnLi4uJyxcclxuICAgICAgICAgICAgICAgIGxpbms6IGl0ZW0sXHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJyMxRUE1QzgnLFxyXG4gICAgICAgICAgICAgIH0pKSxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7IHVsOiBjdXN0b211bCB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHRvcEhpZ2hQYWNrYWdlcyA9IGF3YWl0IFZ1bG5lcmFiaWxpdHlSZXF1ZXN0LnRvcFBhY2thZ2VzV2l0aENWRShcclxuICAgICAgICAgIGNvbnRleHQsXHJcbiAgICAgICAgICBmcm9tLFxyXG4gICAgICAgICAgdG8sXHJcbiAgICAgICAgICAnSGlnaCcsXHJcbiAgICAgICAgICBmaWx0ZXJzLFxyXG4gICAgICAgICAgcGF0dGVyblxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKHRvcEhpZ2hQYWNrYWdlcyAmJiB0b3BIaWdoUGFja2FnZXMubGVuZ3RoKSB7XHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7IHRleHQ6ICdIaWdoIHNldmVyaXR5Jywgc3R5bGU6ICdoMicgfSk7XHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7XHJcbiAgICAgICAgICAgIHRleHQ6ICdDbGljayBvbiBlYWNoIGxpbmsgdG8gcmVhZCBtb3JlIGFib3V0IGVhY2ggZm91bmQgdnVsbmVyYWJpbGl0eS4nLFxyXG4gICAgICAgICAgICBzdHlsZTogJ3N0YW5kYXJkJyxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgY29uc3QgY3VzdG9tdWwgPSBbXTtcclxuICAgICAgICAgIGZvciAoY29uc3QgY3JpdGljYWwgb2YgdG9wSGlnaFBhY2thZ2VzKSB7XHJcbiAgICAgICAgICAgIGN1c3RvbXVsLnB1c2goeyB0ZXh0OiBjcml0aWNhbC5wYWNrYWdlLCBzdHlsZTogJ3N0YW5kYXJkJyB9KTtcclxuICAgICAgICAgICAgY3VzdG9tdWwucHVzaCh7XHJcbiAgICAgICAgICAgICAgdWw6IGNyaXRpY2FsLnJlZmVyZW5jZXMubWFwKChpdGVtKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgdGV4dDogaXRlbSxcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAnIzFFQTVDOCcsXHJcbiAgICAgICAgICAgICAgfSkpLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGN1c3RvbXVsICYmIGN1c3RvbXVsLmxlbmd0aCAmJiBwcmludGVyLmFkZENvbnRlbnQoeyB1bDogY3VzdG9tdWwgfSk7XHJcbiAgICAgICAgICBwcmludGVyLmFkZE5ld0xpbmUoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGxvZygncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByaXZhdGUgZ2V0Q29uZmlnUm93cyhkYXRhLCBsYWJlbHMpIHtcclxuICAgIGxvZygncmVwb3J0aW5nOmdldENvbmZpZ1Jvd3MnLCBgQnVpbGRpbmcgY29uZmlndXJhdGlvbiByb3dzYCwgJ2luZm8nKTtcclxuICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xyXG4gICAgZm9yIChsZXQgcHJvcCBpbiBkYXRhIHx8IFtdKSB7XHJcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGRhdGFbcHJvcF0pKSB7XHJcbiAgICAgICAgZGF0YVtwcm9wXS5mb3JFYWNoKCh4LCBpZHgpID0+IHtcclxuICAgICAgICAgIGlmICh0eXBlb2YgeCA9PT0gJ29iamVjdCcpIGRhdGFbcHJvcF1baWR4XSA9IEpTT04uc3RyaW5naWZ5KHgpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgIHJlc3VsdC5wdXNoKFsobGFiZWxzIHx8IHt9KVtwcm9wXSB8fCBLZXlFcXVpdmFsZW5jZVtwcm9wXSB8fCBwcm9wLCBkYXRhW3Byb3BdIHx8ICctJ10pO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgZ2V0Q29uZmlnVGFibGVzKGRhdGEsIHNlY3Rpb24sIHRhYiwgYXJyYXkgPSBbXSkge1xyXG4gICAgbG9nKCdyZXBvcnRpbmc6Z2V0Q29uZmlnVGFibGVzJywgYEJ1aWxkaW5nIGNvbmZpZ3VyYXRpb24gdGFibGVzYCwgJ2luZm8nKTtcclxuICAgIGxldCBwbGFpbkRhdGEgPSB7fTtcclxuICAgIGNvbnN0IG5lc3RlZERhdGEgPSBbXTtcclxuICAgIGNvbnN0IHRhYmxlRGF0YSA9IFtdO1xyXG5cclxuICAgIGlmIChkYXRhLmxlbmd0aCA9PT0gMSAmJiBBcnJheS5pc0FycmF5KGRhdGEpKSB7XHJcbiAgICAgIHRhYmxlRGF0YVtzZWN0aW9uLmNvbmZpZ1t0YWJdLmNvbmZpZ3VyYXRpb25dID0gZGF0YTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGZvciAobGV0IGtleSBpbiBkYXRhKSB7XHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgKHR5cGVvZiBkYXRhW2tleV0gIT09ICdvYmplY3QnICYmICFBcnJheS5pc0FycmF5KGRhdGFba2V5XSkpIHx8XHJcbiAgICAgICAgICAoQXJyYXkuaXNBcnJheShkYXRhW2tleV0pICYmIHR5cGVvZiBkYXRhW2tleV1bMF0gIT09ICdvYmplY3QnKVxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgcGxhaW5EYXRhW2tleV0gPVxyXG4gICAgICAgICAgICBBcnJheS5pc0FycmF5KGRhdGFba2V5XSkgJiYgdHlwZW9mIGRhdGFba2V5XVswXSAhPT0gJ29iamVjdCdcclxuICAgICAgICAgICAgICA/IGRhdGFba2V5XS5tYXAoKHgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB4ID09PSAnb2JqZWN0JyA/IEpTT04uc3RyaW5naWZ5KHgpIDogeCArICdcXG4nO1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICA6IGRhdGFba2V5XTtcclxuICAgICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoZGF0YVtrZXldKSAmJiB0eXBlb2YgZGF0YVtrZXldWzBdID09PSAnb2JqZWN0Jykge1xyXG4gICAgICAgICAgdGFibGVEYXRhW2tleV0gPSBkYXRhW2tleV07XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGlmIChzZWN0aW9uLmlzR3JvdXBDb25maWcgJiYgWydwYWNrJywgJ2NvbnRlbnQnXS5pbmNsdWRlcyhrZXkpKSB7XHJcbiAgICAgICAgICAgIHRhYmxlRGF0YVtrZXldID0gW2RhdGFba2V5XV07XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBuZXN0ZWREYXRhLnB1c2goZGF0YVtrZXldKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGFycmF5LnB1c2goe1xyXG4gICAgICB0aXRsZTogKHNlY3Rpb24ub3B0aW9ucyB8fCB7fSkuaGlkZUhlYWRlclxyXG4gICAgICAgID8gJydcclxuICAgICAgICA6IChzZWN0aW9uLnRhYnMgfHwgW10pW3RhYl0gfHxcclxuICAgICAgICAgIChzZWN0aW9uLmlzR3JvdXBDb25maWcgPyAoKHNlY3Rpb24ubGFiZWxzIHx8IFtdKVswXSB8fCBbXSlbdGFiXSA6ICcnKSxcclxuICAgICAgY29sdW1uczogWycnLCAnJ10sXHJcbiAgICAgIHR5cGU6ICdjb25maWcnLFxyXG4gICAgICByb3dzOiB0aGlzLmdldENvbmZpZ1Jvd3MocGxhaW5EYXRhLCAoc2VjdGlvbi5sYWJlbHMgfHwgW10pWzBdKSxcclxuICAgIH0pO1xyXG4gICAgZm9yIChsZXQga2V5IGluIHRhYmxlRGF0YSkge1xyXG4gICAgICBjb25zdCBjb2x1bW5zID0gT2JqZWN0LmtleXModGFibGVEYXRhW2tleV1bMF0pO1xyXG4gICAgICBjb2x1bW5zLmZvckVhY2goKGNvbCwgaSkgPT4ge1xyXG4gICAgICAgIGNvbHVtbnNbaV0gPSBjb2xbMF0udG9VcHBlckNhc2UoKSArIGNvbC5zbGljZSgxKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCByb3dzID0gdGFibGVEYXRhW2tleV0ubWFwKCh4KSA9PiB7XHJcbiAgICAgICAgbGV0IHJvdyA9IFtdO1xyXG4gICAgICAgIGZvciAobGV0IGtleSBpbiB4KSB7XHJcbiAgICAgICAgICByb3cucHVzaChcclxuICAgICAgICAgICAgdHlwZW9mIHhba2V5XSAhPT0gJ29iamVjdCdcclxuICAgICAgICAgICAgICA/IHhba2V5XVxyXG4gICAgICAgICAgICAgIDogQXJyYXkuaXNBcnJheSh4W2tleV0pXHJcbiAgICAgICAgICAgICAgPyB4W2tleV0ubWFwKCh4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiB4ICsgJ1xcbic7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgIDogSlNPTi5zdHJpbmdpZnkoeFtrZXldKVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgd2hpbGUgKHJvdy5sZW5ndGggPCBjb2x1bW5zLmxlbmd0aCkge1xyXG4gICAgICAgICAgcm93LnB1c2goJy0nKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHJvdztcclxuICAgICAgfSk7XHJcbiAgICAgIGFycmF5LnB1c2goe1xyXG4gICAgICAgIHRpdGxlOiAoKHNlY3Rpb24ubGFiZWxzIHx8IFtdKVswXSB8fCBbXSlba2V5XSB8fCAnJyxcclxuICAgICAgICB0eXBlOiAndGFibGUnLFxyXG4gICAgICAgIGNvbHVtbnMsXHJcbiAgICAgICAgcm93cyxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBuZXN0ZWREYXRhLmZvckVhY2gobmVzdCA9PiB7XHJcbiAgICAgIHRoaXMuZ2V0Q29uZmlnVGFibGVzKG5lc3QsIHNlY3Rpb24sIHRhYiArIDEsIGFycmF5KTtcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIGFycmF5O1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQ3JlYXRlIGEgcmVwb3J0IGZvciB0aGUgbW9kdWxlc1xyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcclxuICAgKiBAcmV0dXJucyB7Kn0gcmVwb3J0cyBsaXN0IG9yIEVycm9yUmVzcG9uc2VcclxuICAgKi9cclxuICBjcmVhdGVSZXBvcnRzTW9kdWxlcyA9IHRoaXMuY2hlY2tSZXBvcnRzVXNlckRpcmVjdG9yeUlzVmFsaWRSb3V0ZURlY29yYXRvcihhc3luYyAoXHJcbiAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXHJcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXHJcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnlcclxuICApID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNNb2R1bGVzJywgYFJlcG9ydCBzdGFydGVkYCwgJ2luZm8nKTtcclxuICAgICAgY29uc3Qge1xyXG4gICAgICAgIGFycmF5LFxyXG4gICAgICAgIGFnZW50cyxcclxuICAgICAgICBicm93c2VyVGltZXpvbmUsXHJcbiAgICAgICAgc2VhcmNoQmFyLFxyXG4gICAgICAgIGZpbHRlcnMsXHJcbiAgICAgICAgdGltZSxcclxuICAgICAgICB0YWJsZXMsXHJcbiAgICAgICAgc2VjdGlvbixcclxuICAgICAgICBpbmRleFBhdHRlcm5UaXRsZSxcclxuICAgICAgICBhcGlJZFxyXG4gICAgICB9ID0gcmVxdWVzdC5ib2R5O1xyXG4gICAgICBjb25zdCB7IG1vZHVsZUlEIH0gPSByZXF1ZXN0LnBhcmFtcztcclxuICAgICAgY29uc3QgeyBmcm9tLCB0byB9ID0gdGltZSB8fCB7fTtcclxuICAgICAgLy8gSW5pdFxyXG4gICAgICBjb25zdCBwcmludGVyID0gbmV3IFJlcG9ydFByaW50ZXIoKTtcclxuXHJcbiAgICAgIGNyZWF0ZURhdGFEaXJlY3RvcnlJZk5vdEV4aXN0cygpO1xyXG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19ESVJFQ1RPUllfUEFUSCk7XHJcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgpO1xyXG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhwYXRoLmpvaW4oV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCwgY29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLmhhc2hVc2VybmFtZSkpO1xyXG5cclxuICAgICAgYXdhaXQgdGhpcy5yZW5kZXJIZWFkZXIoY29udGV4dCwgcHJpbnRlciwgc2VjdGlvbiwgbW9kdWxlSUQsIGFnZW50cywgYXBpSWQpO1xyXG5cclxuICAgICAgY29uc3QgW3Nhbml0aXplZEZpbHRlcnMsIGFnZW50c0ZpbHRlcl0gPSBmaWx0ZXJzXHJcbiAgICAgICAgPyB0aGlzLnNhbml0aXplS2liYW5hRmlsdGVycyhmaWx0ZXJzLCBzZWFyY2hCYXIpXHJcbiAgICAgICAgOiBbZmFsc2UsIGZhbHNlXTtcclxuXHJcbiAgICAgIGlmICh0aW1lICYmIHNhbml0aXplZEZpbHRlcnMpIHtcclxuICAgICAgICBwcmludGVyLmFkZFRpbWVSYW5nZUFuZEZpbHRlcnMoZnJvbSwgdG8sIHNhbml0aXplZEZpbHRlcnMsIGJyb3dzZXJUaW1lem9uZSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICh0aW1lKSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5leHRlbmRlZEluZm9ybWF0aW9uKFxyXG4gICAgICAgICAgY29udGV4dCxcclxuICAgICAgICAgIHByaW50ZXIsXHJcbiAgICAgICAgICBzZWN0aW9uLFxyXG4gICAgICAgICAgbW9kdWxlSUQsXHJcbiAgICAgICAgICBhcGlJZCxcclxuICAgICAgICAgIG5ldyBEYXRlKGZyb20pLmdldFRpbWUoKSxcclxuICAgICAgICAgIG5ldyBEYXRlKHRvKS5nZXRUaW1lKCksXHJcbiAgICAgICAgICBzYW5pdGl6ZWRGaWx0ZXJzLFxyXG4gICAgICAgICAgaW5kZXhQYXR0ZXJuVGl0bGUsXHJcbiAgICAgICAgICBhZ2VudHNcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBwcmludGVyLmFkZFZpc3VhbGl6YXRpb25zKGFycmF5LCBhZ2VudHMsIG1vZHVsZUlEKTtcclxuXHJcbiAgICAgIGlmICh0YWJsZXMpIHtcclxuICAgICAgICBwcmludGVyLmFkZFRhYmxlcyh0YWJsZXMpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvL2FkZCBhdXRob3JpemVkIGFnZW50c1xyXG4gICAgICBpZiAoYWdlbnRzRmlsdGVyKSB7XHJcbiAgICAgICAgcHJpbnRlci5hZGRBZ2VudHNGaWx0ZXJzKGFnZW50c0ZpbHRlcik7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGF3YWl0IHByaW50ZXIucHJpbnQoY29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLnBhdGhGaWxlbmFtZSk7XHJcblxyXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgIGJvZHk6IHtcclxuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBgUmVwb3J0ICR7Y29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLmZpbGVuYW1lfSB3YXMgY3JlYXRlZGAsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCA1MDI5LCA1MDAsIHJlc3BvbnNlKTtcclxuICAgIH1cclxuICB9LCh7Ym9keTp7IGFnZW50cyB9LCBwYXJhbXM6IHsgbW9kdWxlSUQgfX0pID0+IGB3YXp1aC1tb2R1bGUtJHthZ2VudHMgPyBgYWdlbnRzLSR7YWdlbnRzfWAgOiAnb3ZlcnZpZXcnfS0ke21vZHVsZUlEfS0ke3RoaXMuZ2VuZXJhdGVSZXBvcnRUaW1lc3RhbXAoKX0ucGRmYClcclxuXHJcbiAgLyoqXHJcbiAgICogQ3JlYXRlIGEgcmVwb3J0IGZvciB0aGUgZ3JvdXBzXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxyXG4gICAqIEByZXR1cm5zIHsqfSByZXBvcnRzIGxpc3Qgb3IgRXJyb3JSZXNwb25zZVxyXG4gICAqL1xyXG4gIGNyZWF0ZVJlcG9ydHNHcm91cHMgPSB0aGlzLmNoZWNrUmVwb3J0c1VzZXJEaXJlY3RvcnlJc1ZhbGlkUm91dGVEZWNvcmF0b3IoYXN5bmMoXHJcbiAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXHJcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXHJcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnlcclxuICApID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNHcm91cHMnLCBgUmVwb3J0IHN0YXJ0ZWRgLCAnaW5mbycpO1xyXG4gICAgICBjb25zdCB7IGNvbXBvbmVudHMsIGFwaUlkIH0gPSByZXF1ZXN0LmJvZHk7XHJcbiAgICAgIGNvbnN0IHsgZ3JvdXBJRCB9ID0gcmVxdWVzdC5wYXJhbXM7XHJcbiAgICAgIC8vIEluaXRcclxuICAgICAgY29uc3QgcHJpbnRlciA9IG5ldyBSZXBvcnRQcmludGVyKCk7XHJcblxyXG4gICAgICBjcmVhdGVEYXRhRGlyZWN0b3J5SWZOb3RFeGlzdHMoKTtcclxuICAgICAgY3JlYXRlRGlyZWN0b3J5SWZOb3RFeGlzdHMoV0FaVUhfREFUQV9ET1dOTE9BRFNfRElSRUNUT1JZX1BBVEgpO1xyXG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRIKTtcclxuICAgICAgY3JlYXRlRGlyZWN0b3J5SWZOb3RFeGlzdHMocGF0aC5qb2luKFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgsIGNvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5oYXNoVXNlcm5hbWUpKTtcclxuXHJcbiAgICAgIGxldCB0YWJsZXMgPSBbXTtcclxuICAgICAgY29uc3QgZXF1aXZhbGVuY2VzID0ge1xyXG4gICAgICAgIGxvY2FsZmlsZTogJ0xvY2FsIGZpbGVzJyxcclxuICAgICAgICBvc3F1ZXJ5OiAnT3NxdWVyeScsXHJcbiAgICAgICAgY29tbWFuZDogJ0NvbW1hbmQnLFxyXG4gICAgICAgIHN5c2NoZWNrOiAnU3lzY2hlY2snLFxyXG4gICAgICAgICdvcGVuLXNjYXAnOiAnT3BlblNDQVAnLFxyXG4gICAgICAgICdjaXMtY2F0JzogJ0NJUy1DQVQnLFxyXG4gICAgICAgIHN5c2NvbGxlY3RvcjogJ1N5c2NvbGxlY3RvcicsXHJcbiAgICAgICAgcm9vdGNoZWNrOiAnUm9vdGNoZWNrJyxcclxuICAgICAgICBsYWJlbHM6ICdMYWJlbHMnLFxyXG4gICAgICAgIHNjYTogJ1NlY3VyaXR5IGNvbmZpZ3VyYXRpb24gYXNzZXNzbWVudCcsXHJcbiAgICAgIH07XHJcbiAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XHJcbiAgICAgICAgdGV4dDogYEdyb3VwICR7Z3JvdXBJRH0gY29uZmlndXJhdGlvbmAsXHJcbiAgICAgICAgc3R5bGU6ICdoMScsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gR3JvdXAgY29uZmlndXJhdGlvblxyXG4gICAgICBpZiAoY29tcG9uZW50c1snMCddKSB7XHJcblxyXG4gICAgICAgIGNvbnN0IHsgZGF0YTogeyBkYXRhOiBjb25maWd1cmF0aW9uIH0gfSA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXHJcbiAgICAgICAgICAnR0VUJyxcclxuICAgICAgICAgIGAvZ3JvdXBzLyR7Z3JvdXBJRH0vY29uZmlndXJhdGlvbmAsXHJcbiAgICAgICAgICB7fSxcclxuICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgY29uZmlndXJhdGlvbi5hZmZlY3RlZF9pdGVtcy5sZW5ndGggPiAwICYmXHJcbiAgICAgICAgICBPYmplY3Qua2V5cyhjb25maWd1cmF0aW9uLmFmZmVjdGVkX2l0ZW1zWzBdLmNvbmZpZykubGVuZ3RoXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xyXG4gICAgICAgICAgICB0ZXh0OiAnQ29uZmlndXJhdGlvbnMnLFxyXG4gICAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMTQsIGNvbG9yOiAnIzAwMCcgfSxcclxuICAgICAgICAgICAgbWFyZ2luOiBbMCwgMTAsIDAsIDE1XSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgY29uc3Qgc2VjdGlvbiA9IHtcclxuICAgICAgICAgICAgbGFiZWxzOiBbXSxcclxuICAgICAgICAgICAgaXNHcm91cENvbmZpZzogdHJ1ZSxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgICBmb3IgKGxldCBjb25maWcgb2YgY29uZmlndXJhdGlvbi5hZmZlY3RlZF9pdGVtcykge1xyXG4gICAgICAgICAgICBsZXQgZmlsdGVyVGl0bGUgPSAnJztcclxuICAgICAgICAgICAgbGV0IGluZGV4ID0gMDtcclxuICAgICAgICAgICAgZm9yIChsZXQgZmlsdGVyIG9mIE9iamVjdC5rZXlzKGNvbmZpZy5maWx0ZXJzKSkge1xyXG4gICAgICAgICAgICAgIGZpbHRlclRpdGxlID0gZmlsdGVyVGl0bGUuY29uY2F0KGAke2ZpbHRlcn06ICR7Y29uZmlnLmZpbHRlcnNbZmlsdGVyXX1gKTtcclxuICAgICAgICAgICAgICBpZiAoaW5kZXggPCBPYmplY3Qua2V5cyhjb25maWcuZmlsdGVycykubGVuZ3RoIC0gMSkge1xyXG4gICAgICAgICAgICAgICAgZmlsdGVyVGl0bGUgPSBmaWx0ZXJUaXRsZS5jb25jYXQoJyB8ICcpO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBpbmRleCsrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XHJcbiAgICAgICAgICAgICAgdGV4dDogZmlsdGVyVGl0bGUsXHJcbiAgICAgICAgICAgICAgc3R5bGU6ICdoNCcsXHJcbiAgICAgICAgICAgICAgbWFyZ2luOiBbMCwgMCwgMCwgMTBdLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgbGV0IGlkeCA9IDA7XHJcbiAgICAgICAgICAgIHNlY3Rpb24udGFicyA9IFtdO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBfZCBvZiBPYmplY3Qua2V5cyhjb25maWcuY29uZmlnKSkge1xyXG4gICAgICAgICAgICAgIGZvciAobGV0IGMgb2YgQWdlbnRDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zKSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBzIG9mIGMuc2VjdGlvbnMpIHtcclxuICAgICAgICAgICAgICAgICAgc2VjdGlvbi5vcHRzID0gcy5vcHRzIHx8IHt9O1xyXG4gICAgICAgICAgICAgICAgICBmb3IgKGxldCBjbiBvZiBzLmNvbmZpZyB8fCBbXSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjbi5jb25maWd1cmF0aW9uID09PSBfZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2VjdGlvbi5sYWJlbHMgPSBzLmxhYmVscyB8fCBbW11dO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBmb3IgKGxldCB3byBvZiBzLndvZGxlIHx8IFtdKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHdvLm5hbWUgPT09IF9kKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZWN0aW9uLmxhYmVscyA9IHMubGFiZWxzIHx8IFtbXV07XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIHNlY3Rpb24ubGFiZWxzWzBdWydwYWNrJ10gPSAnUGFja3MnO1xyXG4gICAgICAgICAgICAgIHNlY3Rpb24ubGFiZWxzWzBdWydjb250ZW50J10gPSAnRXZhbHVhdGlvbnMnO1xyXG4gICAgICAgICAgICAgIHNlY3Rpb24ubGFiZWxzWzBdWyc3J10gPSAnU2NhbiBsaXN0ZW5pbmcgbmV0d290ayBwb3J0cyc7XHJcbiAgICAgICAgICAgICAgc2VjdGlvbi50YWJzLnB1c2goZXF1aXZhbGVuY2VzW19kXSk7XHJcblxyXG4gICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGNvbmZpZy5jb25maWdbX2RdKSkge1xyXG4gICAgICAgICAgICAgICAgLyogTE9HIENPTExFQ1RPUiAqL1xyXG4gICAgICAgICAgICAgICAgaWYgKF9kID09PSAnbG9jYWxmaWxlJykge1xyXG4gICAgICAgICAgICAgICAgICBsZXQgZ3JvdXBzID0gW107XHJcbiAgICAgICAgICAgICAgICAgIGNvbmZpZy5jb25maWdbX2RdLmZvckVhY2goKG9iaikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmICghZ3JvdXBzW29iai5sb2dmb3JtYXRdKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBncm91cHNbb2JqLmxvZ2Zvcm1hdF0gPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBzW29iai5sb2dmb3JtYXRdLnB1c2gob2JqKTtcclxuICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgIE9iamVjdC5rZXlzKGdyb3VwcykuZm9yRWFjaCgoZ3JvdXApID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgc2F2ZWlkeCA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBzW2dyb3VwXS5mb3JFYWNoKCh4LCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoT2JqZWN0LmtleXMoeCkubGVuZ3RoID4gT2JqZWN0LmtleXMoZ3JvdXBzW2dyb3VwXVtzYXZlaWR4XSkubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNhdmVpZHggPSBpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvbHVtbnMgPSBPYmplY3Qua2V5cyhncm91cHNbZ3JvdXBdW3NhdmVpZHhdKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCByb3dzID0gZ3JvdXBzW2dyb3VwXS5tYXAoKHgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGxldCByb3cgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoa2V5KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvdy5wdXNoKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGVvZiB4W2tleV0gIT09ICdvYmplY3QnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHhba2V5XVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBBcnJheS5pc0FycmF5KHhba2V5XSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8geFtrZXldLm1hcCgoeCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB4ICsgJ1xcbic7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEpTT04uc3RyaW5naWZ5KHhba2V5XSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJvdztcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLmZvckVhY2goKGNvbCwgaSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29sdW1uc1tpXSA9IGNvbFswXS50b1VwcGVyQ2FzZSgpICsgY29sLnNsaWNlKDEpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHRhYmxlcy5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnTG9jYWwgZmlsZXMnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3RhYmxlJyxcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICByb3dzLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoX2QgPT09ICdsYWJlbHMnKSB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IG9iaiA9IGNvbmZpZy5jb25maWdbX2RdWzBdLmxhYmVsO1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBjb2x1bW5zID0gT2JqZWN0LmtleXMob2JqWzBdKTtcclxuICAgICAgICAgICAgICAgICAgaWYgKCFjb2x1bW5zLmluY2x1ZGVzKCdoaWRkZW4nKSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnMucHVzaCgnaGlkZGVuJyk7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgY29uc3Qgcm93cyA9IG9iai5tYXAoKHgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgcm93ID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKChrZXkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHJvdy5wdXNoKHhba2V5XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJvdztcclxuICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoY29sLCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uc1tpXSA9IGNvbFswXS50b1VwcGVyQ2FzZSgpICsgY29sLnNsaWNlKDEpO1xyXG4gICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnTGFiZWxzJyxcclxuICAgICAgICAgICAgICAgICAgICB0eXBlOiAndGFibGUnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgcm93cyxcclxuICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICBmb3IgKGxldCBfZDIgb2YgY29uZmlnLmNvbmZpZ1tfZF0pIHtcclxuICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCguLi50aGlzLmdldENvbmZpZ1RhYmxlcyhfZDIsIHNlY3Rpb24sIGlkeCkpO1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8qSU5URUdSSVRZIE1PTklUT1JJTkcgTU9OSVRPUkVEIERJUkVDVE9SSUVTICovXHJcbiAgICAgICAgICAgICAgICBpZiAoY29uZmlnLmNvbmZpZ1tfZF0uZGlyZWN0b3JpZXMpIHtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgZGlyZWN0b3JpZXMgPSBjb25maWcuY29uZmlnW19kXS5kaXJlY3RvcmllcztcclxuICAgICAgICAgICAgICAgICAgZGVsZXRlIGNvbmZpZy5jb25maWdbX2RdLmRpcmVjdG9yaWVzO1xyXG4gICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCguLi50aGlzLmdldENvbmZpZ1RhYmxlcyhjb25maWcuY29uZmlnW19kXSwgc2VjdGlvbiwgaWR4KSk7XHJcbiAgICAgICAgICAgICAgICAgIGxldCBkaWZmT3B0cyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICBPYmplY3Qua2V5cyhzZWN0aW9uLm9wdHMpLmZvckVhY2goKHgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBkaWZmT3B0cy5wdXNoKHgpO1xyXG4gICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgICAgICAgICAgICAgICAgICAnJyxcclxuICAgICAgICAgICAgICAgICAgICAuLi5kaWZmT3B0cy5maWx0ZXIoKHgpID0+IHggIT09ICdjaGVja19hbGwnICYmIHggIT09ICdjaGVja19zdW0nKSxcclxuICAgICAgICAgICAgICAgICAgXTtcclxuICAgICAgICAgICAgICAgICAgbGV0IHJvd3MgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgZGlyZWN0b3JpZXMuZm9yRWFjaCgoeCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGxldCByb3cgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICByb3cucHVzaCh4LnBhdGgpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoeSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHkgIT09ICcnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHkgPSB5ICE9PSAnY2hlY2tfd2hvZGF0YScgPyB5IDogJ3dob2RhdGEnO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByb3cucHVzaCh4W3ldID8geFt5XSA6ICdubycpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHJvdy5wdXNoKHgucmVjdXJzaW9uX2xldmVsKTtcclxuICAgICAgICAgICAgICAgICAgICByb3dzLnB1c2gocm93KTtcclxuICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoeCwgaWR4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uc1tpZHhdID0gc2VjdGlvbi5vcHRzW3hdO1xyXG4gICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgY29sdW1ucy5wdXNoKCdSTCcpO1xyXG4gICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdNb25pdG9yZWQgZGlyZWN0b3JpZXMnLFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICd0YWJsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucyxcclxuICAgICAgICAgICAgICAgICAgICByb3dzLFxyXG4gICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgIHRhYmxlcy5wdXNoKC4uLnRoaXMuZ2V0Q29uZmlnVGFibGVzKGNvbmZpZy5jb25maWdbX2RdLCBzZWN0aW9uLCBpZHgpKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgZm9yIChjb25zdCB0YWJsZSBvZiB0YWJsZXMpIHtcclxuICAgICAgICAgICAgICAgIHByaW50ZXIuYWRkQ29uZmlnVGFibGVzKFt0YWJsZV0pO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBpZHgrKztcclxuICAgICAgICAgICAgICB0YWJsZXMgPSBbXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0YWJsZXMgPSBbXTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50KHtcclxuICAgICAgICAgICAgdGV4dDogJ0EgY29uZmlndXJhdGlvbiBmb3IgdGhpcyBncm91cCBoYXMgbm90IHlldCBiZWVuIHNldCB1cC4nLFxyXG4gICAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMTIsIGNvbG9yOiAnIzAwMCcgfSxcclxuICAgICAgICAgICAgbWFyZ2luOiBbMCwgMTAsIDAsIDE1XSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gQWdlbnRzIGluIGdyb3VwXHJcbiAgICAgIGlmIChjb21wb25lbnRzWycxJ10pIHtcclxuICAgICAgICBhd2FpdCB0aGlzLnJlbmRlckhlYWRlcihcclxuICAgICAgICAgIGNvbnRleHQsXHJcbiAgICAgICAgICBwcmludGVyLFxyXG4gICAgICAgICAgJ2dyb3VwQ29uZmlnJyxcclxuICAgICAgICAgIGdyb3VwSUQsXHJcbiAgICAgICAgICBbXSxcclxuICAgICAgICAgIGFwaUlkXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgYXdhaXQgcHJpbnRlci5wcmludChjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMucGF0aEZpbGVuYW1lKTtcclxuXHJcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgYm9keToge1xyXG4gICAgICAgICAgc3VjY2VzczogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IGBSZXBvcnQgJHtjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMuZmlsZW5hbWV9IHdhcyBjcmVhdGVkYCxcclxuICAgICAgICB9LFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNHcm91cHMnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTAyOSwgNTAwLCByZXNwb25zZSk7XHJcbiAgICB9XHJcbiAgfSwgKHtwYXJhbXM6IHsgZ3JvdXBJRCB9fSkgPT4gYHdhenVoLWdyb3VwLWNvbmZpZ3VyYXRpb24tJHtncm91cElEfS0ke3RoaXMuZ2VuZXJhdGVSZXBvcnRUaW1lc3RhbXAoKX0ucGRmYClcclxuXHJcbiAgLyoqXHJcbiAgICogQ3JlYXRlIGEgcmVwb3J0IGZvciB0aGUgYWdlbnRzXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxyXG4gICAqIEByZXR1cm5zIHsqfSByZXBvcnRzIGxpc3Qgb3IgRXJyb3JSZXNwb25zZVxyXG4gICAqL1xyXG4gIGNyZWF0ZVJlcG9ydHNBZ2VudHNDb25maWd1cmF0aW9uID0gdGhpcy5jaGVja1JlcG9ydHNVc2VyRGlyZWN0b3J5SXNWYWxpZFJvdXRlRGVjb3JhdG9yKCBhc3luYyAoXHJcbiAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXHJcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXHJcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnlcclxuICApID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNBZ2VudHNDb25maWd1cmF0aW9uJywgYFJlcG9ydCBzdGFydGVkYCwgJ2luZm8nKTtcclxuICAgICAgY29uc3QgeyBjb21wb25lbnRzLCBhcGlJZCB9ID0gcmVxdWVzdC5ib2R5O1xyXG4gICAgICBjb25zdCB7IGFnZW50SUQgfSA9IHJlcXVlc3QucGFyYW1zO1xyXG5cclxuICAgICAgY29uc3QgcHJpbnRlciA9IG5ldyBSZXBvcnRQcmludGVyKCk7XHJcbiAgICAgIGNyZWF0ZURhdGFEaXJlY3RvcnlJZk5vdEV4aXN0cygpO1xyXG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19ESVJFQ1RPUllfUEFUSCk7XHJcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgpO1xyXG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhwYXRoLmpvaW4oV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCwgY29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLmhhc2hVc2VybmFtZSkpO1xyXG5cclxuICAgICAgbGV0IHdtb2R1bGVzUmVzcG9uc2UgPSB7fTtcclxuICAgICAgbGV0IHRhYmxlcyA9IFtdO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHdtb2R1bGVzUmVzcG9uc2UgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxyXG4gICAgICAgICAgJ0dFVCcsXHJcbiAgICAgICAgICBgL2FnZW50cy8ke2FnZW50SUR9L2NvbmZpZy93bW9kdWxlcy93bW9kdWxlc2AsXHJcbiAgICAgICAgICB7fSxcclxuICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9XHJcbiAgICAgICAgKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBsb2coJ3JlcG9ydGluZzpyZXBvcnQnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yLCAnZGVidWcnKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgYXdhaXQgdGhpcy5yZW5kZXJIZWFkZXIoY29udGV4dCwgcHJpbnRlciwgJ2FnZW50Q29uZmlnJywgJ2FnZW50Q29uZmlnJywgYWdlbnRJRCwgYXBpSWQpO1xyXG5cclxuICAgICAgbGV0IGlkeENvbXBvbmVudCA9IDA7XHJcbiAgICAgIGZvciAobGV0IGNvbmZpZyBvZiBBZ2VudENvbmZpZ3VyYXRpb24uY29uZmlndXJhdGlvbnMpIHtcclxuICAgICAgICBsZXQgdGl0bGVPZlNlY3Rpb24gPSBmYWxzZTtcclxuICAgICAgICBsb2coXHJcbiAgICAgICAgICAncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNBZ2VudHNDb25maWd1cmF0aW9uJyxcclxuICAgICAgICAgIGBJdGVyYXRlIG92ZXIgJHtjb25maWcuc2VjdGlvbnMubGVuZ3RofSBjb25maWd1cmF0aW9uIHNlY3Rpb25zYCxcclxuICAgICAgICAgICdkZWJ1ZydcclxuICAgICAgICApO1xyXG4gICAgICAgIGZvciAobGV0IHNlY3Rpb24gb2YgY29uZmlnLnNlY3Rpb25zKSB7XHJcbiAgICAgICAgICBsZXQgdGl0bGVPZlN1YnNlY3Rpb24gPSBmYWxzZTtcclxuICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgY29tcG9uZW50c1tpZHhDb21wb25lbnRdICYmXHJcbiAgICAgICAgICAgIChzZWN0aW9uLmNvbmZpZyB8fCBzZWN0aW9uLndvZGxlKVxyXG4gICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIGxldCBpZHggPSAwO1xyXG4gICAgICAgICAgICBjb25zdCBjb25maWdzID0gKHNlY3Rpb24uY29uZmlnIHx8IFtdKS5jb25jYXQoc2VjdGlvbi53b2RsZSB8fCBbXSk7XHJcbiAgICAgICAgICAgIGxvZyhcclxuICAgICAgICAgICAgICAncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNBZ2VudHNDb25maWd1cmF0aW9uJyxcclxuICAgICAgICAgICAgICBgSXRlcmF0ZSBvdmVyICR7Y29uZmlncy5sZW5ndGh9IGNvbmZpZ3VyYXRpb24gYmxvY2tzYCxcclxuICAgICAgICAgICAgICAnZGVidWcnXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGNvbmYgb2YgY29uZmlncykge1xyXG4gICAgICAgICAgICAgIGxldCBhZ2VudENvbmZpZ1Jlc3BvbnNlID0ge307XHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGlmICghY29uZlsnbmFtZSddKSB7XHJcbiAgICAgICAgICAgICAgICAgIGFnZW50Q29uZmlnUmVzcG9uc2UgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxyXG4gICAgICAgICAgICAgICAgICAgICdHRVQnLFxyXG4gICAgICAgICAgICAgICAgICAgIGAvYWdlbnRzLyR7YWdlbnRJRH0vY29uZmlnLyR7Y29uZi5jb21wb25lbnR9LyR7Y29uZi5jb25maWd1cmF0aW9ufWAsXHJcbiAgICAgICAgICAgICAgICAgICAge30sXHJcbiAgICAgICAgICAgICAgICAgICAgeyBhcGlIb3N0SUQ6IGFwaUlkIH1cclxuICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgIGZvciAobGV0IHdvZGxlIG9mIHdtb2R1bGVzUmVzcG9uc2UuZGF0YS5kYXRhWyd3bW9kdWxlcyddKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKE9iamVjdC5rZXlzKHdvZGxlKVswXSA9PT0gY29uZlsnbmFtZSddKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBhZ2VudENvbmZpZ1Jlc3BvbnNlLmRhdGEgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IHdvZGxlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBjb25zdCBhZ2VudENvbmZpZyA9XHJcbiAgICAgICAgICAgICAgICAgIGFnZW50Q29uZmlnUmVzcG9uc2UgJiYgYWdlbnRDb25maWdSZXNwb25zZS5kYXRhICYmIGFnZW50Q29uZmlnUmVzcG9uc2UuZGF0YS5kYXRhO1xyXG4gICAgICAgICAgICAgICAgaWYgKCF0aXRsZU9mU2VjdGlvbikge1xyXG4gICAgICAgICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ6IGNvbmZpZy50aXRsZSxcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZTogJ2gxJyxcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW46IFswLCAwLCAwLCAxNV0sXHJcbiAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICB0aXRsZU9mU2VjdGlvbiA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpZiAoIXRpdGxlT2ZTdWJzZWN0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogc2VjdGlvbi5zdWJ0aXRsZSxcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZTogJ2g0JyxcclxuICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogc2VjdGlvbi5kZXNjLFxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlOiB7IGZvbnRTaXplOiAxMiwgY29sb3I6ICcjMDAwJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbjogWzAsIDAsIDAsIDEwXSxcclxuICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgIHRpdGxlT2ZTdWJzZWN0aW9uID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChhZ2VudENvbmZpZykge1xyXG4gICAgICAgICAgICAgICAgICBmb3IgKGxldCBhZ2VudENvbmZpZ0tleSBvZiBPYmplY3Qua2V5cyhhZ2VudENvbmZpZykpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShhZ2VudENvbmZpZ1thZ2VudENvbmZpZ0tleV0pKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAvKiBMT0cgQ09MTEVDVE9SICovXHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoY29uZi5maWx0ZXJCeSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZ3JvdXBzID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFnZW50Q29uZmlnW2FnZW50Q29uZmlnS2V5XS5mb3JFYWNoKChvYmopID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWdyb3Vwc1tvYmoubG9nZm9ybWF0XSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBzW29iai5sb2dmb3JtYXRdID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3Vwc1tvYmoubG9nZm9ybWF0XS5wdXNoKG9iaik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBPYmplY3Qua2V5cyhncm91cHMpLmZvckVhY2goKGdyb3VwKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHNhdmVpZHggPSAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3Vwc1tncm91cF0uZm9yRWFjaCgoeCwgaSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPYmplY3Qua2V5cyh4KS5sZW5ndGggPiBPYmplY3Qua2V5cyhncm91cHNbZ3JvdXBdW3NhdmVpZHhdKS5sZW5ndGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzYXZlaWR4ID0gaTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjb2x1bW5zID0gT2JqZWN0LmtleXMoZ3JvdXBzW2dyb3VwXVtzYXZlaWR4XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgcm93cyA9IGdyb3Vwc1tncm91cF0ubWFwKCh4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcm93ID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLmZvckVhY2goKGtleSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3cucHVzaChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlb2YgeFtrZXldICE9PSAnb2JqZWN0J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB4W2tleV1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogQXJyYXkuaXNBcnJheSh4W2tleV0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHhba2V5XS5tYXAoKHgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geCArICdcXG4nO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBKU09OLnN0cmluZ2lmeSh4W2tleV0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByb3c7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKChjb2wsIGkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnNbaV0gPSBjb2xbMF0udG9VcHBlckNhc2UoKSArIGNvbC5zbGljZSgxKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogc2VjdGlvbi5sYWJlbHNbMF1bZ3JvdXBdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3RhYmxlJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoYWdlbnRDb25maWdLZXkuY29uZmlndXJhdGlvbiAhPT0gJ3NvY2tldCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udGhpcy5nZXRDb25maWdUYWJsZXMoYWdlbnRDb25maWdbYWdlbnRDb25maWdLZXldLCBzZWN0aW9uLCBpZHgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBfZDIgb2YgYWdlbnRDb25maWdbYWdlbnRDb25maWdLZXldKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goLi4udGhpcy5nZXRDb25maWdUYWJsZXMoX2QyLCBzZWN0aW9uLCBpZHgpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAvKklOVEVHUklUWSBNT05JVE9SSU5HIE1PTklUT1JFRCBESVJFQ1RPUklFUyAqL1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbmYubWF0cml4KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHtkaXJlY3RvcmllcyxkaWZmLHN5bmNocm9uaXphdGlvbixmaWxlX2xpbWl0LC4uLnJlc3R9ID0gYWdlbnRDb25maWdbYWdlbnRDb25maWdLZXldO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi50aGlzLmdldENvbmZpZ1RhYmxlcyhyZXN0LCBzZWN0aW9uLCBpZHgpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLihkaWZmICYmIGRpZmYuZGlza19xdW90YSA/IHRoaXMuZ2V0Q29uZmlnVGFibGVzKGRpZmYuZGlza19xdW90YSwge3RhYnM6WydEaXNrIHF1b3RhJ119LCAwICk6IFtdKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi4oZGlmZiAmJiBkaWZmLmZpbGVfc2l6ZSA/IHRoaXMuZ2V0Q29uZmlnVGFibGVzKGRpZmYuZmlsZV9zaXplLCB7dGFiczpbJ0ZpbGUgc2l6ZSddfSwgMCApOiBbXSksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uKHN5bmNocm9uaXphdGlvbiA/IHRoaXMuZ2V0Q29uZmlnVGFibGVzKHN5bmNocm9uaXphdGlvbiwge3RhYnM6WydTeW5jaHJvbml6YXRpb24nXX0sIDAgKTogW10pLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLihmaWxlX2xpbWl0ID8gdGhpcy5nZXRDb25maWdUYWJsZXMoZmlsZV9saW1pdCwge3RhYnM6WydGaWxlIGxpbWl0J119LCAwICk6IFtdKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRpZmZPcHRzID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC5rZXlzKHNlY3Rpb24ub3B0cykuZm9yRWFjaCgoeCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpZmZPcHRzLnB1c2goeCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICcnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmRpZmZPcHRzLmZpbHRlcigoeCkgPT4geCAhPT0gJ2NoZWNrX2FsbCcgJiYgeCAhPT0gJ2NoZWNrX3N1bScpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcm93cyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXJlY3Rvcmllcy5mb3JFYWNoKCh4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJvdyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJvdy5wdXNoKHguZGlyKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLmZvckVhY2goKHkpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh5ICE9PSAnJykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3cucHVzaCh4Lm9wdHMuaW5kZXhPZih5KSA+IC0xID8gJ3llcycgOiAnbm8nKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByb3cucHVzaCh4LnJlY3Vyc2lvbl9sZXZlbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cy5wdXNoKHJvdyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLmZvckVhY2goKHgsIGlkeCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnNbaWR4XSA9IHNlY3Rpb24ub3B0c1t4XTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMucHVzaCgnUkwnKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnTW9uaXRvcmVkIGRpcmVjdG9yaWVzJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAndGFibGUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi50aGlzLmdldENvbmZpZ1RhYmxlcyhhZ2VudENvbmZpZ1thZ2VudENvbmZpZ0tleV0sIHNlY3Rpb24sIGlkeClcclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgIC8vIFByaW50IG5vIGNvbmZpZ3VyZWQgbW9kdWxlIGFuZCBsaW5rIHRvIHRoZSBkb2N1bWVudGF0aW9uXHJcbiAgICAgICAgICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgJ1RoaXMgbW9kdWxlIGlzIG5vdCBjb25maWd1cmVkLiBQbGVhc2UgdGFrZSBhIGxvb2sgb24gaG93IHRvIGNvbmZpZ3VyZSBpdCBpbiAnLFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBgJHtzZWN0aW9uLnN1YnRpdGxlLnRvTG93ZXJDYXNlKCl9IGNvbmZpZ3VyYXRpb24uYCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGluazogc2VjdGlvbi5kb2N1TGluayxcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU6IHsgZm9udFNpemU6IDEyLCBjb2xvcjogJyMxYTBkYWInIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiBbMCwgMCwgMCwgMjBdLFxyXG4gICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICAgICAgbG9nKCdyZXBvcnRpbmc6cmVwb3J0JywgZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgJ2RlYnVnJyk7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGlkeCsrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGZvciAoY29uc3QgdGFibGUgb2YgdGFibGVzKSB7XHJcbiAgICAgICAgICAgICAgcHJpbnRlci5hZGRDb25maWdUYWJsZXMoW3RhYmxlXSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlkeENvbXBvbmVudCsrO1xyXG4gICAgICAgICAgdGFibGVzID0gW107XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBhd2FpdCBwcmludGVyLnByaW50KGNvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5wYXRoRmlsZW5hbWUpO1xyXG5cclxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogYFJlcG9ydCAke2NvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5maWxlbmFtZX0gd2FzIGNyZWF0ZWRgLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgbG9nKCdyZXBvcnRpbmc6Y3JlYXRlUmVwb3J0c0FnZW50c0NvbmZpZ3VyYXRpb24nLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTAyOSwgNTAwLCByZXNwb25zZSk7XHJcbiAgICB9XHJcbiAgfSwgKHsgcGFyYW1zOiB7IGFnZW50SUQgfX0pID0+IGB3YXp1aC1hZ2VudC1jb25maWd1cmF0aW9uLSR7YWdlbnRJRH0tJHt0aGlzLmdlbmVyYXRlUmVwb3J0VGltZXN0YW1wKCl9LnBkZmApXHJcblxyXG4gIC8qKlxyXG4gICAqIENyZWF0ZSBhIHJlcG9ydCBmb3IgdGhlIGFnZW50c1xyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcclxuICAgKiBAcmV0dXJucyB7Kn0gcmVwb3J0cyBsaXN0IG9yIEVycm9yUmVzcG9uc2VcclxuICAgKi9cclxuICBjcmVhdGVSZXBvcnRzQWdlbnRzSW52ZW50b3J5ID0gdGhpcy5jaGVja1JlcG9ydHNVc2VyRGlyZWN0b3J5SXNWYWxpZFJvdXRlRGVjb3JhdG9yKCBhc3luYyAoXHJcbiAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXHJcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXHJcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnlcclxuICApID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNBZ2VudHNJbnZlbnRvcnknLCBgUmVwb3J0IHN0YXJ0ZWRgLCAnaW5mbycpO1xyXG4gICAgICBjb25zdCB7IHNlYXJjaEJhciwgZmlsdGVycywgdGltZSwgaW5kZXhQYXR0ZXJuVGl0bGUsIGFwaUlkIH0gPSByZXF1ZXN0LmJvZHk7XHJcbiAgICAgIGNvbnN0IHsgYWdlbnRJRCB9ID0gcmVxdWVzdC5wYXJhbXM7XHJcbiAgICAgIGNvbnN0IHsgZnJvbSwgdG8gfSA9IHRpbWUgfHwge307XHJcbiAgICAgIC8vIEluaXRcclxuICAgICAgY29uc3QgcHJpbnRlciA9IG5ldyBSZXBvcnRQcmludGVyKCk7XHJcblxyXG4gICAgICBjb25zdCB7IGhhc2hVc2VybmFtZSB9ID0gYXdhaXQgY29udGV4dC53YXp1aC5zZWN1cml0eS5nZXRDdXJyZW50VXNlcihyZXF1ZXN0LCBjb250ZXh0KTtcclxuICAgICAgY3JlYXRlRGF0YURpcmVjdG9yeUlmTm90RXhpc3RzKCk7XHJcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKFdBWlVIX0RBVEFfRE9XTkxPQURTX0RJUkVDVE9SWV9QQVRIKTtcclxuICAgICAgY3JlYXRlRGlyZWN0b3J5SWZOb3RFeGlzdHMoV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCk7XHJcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKHBhdGguam9pbihXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRILCBoYXNoVXNlcm5hbWUpKTtcclxuXHJcbiAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNBZ2VudHNJbnZlbnRvcnknLCBgU3lzY29sbGVjdG9yIHJlcG9ydGAsICdkZWJ1ZycpO1xyXG4gICAgICBjb25zdCBzYW5pdGl6ZWRGaWx0ZXJzID0gZmlsdGVycyA/IHRoaXMuc2FuaXRpemVLaWJhbmFGaWx0ZXJzKGZpbHRlcnMsIHNlYXJjaEJhcikgOiBmYWxzZTtcclxuXHJcbiAgICAgIC8vIEdldCB0aGUgYWdlbnQgT1NcclxuICAgICAgbGV0IGFnZW50T3MgPSAnJztcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBhZ2VudFJlc3BvbnNlID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdChcclxuICAgICAgICAgICdHRVQnLFxyXG4gICAgICAgICAgJy9hZ2VudHMnLFxyXG4gICAgICAgICAgeyBwYXJhbXM6IHsgcTogYGlkPSR7YWdlbnRJRH1gIH0gfSxcclxuICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9XHJcbiAgICAgICAgKTtcclxuICAgICAgICBhZ2VudE9zID0gYWdlbnRSZXNwb25zZS5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXNbMF0ub3MucGxhdGZvcm07XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgbG9nKCdyZXBvcnRpbmc6Y3JlYXRlUmVwb3J0c0FnZW50c0ludmVudG9yeScsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsICdkZWJ1ZycpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBBZGQgdGl0bGVcclxuICAgICAgcHJpbnRlci5hZGRDb250ZW50V2l0aE5ld0xpbmUoe1xyXG4gICAgICAgIHRleHQ6ICdJbnZlbnRvcnkgZGF0YSByZXBvcnQnLFxyXG4gICAgICAgIHN0eWxlOiAnaDEnLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIC8vIEFkZCB0YWJsZSB3aXRoIHRoZSBhZ2VudCBpbmZvXHJcbiAgICAgIGF3YWl0IHRoaXMuYnVpbGRBZ2VudHNUYWJsZShjb250ZXh0LCBwcmludGVyLCBbYWdlbnRJRF0sIGFwaUlkKTtcclxuXHJcbiAgICAgIC8vIEdldCBzeXNjb2xsZWN0b3IgcGFja2FnZXMgYW5kIHByb2Nlc3Nlc1xyXG4gICAgICBjb25zdCBhZ2VudFJlcXVlc3RzSW52ZW50b3J5ID0gW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGVuZHBvaW50OiBgL3N5c2NvbGxlY3Rvci8ke2FnZW50SUR9L3BhY2thZ2VzYCxcclxuICAgICAgICAgIGxvZ2dlck1lc3NhZ2U6IGBGZXRjaGluZyBwYWNrYWdlcyBmb3IgYWdlbnQgJHthZ2VudElEfWAsXHJcbiAgICAgICAgICB0YWJsZToge1xyXG4gICAgICAgICAgICB0aXRsZTogJ1BhY2thZ2VzJyxcclxuICAgICAgICAgICAgY29sdW1uczpcclxuICAgICAgICAgICAgICBhZ2VudE9zID09PSAnd2luZG93cydcclxuICAgICAgICAgICAgICAgID8gW1xyXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICduYW1lJywgbGFiZWw6ICdOYW1lJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdhcmNoaXRlY3R1cmUnLCBsYWJlbDogJ0FyY2hpdGVjdHVyZScgfSxcclxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAndmVyc2lvbicsIGxhYmVsOiAnVmVyc2lvbicgfSxcclxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAndmVuZG9yJywgbGFiZWw6ICdWZW5kb3InIH0sXHJcbiAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgIDogW1xyXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICduYW1lJywgbGFiZWw6ICdOYW1lJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdhcmNoaXRlY3R1cmUnLCBsYWJlbDogJ0FyY2hpdGVjdHVyZScgfSxcclxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAndmVyc2lvbicsIGxhYmVsOiAnVmVyc2lvbicgfSxcclxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAndmVuZG9yJywgbGFiZWw6ICdWZW5kb3InIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ2Rlc2NyaXB0aW9uJywgbGFiZWw6ICdEZXNjcmlwdGlvbicgfSxcclxuICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBlbmRwb2ludDogYC9zeXNjb2xsZWN0b3IvJHthZ2VudElEfS9wcm9jZXNzZXNgLFxyXG4gICAgICAgICAgbG9nZ2VyTWVzc2FnZTogYEZldGNoaW5nIHByb2Nlc3NlcyBmb3IgYWdlbnQgJHthZ2VudElEfWAsXHJcbiAgICAgICAgICB0YWJsZToge1xyXG4gICAgICAgICAgICB0aXRsZTogJ1Byb2Nlc3NlcycsXHJcbiAgICAgICAgICAgIGNvbHVtbnM6XHJcbiAgICAgICAgICAgICAgYWdlbnRPcyA9PT0gJ3dpbmRvd3MnXHJcbiAgICAgICAgICAgICAgICA/IFtcclxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnbmFtZScsIGxhYmVsOiAnTmFtZScgfSxcclxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnY21kJywgbGFiZWw6ICdDTUQnIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ3ByaW9yaXR5JywgbGFiZWw6ICdQcmlvcml0eScgfSxcclxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnbmx3cCcsIGxhYmVsOiAnTkxXUCcgfSxcclxuICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ25hbWUnLCBsYWJlbDogJ05hbWUnIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ2V1c2VyJywgbGFiZWw6ICdFZmZlY3RpdmUgdXNlcicgfSxcclxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnbmljZScsIGxhYmVsOiAnUHJpb3JpdHknIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ3N0YXRlJywgbGFiZWw6ICdTdGF0ZScgfSxcclxuICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBtYXBSZXNwb25zZUl0ZW1zOiAoaXRlbSkgPT5cclxuICAgICAgICAgICAgYWdlbnRPcyA9PT0gJ3dpbmRvd3MnID8gaXRlbSA6IHsgLi4uaXRlbSwgc3RhdGU6IFByb2Nlc3NFcXVpdmFsZW5jZVtpdGVtLnN0YXRlXSB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZW5kcG9pbnQ6IGAvc3lzY29sbGVjdG9yLyR7YWdlbnRJRH0vcG9ydHNgLFxyXG4gICAgICAgICAgbG9nZ2VyTWVzc2FnZTogYEZldGNoaW5nIHBvcnRzIGZvciBhZ2VudCAke2FnZW50SUR9YCxcclxuICAgICAgICAgIHRhYmxlOiB7XHJcbiAgICAgICAgICAgIHRpdGxlOiAnTmV0d29yayBwb3J0cycsXHJcbiAgICAgICAgICAgIGNvbHVtbnM6XHJcbiAgICAgICAgICAgICAgYWdlbnRPcyA9PT0gJ3dpbmRvd3MnXHJcbiAgICAgICAgICAgICAgICA/IFtcclxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnbG9jYWxfaXAnLCBsYWJlbDogJ0xvY2FsIElQJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdsb2NhbF9wb3J0JywgbGFiZWw6ICdMb2NhbCBwb3J0JyB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdwcm9jZXNzJywgbGFiZWw6ICdQcm9jZXNzJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdzdGF0ZScsIGxhYmVsOiAnU3RhdGUnIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ3Byb3RvY29sJywgbGFiZWw6ICdQcm90b2NvbCcgfSxcclxuICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ2xvY2FsX2lwJywgbGFiZWw6ICdMb2NhbCBJUCcgfSxcclxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnbG9jYWxfcG9ydCcsIGxhYmVsOiAnTG9jYWwgcG9ydCcgfSxcclxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnc3RhdGUnLCBsYWJlbDogJ1N0YXRlJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdwcm90b2NvbCcsIGxhYmVsOiAnUHJvdG9jb2wnIH0sXHJcbiAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgbWFwUmVzcG9uc2VJdGVtczogKGl0ZW0pID0+ICh7XHJcbiAgICAgICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgICAgIGxvY2FsX2lwOiBpdGVtLmxvY2FsLmlwLFxyXG4gICAgICAgICAgICBsb2NhbF9wb3J0OiBpdGVtLmxvY2FsLnBvcnQsXHJcbiAgICAgICAgICB9KSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGVuZHBvaW50OiBgL3N5c2NvbGxlY3Rvci8ke2FnZW50SUR9L25ldGlmYWNlYCxcclxuICAgICAgICAgIGxvZ2dlck1lc3NhZ2U6IGBGZXRjaGluZyBuZXRpZmFjZSBmb3IgYWdlbnQgJHthZ2VudElEfWAsXHJcbiAgICAgICAgICB0YWJsZToge1xyXG4gICAgICAgICAgICB0aXRsZTogJ05ldHdvcmsgaW50ZXJmYWNlcycsXHJcbiAgICAgICAgICAgIGNvbHVtbnM6IFtcclxuICAgICAgICAgICAgICB7IGlkOiAnbmFtZScsIGxhYmVsOiAnTmFtZScgfSxcclxuICAgICAgICAgICAgICB7IGlkOiAnbWFjJywgbGFiZWw6ICdNYWMnIH0sXHJcbiAgICAgICAgICAgICAgeyBpZDogJ3N0YXRlJywgbGFiZWw6ICdTdGF0ZScgfSxcclxuICAgICAgICAgICAgICB7IGlkOiAnbXR1JywgbGFiZWw6ICdNVFUnIH0sXHJcbiAgICAgICAgICAgICAgeyBpZDogJ3R5cGUnLCBsYWJlbDogJ1R5cGUnIH0sXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgZW5kcG9pbnQ6IGAvc3lzY29sbGVjdG9yLyR7YWdlbnRJRH0vbmV0YWRkcmAsXHJcbiAgICAgICAgICBsb2dnZXJNZXNzYWdlOiBgRmV0Y2hpbmcgbmV0YWRkciBmb3IgYWdlbnQgJHthZ2VudElEfWAsXHJcbiAgICAgICAgICB0YWJsZToge1xyXG4gICAgICAgICAgICB0aXRsZTogJ05ldHdvcmsgc2V0dGluZ3MnLFxyXG4gICAgICAgICAgICBjb2x1bW5zOiBbXHJcbiAgICAgICAgICAgICAgeyBpZDogJ2lmYWNlJywgbGFiZWw6ICdJbnRlcmZhY2UnIH0sXHJcbiAgICAgICAgICAgICAgeyBpZDogJ2FkZHJlc3MnLCBsYWJlbDogJ2FkZHJlc3MnIH0sXHJcbiAgICAgICAgICAgICAgeyBpZDogJ25ldG1hc2snLCBsYWJlbDogJ05ldG1hc2snIH0sXHJcbiAgICAgICAgICAgICAgeyBpZDogJ3Byb3RvJywgbGFiZWw6ICdQcm90b2NvbCcgfSxcclxuICAgICAgICAgICAgICB7IGlkOiAnYnJvYWRjYXN0JywgbGFiZWw6ICdCcm9hZGNhc3QnIH0sXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgIF07XHJcblxyXG4gICAgICBhZ2VudE9zID09PSAnd2luZG93cycgJiZcclxuICAgICAgICBhZ2VudFJlcXVlc3RzSW52ZW50b3J5LnB1c2goe1xyXG4gICAgICAgICAgZW5kcG9pbnQ6IGAvc3lzY29sbGVjdG9yLyR7YWdlbnRJRH0vaG90Zml4ZXNgLFxyXG4gICAgICAgICAgbG9nZ2VyTWVzc2FnZTogYEZldGNoaW5nIGhvdGZpeGVzIGZvciBhZ2VudCAke2FnZW50SUR9YCxcclxuICAgICAgICAgIHRhYmxlOiB7XHJcbiAgICAgICAgICAgIHRpdGxlOiAnV2luZG93cyB1cGRhdGVzJyxcclxuICAgICAgICAgICAgY29sdW1uczogW3sgaWQ6ICdob3RmaXgnLCBsYWJlbDogJ1VwZGF0ZSBjb2RlJyB9XSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCByZXF1ZXN0SW52ZW50b3J5ID0gYXN5bmMgKGFnZW50UmVxdWVzdEludmVudG9yeSkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBsb2coXHJcbiAgICAgICAgICAgICdyZXBvcnRpbmc6Y3JlYXRlUmVwb3J0c0FnZW50c0ludmVudG9yeScsXHJcbiAgICAgICAgICAgIGFnZW50UmVxdWVzdEludmVudG9yeS5sb2dnZXJNZXNzYWdlLFxyXG4gICAgICAgICAgICAnZGVidWcnXHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgIGNvbnN0IGludmVudG9yeVJlc3BvbnNlID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdChcclxuICAgICAgICAgICAgJ0dFVCcsXHJcbiAgICAgICAgICAgIGFnZW50UmVxdWVzdEludmVudG9yeS5lbmRwb2ludCxcclxuICAgICAgICAgICAge30sXHJcbiAgICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9XHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgIGNvbnN0IGludmVudG9yeSA9XHJcbiAgICAgICAgICAgIGludmVudG9yeVJlc3BvbnNlICYmXHJcbiAgICAgICAgICAgIGludmVudG9yeVJlc3BvbnNlLmRhdGEgJiZcclxuICAgICAgICAgICAgaW52ZW50b3J5UmVzcG9uc2UuZGF0YS5kYXRhICYmXHJcbiAgICAgICAgICAgIGludmVudG9yeVJlc3BvbnNlLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtcztcclxuICAgICAgICAgIGlmIChpbnZlbnRvcnkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAuLi5hZ2VudFJlcXVlc3RJbnZlbnRvcnkudGFibGUsXHJcbiAgICAgICAgICAgICAgaXRlbXM6IGFnZW50UmVxdWVzdEludmVudG9yeS5tYXBSZXNwb25zZUl0ZW1zXHJcbiAgICAgICAgICAgICAgICA/IGludmVudG9yeS5tYXAoYWdlbnRSZXF1ZXN0SW52ZW50b3J5Lm1hcFJlc3BvbnNlSXRlbXMpXHJcbiAgICAgICAgICAgICAgICA6IGludmVudG9yeSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgbG9nKCdyZXBvcnRpbmc6Y3JlYXRlUmVwb3J0c0FnZW50c0ludmVudG9yeScsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsICdkZWJ1ZycpO1xyXG4gICAgICAgIH1cclxuICAgICAgfTtcclxuXHJcbiAgICAgIGlmICh0aW1lKSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5leHRlbmRlZEluZm9ybWF0aW9uKFxyXG4gICAgICAgICAgY29udGV4dCxcclxuICAgICAgICAgIHByaW50ZXIsXHJcbiAgICAgICAgICAnYWdlbnRzJyxcclxuICAgICAgICAgICdzeXNjb2xsZWN0b3InLFxyXG4gICAgICAgICAgYXBpSWQsXHJcbiAgICAgICAgICBmcm9tLFxyXG4gICAgICAgICAgdG8sXHJcbiAgICAgICAgICBzYW5pdGl6ZWRGaWx0ZXJzICsgJyBBTkQgcnVsZS5ncm91cHM6IFwidnVsbmVyYWJpbGl0eS1kZXRlY3RvclwiJyxcclxuICAgICAgICAgIGluZGV4UGF0dGVyblRpdGxlLFxyXG4gICAgICAgICAgYWdlbnRJRFxyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIEFkZCBpbnZlbnRvcnkgdGFibGVzXHJcbiAgICAgIChhd2FpdCBQcm9taXNlLmFsbChhZ2VudFJlcXVlc3RzSW52ZW50b3J5Lm1hcChyZXF1ZXN0SW52ZW50b3J5KSkpXHJcbiAgICAgICAgLmZpbHRlcigodGFibGUpID0+IHRhYmxlKVxyXG4gICAgICAgIC5mb3JFYWNoKCh0YWJsZSkgPT4gcHJpbnRlci5hZGRTaW1wbGVUYWJsZSh0YWJsZSkpO1xyXG5cclxuICAgICAgLy8gUHJpbnQgdGhlIGRvY3VtZW50XHJcbiAgICAgIGF3YWl0IHByaW50ZXIucHJpbnQoY29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLnBhdGhGaWxlbmFtZSk7XHJcblxyXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgIGJvZHk6IHtcclxuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBgUmVwb3J0ICR7Y29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLmZpbGVuYW1lfSB3YXMgY3JlYXRlZGAsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3JlcG9ydGluZzpjcmVhdGVSZXBvcnRzQWdlbnRzJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDUwMjksIDUwMCwgcmVzcG9uc2UpO1xyXG4gICAgfVxyXG4gIH0sICh7cGFyYW1zOiB7IGFnZW50SUQgfX0pID0+IGB3YXp1aC1hZ2VudC1pbnZlbnRvcnktJHthZ2VudElEfS0ke3RoaXMuZ2VuZXJhdGVSZXBvcnRUaW1lc3RhbXAoKX0ucGRmYClcclxuXHJcbiAgLyoqXHJcbiAgICogRmV0Y2ggdGhlIHJlcG9ydHMgbGlzdFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcclxuICAgKiBAcmV0dXJucyB7QXJyYXk8T2JqZWN0Pn0gcmVwb3J0cyBsaXN0IG9yIEVycm9yUmVzcG9uc2VcclxuICAgKi9cclxuICBhc3luYyBnZXRSZXBvcnRzKFxyXG4gICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxyXG4gICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxyXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5XHJcbiAgKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBsb2coJ3JlcG9ydGluZzpnZXRSZXBvcnRzJywgYEZldGNoaW5nIGNyZWF0ZWQgcmVwb3J0c2AsICdpbmZvJyk7XHJcbiAgICAgIGNvbnN0IHsgaGFzaFVzZXJuYW1lIH0gPSBhd2FpdCBjb250ZXh0LndhenVoLnNlY3VyaXR5LmdldEN1cnJlbnRVc2VyKHJlcXVlc3QsIGNvbnRleHQpO1xyXG4gICAgICBjcmVhdGVEYXRhRGlyZWN0b3J5SWZOb3RFeGlzdHMoKTtcclxuICAgICAgY3JlYXRlRGlyZWN0b3J5SWZOb3RFeGlzdHMoV0FaVUhfREFUQV9ET1dOTE9BRFNfRElSRUNUT1JZX1BBVEgpO1xyXG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRIKTtcclxuICAgICAgY29uc3QgdXNlclJlcG9ydHNEaXJlY3RvcnlQYXRoID0gcGF0aC5qb2luKFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgsIGhhc2hVc2VybmFtZSk7XHJcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKHVzZXJSZXBvcnRzRGlyZWN0b3J5UGF0aCk7XHJcbiAgICAgIGxvZygncmVwb3J0aW5nOmdldFJlcG9ydHMnLCBgRGlyZWN0b3J5OiAke3VzZXJSZXBvcnRzRGlyZWN0b3J5UGF0aH1gLCAnZGVidWcnKTtcclxuXHJcbiAgICAgIGNvbnN0IHNvcnRSZXBvcnRzQnlEYXRlID0gKGEsIGIpID0+IChhLmRhdGUgPCBiLmRhdGUgPyAxIDogYS5kYXRlID4gYi5kYXRlID8gLTEgOiAwKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlcG9ydHMgPSBmcy5yZWFkZGlyU3luYyh1c2VyUmVwb3J0c0RpcmVjdG9yeVBhdGgpLm1hcCgoZmlsZSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHN0YXRzID0gZnMuc3RhdFN5bmModXNlclJlcG9ydHNEaXJlY3RvcnlQYXRoICsgJy8nICsgZmlsZSk7XHJcbiAgICAgICAgLy8gR2V0IHRoZSBmaWxlIGNyZWF0aW9uIHRpbWUgKGJpdGh0aW1lKS4gSXQgcmV0dXJucyB0aGUgZmlyc3QgdmFsdWUgdGhhdCBpcyBhIHRydXRoeSB2YWx1ZSBvZiBuZXh0IGZpbGUgc3RhdHM6IGJpcnRodGltZSwgbXRpbWUsIGN0aW1lIGFuZCBhdGltZS5cclxuICAgICAgICAvLyBUaGlzIHNvbHZlcyBzb21lIE9TcyBjYW4gaGF2ZSB0aGUgYml0aHRpbWVNcyBlcXVhbCB0byAwIGFuZCByZXR1cm5zIHRoZSBkYXRlIGxpa2UgMTk3MC0wMS0wMVxyXG4gICAgICAgIGNvbnN0IGJpcnRoVGltZUZpZWxkID0gWydiaXJ0aHRpbWUnLCAnbXRpbWUnLCAnY3RpbWUnLCAnYXRpbWUnXS5maW5kKFxyXG4gICAgICAgICAgKHRpbWUpID0+IHN0YXRzW2Ake3RpbWV9TXNgXVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIG5hbWU6IGZpbGUsXHJcbiAgICAgICAgICBzaXplOiBzdGF0cy5zaXplLFxyXG4gICAgICAgICAgZGF0ZTogc3RhdHNbYmlydGhUaW1lRmllbGRdLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pO1xyXG4gICAgICBsb2coJ3JlcG9ydGluZzpnZXRSZXBvcnRzJywgYFVzaW5nIFRpbVNvcnQgZm9yIHNvcnRpbmcgJHtyZXBvcnRzLmxlbmd0aH0gaXRlbXNgLCAnZGVidWcnKTtcclxuICAgICAgVGltU29ydC5zb3J0KHJlcG9ydHMsIHNvcnRSZXBvcnRzQnlEYXRlKTtcclxuICAgICAgbG9nKCdyZXBvcnRpbmc6Z2V0UmVwb3J0cycsIGBUb3RhbCByZXBvcnRzOiAke3JlcG9ydHMubGVuZ3RofWAsICdkZWJ1ZycpO1xyXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgIGJvZHk6IHsgcmVwb3J0cyB9LFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGxvZygncmVwb3J0aW5nOmdldFJlcG9ydHMnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTAzMSwgNTAwLCByZXNwb25zZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBGZXRjaCBzcGVjaWZpYyByZXBvcnRcclxuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXHJcbiAgICogQHJldHVybnMge09iamVjdH0gcmVwb3J0IG9yIEVycm9yUmVzcG9uc2VcclxuICAgKi9cclxuICBnZXRSZXBvcnRCeU5hbWUgPSB0aGlzLmNoZWNrUmVwb3J0c1VzZXJEaXJlY3RvcnlJc1ZhbGlkUm91dGVEZWNvcmF0b3IoYXN5bmMgKFxyXG4gICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxyXG4gICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxyXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5XHJcbiAgKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBsb2coJ3JlcG9ydGluZzpnZXRSZXBvcnRCeU5hbWUnLCBgR2V0dGluZyAke2NvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5wYXRoRmlsZW5hbWV9IHJlcG9ydGAsICdkZWJ1ZycpO1xyXG4gICAgICBjb25zdCByZXBvcnRGaWxlQnVmZmVyID0gZnMucmVhZEZpbGVTeW5jKGNvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5wYXRoRmlsZW5hbWUpO1xyXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9wZGYnIH0sXHJcbiAgICAgICAgYm9keTogcmVwb3J0RmlsZUJ1ZmZlcixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3JlcG9ydGluZzpnZXRSZXBvcnRCeU5hbWUnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTAzMCwgNTAwLCByZXNwb25zZSk7XHJcbiAgICB9XHJcbiAgfSwgKHJlcXVlc3QpID0+IHJlcXVlc3QucGFyYW1zLm5hbWUpXHJcblxyXG4gIC8qKlxyXG4gICAqIERlbGV0ZSBzcGVjaWZpYyByZXBvcnRcclxuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXHJcbiAgICogQHJldHVybnMge09iamVjdH0gc3RhdHVzIG9iaiBvciBFcnJvclJlc3BvbnNlXHJcbiAgICovXHJcbiAgZGVsZXRlUmVwb3J0QnlOYW1lID0gdGhpcy5jaGVja1JlcG9ydHNVc2VyRGlyZWN0b3J5SXNWYWxpZFJvdXRlRGVjb3JhdG9yKGFzeW5jIChcclxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcclxuICAgIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcclxuICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeVxyXG4gICkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgbG9nKCdyZXBvcnRpbmc6ZGVsZXRlUmVwb3J0QnlOYW1lJywgYERlbGV0aW5nICR7Y29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLnBhdGhGaWxlbmFtZX0gcmVwb3J0YCwgJ2RlYnVnJyk7XHJcbiAgICAgIGZzLnVubGlua1N5bmMoY29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLnBhdGhGaWxlbmFtZSk7XHJcbiAgICAgIGxvZygncmVwb3J0aW5nOmRlbGV0ZVJlcG9ydEJ5TmFtZScsIGAke2NvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5wYXRoRmlsZW5hbWV9IHJlcG9ydCB3YXMgZGVsZXRlZGAsICdpbmZvJyk7XHJcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgYm9keTogeyBlcnJvcjogMCB9LFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGxvZygncmVwb3J0aW5nOmRlbGV0ZVJlcG9ydEJ5TmFtZScsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCA1MDMyLCA1MDAsIHJlc3BvbnNlKTtcclxuICAgIH1cclxuICB9LChyZXF1ZXN0KSA9PiByZXF1ZXN0LnBhcmFtcy5uYW1lKVxyXG5cclxuICBjaGVja1JlcG9ydHNVc2VyRGlyZWN0b3J5SXNWYWxpZFJvdXRlRGVjb3JhdG9yKHJvdXRlSGFuZGxlciwgcmVwb3J0RmlsZU5hbWVBY2Nlc3Nvcil7XHJcbiAgICByZXR1cm4gKGFzeW5jIChcclxuICAgICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxyXG4gICAgICByZXF1ZXN0OiBLaWJhbmFSZXF1ZXN0LFxyXG4gICAgICByZXNwb25zZTogS2liYW5hUmVzcG9uc2VGYWN0b3J5XHJcbiAgICApID0+IHtcclxuICAgICAgdHJ5e1xyXG4gICAgICAgIGNvbnN0IHsgdXNlcm5hbWUsIGhhc2hVc2VybmFtZSB9ID0gYXdhaXQgY29udGV4dC53YXp1aC5zZWN1cml0eS5nZXRDdXJyZW50VXNlcihyZXF1ZXN0LCBjb250ZXh0KTtcclxuICAgICAgICBjb25zdCB1c2VyUmVwb3J0c0RpcmVjdG9yeVBhdGggPSBwYXRoLmpvaW4oV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCwgaGFzaFVzZXJuYW1lKTtcclxuICAgICAgICBjb25zdCBmaWxlbmFtZSA9IHJlcG9ydEZpbGVOYW1lQWNjZXNzb3IocmVxdWVzdCk7XHJcbiAgICAgICAgY29uc3QgcGF0aEZpbGVuYW1lID0gcGF0aC5qb2luKHVzZXJSZXBvcnRzRGlyZWN0b3J5UGF0aCwgZmlsZW5hbWUpO1xyXG4gICAgICAgIGxvZygncmVwb3J0aW5nOmNoZWNrUmVwb3J0c1VzZXJEaXJlY3RvcnlJc1ZhbGlkUm91dGVEZWNvcmF0b3InLCBgQ2hlY2tpbmcgdGhlIHVzZXIgJHt1c2VybmFtZX0oJHtoYXNoVXNlcm5hbWV9KSBjYW4gZG8gYWN0aW9ucyBpbiB0aGUgcmVwb3J0cyBmaWxlOiAke3BhdGhGaWxlbmFtZX1gLCAnZGVidWcnKTtcclxuICAgICAgICBpZighcGF0aEZpbGVuYW1lLnN0YXJ0c1dpdGgodXNlclJlcG9ydHNEaXJlY3RvcnlQYXRoKSB8fCBwYXRoRmlsZW5hbWUuaW5jbHVkZXMoJy4uLycpKXtcclxuICAgICAgICAgIGxvZygnc2VjdXJpdHk6cmVwb3J0aW5nOmNoZWNrUmVwb3J0c1VzZXJEaXJlY3RvcnlJc1ZhbGlkUm91dGVEZWNvcmF0b3InLCBgVXNlciAke3VzZXJuYW1lfSgke2hhc2hVc2VybmFtZX0pIHRyaWVkIHRvIGFjY2VzcyB0byBhIG5vbiB1c2VyIHJlcG9ydCBmaWxlOiAke3BhdGhGaWxlbmFtZX1gLCAnd2FybicpO1xyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmJhZFJlcXVlc3Qoe1xyXG4gICAgICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICAgICAgbWVzc2FnZTogJzUwNDAgLSBZb3Ugc2hhbGwgbm90IHBhc3MhJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGxvZygncmVwb3J0aW5nOmNoZWNrUmVwb3J0c1VzZXJEaXJlY3RvcnlJc1ZhbGlkUm91dGVEZWNvcmF0b3InLCAnQ2hlY2tpbmcgdGhlIHVzZXIgY2FuIGRvIGFjdGlvbnMgaW4gdGhlIHJlcG9ydHMgZmlsZScsICdkZWJ1ZycpO1xyXG4gICAgICAgIHJldHVybiBhd2FpdCByb3V0ZUhhbmRsZXIuYmluZCh0aGlzKSh7Li4uY29udGV4dCwgd2F6dWhFbmRwb2ludFBhcmFtczogeyBoYXNoVXNlcm5hbWUsIGZpbGVuYW1lLCBwYXRoRmlsZW5hbWUgfX0sIHJlcXVlc3QsIHJlc3BvbnNlKTtcclxuICAgICAgfWNhdGNoKGVycm9yKXtcclxuICAgICAgICBsb2coJ3JlcG9ydGluZzpjaGVja1JlcG9ydHNVc2VyRGlyZWN0b3J5SXNWYWxpZFJvdXRlRGVjb3JhdG9yJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTA0MCwgNTAwLCByZXNwb25zZSk7XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGdlbmVyYXRlUmVwb3J0VGltZXN0YW1wKCl7XHJcbiAgICByZXR1cm4gYCR7KERhdGUubm93KCkgLyAxMDAwKSB8IDB9YDtcclxuICB9XHJcbn1cclxuIl19