"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.jobs = void 0;
const jobs = {
  'manager-stats-remoted': {
    status: true,
    method: "GET",
    request: '/manager/stats/remoted?pretty',
    params: {},
    interval: '0 */5 * * * *',
    index: {
      name: 'statistics',
      creation: 'w',
      mapping: '{"remoted": ${data.affected_items[0]}, "apiName": ${apiName}, "cluster": "false"}'
    }
  },
  'manager-stats-analysisd': {
    status: true,
    method: "GET",
    request: '/manager/stats/analysisd?pretty',
    params: {},
    interval: '0 */5 * * * *',
    index: {
      name: 'statistics',
      creation: 'w',
      mapping: '{"analysisd": ${data.affected_items[0]}, "apiName": ${apiName}, "cluster": "false"}'
    }
  },
  'cluster-stats-remoted': {
    status: true,
    method: "GET",
    request: {
      request: '/cluster/{nodeName}/stats/remoted?pretty',
      params: {
        nodeName: {
          request: '/cluster/nodes?select=name'
        }
      }
    },
    params: {},
    interval: '0 */5 * * * *',
    index: {
      name: 'statistics',
      creation: 'w',
      mapping: '{"remoted": ${data.affected_items[0]}, "apiName": ${apiName}, "nodeName": ${nodeName}, "cluster": "true"}'
    }
  },
  'cluster-stats-analysisd': {
    status: true,
    method: "GET",
    request: {
      request: '/cluster/{nodeName}/stats/analysisd?pretty',
      params: {
        nodeName: {
          request: '/cluster/nodes?select=name'
        }
      }
    },
    params: {},
    interval: '0 */5 * * * *',
    index: {
      name: 'statistics',
      creation: 'w',
      mapping: '{"analysisd": ${data.affected_items[0]}, "apiName": ${apiName}, "nodeName": ${nodeName}, "cluster": "true"}'
    }
  }
};
exports.jobs = jobs;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByZWRlZmluZWQtam9icy50cyJdLCJuYW1lcyI6WyJqb2JzIiwic3RhdHVzIiwibWV0aG9kIiwicmVxdWVzdCIsInBhcmFtcyIsImludGVydmFsIiwiaW5kZXgiLCJuYW1lIiwiY3JlYXRpb24iLCJtYXBwaW5nIiwibm9kZU5hbWUiXSwibWFwcGluZ3MiOiI7Ozs7OztBQXNCTyxNQUFNQSxJQUEwQixHQUFHO0FBQ3hDLDJCQUF5QjtBQUN2QkMsSUFBQUEsTUFBTSxFQUFFLElBRGU7QUFFdkJDLElBQUFBLE1BQU0sRUFBRSxLQUZlO0FBR3ZCQyxJQUFBQSxPQUFPLEVBQUUsK0JBSGM7QUFJdkJDLElBQUFBLE1BQU0sRUFBRSxFQUplO0FBS3ZCQyxJQUFBQSxRQUFRLEVBQUUsZUFMYTtBQU12QkMsSUFBQUEsS0FBSyxFQUFFO0FBQ0xDLE1BQUFBLElBQUksRUFBRSxZQUREO0FBRUxDLE1BQUFBLFFBQVEsRUFBRSxHQUZMO0FBR0xDLE1BQUFBLE9BQU8sRUFBRTtBQUhKO0FBTmdCLEdBRGU7QUFheEMsNkJBQTJCO0FBQ3pCUixJQUFBQSxNQUFNLEVBQUUsSUFEaUI7QUFFekJDLElBQUFBLE1BQU0sRUFBRSxLQUZpQjtBQUd6QkMsSUFBQUEsT0FBTyxFQUFFLGlDQUhnQjtBQUl6QkMsSUFBQUEsTUFBTSxFQUFFLEVBSmlCO0FBS3pCQyxJQUFBQSxRQUFRLEVBQUUsZUFMZTtBQU16QkMsSUFBQUEsS0FBSyxFQUFFO0FBQ0xDLE1BQUFBLElBQUksRUFBRSxZQUREO0FBRUxDLE1BQUFBLFFBQVEsRUFBRSxHQUZMO0FBR0xDLE1BQUFBLE9BQU8sRUFBRTtBQUhKO0FBTmtCLEdBYmE7QUF5QnhDLDJCQUF5QjtBQUN2QlIsSUFBQUEsTUFBTSxFQUFFLElBRGU7QUFFdkJDLElBQUFBLE1BQU0sRUFBRSxLQUZlO0FBR3ZCQyxJQUFBQSxPQUFPLEVBQUU7QUFDUEEsTUFBQUEsT0FBTyxFQUFFLDBDQURGO0FBRVBDLE1BQUFBLE1BQU0sRUFBRTtBQUNOTSxRQUFBQSxRQUFRLEVBQUU7QUFDUlAsVUFBQUEsT0FBTyxFQUFFO0FBREQ7QUFESjtBQUZELEtBSGM7QUFXdkJDLElBQUFBLE1BQU0sRUFBRSxFQVhlO0FBWXZCQyxJQUFBQSxRQUFRLEVBQUUsZUFaYTtBQWF2QkMsSUFBQUEsS0FBSyxFQUFFO0FBQ0xDLE1BQUFBLElBQUksRUFBQyxZQURBO0FBRUxDLE1BQUFBLFFBQVEsRUFBRSxHQUZMO0FBR0xDLE1BQUFBLE9BQU8sRUFBRTtBQUhKO0FBYmdCLEdBekJlO0FBNEN4Qyw2QkFBMkI7QUFDekJSLElBQUFBLE1BQU0sRUFBRSxJQURpQjtBQUV6QkMsSUFBQUEsTUFBTSxFQUFFLEtBRmlCO0FBR3pCQyxJQUFBQSxPQUFPLEVBQUU7QUFDUEEsTUFBQUEsT0FBTyxFQUFFLDRDQURGO0FBRVBDLE1BQUFBLE1BQU0sRUFBRTtBQUNOTSxRQUFBQSxRQUFRLEVBQUU7QUFDUlAsVUFBQUEsT0FBTyxFQUFFO0FBREQ7QUFESjtBQUZELEtBSGdCO0FBV3pCQyxJQUFBQSxNQUFNLEVBQUUsRUFYaUI7QUFZekJDLElBQUFBLFFBQVEsRUFBRSxlQVplO0FBYXpCQyxJQUFBQSxLQUFLLEVBQUU7QUFDTEMsTUFBQUEsSUFBSSxFQUFFLFlBREQ7QUFFTEMsTUFBQUEsUUFBUSxFQUFFLEdBRkw7QUFHTEMsTUFBQUEsT0FBTyxFQUFFO0FBSEo7QUFia0I7QUE1Q2EsQ0FBbkMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJSW5kZXhDb25maWd1cmF0aW9uIH0gZnJvbSAnLi9pbmRleCc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElKb2Ige1xyXG4gIHN0YXR1czogYm9vbGVhblxyXG4gIG1ldGhvZDogJ0dFVCcgfCAnUE9TVCcgfCAnUFVUJyB8ICdERUxFVEUnXHJcbiAgcmVxdWVzdDogc3RyaW5nIHwgSVJlcXVlc3RcclxuICBwYXJhbXM6IHt9XHJcbiAgaW50ZXJ2YWw6IHN0cmluZ1xyXG4gIGluZGV4OiBJSW5kZXhDb25maWd1cmF0aW9uXHJcbiAgYXBpcz86IHN0cmluZ1tdXHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVJlcXVlc3Qge1xyXG4gIHJlcXVlc3Q6IHN0cmluZ1xyXG4gIHBhcmFtczoge1xyXG4gICAgW2tleTpzdHJpbmddOiB7XHJcbiAgICAgIHJlcXVlc3Q/OiBzdHJpbmdcclxuICAgICAgbGlzdD86IHN0cmluZ1tdXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY29uc3Qgam9iczoge1trZXk6c3RyaW5nXTogSUpvYn0gPSB7XHJcbiAgJ21hbmFnZXItc3RhdHMtcmVtb3RlZCc6IHtcclxuICAgIHN0YXR1czogdHJ1ZSxcclxuICAgIG1ldGhvZDogXCJHRVRcIixcclxuICAgIHJlcXVlc3Q6ICcvbWFuYWdlci9zdGF0cy9yZW1vdGVkP3ByZXR0eScsXHJcbiAgICBwYXJhbXM6IHt9LFxyXG4gICAgaW50ZXJ2YWw6ICcwICovNSAqICogKiAqJyxcclxuICAgIGluZGV4OiB7XHJcbiAgICAgIG5hbWU6ICdzdGF0aXN0aWNzJyxcclxuICAgICAgY3JlYXRpb246ICd3JyxcclxuICAgICAgbWFwcGluZzogJ3tcInJlbW90ZWRcIjogJHtkYXRhLmFmZmVjdGVkX2l0ZW1zWzBdfSwgXCJhcGlOYW1lXCI6ICR7YXBpTmFtZX0sIFwiY2x1c3RlclwiOiBcImZhbHNlXCJ9JyxcclxuICAgIH1cclxuICB9LFxyXG4gICdtYW5hZ2VyLXN0YXRzLWFuYWx5c2lzZCc6IHtcclxuICAgIHN0YXR1czogdHJ1ZSxcclxuICAgIG1ldGhvZDogXCJHRVRcIixcclxuICAgIHJlcXVlc3Q6ICcvbWFuYWdlci9zdGF0cy9hbmFseXNpc2Q/cHJldHR5JyxcclxuICAgIHBhcmFtczoge30sXHJcbiAgICBpbnRlcnZhbDogJzAgKi81ICogKiAqIConLFxyXG4gICAgaW5kZXg6IHtcclxuICAgICAgbmFtZTogJ3N0YXRpc3RpY3MnLFxyXG4gICAgICBjcmVhdGlvbjogJ3cnLFxyXG4gICAgICBtYXBwaW5nOiAne1wiYW5hbHlzaXNkXCI6ICR7ZGF0YS5hZmZlY3RlZF9pdGVtc1swXX0sIFwiYXBpTmFtZVwiOiAke2FwaU5hbWV9LCBcImNsdXN0ZXJcIjogXCJmYWxzZVwifScsXHJcbiAgICB9XHJcbiAgfSxcclxuICAnY2x1c3Rlci1zdGF0cy1yZW1vdGVkJzoge1xyXG4gICAgc3RhdHVzOiB0cnVlLFxyXG4gICAgbWV0aG9kOiBcIkdFVFwiLFxyXG4gICAgcmVxdWVzdDoge1xyXG4gICAgICByZXF1ZXN0OiAnL2NsdXN0ZXIve25vZGVOYW1lfS9zdGF0cy9yZW1vdGVkP3ByZXR0eScsXHJcbiAgICAgIHBhcmFtczoge1xyXG4gICAgICAgIG5vZGVOYW1lOiB7XHJcbiAgICAgICAgICByZXF1ZXN0OiAnL2NsdXN0ZXIvbm9kZXM/c2VsZWN0PW5hbWUnXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAgcGFyYW1zOiB7fSxcclxuICAgIGludGVydmFsOiAnMCAqLzUgKiAqICogKicsXHJcbiAgICBpbmRleDoge1xyXG4gICAgICBuYW1lOidzdGF0aXN0aWNzJyxcclxuICAgICAgY3JlYXRpb246ICd3JyxcclxuICAgICAgbWFwcGluZzogJ3tcInJlbW90ZWRcIjogJHtkYXRhLmFmZmVjdGVkX2l0ZW1zWzBdfSwgXCJhcGlOYW1lXCI6ICR7YXBpTmFtZX0sIFwibm9kZU5hbWVcIjogJHtub2RlTmFtZX0sIFwiY2x1c3RlclwiOiBcInRydWVcIn0nLFxyXG4gICAgfVxyXG4gIH0sXHJcbiAgJ2NsdXN0ZXItc3RhdHMtYW5hbHlzaXNkJzoge1xyXG4gICAgc3RhdHVzOiB0cnVlLFxyXG4gICAgbWV0aG9kOiBcIkdFVFwiLFxyXG4gICAgcmVxdWVzdDoge1xyXG4gICAgICByZXF1ZXN0OiAnL2NsdXN0ZXIve25vZGVOYW1lfS9zdGF0cy9hbmFseXNpc2Q/cHJldHR5JyxcclxuICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgbm9kZU5hbWU6IHtcclxuICAgICAgICAgIHJlcXVlc3Q6ICcvY2x1c3Rlci9ub2Rlcz9zZWxlY3Q9bmFtZSdcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgICBwYXJhbXM6IHt9LFxyXG4gICAgaW50ZXJ2YWw6ICcwICovNSAqICogKiAqJyxcclxuICAgIGluZGV4OiB7XHJcbiAgICAgIG5hbWU6ICdzdGF0aXN0aWNzJyxcclxuICAgICAgY3JlYXRpb246ICd3JyxcclxuICAgICAgbWFwcGluZzogJ3tcImFuYWx5c2lzZFwiOiAke2RhdGEuYWZmZWN0ZWRfaXRlbXNbMF19LCBcImFwaU5hbWVcIjogJHthcGlOYW1lfSwgXCJub2RlTmFtZVwiOiAke25vZGVOYW1lfSwgXCJjbHVzdGVyXCI6IFwidHJ1ZVwifScsXHJcbiAgICB9XHJcbiAgfSxcclxufSJdfQ==