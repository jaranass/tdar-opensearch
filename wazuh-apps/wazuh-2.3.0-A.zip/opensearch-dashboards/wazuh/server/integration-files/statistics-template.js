"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.statisticsTemplate = void 0;

/*
 * Wazuh app - Module for statistics template
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
const statisticsTemplate = {
  order: 0,
  settings: {
    'index.refresh_interval': '5s'
  },
  "mappings": {
    "dynamic_templates": [{
      "string_as_keyword": {
        "match_mapping_type": "string",
        "mapping": {
          "type": "keyword"
        }
      }
    }],
    "properties": {
      "analysisd": {
        "properties": {
          "alerts_queue_size": {
            "type": "long"
          },
          "alerts_queue_usage": {
            "type": "long"
          },
          "alerts_written": {
            "type": "long"
          },
          "archives_queue_size": {
            "type": "long"
          },
          "archives_queue_usage": {
            "type": "long"
          },
          "dbsync_mdps": {
            "type": "long"
          },
          "dbsync_messages_dispatched": {
            "type": "long"
          },
          "dbsync_queue_size": {
            "type": "long"
          },
          "dbsync_queue_usage": {
            "type": "long"
          },
          "event_queue_size": {
            "type": "long"
          },
          "event_queue_usage": {
            "type": "long"
          },
          "events_dropped": {
            "type": "long"
          },
          "events_edps": {
            "type": "long"
          },
          "events_processed": {
            "type": "long"
          },
          "events_received": {
            "type": "long"
          },
          "firewall_queue_size": {
            "type": "long"
          },
          "firewall_queue_usage": {
            "type": "long"
          },
          "firewall_written": {
            "type": "long"
          },
          "fts_written": {
            "type": "long"
          },
          "hostinfo_edps": {
            "type": "long"
          },
          "hostinfo_events_decoded": {
            "type": "long"
          },
          "hostinfo_queue_size": {
            "type": "long"
          },
          "hostinfo_queue_usage": {
            "type": "long"
          },
          "other_events_decoded": {
            "type": "long"
          },
          "other_events_edps": {
            "type": "long"
          },
          "rootcheck_edps": {
            "type": "long"
          },
          "rootcheck_events_decoded": {
            "type": "long"
          },
          "rootcheck_queue_size": {
            "type": "long"
          },
          "rootcheck_queue_usage": {
            "type": "long"
          },
          "rule_matching_queue_size": {
            "type": "long"
          },
          "rule_matching_queue_usage": {
            "type": "long"
          },
          "sca_edps": {
            "type": "long"
          },
          "sca_events_decoded": {
            "type": "long"
          },
          "sca_queue_size": {
            "type": "long"
          },
          "sca_queue_usage": {
            "type": "long"
          },
          "statistical_queue_size": {
            "type": "long"
          },
          "statistical_queue_usage": {
            "type": "long"
          },
          "syscheck_edps": {
            "type": "long"
          },
          "syscheck_events_decoded": {
            "type": "long"
          },
          "syscheck_queue_size": {
            "type": "long"
          },
          "syscheck_queue_usage": {
            "type": "long"
          },
          "syscollector_edps": {
            "type": "long"
          },
          "syscollector_events_decoded": {
            "type": "long"
          },
          "syscollector_queue_size": {
            "type": "long"
          },
          "syscollector_queue_usage": {
            "type": "long"
          },
          "total_events_decoded": {
            "type": "long"
          },
          "upgrade_queue_size": {
            "type": "long"
          },
          "upgrade_queue_usage": {
            "type": "long"
          },
          "winevt_edps": {
            "type": "long"
          },
          "winevt_events_decoded": {
            "type": "long"
          },
          "winevt_queue_size": {
            "type": "long"
          },
          "winevt_queue_usage": {
            "type": "long"
          }
        }
      },
      "apiName": {
        "type": "text",
        "fields": {
          "keyword": {
            "type": "keyword",
            "ignore_above": 256
          }
        }
      },
      "cluster": {
        "type": "text",
        "fields": {
          "keyword": {
            "type": "keyword",
            "ignore_above": 256
          }
        }
      },
      "nodeName": {
        "type": "text",
        "fields": {
          "keyword": {
            "type": "keyword",
            "ignore_above": 256
          }
        }
      },
      "name": {
        "type": "keyword"
      },
      "remoted": {
        "properties": {
          "ctrl_msg_count": {
            "type": "long"
          },
          "dequeued_after_close": {
            "type": "long"
          },
          "discarded_count": {
            "type": "long"
          },
          "evt_count": {
            "type": "long"
          },
          "msg_sent": {
            "type": "long"
          },
          "queue_size": {
            "type": "keyword"
          },
          "recv_bytes": {
            "type": "long"
          },
          "tcp_sessions": {
            "type": "long"
          },
          "total_queue_size": {
            "type": "long"
          }
        }
      },
      "status": {
        "type": "keyword"
      },
      "timestamp": {
        "type": "date",
        "format": "dateOptionalTime"
      }
    }
  }
};
exports.statisticsTemplate = statisticsTemplate;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0YXRpc3RpY3MtdGVtcGxhdGUudHMiXSwibmFtZXMiOlsic3RhdGlzdGljc1RlbXBsYXRlIiwib3JkZXIiLCJzZXR0aW5ncyJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNQSxrQkFBa0IsR0FBRztBQUNoQ0MsRUFBQUEsS0FBSyxFQUFFLENBRHlCO0FBRWhDQyxFQUFBQSxRQUFRLEVBQUU7QUFDUiw4QkFBMEI7QUFEbEIsR0FGc0I7QUFLaEMsY0FBYTtBQUNYLHlCQUFzQixDQUNwQjtBQUNFLDJCQUFzQjtBQUNwQiw4QkFBdUIsUUFESDtBQUVwQixtQkFBWTtBQUNWLGtCQUFTO0FBREM7QUFGUTtBQUR4QixLQURvQixDQURYO0FBV1gsa0JBQWU7QUFDYixtQkFBYztBQUNaLHNCQUFlO0FBQ2IsK0JBQXNCO0FBQ3BCLG9CQUFTO0FBRFcsV0FEVDtBQUliLGdDQUF1QjtBQUNyQixvQkFBUztBQURZLFdBSlY7QUFPYiw0QkFBbUI7QUFDakIsb0JBQVM7QUFEUSxXQVBOO0FBVWIsaUNBQXdCO0FBQ3RCLG9CQUFTO0FBRGEsV0FWWDtBQWFiLGtDQUF5QjtBQUN2QixvQkFBUztBQURjLFdBYlo7QUFnQmIseUJBQWdCO0FBQ2Qsb0JBQVM7QUFESyxXQWhCSDtBQW1CYix3Q0FBK0I7QUFDN0Isb0JBQVM7QUFEb0IsV0FuQmxCO0FBc0JiLCtCQUFzQjtBQUNwQixvQkFBUztBQURXLFdBdEJUO0FBeUJiLGdDQUF1QjtBQUNyQixvQkFBUztBQURZLFdBekJWO0FBNEJiLDhCQUFxQjtBQUNuQixvQkFBUztBQURVLFdBNUJSO0FBK0JiLCtCQUFzQjtBQUNwQixvQkFBUztBQURXLFdBL0JUO0FBa0NiLDRCQUFtQjtBQUNqQixvQkFBUztBQURRLFdBbENOO0FBcUNiLHlCQUFnQjtBQUNkLG9CQUFTO0FBREssV0FyQ0g7QUF3Q2IsOEJBQXFCO0FBQ25CLG9CQUFTO0FBRFUsV0F4Q1I7QUEyQ2IsNkJBQW9CO0FBQ2xCLG9CQUFTO0FBRFMsV0EzQ1A7QUE4Q2IsaUNBQXdCO0FBQ3RCLG9CQUFTO0FBRGEsV0E5Q1g7QUFpRGIsa0NBQXlCO0FBQ3ZCLG9CQUFTO0FBRGMsV0FqRFo7QUFvRGIsOEJBQXFCO0FBQ25CLG9CQUFTO0FBRFUsV0FwRFI7QUF1RGIseUJBQWdCO0FBQ2Qsb0JBQVM7QUFESyxXQXZESDtBQTBEYiwyQkFBa0I7QUFDaEIsb0JBQVM7QUFETyxXQTFETDtBQTZEYixxQ0FBNEI7QUFDMUIsb0JBQVM7QUFEaUIsV0E3RGY7QUFnRWIsaUNBQXdCO0FBQ3RCLG9CQUFTO0FBRGEsV0FoRVg7QUFtRWIsa0NBQXlCO0FBQ3ZCLG9CQUFTO0FBRGMsV0FuRVo7QUFzRWIsa0NBQXlCO0FBQ3ZCLG9CQUFTO0FBRGMsV0F0RVo7QUF5RWIsK0JBQXNCO0FBQ3BCLG9CQUFTO0FBRFcsV0F6RVQ7QUE0RWIsNEJBQW1CO0FBQ2pCLG9CQUFTO0FBRFEsV0E1RU47QUErRWIsc0NBQTZCO0FBQzNCLG9CQUFTO0FBRGtCLFdBL0VoQjtBQWtGYixrQ0FBeUI7QUFDdkIsb0JBQVM7QUFEYyxXQWxGWjtBQXFGYixtQ0FBMEI7QUFDeEIsb0JBQVM7QUFEZSxXQXJGYjtBQXdGYixzQ0FBNkI7QUFDM0Isb0JBQVM7QUFEa0IsV0F4RmhCO0FBMkZiLHVDQUE4QjtBQUM1QixvQkFBUztBQURtQixXQTNGakI7QUE4RmIsc0JBQWE7QUFDWCxvQkFBUztBQURFLFdBOUZBO0FBaUdiLGdDQUF1QjtBQUNyQixvQkFBUztBQURZLFdBakdWO0FBb0diLDRCQUFtQjtBQUNqQixvQkFBUztBQURRLFdBcEdOO0FBdUdiLDZCQUFvQjtBQUNsQixvQkFBUztBQURTLFdBdkdQO0FBMEdiLG9DQUEyQjtBQUN6QixvQkFBUztBQURnQixXQTFHZDtBQTZHYixxQ0FBNEI7QUFDMUIsb0JBQVM7QUFEaUIsV0E3R2Y7QUFnSGIsMkJBQWtCO0FBQ2hCLG9CQUFTO0FBRE8sV0FoSEw7QUFtSGIscUNBQTRCO0FBQzFCLG9CQUFTO0FBRGlCLFdBbkhmO0FBc0hiLGlDQUF3QjtBQUN0QixvQkFBUztBQURhLFdBdEhYO0FBeUhiLGtDQUF5QjtBQUN2QixvQkFBUztBQURjLFdBekhaO0FBNEhiLCtCQUFzQjtBQUNwQixvQkFBUztBQURXLFdBNUhUO0FBK0hiLHlDQUFnQztBQUM5QixvQkFBUztBQURxQixXQS9IbkI7QUFrSWIscUNBQTRCO0FBQzFCLG9CQUFTO0FBRGlCLFdBbElmO0FBcUliLHNDQUE2QjtBQUMzQixvQkFBUztBQURrQixXQXJJaEI7QUF3SWIsa0NBQXlCO0FBQ3ZCLG9CQUFTO0FBRGMsV0F4SVo7QUEySWIsZ0NBQXVCO0FBQ3JCLG9CQUFTO0FBRFksV0EzSVY7QUE4SWIsaUNBQXdCO0FBQ3RCLG9CQUFTO0FBRGEsV0E5SVg7QUFpSmIseUJBQWdCO0FBQ2Qsb0JBQVM7QUFESyxXQWpKSDtBQW9KYixtQ0FBMEI7QUFDeEIsb0JBQVM7QUFEZSxXQXBKYjtBQXVKYiwrQkFBc0I7QUFDcEIsb0JBQVM7QUFEVyxXQXZKVDtBQTBKYixnQ0FBdUI7QUFDckIsb0JBQVM7QUFEWTtBQTFKVjtBQURILE9BREQ7QUFpS2IsaUJBQVk7QUFDVixnQkFBUyxNQURDO0FBRVYsa0JBQVc7QUFDVCxxQkFBWTtBQUNWLG9CQUFTLFNBREM7QUFFViw0QkFBaUI7QUFGUDtBQURIO0FBRkQsT0FqS0M7QUEwS2IsaUJBQVk7QUFDVixnQkFBUyxNQURDO0FBRVYsa0JBQVc7QUFDVCxxQkFBWTtBQUNWLG9CQUFTLFNBREM7QUFFViw0QkFBaUI7QUFGUDtBQURIO0FBRkQsT0ExS0M7QUFtTGIsa0JBQWE7QUFDWCxnQkFBUyxNQURFO0FBRVgsa0JBQVc7QUFDVCxxQkFBWTtBQUNWLG9CQUFTLFNBREM7QUFFViw0QkFBaUI7QUFGUDtBQURIO0FBRkEsT0FuTEE7QUE0TGIsY0FBUztBQUNQLGdCQUFTO0FBREYsT0E1TEk7QUErTGIsaUJBQVk7QUFDVixzQkFBZTtBQUNiLDRCQUFtQjtBQUNqQixvQkFBUztBQURRLFdBRE47QUFJYixrQ0FBeUI7QUFDdkIsb0JBQVM7QUFEYyxXQUpaO0FBT2IsNkJBQW9CO0FBQ2xCLG9CQUFTO0FBRFMsV0FQUDtBQVViLHVCQUFjO0FBQ1osb0JBQVM7QUFERyxXQVZEO0FBYWIsc0JBQWE7QUFDWCxvQkFBUztBQURFLFdBYkE7QUFnQmIsd0JBQWU7QUFDYixvQkFBUztBQURJLFdBaEJGO0FBbUJiLHdCQUFlO0FBQ2Isb0JBQVM7QUFESSxXQW5CRjtBQXNCYiwwQkFBaUI7QUFDZixvQkFBUztBQURNLFdBdEJKO0FBeUJiLDhCQUFxQjtBQUNuQixvQkFBUztBQURVO0FBekJSO0FBREwsT0EvTEM7QUE4TmIsZ0JBQVc7QUFDVCxnQkFBUztBQURBLE9BOU5FO0FBaU9iLG1CQUFjO0FBQ1osZ0JBQVMsTUFERztBQUVaLGtCQUFXO0FBRkM7QUFqT0Q7QUFYSjtBQUxtQixDQUEzQiIsInNvdXJjZXNDb250ZW50IjpbIi8qXHJcbiAqIFdhenVoIGFwcCAtIE1vZHVsZSBmb3Igc3RhdGlzdGljcyB0ZW1wbGF0ZVxyXG4gKiBDb3B5cmlnaHQgKEMpIDIwMTUtMjAyMiBXYXp1aCwgSW5jLlxyXG4gKlxyXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxyXG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxyXG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxyXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxyXG4gKlxyXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxyXG4gKi9cclxuZXhwb3J0IGNvbnN0IHN0YXRpc3RpY3NUZW1wbGF0ZSA9IHtcclxuICBvcmRlcjogMCxcclxuICBzZXR0aW5nczoge1xyXG4gICAgJ2luZGV4LnJlZnJlc2hfaW50ZXJ2YWwnOiAnNXMnXHJcbiAgfSxcclxuICBcIm1hcHBpbmdzXCIgOiB7XHJcbiAgICBcImR5bmFtaWNfdGVtcGxhdGVzXCIgOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBcInN0cmluZ19hc19rZXl3b3JkXCIgOiB7XHJcbiAgICAgICAgICBcIm1hdGNoX21hcHBpbmdfdHlwZVwiIDogXCJzdHJpbmdcIixcclxuICAgICAgICAgIFwibWFwcGluZ1wiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwia2V5d29yZFwiXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICBdLFxyXG4gICAgXCJwcm9wZXJ0aWVzXCIgOiB7XHJcbiAgICAgIFwiYW5hbHlzaXNkXCIgOiB7XHJcbiAgICAgICAgXCJwcm9wZXJ0aWVzXCIgOiB7XHJcbiAgICAgICAgICBcImFsZXJ0c19xdWV1ZV9zaXplXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImFsZXJ0c19xdWV1ZV91c2FnZVwiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJhbGVydHNfd3JpdHRlblwiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJhcmNoaXZlc19xdWV1ZV9zaXplXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImFyY2hpdmVzX3F1ZXVlX3VzYWdlXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImRic3luY19tZHBzXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImRic3luY19tZXNzYWdlc19kaXNwYXRjaGVkXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImRic3luY19xdWV1ZV9zaXplXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImRic3luY19xdWV1ZV91c2FnZVwiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJldmVudF9xdWV1ZV9zaXplXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImV2ZW50X3F1ZXVlX3VzYWdlXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImV2ZW50c19kcm9wcGVkXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImV2ZW50c19lZHBzXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImV2ZW50c19wcm9jZXNzZWRcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwiZXZlbnRzX3JlY2VpdmVkXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImZpcmV3YWxsX3F1ZXVlX3NpemVcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwiZmlyZXdhbGxfcXVldWVfdXNhZ2VcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwiZmlyZXdhbGxfd3JpdHRlblwiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJmdHNfd3JpdHRlblwiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJob3N0aW5mb19lZHBzXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImhvc3RpbmZvX2V2ZW50c19kZWNvZGVkXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImhvc3RpbmZvX3F1ZXVlX3NpemVcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwiaG9zdGluZm9fcXVldWVfdXNhZ2VcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwib3RoZXJfZXZlbnRzX2RlY29kZWRcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwib3RoZXJfZXZlbnRzX2VkcHNcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwicm9vdGNoZWNrX2VkcHNcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwicm9vdGNoZWNrX2V2ZW50c19kZWNvZGVkXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcInJvb3RjaGVja19xdWV1ZV9zaXplXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcInJvb3RjaGVja19xdWV1ZV91c2FnZVwiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJydWxlX21hdGNoaW5nX3F1ZXVlX3NpemVcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwicnVsZV9tYXRjaGluZ19xdWV1ZV91c2FnZVwiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJzY2FfZWRwc1wiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJzY2FfZXZlbnRzX2RlY29kZWRcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwic2NhX3F1ZXVlX3NpemVcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwic2NhX3F1ZXVlX3VzYWdlXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcInN0YXRpc3RpY2FsX3F1ZXVlX3NpemVcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwic3RhdGlzdGljYWxfcXVldWVfdXNhZ2VcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwic3lzY2hlY2tfZWRwc1wiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJzeXNjaGVja19ldmVudHNfZGVjb2RlZFwiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJzeXNjaGVja19xdWV1ZV9zaXplXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcInN5c2NoZWNrX3F1ZXVlX3VzYWdlXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcInN5c2NvbGxlY3Rvcl9lZHBzXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcInN5c2NvbGxlY3Rvcl9ldmVudHNfZGVjb2RlZFwiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJzeXNjb2xsZWN0b3JfcXVldWVfc2l6ZVwiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJzeXNjb2xsZWN0b3JfcXVldWVfdXNhZ2VcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwidG90YWxfZXZlbnRzX2RlY29kZWRcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwidXBncmFkZV9xdWV1ZV9zaXplXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcInVwZ3JhZGVfcXVldWVfdXNhZ2VcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwid2luZXZ0X2VkcHNcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwid2luZXZ0X2V2ZW50c19kZWNvZGVkXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcIndpbmV2dF9xdWV1ZV9zaXplXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcIndpbmV2dF9xdWV1ZV91c2FnZVwiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBcImFwaU5hbWVcIiA6IHtcclxuICAgICAgICBcInR5cGVcIiA6IFwidGV4dFwiLFxyXG4gICAgICAgIFwiZmllbGRzXCIgOiB7XHJcbiAgICAgICAgICBcImtleXdvcmRcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImtleXdvcmRcIixcclxuICAgICAgICAgICAgXCJpZ25vcmVfYWJvdmVcIiA6IDI1NlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgXCJjbHVzdGVyXCIgOiB7XHJcbiAgICAgICAgXCJ0eXBlXCIgOiBcInRleHRcIixcclxuICAgICAgICBcImZpZWxkc1wiIDoge1xyXG4gICAgICAgICAgXCJrZXl3b3JkXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJrZXl3b3JkXCIsXHJcbiAgICAgICAgICAgIFwiaWdub3JlX2Fib3ZlXCIgOiAyNTZcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIFwibm9kZU5hbWVcIiA6IHtcclxuICAgICAgICBcInR5cGVcIiA6IFwidGV4dFwiLFxyXG4gICAgICAgIFwiZmllbGRzXCIgOiB7XHJcbiAgICAgICAgICBcImtleXdvcmRcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImtleXdvcmRcIixcclxuICAgICAgICAgICAgXCJpZ25vcmVfYWJvdmVcIiA6IDI1NlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgXCJuYW1lXCIgOiB7XHJcbiAgICAgICAgXCJ0eXBlXCIgOiBcImtleXdvcmRcIlxyXG4gICAgICB9LCBcclxuICAgICAgXCJyZW1vdGVkXCIgOiB7XHJcbiAgICAgICAgXCJwcm9wZXJ0aWVzXCIgOiB7XHJcbiAgICAgICAgICBcImN0cmxfbXNnX2NvdW50XCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImRlcXVldWVkX2FmdGVyX2Nsb3NlXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImRpc2NhcmRlZF9jb3VudFwiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJldnRfY291bnRcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwibXNnX3NlbnRcIiA6IHtcclxuICAgICAgICAgICAgXCJ0eXBlXCIgOiBcImxvbmdcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwicXVldWVfc2l6ZVwiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwia2V5d29yZFwiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJyZWN2X2J5dGVzXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcInRjcF9zZXNzaW9uc1wiIDoge1xyXG4gICAgICAgICAgICBcInR5cGVcIiA6IFwibG9uZ1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJ0b3RhbF9xdWV1ZV9zaXplXCIgOiB7XHJcbiAgICAgICAgICAgIFwidHlwZVwiIDogXCJsb25nXCJcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIFwic3RhdHVzXCIgOiB7XHJcbiAgICAgICAgXCJ0eXBlXCIgOiBcImtleXdvcmRcIlxyXG4gICAgICB9LFxyXG4gICAgICBcInRpbWVzdGFtcFwiIDoge1xyXG4gICAgICAgIFwidHlwZVwiIDogXCJkYXRlXCIsXHJcbiAgICAgICAgXCJmb3JtYXRcIiA6IFwiZGF0ZU9wdGlvbmFsVGltZVwiXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn07XHJcbiJdfQ==