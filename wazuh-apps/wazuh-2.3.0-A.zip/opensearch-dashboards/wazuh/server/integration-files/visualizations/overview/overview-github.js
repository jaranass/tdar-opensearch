"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/*
 * Wazuh app - Module for Overview/GitHub visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Overview-GitHub-Alerts-Evolution-By-Organization',
  _source: {
    title: 'Alerts evolution by organization',
    visState: JSON.stringify({
      title: 'Alerts evolution by organization',
      type: 'area',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-7d',
            to: 'now'
          },
          useNormalizedEsInterval: true,
          scaleMetricValues: false,
          interval: 'auto',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {},
          customLabel: ''
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'group'
      }],
      params: {
        type: 'area',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100,
            rotate: 0
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: true,
          type: 'line',
          mode: 'normal',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          lineWidth: 2,
          showCircles: true,
          interpolate: 'linear',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#E7664C'
        },
        labels: {},
        orderBucketsBySum: false
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-5-Organizations-By-Alerts',
  _source: {
    title: 'Top 5 organizations by alerts',
    visState: JSON.stringify({
      title: 'Top 5 organizations by alerts',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: false,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Users-With-More-Alerts',
  _source: {
    title: 'Users with more alerts',
    visState: JSON.stringify({
      title: 'Users with more alerts',
      type: 'line',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.actor',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'group'
      }],
      params: {
        type: 'line',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: true,
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          lineWidth: 2,
          interpolate: 'linear',
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {},
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#E7664C'
        }
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Alert-Action-Type-By-Organization',
  _source: {
    title: 'Top alerts by alert action type and organization',
    visState: JSON.stringify({
      title: 'Top alerts by alert action type and organization',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.action',
          orderBy: '1',
          order: 'desc',
          size: 3,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Alert-Summary',
  _source: {
    title: 'Alert summary',
    visState: JSON.stringify({
      title: 'Alert summary',
      type: 'table',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'agent.name',
          orderBy: '1',
          order: 'desc',
          size: 50,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'bucket'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'bucket'
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        params: {
          field: 'rule.description',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'bucket'
      }],
      params: {
        perPage: 10,
        showPartialRows: false,
        showMetricsAtAllLevels: false,
        sort: {
          columnIndex: null,
          direction: null
        },
        showTotal: false,
        totalFunc: 'sum',
        percentageCol: ''
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-Ten-Organizations',
  _source: {
    title: 'Top 10 organizations',
    visState: JSON.stringify({
      title: 'Top 10 Organizations',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Organizations'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Countries',
  _source: {
    title: 'Countries',
    visState: JSON.stringify({
      title: 'Top github actors countries',
      type: 'tagcloud',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.actor_location.country_code',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Top countries '
        },
        schema: 'segment'
      }],
      params: {
        scale: 'linear',
        orientation: 'single',
        minFontSize: 18,
        maxFontSize: 72,
        showLabel: true
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-Events',
  _source: {
    title: 'GitHub top events',
    visState: JSON.stringify({
      title: 'Github Top Events',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.action',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Github Actions'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: false,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Stats',
  _source: {
    title: 'GitHub Stats',
    visState: JSON.stringify({
      title: 'Github Stats',
      type: 'metric',
      aggs: [{
        id: '2',
        enabled: true,
        type: 'count',
        params: {
          customLabel: 'Total Alerts'
        },
        schema: 'metric'
      }, {
        id: '1',
        enabled: true,
        type: 'top_hits',
        params: {
          field: 'rule.level',
          aggregate: 'concat',
          size: 1,
          sortField: 'rule.level',
          sortOrder: 'desc',
          customLabel: 'Max rule level detected'
        },
        schema: 'metric'
      }],
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'metric',
        metric: {
          percentageMode: false,
          useRanges: false,
          colorSchema: 'Green to Red',
          metricColorMode: 'None',
          colorsRange: [{
            from: 0,
            to: 10000
          }],
          labels: {
            show: true
          },
          invertColors: false,
          style: {
            bgFill: '#000',
            bgColor: false,
            labelColor: false,
            subText: '',
            fontSize: 60
          }
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Organization-Heatmap',
  _source: {
    title: 'GitHub Organization Heatmap',
    visState: JSON.stringify({
      title: 'GitHub Organization Heatmap',
      type: 'heatmap',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.action',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'group'
      }],
      params: {
        type: 'heatmap',
        addTooltip: true,
        addLegend: true,
        enableHover: false,
        legendPosition: 'right',
        times: [],
        colorsNumber: 4,
        colorSchema: 'Blues',
        setColorRange: false,
        colorsRange: [],
        invertColors: false,
        percentageMode: false,
        valueAxes: [{
          show: false,
          id: 'ValueAxis-1',
          type: 'value',
          scale: {
            type: 'linear',
            defaultYExtents: false
          },
          labels: {
            show: false,
            rotate: 0,
            overwriteColor: false,
            color: 'black'
          }
        }]
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-Ten-Organizations',
  _source: {
    title: 'GitHub top 10 organizations',
    visState: JSON.stringify({
      title: 'Top 10 Organizations',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Organizations'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-Ten-Actors',
  _source: {
    title: 'Top 10 actors',
    visState: JSON.stringify({
      title: 'Top 10 Actors',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.actor',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Actors'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-Ten-Repositories',
  _source: {
    title: 'Top 10 repositories',
    visState: JSON.stringify({
      title: 'Top 10 Repositories',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.repo',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Repositories'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-Ten-Actions',
  _source: {
    title: 'Top 10 actions',
    visState: JSON.stringify({
      title: 'Top 10 Actions',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.action',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Actions'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Alert-Level-Evolution',
  _source: {
    title: 'Alert level evolution',
    visState: JSON.stringify({
      title: 'Rule Level Over Time',
      type: 'area',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-30d',
            to: 'now'
          },
          useNormalizedEsInterval: true,
          scaleMetricValues: false,
          interval: 'd',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {}
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'rule.level',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'group'
      }],
      params: {
        type: 'area',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: true,
          type: 'area',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          lineWidth: 2,
          showCircles: true,
          interpolate: 'step-after',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#E7664C'
        },
        labels: {}
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm92ZXJ2aWV3LWdpdGh1Yi50cyJdLCJuYW1lcyI6WyJfaWQiLCJfc291cmNlIiwidGl0bGUiLCJ2aXNTdGF0ZSIsIkpTT04iLCJzdHJpbmdpZnkiLCJ0eXBlIiwiYWdncyIsImlkIiwiZW5hYmxlZCIsInBhcmFtcyIsInNjaGVtYSIsImZpZWxkIiwidGltZVJhbmdlIiwiZnJvbSIsInRvIiwidXNlTm9ybWFsaXplZEVzSW50ZXJ2YWwiLCJzY2FsZU1ldHJpY1ZhbHVlcyIsImludGVydmFsIiwiZHJvcF9wYXJ0aWFscyIsIm1pbl9kb2NfY291bnQiLCJleHRlbmRlZF9ib3VuZHMiLCJjdXN0b21MYWJlbCIsIm9yZGVyQnkiLCJvcmRlciIsInNpemUiLCJvdGhlckJ1Y2tldCIsIm90aGVyQnVja2V0TGFiZWwiLCJtaXNzaW5nQnVja2V0IiwibWlzc2luZ0J1Y2tldExhYmVsIiwiZ3JpZCIsImNhdGVnb3J5TGluZXMiLCJjYXRlZ29yeUF4ZXMiLCJwb3NpdGlvbiIsInNob3ciLCJzdHlsZSIsInNjYWxlIiwibGFiZWxzIiwiZmlsdGVyIiwidHJ1bmNhdGUiLCJyb3RhdGUiLCJ2YWx1ZUF4ZXMiLCJuYW1lIiwibW9kZSIsInRleHQiLCJzZXJpZXNQYXJhbXMiLCJkYXRhIiwibGFiZWwiLCJkcmF3TGluZXNCZXR3ZWVuUG9pbnRzIiwibGluZVdpZHRoIiwic2hvd0NpcmNsZXMiLCJpbnRlcnBvbGF0ZSIsInZhbHVlQXhpcyIsImFkZFRvb2x0aXAiLCJhZGRMZWdlbmQiLCJsZWdlbmRQb3NpdGlvbiIsInRpbWVzIiwiYWRkVGltZU1hcmtlciIsInRocmVzaG9sZExpbmUiLCJ2YWx1ZSIsIndpZHRoIiwiY29sb3IiLCJvcmRlckJ1Y2tldHNCeVN1bSIsInVpU3RhdGVKU09OIiwiZGVzY3JpcHRpb24iLCJ2ZXJzaW9uIiwia2liYW5hU2F2ZWRPYmplY3RNZXRhIiwic2VhcmNoU291cmNlSlNPTiIsIl90eXBlIiwiaXNEb251dCIsInZhbHVlcyIsImxhc3RfbGV2ZWwiLCJwZXJQYWdlIiwic2hvd1BhcnRpYWxSb3dzIiwic2hvd01ldHJpY3NBdEFsbExldmVscyIsInNvcnQiLCJjb2x1bW5JbmRleCIsImRpcmVjdGlvbiIsInNob3dUb3RhbCIsInRvdGFsRnVuYyIsInBlcmNlbnRhZ2VDb2wiLCJ2aXMiLCJvcmllbnRhdGlvbiIsIm1pbkZvbnRTaXplIiwibWF4Rm9udFNpemUiLCJzaG93TGFiZWwiLCJhZ2dyZWdhdGUiLCJzb3J0RmllbGQiLCJzb3J0T3JkZXIiLCJtZXRyaWMiLCJwZXJjZW50YWdlTW9kZSIsInVzZVJhbmdlcyIsImNvbG9yU2NoZW1hIiwibWV0cmljQ29sb3JNb2RlIiwiY29sb3JzUmFuZ2UiLCJpbnZlcnRDb2xvcnMiLCJiZ0ZpbGwiLCJiZ0NvbG9yIiwibGFiZWxDb2xvciIsInN1YlRleHQiLCJmb250U2l6ZSIsImVuYWJsZUhvdmVyIiwiY29sb3JzTnVtYmVyIiwic2V0Q29sb3JSYW5nZSIsImRlZmF1bHRZRXh0ZW50cyIsIm92ZXJ3cml0ZUNvbG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtlQUNlLENBQ2I7QUFDRUEsRUFBQUEsR0FBRyxFQUFFLDREQURQO0FBRUVDLEVBQUFBLE9BQU8sRUFBRTtBQUNQQyxJQUFBQSxLQUFLLEVBQUUsa0NBREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QkgsTUFBQUEsS0FBSyxFQUFFLGtDQURnQjtBQUV2QkksTUFBQUEsSUFBSSxFQUFFLE1BRmlCO0FBR3ZCQyxNQUFBQSxJQUFJLEVBQUUsQ0FDSjtBQUNFQyxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUUsRUFKVjtBQUtFQyxRQUFBQSxNQUFNLEVBQUU7QUFMVixPQURJLEVBUUo7QUFDRUgsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRUMsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUgsUUFBQUEsSUFBSSxFQUFFLGdCQUhSO0FBSUVJLFFBQUFBLE1BQU0sRUFBRTtBQUNORSxVQUFBQSxLQUFLLEVBQUUsV0FERDtBQUVOQyxVQUFBQSxTQUFTLEVBQUU7QUFDVEMsWUFBQUEsSUFBSSxFQUFFLFFBREc7QUFFVEMsWUFBQUEsRUFBRSxFQUFFO0FBRkssV0FGTDtBQU1OQyxVQUFBQSx1QkFBdUIsRUFBRSxJQU5uQjtBQU9OQyxVQUFBQSxpQkFBaUIsRUFBRSxLQVBiO0FBUU5DLFVBQUFBLFFBQVEsRUFBRSxNQVJKO0FBU05DLFVBQUFBLGFBQWEsRUFBRSxLQVRUO0FBVU5DLFVBQUFBLGFBQWEsRUFBRSxDQVZUO0FBV05DLFVBQUFBLGVBQWUsRUFBRSxFQVhYO0FBWU5DLFVBQUFBLFdBQVcsRUFBRTtBQVpQLFNBSlY7QUFrQkVYLFFBQUFBLE1BQU0sRUFBRTtBQWxCVixPQVJJLEVBNEJKO0FBQ0VILFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUVDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0VILFFBQUFBLElBQUksRUFBRSxPQUhSO0FBSUVJLFFBQUFBLE1BQU0sRUFBRTtBQUNORSxVQUFBQSxLQUFLLEVBQUUsaUJBREQ7QUFFTlcsVUFBQUEsT0FBTyxFQUFFLEdBRkg7QUFHTkMsVUFBQUEsS0FBSyxFQUFFLE1BSEQ7QUFJTkMsVUFBQUEsSUFBSSxFQUFFLENBSkE7QUFLTkMsVUFBQUEsV0FBVyxFQUFFLEtBTFA7QUFNTkMsVUFBQUEsZ0JBQWdCLEVBQUUsT0FOWjtBQU9OQyxVQUFBQSxhQUFhLEVBQUUsS0FQVDtBQVFOQyxVQUFBQSxrQkFBa0IsRUFBRTtBQVJkLFNBSlY7QUFjRWxCLFFBQUFBLE1BQU0sRUFBRTtBQWRWLE9BNUJJLENBSGlCO0FBZ0R2QkQsTUFBQUEsTUFBTSxFQUFFO0FBQ05KLFFBQUFBLElBQUksRUFBRSxNQURBO0FBRU53QixRQUFBQSxJQUFJLEVBQUU7QUFDSkMsVUFBQUEsYUFBYSxFQUFFO0FBRFgsU0FGQTtBQUtOQyxRQUFBQSxZQUFZLEVBQUUsQ0FDWjtBQUNFeEIsVUFBQUEsRUFBRSxFQUFFLGdCQUROO0FBRUVGLFVBQUFBLElBQUksRUFBRSxVQUZSO0FBR0UyQixVQUFBQSxRQUFRLEVBQUUsUUFIWjtBQUlFQyxVQUFBQSxJQUFJLEVBQUUsSUFKUjtBQUtFQyxVQUFBQSxLQUFLLEVBQUUsRUFMVDtBQU1FQyxVQUFBQSxLQUFLLEVBQUU7QUFDTDlCLFlBQUFBLElBQUksRUFBRTtBQURELFdBTlQ7QUFTRStCLFVBQUFBLE1BQU0sRUFBRTtBQUNOSCxZQUFBQSxJQUFJLEVBQUUsSUFEQTtBQUVOSSxZQUFBQSxNQUFNLEVBQUUsSUFGRjtBQUdOQyxZQUFBQSxRQUFRLEVBQUUsR0FISjtBQUlOQyxZQUFBQSxNQUFNLEVBQUU7QUFKRixXQVRWO0FBZUV0QyxVQUFBQSxLQUFLLEVBQUU7QUFmVCxTQURZLENBTFI7QUF3Qk51QyxRQUFBQSxTQUFTLEVBQUUsQ0FDVDtBQUNFakMsVUFBQUEsRUFBRSxFQUFFLGFBRE47QUFFRWtDLFVBQUFBLElBQUksRUFBRSxZQUZSO0FBR0VwQyxVQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFMkIsVUFBQUEsUUFBUSxFQUFFLE1BSlo7QUFLRUMsVUFBQUEsSUFBSSxFQUFFLElBTFI7QUFNRUMsVUFBQUEsS0FBSyxFQUFFLEVBTlQ7QUFPRUMsVUFBQUEsS0FBSyxFQUFFO0FBQ0w5QixZQUFBQSxJQUFJLEVBQUUsUUFERDtBQUVMcUMsWUFBQUEsSUFBSSxFQUFFO0FBRkQsV0FQVDtBQVdFTixVQUFBQSxNQUFNLEVBQUU7QUFDTkgsWUFBQUEsSUFBSSxFQUFFLElBREE7QUFFTk0sWUFBQUEsTUFBTSxFQUFFLENBRkY7QUFHTkYsWUFBQUEsTUFBTSxFQUFFLEtBSEY7QUFJTkMsWUFBQUEsUUFBUSxFQUFFO0FBSkosV0FYVjtBQWlCRXJDLFVBQUFBLEtBQUssRUFBRTtBQUNMMEMsWUFBQUEsSUFBSSxFQUFFO0FBREQ7QUFqQlQsU0FEUyxDQXhCTDtBQStDTkMsUUFBQUEsWUFBWSxFQUFFLENBQ1o7QUFDRVgsVUFBQUEsSUFBSSxFQUFFLElBRFI7QUFFRTVCLFVBQUFBLElBQUksRUFBRSxNQUZSO0FBR0VxQyxVQUFBQSxJQUFJLEVBQUUsUUFIUjtBQUlFRyxVQUFBQSxJQUFJLEVBQUU7QUFDSkMsWUFBQUEsS0FBSyxFQUFFLE9BREg7QUFFSnZDLFlBQUFBLEVBQUUsRUFBRTtBQUZBLFdBSlI7QUFRRXdDLFVBQUFBLHNCQUFzQixFQUFFLElBUjFCO0FBU0VDLFVBQUFBLFNBQVMsRUFBRSxDQVRiO0FBVUVDLFVBQUFBLFdBQVcsRUFBRSxJQVZmO0FBV0VDLFVBQUFBLFdBQVcsRUFBRSxRQVhmO0FBWUVDLFVBQUFBLFNBQVMsRUFBRTtBQVpiLFNBRFksQ0EvQ1I7QUErRE5DLFFBQUFBLFVBQVUsRUFBRSxJQS9ETjtBQWdFTkMsUUFBQUEsU0FBUyxFQUFFLElBaEVMO0FBaUVOQyxRQUFBQSxjQUFjLEVBQUUsT0FqRVY7QUFrRU5DLFFBQUFBLEtBQUssRUFBRSxFQWxFRDtBQW1FTkMsUUFBQUEsYUFBYSxFQUFFLEtBbkVUO0FBb0VOQyxRQUFBQSxhQUFhLEVBQUU7QUFDYnhCLFVBQUFBLElBQUksRUFBRSxLQURPO0FBRWJ5QixVQUFBQSxLQUFLLEVBQUUsRUFGTTtBQUdiQyxVQUFBQSxLQUFLLEVBQUUsQ0FITTtBQUliekIsVUFBQUEsS0FBSyxFQUFFLE1BSk07QUFLYjBCLFVBQUFBLEtBQUssRUFBRTtBQUxNLFNBcEVUO0FBMkVOeEIsUUFBQUEsTUFBTSxFQUFFLEVBM0VGO0FBNEVOeUIsUUFBQUEsaUJBQWlCLEVBQUU7QUE1RWI7QUFoRGUsS0FBZixDQUZIO0FBaUlQQyxJQUFBQSxXQUFXLEVBQUUsRUFqSU47QUFrSVBDLElBQUFBLFdBQVcsRUFBRSxFQWxJTjtBQW1JUEMsSUFBQUEsT0FBTyxFQUFFLENBbklGO0FBb0lQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQ2Q7QUFGbUI7QUFwSWhCLEdBRlg7QUEySUVDLEVBQUFBLEtBQUssRUFBRTtBQTNJVCxDQURhLEVBOEliO0FBQ0VwRSxFQUFBQSxHQUFHLEVBQUUseURBRFA7QUFFRUMsRUFBQUEsT0FBTyxFQUFFO0FBQ1BDLElBQUFBLEtBQUssRUFBRSwrQkFEQTtBQUVQQyxJQUFBQSxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ3ZCSCxNQUFBQSxLQUFLLEVBQUUsK0JBRGdCO0FBRXZCSSxNQUFBQSxJQUFJLEVBQUUsS0FGaUI7QUFHdkJDLE1BQUFBLElBQUksRUFBRSxDQUNKO0FBQ0VDLFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUVDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0VILFFBQUFBLElBQUksRUFBRSxPQUhSO0FBSUVJLFFBQUFBLE1BQU0sRUFBRSxFQUpWO0FBS0VDLFFBQUFBLE1BQU0sRUFBRTtBQUxWLE9BREksRUFRSjtBQUNFSCxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUU7QUFDTkUsVUFBQUEsS0FBSyxFQUFFLGlCQUREO0FBRU5XLFVBQUFBLE9BQU8sRUFBRSxHQUZIO0FBR05DLFVBQUFBLEtBQUssRUFBRSxNQUhEO0FBSU5DLFVBQUFBLElBQUksRUFBRSxDQUpBO0FBS05DLFVBQUFBLFdBQVcsRUFBRSxLQUxQO0FBTU5DLFVBQUFBLGdCQUFnQixFQUFFLE9BTlo7QUFPTkMsVUFBQUEsYUFBYSxFQUFFLEtBUFQ7QUFRTkMsVUFBQUEsa0JBQWtCLEVBQUU7QUFSZCxTQUpWO0FBY0VsQixRQUFBQSxNQUFNLEVBQUU7QUFkVixPQVJJLENBSGlCO0FBNEJ2QkQsTUFBQUEsTUFBTSxFQUFFO0FBQ05KLFFBQUFBLElBQUksRUFBRSxLQURBO0FBRU4rQyxRQUFBQSxVQUFVLEVBQUUsSUFGTjtBQUdOQyxRQUFBQSxTQUFTLEVBQUUsSUFITDtBQUlOQyxRQUFBQSxjQUFjLEVBQUUsT0FKVjtBQUtOYyxRQUFBQSxPQUFPLEVBQUUsS0FMSDtBQU1OaEMsUUFBQUEsTUFBTSxFQUFFO0FBQ05ILFVBQUFBLElBQUksRUFBRSxLQURBO0FBRU5vQyxVQUFBQSxNQUFNLEVBQUUsSUFGRjtBQUdOQyxVQUFBQSxVQUFVLEVBQUUsSUFITjtBQUlOaEMsVUFBQUEsUUFBUSxFQUFFO0FBSko7QUFORjtBQTVCZSxLQUFmLENBRkg7QUE0Q1B3QixJQUFBQSxXQUFXLEVBQUUsRUE1Q047QUE2Q1BDLElBQUFBLFdBQVcsRUFBRSxFQTdDTjtBQThDUEMsSUFBQUEsT0FBTyxFQUFFLENBOUNGO0FBK0NQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQ2Q7QUFGbUI7QUEvQ2hCLEdBRlg7QUFzREVDLEVBQUFBLEtBQUssRUFBRTtBQXREVCxDQTlJYSxFQXNNYjtBQUNFcEUsRUFBQUEsR0FBRyxFQUFFLGtEQURQO0FBRUVDLEVBQUFBLE9BQU8sRUFBRTtBQUNQQyxJQUFBQSxLQUFLLEVBQUUsd0JBREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QkgsTUFBQUEsS0FBSyxFQUFFLHdCQURnQjtBQUV2QkksTUFBQUEsSUFBSSxFQUFFLE1BRmlCO0FBR3ZCQyxNQUFBQSxJQUFJLEVBQUUsQ0FDSjtBQUNFQyxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUUsRUFKVjtBQUtFQyxRQUFBQSxNQUFNLEVBQUU7QUFMVixPQURJLEVBUUo7QUFDRUgsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRUMsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUgsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRUksUUFBQUEsTUFBTSxFQUFFO0FBQ05FLFVBQUFBLEtBQUssRUFBRSxpQkFERDtBQUVOVyxVQUFBQSxPQUFPLEVBQUUsR0FGSDtBQUdOQyxVQUFBQSxLQUFLLEVBQUUsTUFIRDtBQUlOQyxVQUFBQSxJQUFJLEVBQUUsQ0FKQTtBQUtOQyxVQUFBQSxXQUFXLEVBQUUsS0FMUDtBQU1OQyxVQUFBQSxnQkFBZ0IsRUFBRSxPQU5aO0FBT05DLFVBQUFBLGFBQWEsRUFBRSxLQVBUO0FBUU5DLFVBQUFBLGtCQUFrQixFQUFFO0FBUmQsU0FKVjtBQWNFbEIsUUFBQUEsTUFBTSxFQUFFO0FBZFYsT0FSSSxFQXdCSjtBQUNFSCxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUU7QUFDTkUsVUFBQUEsS0FBSyxFQUFFLG1CQUREO0FBRU5XLFVBQUFBLE9BQU8sRUFBRSxHQUZIO0FBR05DLFVBQUFBLEtBQUssRUFBRSxNQUhEO0FBSU5DLFVBQUFBLElBQUksRUFBRSxDQUpBO0FBS05DLFVBQUFBLFdBQVcsRUFBRSxLQUxQO0FBTU5DLFVBQUFBLGdCQUFnQixFQUFFLE9BTlo7QUFPTkMsVUFBQUEsYUFBYSxFQUFFLEtBUFQ7QUFRTkMsVUFBQUEsa0JBQWtCLEVBQUU7QUFSZCxTQUpWO0FBY0VsQixRQUFBQSxNQUFNLEVBQUU7QUFkVixPQXhCSSxDQUhpQjtBQTRDdkJELE1BQUFBLE1BQU0sRUFBRTtBQUNOSixRQUFBQSxJQUFJLEVBQUUsTUFEQTtBQUVOd0IsUUFBQUEsSUFBSSxFQUFFO0FBQ0pDLFVBQUFBLGFBQWEsRUFBRTtBQURYLFNBRkE7QUFLTkMsUUFBQUEsWUFBWSxFQUFFLENBQ1o7QUFDRXhCLFVBQUFBLEVBQUUsRUFBRSxnQkFETjtBQUVFRixVQUFBQSxJQUFJLEVBQUUsVUFGUjtBQUdFMkIsVUFBQUEsUUFBUSxFQUFFLFFBSFo7QUFJRUMsVUFBQUEsSUFBSSxFQUFFLElBSlI7QUFLRUMsVUFBQUEsS0FBSyxFQUFFLEVBTFQ7QUFNRUMsVUFBQUEsS0FBSyxFQUFFO0FBQ0w5QixZQUFBQSxJQUFJLEVBQUU7QUFERCxXQU5UO0FBU0UrQixVQUFBQSxNQUFNLEVBQUU7QUFDTkgsWUFBQUEsSUFBSSxFQUFFLElBREE7QUFFTkksWUFBQUEsTUFBTSxFQUFFLElBRkY7QUFHTkMsWUFBQUEsUUFBUSxFQUFFO0FBSEosV0FUVjtBQWNFckMsVUFBQUEsS0FBSyxFQUFFO0FBZFQsU0FEWSxDQUxSO0FBdUJOdUMsUUFBQUEsU0FBUyxFQUFFLENBQ1Q7QUFDRWpDLFVBQUFBLEVBQUUsRUFBRSxhQUROO0FBRUVrQyxVQUFBQSxJQUFJLEVBQUUsWUFGUjtBQUdFcEMsVUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRTJCLFVBQUFBLFFBQVEsRUFBRSxNQUpaO0FBS0VDLFVBQUFBLElBQUksRUFBRSxJQUxSO0FBTUVDLFVBQUFBLEtBQUssRUFBRSxFQU5UO0FBT0VDLFVBQUFBLEtBQUssRUFBRTtBQUNMOUIsWUFBQUEsSUFBSSxFQUFFLFFBREQ7QUFFTHFDLFlBQUFBLElBQUksRUFBRTtBQUZELFdBUFQ7QUFXRU4sVUFBQUEsTUFBTSxFQUFFO0FBQ05ILFlBQUFBLElBQUksRUFBRSxJQURBO0FBRU5NLFlBQUFBLE1BQU0sRUFBRSxDQUZGO0FBR05GLFlBQUFBLE1BQU0sRUFBRSxLQUhGO0FBSU5DLFlBQUFBLFFBQVEsRUFBRTtBQUpKLFdBWFY7QUFpQkVyQyxVQUFBQSxLQUFLLEVBQUU7QUFDTDBDLFlBQUFBLElBQUksRUFBRTtBQUREO0FBakJULFNBRFMsQ0F2Qkw7QUE4Q05DLFFBQUFBLFlBQVksRUFBRSxDQUNaO0FBQ0VYLFVBQUFBLElBQUksRUFBRSxJQURSO0FBRUU1QixVQUFBQSxJQUFJLEVBQUUsV0FGUjtBQUdFcUMsVUFBQUEsSUFBSSxFQUFFLFNBSFI7QUFJRUcsVUFBQUEsSUFBSSxFQUFFO0FBQ0pDLFlBQUFBLEtBQUssRUFBRSxPQURIO0FBRUp2QyxZQUFBQSxFQUFFLEVBQUU7QUFGQSxXQUpSO0FBUUU0QyxVQUFBQSxTQUFTLEVBQUUsYUFSYjtBQVNFSixVQUFBQSxzQkFBc0IsRUFBRSxJQVQxQjtBQVVFQyxVQUFBQSxTQUFTLEVBQUUsQ0FWYjtBQVdFRSxVQUFBQSxXQUFXLEVBQUUsUUFYZjtBQVlFRCxVQUFBQSxXQUFXLEVBQUU7QUFaZixTQURZLENBOUNSO0FBOERORyxRQUFBQSxVQUFVLEVBQUUsSUE5RE47QUErRE5DLFFBQUFBLFNBQVMsRUFBRSxJQS9ETDtBQWdFTkMsUUFBQUEsY0FBYyxFQUFFLE9BaEVWO0FBaUVOQyxRQUFBQSxLQUFLLEVBQUUsRUFqRUQ7QUFrRU5DLFFBQUFBLGFBQWEsRUFBRSxLQWxFVDtBQW1FTnBCLFFBQUFBLE1BQU0sRUFBRSxFQW5FRjtBQW9FTnFCLFFBQUFBLGFBQWEsRUFBRTtBQUNieEIsVUFBQUEsSUFBSSxFQUFFLEtBRE87QUFFYnlCLFVBQUFBLEtBQUssRUFBRSxFQUZNO0FBR2JDLFVBQUFBLEtBQUssRUFBRSxDQUhNO0FBSWJ6QixVQUFBQSxLQUFLLEVBQUUsTUFKTTtBQUtiMEIsVUFBQUEsS0FBSyxFQUFFO0FBTE07QUFwRVQ7QUE1Q2UsS0FBZixDQUZIO0FBMkhQRSxJQUFBQSxXQUFXLEVBQUUsRUEzSE47QUE0SFBDLElBQUFBLFdBQVcsRUFBRSxFQTVITjtBQTZIUEMsSUFBQUEsT0FBTyxFQUFFLENBN0hGO0FBOEhQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQ2Q7QUFGbUI7QUE5SGhCLEdBRlg7QUFxSUVDLEVBQUFBLEtBQUssRUFBRTtBQXJJVCxDQXRNYSxFQTZVYjtBQUNFcEUsRUFBQUEsR0FBRyxFQUFFLDZEQURQO0FBRUVDLEVBQUFBLE9BQU8sRUFBRTtBQUNQQyxJQUFBQSxLQUFLLEVBQUUsa0RBREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QkgsTUFBQUEsS0FBSyxFQUFFLGtEQURnQjtBQUV2QkksTUFBQUEsSUFBSSxFQUFFLEtBRmlCO0FBR3ZCQyxNQUFBQSxJQUFJLEVBQUUsQ0FDSjtBQUNFQyxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUUsRUFKVjtBQUtFQyxRQUFBQSxNQUFNLEVBQUU7QUFMVixPQURJLEVBUUo7QUFDRUgsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRUMsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUgsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRUksUUFBQUEsTUFBTSxFQUFFO0FBQ05FLFVBQUFBLEtBQUssRUFBRSxpQkFERDtBQUVOVyxVQUFBQSxPQUFPLEVBQUUsR0FGSDtBQUdOQyxVQUFBQSxLQUFLLEVBQUUsTUFIRDtBQUlOQyxVQUFBQSxJQUFJLEVBQUUsQ0FKQTtBQUtOQyxVQUFBQSxXQUFXLEVBQUUsS0FMUDtBQU1OQyxVQUFBQSxnQkFBZ0IsRUFBRSxPQU5aO0FBT05DLFVBQUFBLGFBQWEsRUFBRSxLQVBUO0FBUU5DLFVBQUFBLGtCQUFrQixFQUFFO0FBUmQsU0FKVjtBQWNFbEIsUUFBQUEsTUFBTSxFQUFFO0FBZFYsT0FSSSxFQXdCSjtBQUNFSCxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUU7QUFDTkUsVUFBQUEsS0FBSyxFQUFFLG9CQUREO0FBRU5XLFVBQUFBLE9BQU8sRUFBRSxHQUZIO0FBR05DLFVBQUFBLEtBQUssRUFBRSxNQUhEO0FBSU5DLFVBQUFBLElBQUksRUFBRSxDQUpBO0FBS05DLFVBQUFBLFdBQVcsRUFBRSxLQUxQO0FBTU5DLFVBQUFBLGdCQUFnQixFQUFFLE9BTlo7QUFPTkMsVUFBQUEsYUFBYSxFQUFFLEtBUFQ7QUFRTkMsVUFBQUEsa0JBQWtCLEVBQUU7QUFSZCxTQUpWO0FBY0VsQixRQUFBQSxNQUFNLEVBQUU7QUFkVixPQXhCSSxDQUhpQjtBQTRDdkJELE1BQUFBLE1BQU0sRUFBRTtBQUNOSixRQUFBQSxJQUFJLEVBQUUsS0FEQTtBQUVOK0MsUUFBQUEsVUFBVSxFQUFFLElBRk47QUFHTkMsUUFBQUEsU0FBUyxFQUFFLElBSEw7QUFJTkMsUUFBQUEsY0FBYyxFQUFFLE9BSlY7QUFLTmMsUUFBQUEsT0FBTyxFQUFFLElBTEg7QUFNTmhDLFFBQUFBLE1BQU0sRUFBRTtBQUNOSCxVQUFBQSxJQUFJLEVBQUUsS0FEQTtBQUVOb0MsVUFBQUEsTUFBTSxFQUFFLElBRkY7QUFHTkMsVUFBQUEsVUFBVSxFQUFFLElBSE47QUFJTmhDLFVBQUFBLFFBQVEsRUFBRTtBQUpKO0FBTkY7QUE1Q2UsS0FBZixDQUZIO0FBNERQd0IsSUFBQUEsV0FBVyxFQUFFLEVBNUROO0FBNkRQQyxJQUFBQSxXQUFXLEVBQUUsRUE3RE47QUE4RFBDLElBQUFBLE9BQU8sRUFBRSxDQTlERjtBQStEUEMsSUFBQUEscUJBQXFCLEVBQUU7QUFDckJDLE1BQUFBLGdCQUFnQixFQUNkO0FBRm1CO0FBL0RoQixHQUZYO0FBc0VFQyxFQUFBQSxLQUFLLEVBQUU7QUF0RVQsQ0E3VWEsRUFxWmI7QUFDRXBFLEVBQUFBLEdBQUcsRUFBRSx5Q0FEUDtBQUVFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLGVBREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QkgsTUFBQUEsS0FBSyxFQUFFLGVBRGdCO0FBRXZCSSxNQUFBQSxJQUFJLEVBQUUsT0FGaUI7QUFHdkJDLE1BQUFBLElBQUksRUFBRSxDQUNKO0FBQ0VDLFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUVDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0VILFFBQUFBLElBQUksRUFBRSxPQUhSO0FBSUVJLFFBQUFBLE1BQU0sRUFBRSxFQUpWO0FBS0VDLFFBQUFBLE1BQU0sRUFBRTtBQUxWLE9BREksRUFRSjtBQUNFSCxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUU7QUFDTkUsVUFBQUEsS0FBSyxFQUFFLFlBREQ7QUFFTlcsVUFBQUEsT0FBTyxFQUFFLEdBRkg7QUFHTkMsVUFBQUEsS0FBSyxFQUFFLE1BSEQ7QUFJTkMsVUFBQUEsSUFBSSxFQUFFLEVBSkE7QUFLTkMsVUFBQUEsV0FBVyxFQUFFLEtBTFA7QUFNTkMsVUFBQUEsZ0JBQWdCLEVBQUUsT0FOWjtBQU9OQyxVQUFBQSxhQUFhLEVBQUUsS0FQVDtBQVFOQyxVQUFBQSxrQkFBa0IsRUFBRTtBQVJkLFNBSlY7QUFjRWxCLFFBQUFBLE1BQU0sRUFBRTtBQWRWLE9BUkksRUF3Qko7QUFDRUgsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRUMsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUgsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRUksUUFBQUEsTUFBTSxFQUFFO0FBQ05FLFVBQUFBLEtBQUssRUFBRSxpQkFERDtBQUVOVyxVQUFBQSxPQUFPLEVBQUUsR0FGSDtBQUdOQyxVQUFBQSxLQUFLLEVBQUUsTUFIRDtBQUlOQyxVQUFBQSxJQUFJLEVBQUUsRUFKQTtBQUtOQyxVQUFBQSxXQUFXLEVBQUUsS0FMUDtBQU1OQyxVQUFBQSxnQkFBZ0IsRUFBRSxPQU5aO0FBT05DLFVBQUFBLGFBQWEsRUFBRSxLQVBUO0FBUU5DLFVBQUFBLGtCQUFrQixFQUFFO0FBUmQsU0FKVjtBQWNFbEIsUUFBQUEsTUFBTSxFQUFFO0FBZFYsT0F4QkksRUF3Q0o7QUFDRUgsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRUMsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUgsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRUksUUFBQUEsTUFBTSxFQUFFO0FBQ05FLFVBQUFBLEtBQUssRUFBRSxrQkFERDtBQUVOVyxVQUFBQSxPQUFPLEVBQUUsR0FGSDtBQUdOQyxVQUFBQSxLQUFLLEVBQUUsTUFIRDtBQUlOQyxVQUFBQSxJQUFJLEVBQUUsRUFKQTtBQUtOQyxVQUFBQSxXQUFXLEVBQUUsS0FMUDtBQU1OQyxVQUFBQSxnQkFBZ0IsRUFBRSxPQU5aO0FBT05DLFVBQUFBLGFBQWEsRUFBRSxLQVBUO0FBUU5DLFVBQUFBLGtCQUFrQixFQUFFO0FBUmQsU0FKVjtBQWNFbEIsUUFBQUEsTUFBTSxFQUFFO0FBZFYsT0F4Q0ksQ0FIaUI7QUE0RHZCRCxNQUFBQSxNQUFNLEVBQUU7QUFDTjhELFFBQUFBLE9BQU8sRUFBRSxFQURIO0FBRU5DLFFBQUFBLGVBQWUsRUFBRSxLQUZYO0FBR05DLFFBQUFBLHNCQUFzQixFQUFFLEtBSGxCO0FBSU5DLFFBQUFBLElBQUksRUFBRTtBQUNKQyxVQUFBQSxXQUFXLEVBQUUsSUFEVDtBQUVKQyxVQUFBQSxTQUFTLEVBQUU7QUFGUCxTQUpBO0FBUU5DLFFBQUFBLFNBQVMsRUFBRSxLQVJMO0FBU05DLFFBQUFBLFNBQVMsRUFBRSxLQVRMO0FBVU5DLFFBQUFBLGFBQWEsRUFBRTtBQVZUO0FBNURlLEtBQWYsQ0FGSDtBQTJFUGpCLElBQUFBLFdBQVcsRUFBRTNELElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQzFCNEUsTUFBQUEsR0FBRyxFQUFFO0FBQUV2RSxRQUFBQSxNQUFNLEVBQUU7QUFBRWlFLFVBQUFBLElBQUksRUFBRTtBQUFFQyxZQUFBQSxXQUFXLEVBQUUsQ0FBZjtBQUFrQkMsWUFBQUEsU0FBUyxFQUFFO0FBQTdCO0FBQVI7QUFBVjtBQURxQixLQUFmLENBM0VOO0FBOEVQYixJQUFBQSxXQUFXLEVBQUUsRUE5RU47QUErRVBDLElBQUFBLE9BQU8sRUFBRSxDQS9FRjtBQWdGUEMsSUFBQUEscUJBQXFCLEVBQUU7QUFDckJDLE1BQUFBLGdCQUFnQixFQUNkO0FBRm1CO0FBaEZoQixHQUZYO0FBdUZFQyxFQUFBQSxLQUFLLEVBQUU7QUF2RlQsQ0FyWmEsRUE4ZWI7QUFDRXBFLEVBQUFBLEdBQUcsRUFBRSxpREFEUDtBQUVFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLHNCQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSxzQkFEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxLQUZpQjtBQUd2QkMsTUFBQUEsSUFBSSxFQUFFLENBQ0o7QUFDRUMsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRUMsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUgsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRUksUUFBQUEsTUFBTSxFQUFFLEVBSlY7QUFLRUMsUUFBQUEsTUFBTSxFQUFFO0FBTFYsT0FESSxFQVFKO0FBQ0VILFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUVDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0VILFFBQUFBLElBQUksRUFBRSxPQUhSO0FBSUVJLFFBQUFBLE1BQU0sRUFBRTtBQUNORSxVQUFBQSxLQUFLLEVBQUUsaUJBREQ7QUFFTlcsVUFBQUEsT0FBTyxFQUFFLEdBRkg7QUFHTkMsVUFBQUEsS0FBSyxFQUFFLE1BSEQ7QUFJTkMsVUFBQUEsSUFBSSxFQUFFLEVBSkE7QUFLTkMsVUFBQUEsV0FBVyxFQUFFLEtBTFA7QUFNTkMsVUFBQUEsZ0JBQWdCLEVBQUUsT0FOWjtBQU9OQyxVQUFBQSxhQUFhLEVBQUUsS0FQVDtBQVFOQyxVQUFBQSxrQkFBa0IsRUFBRSxTQVJkO0FBU05QLFVBQUFBLFdBQVcsRUFBRTtBQVRQLFNBSlY7QUFlRVgsUUFBQUEsTUFBTSxFQUFFO0FBZlYsT0FSSSxDQUhpQjtBQTZCdkJELE1BQUFBLE1BQU0sRUFBRTtBQUNOSixRQUFBQSxJQUFJLEVBQUUsS0FEQTtBQUVOK0MsUUFBQUEsVUFBVSxFQUFFLElBRk47QUFHTkMsUUFBQUEsU0FBUyxFQUFFLElBSEw7QUFJTkMsUUFBQUEsY0FBYyxFQUFFLE9BSlY7QUFLTmMsUUFBQUEsT0FBTyxFQUFFLElBTEg7QUFNTmhDLFFBQUFBLE1BQU0sRUFBRTtBQUNOSCxVQUFBQSxJQUFJLEVBQUUsS0FEQTtBQUVOb0MsVUFBQUEsTUFBTSxFQUFFLElBRkY7QUFHTkMsVUFBQUEsVUFBVSxFQUFFLElBSE47QUFJTmhDLFVBQUFBLFFBQVEsRUFBRTtBQUpKO0FBTkY7QUE3QmUsS0FBZixDQUZIO0FBNkNQd0IsSUFBQUEsV0FBVyxFQUFFM0QsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDMUI0RSxNQUFBQSxHQUFHLEVBQUU7QUFBRXZFLFFBQUFBLE1BQU0sRUFBRTtBQUFFaUUsVUFBQUEsSUFBSSxFQUFFO0FBQUVDLFlBQUFBLFdBQVcsRUFBRSxDQUFmO0FBQWtCQyxZQUFBQSxTQUFTLEVBQUU7QUFBN0I7QUFBUjtBQUFWO0FBRHFCLEtBQWYsQ0E3Q047QUFnRFBiLElBQUFBLFdBQVcsRUFBRSxFQWhETjtBQWlEUEMsSUFBQUEsT0FBTyxFQUFFLENBakRGO0FBa0RQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQ2Q7QUFGbUI7QUFsRGhCLEdBRlg7QUF5REVDLEVBQUFBLEtBQUssRUFBRTtBQXpEVCxDQTllYSxFQXlpQmI7QUFDRXBFLEVBQUFBLEdBQUcsRUFBRSxxQ0FEUDtBQUVFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLFdBREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QkgsTUFBQUEsS0FBSyxFQUFFLDZCQURnQjtBQUV2QkksTUFBQUEsSUFBSSxFQUFFLFVBRmlCO0FBR3ZCQyxNQUFBQSxJQUFJLEVBQUUsQ0FDSjtBQUNFQyxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUUsRUFKVjtBQUtFQyxRQUFBQSxNQUFNLEVBQUU7QUFMVixPQURJLEVBUUo7QUFDRUgsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRUMsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUgsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRUksUUFBQUEsTUFBTSxFQUFFO0FBQ05FLFVBQUFBLEtBQUssRUFBRSx5Q0FERDtBQUVOVyxVQUFBQSxPQUFPLEVBQUUsR0FGSDtBQUdOQyxVQUFBQSxLQUFLLEVBQUUsTUFIRDtBQUlOQyxVQUFBQSxJQUFJLEVBQUUsRUFKQTtBQUtOQyxVQUFBQSxXQUFXLEVBQUUsS0FMUDtBQU1OQyxVQUFBQSxnQkFBZ0IsRUFBRSxPQU5aO0FBT05DLFVBQUFBLGFBQWEsRUFBRSxLQVBUO0FBUU5DLFVBQUFBLGtCQUFrQixFQUFFLFNBUmQ7QUFTTlAsVUFBQUEsV0FBVyxFQUFFO0FBVFAsU0FKVjtBQWVFWCxRQUFBQSxNQUFNLEVBQUU7QUFmVixPQVJJLENBSGlCO0FBNkJ2QkQsTUFBQUEsTUFBTSxFQUFFO0FBQ04wQixRQUFBQSxLQUFLLEVBQUUsUUFERDtBQUVOOEMsUUFBQUEsV0FBVyxFQUFFLFFBRlA7QUFHTkMsUUFBQUEsV0FBVyxFQUFFLEVBSFA7QUFJTkMsUUFBQUEsV0FBVyxFQUFFLEVBSlA7QUFLTkMsUUFBQUEsU0FBUyxFQUFFO0FBTEw7QUE3QmUsS0FBZixDQUZIO0FBdUNQdEIsSUFBQUEsV0FBVyxFQUFFM0QsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDMUI0RSxNQUFBQSxHQUFHLEVBQUU7QUFBRXZFLFFBQUFBLE1BQU0sRUFBRTtBQUFFaUUsVUFBQUEsSUFBSSxFQUFFO0FBQUVDLFlBQUFBLFdBQVcsRUFBRSxDQUFmO0FBQWtCQyxZQUFBQSxTQUFTLEVBQUU7QUFBN0I7QUFBUjtBQUFWO0FBRHFCLEtBQWYsQ0F2Q047QUEwQ1BiLElBQUFBLFdBQVcsRUFBRSxFQTFDTjtBQTJDUEMsSUFBQUEsT0FBTyxFQUFFLENBM0NGO0FBNENQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQ2Q7QUFGbUI7QUE1Q2hCLEdBRlg7QUFtREVDLEVBQUFBLEtBQUssRUFBRTtBQW5EVCxDQXppQmEsRUE4bEJiO0FBQ0VwRSxFQUFBQSxHQUFHLEVBQUUsc0NBRFA7QUFFRUMsRUFBQUEsT0FBTyxFQUFFO0FBQ1BDLElBQUFBLEtBQUssRUFBRSxtQkFEQTtBQUVQQyxJQUFBQSxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ3ZCSCxNQUFBQSxLQUFLLEVBQUUsbUJBRGdCO0FBRXZCSSxNQUFBQSxJQUFJLEVBQUUsS0FGaUI7QUFHdkJDLE1BQUFBLElBQUksRUFBRSxDQUNKO0FBQ0VDLFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUVDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0VILFFBQUFBLElBQUksRUFBRSxPQUhSO0FBSUVJLFFBQUFBLE1BQU0sRUFBRSxFQUpWO0FBS0VDLFFBQUFBLE1BQU0sRUFBRTtBQUxWLE9BREksRUFRSjtBQUNFSCxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUU7QUFDTkUsVUFBQUEsS0FBSyxFQUFFLG9CQUREO0FBRU5XLFVBQUFBLE9BQU8sRUFBRSxHQUZIO0FBR05DLFVBQUFBLEtBQUssRUFBRSxNQUhEO0FBSU5DLFVBQUFBLElBQUksRUFBRSxFQUpBO0FBS05DLFVBQUFBLFdBQVcsRUFBRSxLQUxQO0FBTU5DLFVBQUFBLGdCQUFnQixFQUFFLE9BTlo7QUFPTkMsVUFBQUEsYUFBYSxFQUFFLEtBUFQ7QUFRTkMsVUFBQUEsa0JBQWtCLEVBQUUsU0FSZDtBQVNOUCxVQUFBQSxXQUFXLEVBQUU7QUFUUCxTQUpWO0FBZUVYLFFBQUFBLE1BQU0sRUFBRTtBQWZWLE9BUkksQ0FIaUI7QUE2QnZCRCxNQUFBQSxNQUFNLEVBQUU7QUFDTkosUUFBQUEsSUFBSSxFQUFFLEtBREE7QUFFTitDLFFBQUFBLFVBQVUsRUFBRSxJQUZOO0FBR05DLFFBQUFBLFNBQVMsRUFBRSxJQUhMO0FBSU5DLFFBQUFBLGNBQWMsRUFBRSxPQUpWO0FBS05jLFFBQUFBLE9BQU8sRUFBRSxLQUxIO0FBTU5oQyxRQUFBQSxNQUFNLEVBQUU7QUFDTkgsVUFBQUEsSUFBSSxFQUFFLEtBREE7QUFFTm9DLFVBQUFBLE1BQU0sRUFBRSxJQUZGO0FBR05DLFVBQUFBLFVBQVUsRUFBRSxJQUhOO0FBSU5oQyxVQUFBQSxRQUFRLEVBQUU7QUFKSjtBQU5GO0FBN0JlLEtBQWYsQ0FGSDtBQTZDUHdCLElBQUFBLFdBQVcsRUFBRTNELElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQzFCNEUsTUFBQUEsR0FBRyxFQUFFO0FBQUV2RSxRQUFBQSxNQUFNLEVBQUU7QUFBRWlFLFVBQUFBLElBQUksRUFBRTtBQUFFQyxZQUFBQSxXQUFXLEVBQUUsQ0FBZjtBQUFrQkMsWUFBQUEsU0FBUyxFQUFFO0FBQTdCO0FBQVI7QUFBVjtBQURxQixLQUFmLENBN0NOO0FBZ0RQYixJQUFBQSxXQUFXLEVBQUUsRUFoRE47QUFpRFBDLElBQUFBLE9BQU8sRUFBRSxDQWpERjtBQWtEUEMsSUFBQUEscUJBQXFCLEVBQUU7QUFDckJDLE1BQUFBLGdCQUFnQixFQUNkO0FBRm1CO0FBbERoQixHQUZYO0FBeURFQyxFQUFBQSxLQUFLLEVBQUU7QUF6RFQsQ0E5bEJhLEVBeXBCYjtBQUNFcEUsRUFBQUEsR0FBRyxFQUFFLGlDQURQO0FBRUVDLEVBQUFBLE9BQU8sRUFBRTtBQUNQQyxJQUFBQSxLQUFLLEVBQUUsY0FEQTtBQUVQQyxJQUFBQSxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ3ZCSCxNQUFBQSxLQUFLLEVBQUUsY0FEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxRQUZpQjtBQUd2QkMsTUFBQUEsSUFBSSxFQUFFLENBQ0o7QUFDRUMsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRUMsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUgsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRUksUUFBQUEsTUFBTSxFQUFFO0FBQ05ZLFVBQUFBLFdBQVcsRUFBRTtBQURQLFNBSlY7QUFPRVgsUUFBQUEsTUFBTSxFQUFFO0FBUFYsT0FESSxFQVVKO0FBQ0VILFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUVDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0VILFFBQUFBLElBQUksRUFBRSxVQUhSO0FBSUVJLFFBQUFBLE1BQU0sRUFBRTtBQUNORSxVQUFBQSxLQUFLLEVBQUUsWUFERDtBQUVOMEUsVUFBQUEsU0FBUyxFQUFFLFFBRkw7QUFHTjdELFVBQUFBLElBQUksRUFBRSxDQUhBO0FBSU44RCxVQUFBQSxTQUFTLEVBQUUsWUFKTDtBQUtOQyxVQUFBQSxTQUFTLEVBQUUsTUFMTDtBQU1ObEUsVUFBQUEsV0FBVyxFQUFFO0FBTlAsU0FKVjtBQVlFWCxRQUFBQSxNQUFNLEVBQUU7QUFaVixPQVZJLENBSGlCO0FBNEJ2QkQsTUFBQUEsTUFBTSxFQUFFO0FBQ04yQyxRQUFBQSxVQUFVLEVBQUUsSUFETjtBQUVOQyxRQUFBQSxTQUFTLEVBQUUsS0FGTDtBQUdOaEQsUUFBQUEsSUFBSSxFQUFFLFFBSEE7QUFJTm1GLFFBQUFBLE1BQU0sRUFBRTtBQUNOQyxVQUFBQSxjQUFjLEVBQUUsS0FEVjtBQUVOQyxVQUFBQSxTQUFTLEVBQUUsS0FGTDtBQUdOQyxVQUFBQSxXQUFXLEVBQUUsY0FIUDtBQUlOQyxVQUFBQSxlQUFlLEVBQUUsTUFKWDtBQUtOQyxVQUFBQSxXQUFXLEVBQUUsQ0FDWDtBQUNFaEYsWUFBQUEsSUFBSSxFQUFFLENBRFI7QUFFRUMsWUFBQUEsRUFBRSxFQUFFO0FBRk4sV0FEVyxDQUxQO0FBV05zQixVQUFBQSxNQUFNLEVBQUU7QUFDTkgsWUFBQUEsSUFBSSxFQUFFO0FBREEsV0FYRjtBQWNONkQsVUFBQUEsWUFBWSxFQUFFLEtBZFI7QUFlTjVELFVBQUFBLEtBQUssRUFBRTtBQUNMNkQsWUFBQUEsTUFBTSxFQUFFLE1BREg7QUFFTEMsWUFBQUEsT0FBTyxFQUFFLEtBRko7QUFHTEMsWUFBQUEsVUFBVSxFQUFFLEtBSFA7QUFJTEMsWUFBQUEsT0FBTyxFQUFFLEVBSko7QUFLTEMsWUFBQUEsUUFBUSxFQUFFO0FBTEw7QUFmRDtBQUpGO0FBNUJlLEtBQWYsQ0FGSDtBQTJEUHJDLElBQUFBLFdBQVcsRUFBRTNELElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQzFCNEUsTUFBQUEsR0FBRyxFQUFFO0FBQUV2RSxRQUFBQSxNQUFNLEVBQUU7QUFBRWlFLFVBQUFBLElBQUksRUFBRTtBQUFFQyxZQUFBQSxXQUFXLEVBQUUsQ0FBZjtBQUFrQkMsWUFBQUEsU0FBUyxFQUFFO0FBQTdCO0FBQVI7QUFBVjtBQURxQixLQUFmLENBM0ROO0FBOERQYixJQUFBQSxXQUFXLEVBQUUsRUE5RE47QUErRFBDLElBQUFBLE9BQU8sRUFBRSxDQS9ERjtBQWdFUEMsSUFBQUEscUJBQXFCLEVBQUU7QUFDckJDLE1BQUFBLGdCQUFnQixFQUNkO0FBRm1CO0FBaEVoQixHQUZYO0FBdUVFQyxFQUFBQSxLQUFLLEVBQUU7QUF2RVQsQ0F6cEJhLEVBa3VCYjtBQUNFcEUsRUFBQUEsR0FBRyxFQUFFLGdEQURQO0FBRUVDLEVBQUFBLE9BQU8sRUFBRTtBQUNQQyxJQUFBQSxLQUFLLEVBQUUsNkJBREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QkgsTUFBQUEsS0FBSyxFQUFFLDZCQURnQjtBQUV2QkksTUFBQUEsSUFBSSxFQUFFLFNBRmlCO0FBR3ZCQyxNQUFBQSxJQUFJLEVBQUUsQ0FDSjtBQUNFQyxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUUsRUFKVjtBQUtFQyxRQUFBQSxNQUFNLEVBQUU7QUFMVixPQURJLEVBUUo7QUFDRUgsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRUMsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUgsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRUksUUFBQUEsTUFBTSxFQUFFO0FBQ05FLFVBQUFBLEtBQUssRUFBRSxpQkFERDtBQUVOVyxVQUFBQSxPQUFPLEVBQUUsR0FGSDtBQUdOQyxVQUFBQSxLQUFLLEVBQUUsTUFIRDtBQUlOQyxVQUFBQSxJQUFJLEVBQUUsRUFKQTtBQUtOQyxVQUFBQSxXQUFXLEVBQUUsS0FMUDtBQU1OQyxVQUFBQSxnQkFBZ0IsRUFBRSxPQU5aO0FBT05DLFVBQUFBLGFBQWEsRUFBRSxLQVBUO0FBUU5DLFVBQUFBLGtCQUFrQixFQUFFO0FBUmQsU0FKVjtBQWNFbEIsUUFBQUEsTUFBTSxFQUFFO0FBZFYsT0FSSSxFQXdCSjtBQUNFSCxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUU7QUFDTkUsVUFBQUEsS0FBSyxFQUFFLG9CQUREO0FBRU5XLFVBQUFBLE9BQU8sRUFBRSxHQUZIO0FBR05DLFVBQUFBLEtBQUssRUFBRSxNQUhEO0FBSU5DLFVBQUFBLElBQUksRUFBRSxDQUpBO0FBS05DLFVBQUFBLFdBQVcsRUFBRSxLQUxQO0FBTU5DLFVBQUFBLGdCQUFnQixFQUFFLE9BTlo7QUFPTkMsVUFBQUEsYUFBYSxFQUFFLEtBUFQ7QUFRTkMsVUFBQUEsa0JBQWtCLEVBQUU7QUFSZCxTQUpWO0FBY0VsQixRQUFBQSxNQUFNLEVBQUU7QUFkVixPQXhCSSxDQUhpQjtBQTRDdkJELE1BQUFBLE1BQU0sRUFBRTtBQUNOSixRQUFBQSxJQUFJLEVBQUUsU0FEQTtBQUVOK0MsUUFBQUEsVUFBVSxFQUFFLElBRk47QUFHTkMsUUFBQUEsU0FBUyxFQUFFLElBSEw7QUFJTitDLFFBQUFBLFdBQVcsRUFBRSxLQUpQO0FBS045QyxRQUFBQSxjQUFjLEVBQUUsT0FMVjtBQU1OQyxRQUFBQSxLQUFLLEVBQUUsRUFORDtBQU9OOEMsUUFBQUEsWUFBWSxFQUFFLENBUFI7QUFRTlYsUUFBQUEsV0FBVyxFQUFFLE9BUlA7QUFTTlcsUUFBQUEsYUFBYSxFQUFFLEtBVFQ7QUFVTlQsUUFBQUEsV0FBVyxFQUFFLEVBVlA7QUFXTkMsUUFBQUEsWUFBWSxFQUFFLEtBWFI7QUFZTkwsUUFBQUEsY0FBYyxFQUFFLEtBWlY7QUFhTmpELFFBQUFBLFNBQVMsRUFBRSxDQUNUO0FBQ0VQLFVBQUFBLElBQUksRUFBRSxLQURSO0FBRUUxQixVQUFBQSxFQUFFLEVBQUUsYUFGTjtBQUdFRixVQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFOEIsVUFBQUEsS0FBSyxFQUFFO0FBQ0w5QixZQUFBQSxJQUFJLEVBQUUsUUFERDtBQUVMa0csWUFBQUEsZUFBZSxFQUFFO0FBRlosV0FKVDtBQVFFbkUsVUFBQUEsTUFBTSxFQUFFO0FBQ05ILFlBQUFBLElBQUksRUFBRSxLQURBO0FBRU5NLFlBQUFBLE1BQU0sRUFBRSxDQUZGO0FBR05pRSxZQUFBQSxjQUFjLEVBQUUsS0FIVjtBQUlONUMsWUFBQUEsS0FBSyxFQUFFO0FBSkQ7QUFSVixTQURTO0FBYkw7QUE1Q2UsS0FBZixDQUZIO0FBOEVQRSxJQUFBQSxXQUFXLEVBQUUzRCxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUMxQjRFLE1BQUFBLEdBQUcsRUFBRTtBQUFFdkUsUUFBQUEsTUFBTSxFQUFFO0FBQUVpRSxVQUFBQSxJQUFJLEVBQUU7QUFBRUMsWUFBQUEsV0FBVyxFQUFFLENBQWY7QUFBa0JDLFlBQUFBLFNBQVMsRUFBRTtBQUE3QjtBQUFSO0FBQVY7QUFEcUIsS0FBZixDQTlFTjtBQWlGUGIsSUFBQUEsV0FBVyxFQUFFLEVBakZOO0FBa0ZQQyxJQUFBQSxPQUFPLEVBQUUsQ0FsRkY7QUFtRlBDLElBQUFBLHFCQUFxQixFQUFFO0FBQ3JCQyxNQUFBQSxnQkFBZ0IsRUFDZDtBQUZtQjtBQW5GaEIsR0FGWDtBQTBGRUMsRUFBQUEsS0FBSyxFQUFFO0FBMUZULENBbHVCYSxFQTh6QmI7QUFDRXBFLEVBQUFBLEdBQUcsRUFBRSxpREFEUDtBQUVFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLDZCQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSxzQkFEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxLQUZpQjtBQUd2QkMsTUFBQUEsSUFBSSxFQUFFLENBQ0o7QUFDRUMsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRUMsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUgsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRUksUUFBQUEsTUFBTSxFQUFFLEVBSlY7QUFLRUMsUUFBQUEsTUFBTSxFQUFFO0FBTFYsT0FESSxFQVFKO0FBQ0VILFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUVDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0VILFFBQUFBLElBQUksRUFBRSxPQUhSO0FBSUVJLFFBQUFBLE1BQU0sRUFBRTtBQUNORSxVQUFBQSxLQUFLLEVBQUUsaUJBREQ7QUFFTlcsVUFBQUEsT0FBTyxFQUFFLEdBRkg7QUFHTkMsVUFBQUEsS0FBSyxFQUFFLE1BSEQ7QUFJTkMsVUFBQUEsSUFBSSxFQUFFLEVBSkE7QUFLTkMsVUFBQUEsV0FBVyxFQUFFLEtBTFA7QUFNTkMsVUFBQUEsZ0JBQWdCLEVBQUUsT0FOWjtBQU9OQyxVQUFBQSxhQUFhLEVBQUUsS0FQVDtBQVFOQyxVQUFBQSxrQkFBa0IsRUFBRSxTQVJkO0FBU05QLFVBQUFBLFdBQVcsRUFBRTtBQVRQLFNBSlY7QUFlRVgsUUFBQUEsTUFBTSxFQUFFO0FBZlYsT0FSSSxDQUhpQjtBQTZCdkJELE1BQUFBLE1BQU0sRUFBRTtBQUNOSixRQUFBQSxJQUFJLEVBQUUsS0FEQTtBQUVOK0MsUUFBQUEsVUFBVSxFQUFFLElBRk47QUFHTkMsUUFBQUEsU0FBUyxFQUFFLElBSEw7QUFJTkMsUUFBQUEsY0FBYyxFQUFFLE9BSlY7QUFLTmMsUUFBQUEsT0FBTyxFQUFFLElBTEg7QUFNTmhDLFFBQUFBLE1BQU0sRUFBRTtBQUNOSCxVQUFBQSxJQUFJLEVBQUUsS0FEQTtBQUVOb0MsVUFBQUEsTUFBTSxFQUFFLElBRkY7QUFHTkMsVUFBQUEsVUFBVSxFQUFFLElBSE47QUFJTmhDLFVBQUFBLFFBQVEsRUFBRTtBQUpKO0FBTkY7QUE3QmUsS0FBZixDQUZIO0FBNkNQd0IsSUFBQUEsV0FBVyxFQUFFM0QsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDMUI0RSxNQUFBQSxHQUFHLEVBQUU7QUFBRXZFLFFBQUFBLE1BQU0sRUFBRTtBQUFFaUUsVUFBQUEsSUFBSSxFQUFFO0FBQUVDLFlBQUFBLFdBQVcsRUFBRSxDQUFmO0FBQWtCQyxZQUFBQSxTQUFTLEVBQUU7QUFBN0I7QUFBUjtBQUFWO0FBRHFCLEtBQWYsQ0E3Q047QUFnRFBiLElBQUFBLFdBQVcsRUFBRSxFQWhETjtBQWlEUEMsSUFBQUEsT0FBTyxFQUFFLENBakRGO0FBa0RQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQ2Q7QUFGbUI7QUFsRGhCLEdBRlg7QUF5REVDLEVBQUFBLEtBQUssRUFBRTtBQXpEVCxDQTl6QmEsRUF5M0JiO0FBQ0VwRSxFQUFBQSxHQUFHLEVBQUUsMENBRFA7QUFFRUMsRUFBQUEsT0FBTyxFQUFFO0FBQ1BDLElBQUFBLEtBQUssRUFBRSxlQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSxlQURnQjtBQUV2QkksTUFBQUEsSUFBSSxFQUFFLEtBRmlCO0FBR3ZCQyxNQUFBQSxJQUFJLEVBQUUsQ0FDSjtBQUNFQyxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUUsRUFKVjtBQUtFQyxRQUFBQSxNQUFNLEVBQUU7QUFMVixPQURJLEVBUUo7QUFDRUgsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRUMsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUgsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRUksUUFBQUEsTUFBTSxFQUFFO0FBQ05FLFVBQUFBLEtBQUssRUFBRSxtQkFERDtBQUVOVyxVQUFBQSxPQUFPLEVBQUUsR0FGSDtBQUdOQyxVQUFBQSxLQUFLLEVBQUUsTUFIRDtBQUlOQyxVQUFBQSxJQUFJLEVBQUUsRUFKQTtBQUtOQyxVQUFBQSxXQUFXLEVBQUUsS0FMUDtBQU1OQyxVQUFBQSxnQkFBZ0IsRUFBRSxPQU5aO0FBT05DLFVBQUFBLGFBQWEsRUFBRSxLQVBUO0FBUU5DLFVBQUFBLGtCQUFrQixFQUFFLFNBUmQ7QUFTTlAsVUFBQUEsV0FBVyxFQUFFO0FBVFAsU0FKVjtBQWVFWCxRQUFBQSxNQUFNLEVBQUU7QUFmVixPQVJJLENBSGlCO0FBNkJ2QkQsTUFBQUEsTUFBTSxFQUFFO0FBQ05KLFFBQUFBLElBQUksRUFBRSxLQURBO0FBRU4rQyxRQUFBQSxVQUFVLEVBQUUsSUFGTjtBQUdOQyxRQUFBQSxTQUFTLEVBQUUsSUFITDtBQUlOQyxRQUFBQSxjQUFjLEVBQUUsT0FKVjtBQUtOYyxRQUFBQSxPQUFPLEVBQUUsSUFMSDtBQU1OaEMsUUFBQUEsTUFBTSxFQUFFO0FBQ05ILFVBQUFBLElBQUksRUFBRSxLQURBO0FBRU5vQyxVQUFBQSxNQUFNLEVBQUUsSUFGRjtBQUdOQyxVQUFBQSxVQUFVLEVBQUUsSUFITjtBQUlOaEMsVUFBQUEsUUFBUSxFQUFFO0FBSko7QUFORjtBQTdCZSxLQUFmLENBRkg7QUE2Q1B3QixJQUFBQSxXQUFXLEVBQUUzRCxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUMxQjRFLE1BQUFBLEdBQUcsRUFBRTtBQUFFdkUsUUFBQUEsTUFBTSxFQUFFO0FBQUVpRSxVQUFBQSxJQUFJLEVBQUU7QUFBRUMsWUFBQUEsV0FBVyxFQUFFLENBQWY7QUFBa0JDLFlBQUFBLFNBQVMsRUFBRTtBQUE3QjtBQUFSO0FBQVY7QUFEcUIsS0FBZixDQTdDTjtBQWdEUGIsSUFBQUEsV0FBVyxFQUFFLEVBaEROO0FBaURQQyxJQUFBQSxPQUFPLEVBQUUsQ0FqREY7QUFrRFBDLElBQUFBLHFCQUFxQixFQUFFO0FBQ3JCQyxNQUFBQSxnQkFBZ0IsRUFDZDtBQUZtQjtBQWxEaEIsR0FGWDtBQXlERUMsRUFBQUEsS0FBSyxFQUFFO0FBekRULENBejNCYSxFQW83QmI7QUFDRXBFLEVBQUFBLEdBQUcsRUFBRSxnREFEUDtBQUVFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLHFCQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSxxQkFEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxLQUZpQjtBQUd2QkMsTUFBQUEsSUFBSSxFQUFFLENBQ0o7QUFDRUMsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRUMsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUgsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRUksUUFBQUEsTUFBTSxFQUFFLEVBSlY7QUFLRUMsUUFBQUEsTUFBTSxFQUFFO0FBTFYsT0FESSxFQVFKO0FBQ0VILFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUVDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0VILFFBQUFBLElBQUksRUFBRSxPQUhSO0FBSUVJLFFBQUFBLE1BQU0sRUFBRTtBQUNORSxVQUFBQSxLQUFLLEVBQUUsa0JBREQ7QUFFTlcsVUFBQUEsT0FBTyxFQUFFLEdBRkg7QUFHTkMsVUFBQUEsS0FBSyxFQUFFLE1BSEQ7QUFJTkMsVUFBQUEsSUFBSSxFQUFFLEVBSkE7QUFLTkMsVUFBQUEsV0FBVyxFQUFFLEtBTFA7QUFNTkMsVUFBQUEsZ0JBQWdCLEVBQUUsT0FOWjtBQU9OQyxVQUFBQSxhQUFhLEVBQUUsS0FQVDtBQVFOQyxVQUFBQSxrQkFBa0IsRUFBRSxTQVJkO0FBU05QLFVBQUFBLFdBQVcsRUFBRTtBQVRQLFNBSlY7QUFlRVgsUUFBQUEsTUFBTSxFQUFFO0FBZlYsT0FSSSxDQUhpQjtBQTZCdkJELE1BQUFBLE1BQU0sRUFBRTtBQUNOSixRQUFBQSxJQUFJLEVBQUUsS0FEQTtBQUVOK0MsUUFBQUEsVUFBVSxFQUFFLElBRk47QUFHTkMsUUFBQUEsU0FBUyxFQUFFLElBSEw7QUFJTkMsUUFBQUEsY0FBYyxFQUFFLE9BSlY7QUFLTmMsUUFBQUEsT0FBTyxFQUFFLElBTEg7QUFNTmhDLFFBQUFBLE1BQU0sRUFBRTtBQUNOSCxVQUFBQSxJQUFJLEVBQUUsS0FEQTtBQUVOb0MsVUFBQUEsTUFBTSxFQUFFLElBRkY7QUFHTkMsVUFBQUEsVUFBVSxFQUFFLElBSE47QUFJTmhDLFVBQUFBLFFBQVEsRUFBRTtBQUpKO0FBTkY7QUE3QmUsS0FBZixDQUZIO0FBNkNQd0IsSUFBQUEsV0FBVyxFQUFFM0QsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDMUI0RSxNQUFBQSxHQUFHLEVBQUU7QUFBRXZFLFFBQUFBLE1BQU0sRUFBRTtBQUFFaUUsVUFBQUEsSUFBSSxFQUFFO0FBQUVDLFlBQUFBLFdBQVcsRUFBRSxDQUFmO0FBQWtCQyxZQUFBQSxTQUFTLEVBQUU7QUFBN0I7QUFBUjtBQUFWO0FBRHFCLEtBQWYsQ0E3Q047QUFnRFBiLElBQUFBLFdBQVcsRUFBRSxFQWhETjtBQWlEUEMsSUFBQUEsT0FBTyxFQUFFLENBakRGO0FBa0RQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQ2Q7QUFGbUI7QUFsRGhCLEdBRlg7QUF5REVDLEVBQUFBLEtBQUssRUFBRTtBQXpEVCxDQXA3QmEsRUErK0JiO0FBQ0VwRSxFQUFBQSxHQUFHLEVBQUUsMkNBRFA7QUFFRUMsRUFBQUEsT0FBTyxFQUFFO0FBQ1BDLElBQUFBLEtBQUssRUFBRSxnQkFEQTtBQUVQQyxJQUFBQSxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ3ZCSCxNQUFBQSxLQUFLLEVBQUUsZ0JBRGdCO0FBRXZCSSxNQUFBQSxJQUFJLEVBQUUsS0FGaUI7QUFHdkJDLE1BQUFBLElBQUksRUFBRSxDQUNKO0FBQ0VDLFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUVDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0VILFFBQUFBLElBQUksRUFBRSxPQUhSO0FBSUVJLFFBQUFBLE1BQU0sRUFBRSxFQUpWO0FBS0VDLFFBQUFBLE1BQU0sRUFBRTtBQUxWLE9BREksRUFRSjtBQUNFSCxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUU7QUFDTkUsVUFBQUEsS0FBSyxFQUFFLG9CQUREO0FBRU5XLFVBQUFBLE9BQU8sRUFBRSxHQUZIO0FBR05DLFVBQUFBLEtBQUssRUFBRSxNQUhEO0FBSU5DLFVBQUFBLElBQUksRUFBRSxFQUpBO0FBS05DLFVBQUFBLFdBQVcsRUFBRSxLQUxQO0FBTU5DLFVBQUFBLGdCQUFnQixFQUFFLE9BTlo7QUFPTkMsVUFBQUEsYUFBYSxFQUFFLEtBUFQ7QUFRTkMsVUFBQUEsa0JBQWtCLEVBQUUsU0FSZDtBQVNOUCxVQUFBQSxXQUFXLEVBQUU7QUFUUCxTQUpWO0FBZUVYLFFBQUFBLE1BQU0sRUFBRTtBQWZWLE9BUkksQ0FIaUI7QUE2QnZCRCxNQUFBQSxNQUFNLEVBQUU7QUFDTkosUUFBQUEsSUFBSSxFQUFFLEtBREE7QUFFTitDLFFBQUFBLFVBQVUsRUFBRSxJQUZOO0FBR05DLFFBQUFBLFNBQVMsRUFBRSxJQUhMO0FBSU5DLFFBQUFBLGNBQWMsRUFBRSxPQUpWO0FBS05jLFFBQUFBLE9BQU8sRUFBRSxJQUxIO0FBTU5oQyxRQUFBQSxNQUFNLEVBQUU7QUFDTkgsVUFBQUEsSUFBSSxFQUFFLEtBREE7QUFFTm9DLFVBQUFBLE1BQU0sRUFBRSxJQUZGO0FBR05DLFVBQUFBLFVBQVUsRUFBRSxJQUhOO0FBSU5oQyxVQUFBQSxRQUFRLEVBQUU7QUFKSjtBQU5GO0FBN0JlLEtBQWYsQ0FGSDtBQTZDUHdCLElBQUFBLFdBQVcsRUFBRTNELElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQzFCNEUsTUFBQUEsR0FBRyxFQUFFO0FBQUV2RSxRQUFBQSxNQUFNLEVBQUU7QUFBRWlFLFVBQUFBLElBQUksRUFBRTtBQUFFQyxZQUFBQSxXQUFXLEVBQUUsQ0FBZjtBQUFrQkMsWUFBQUEsU0FBUyxFQUFFO0FBQTdCO0FBQVI7QUFBVjtBQURxQixLQUFmLENBN0NOO0FBZ0RQYixJQUFBQSxXQUFXLEVBQUUsRUFoRE47QUFpRFBDLElBQUFBLE9BQU8sRUFBRSxDQWpERjtBQWtEUEMsSUFBQUEscUJBQXFCLEVBQUU7QUFDckJDLE1BQUFBLGdCQUFnQixFQUNkO0FBRm1CO0FBbERoQixHQUZYO0FBeURFQyxFQUFBQSxLQUFLLEVBQUU7QUF6RFQsQ0EvK0JhLEVBMGlDYjtBQUNFcEUsRUFBQUEsR0FBRyxFQUFFLGlEQURQO0FBRUVDLEVBQUFBLE9BQU8sRUFBRTtBQUNQQyxJQUFBQSxLQUFLLEVBQUUsdUJBREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QkgsTUFBQUEsS0FBSyxFQUFFLHNCQURnQjtBQUV2QkksTUFBQUEsSUFBSSxFQUFFLE1BRmlCO0FBR3ZCQyxNQUFBQSxJQUFJLEVBQUUsQ0FDSjtBQUNFQyxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFQyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFSCxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFSSxRQUFBQSxNQUFNLEVBQUUsRUFKVjtBQUtFQyxRQUFBQSxNQUFNLEVBQUU7QUFMVixPQURJLEVBUUo7QUFDRUgsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRUMsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRUgsUUFBQUEsSUFBSSxFQUFFLGdCQUhSO0FBSUVJLFFBQUFBLE1BQU0sRUFBRTtBQUNORSxVQUFBQSxLQUFLLEVBQUUsV0FERDtBQUVOQyxVQUFBQSxTQUFTLEVBQUU7QUFDVEMsWUFBQUEsSUFBSSxFQUFFLFNBREc7QUFFVEMsWUFBQUEsRUFBRSxFQUFFO0FBRkssV0FGTDtBQU1OQyxVQUFBQSx1QkFBdUIsRUFBRSxJQU5uQjtBQU9OQyxVQUFBQSxpQkFBaUIsRUFBRSxLQVBiO0FBUU5DLFVBQUFBLFFBQVEsRUFBRSxHQVJKO0FBU05DLFVBQUFBLGFBQWEsRUFBRSxLQVRUO0FBVU5DLFVBQUFBLGFBQWEsRUFBRSxDQVZUO0FBV05DLFVBQUFBLGVBQWUsRUFBRTtBQVhYLFNBSlY7QUFpQkVWLFFBQUFBLE1BQU0sRUFBRTtBQWpCVixPQVJJLEVBMkJKO0FBQ0VILFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUVDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0VILFFBQUFBLElBQUksRUFBRSxPQUhSO0FBSUVJLFFBQUFBLE1BQU0sRUFBRTtBQUNORSxVQUFBQSxLQUFLLEVBQUUsWUFERDtBQUVOVyxVQUFBQSxPQUFPLEVBQUUsR0FGSDtBQUdOQyxVQUFBQSxLQUFLLEVBQUUsTUFIRDtBQUlOQyxVQUFBQSxJQUFJLEVBQUUsRUFKQTtBQUtOQyxVQUFBQSxXQUFXLEVBQUUsS0FMUDtBQU1OQyxVQUFBQSxnQkFBZ0IsRUFBRSxPQU5aO0FBT05DLFVBQUFBLGFBQWEsRUFBRSxLQVBUO0FBUU5DLFVBQUFBLGtCQUFrQixFQUFFO0FBUmQsU0FKVjtBQWNFbEIsUUFBQUEsTUFBTSxFQUFFO0FBZFYsT0EzQkksQ0FIaUI7QUErQ3ZCRCxNQUFBQSxNQUFNLEVBQUU7QUFDTkosUUFBQUEsSUFBSSxFQUFFLE1BREE7QUFFTndCLFFBQUFBLElBQUksRUFBRTtBQUNKQyxVQUFBQSxhQUFhLEVBQUU7QUFEWCxTQUZBO0FBS05DLFFBQUFBLFlBQVksRUFBRSxDQUNaO0FBQ0V4QixVQUFBQSxFQUFFLEVBQUUsZ0JBRE47QUFFRUYsVUFBQUEsSUFBSSxFQUFFLFVBRlI7QUFHRTJCLFVBQUFBLFFBQVEsRUFBRSxRQUhaO0FBSUVDLFVBQUFBLElBQUksRUFBRSxJQUpSO0FBS0VDLFVBQUFBLEtBQUssRUFBRSxFQUxUO0FBTUVDLFVBQUFBLEtBQUssRUFBRTtBQUNMOUIsWUFBQUEsSUFBSSxFQUFFO0FBREQsV0FOVDtBQVNFK0IsVUFBQUEsTUFBTSxFQUFFO0FBQ05ILFlBQUFBLElBQUksRUFBRSxJQURBO0FBRU5JLFlBQUFBLE1BQU0sRUFBRSxJQUZGO0FBR05DLFlBQUFBLFFBQVEsRUFBRTtBQUhKLFdBVFY7QUFjRXJDLFVBQUFBLEtBQUssRUFBRTtBQWRULFNBRFksQ0FMUjtBQXVCTnVDLFFBQUFBLFNBQVMsRUFBRSxDQUNUO0FBQ0VqQyxVQUFBQSxFQUFFLEVBQUUsYUFETjtBQUVFa0MsVUFBQUEsSUFBSSxFQUFFLFlBRlI7QUFHRXBDLFVBQUFBLElBQUksRUFBRSxPQUhSO0FBSUUyQixVQUFBQSxRQUFRLEVBQUUsTUFKWjtBQUtFQyxVQUFBQSxJQUFJLEVBQUUsSUFMUjtBQU1FQyxVQUFBQSxLQUFLLEVBQUUsRUFOVDtBQU9FQyxVQUFBQSxLQUFLLEVBQUU7QUFDTDlCLFlBQUFBLElBQUksRUFBRSxRQUREO0FBRUxxQyxZQUFBQSxJQUFJLEVBQUU7QUFGRCxXQVBUO0FBV0VOLFVBQUFBLE1BQU0sRUFBRTtBQUNOSCxZQUFBQSxJQUFJLEVBQUUsSUFEQTtBQUVOTSxZQUFBQSxNQUFNLEVBQUUsQ0FGRjtBQUdORixZQUFBQSxNQUFNLEVBQUUsS0FIRjtBQUlOQyxZQUFBQSxRQUFRLEVBQUU7QUFKSixXQVhWO0FBaUJFckMsVUFBQUEsS0FBSyxFQUFFO0FBQ0wwQyxZQUFBQSxJQUFJLEVBQUU7QUFERDtBQWpCVCxTQURTLENBdkJMO0FBOENOQyxRQUFBQSxZQUFZLEVBQUUsQ0FDWjtBQUNFWCxVQUFBQSxJQUFJLEVBQUUsSUFEUjtBQUVFNUIsVUFBQUEsSUFBSSxFQUFFLE1BRlI7QUFHRXFDLFVBQUFBLElBQUksRUFBRSxTQUhSO0FBSUVHLFVBQUFBLElBQUksRUFBRTtBQUNKQyxZQUFBQSxLQUFLLEVBQUUsT0FESDtBQUVKdkMsWUFBQUEsRUFBRSxFQUFFO0FBRkEsV0FKUjtBQVFFd0MsVUFBQUEsc0JBQXNCLEVBQUUsSUFSMUI7QUFTRUMsVUFBQUEsU0FBUyxFQUFFLENBVGI7QUFVRUMsVUFBQUEsV0FBVyxFQUFFLElBVmY7QUFXRUMsVUFBQUEsV0FBVyxFQUFFLFlBWGY7QUFZRUMsVUFBQUEsU0FBUyxFQUFFO0FBWmIsU0FEWSxDQTlDUjtBQThETkMsUUFBQUEsVUFBVSxFQUFFLElBOUROO0FBK0ROQyxRQUFBQSxTQUFTLEVBQUUsSUEvREw7QUFnRU5DLFFBQUFBLGNBQWMsRUFBRSxPQWhFVjtBQWlFTkMsUUFBQUEsS0FBSyxFQUFFLEVBakVEO0FBa0VOQyxRQUFBQSxhQUFhLEVBQUUsS0FsRVQ7QUFtRU5DLFFBQUFBLGFBQWEsRUFBRTtBQUNieEIsVUFBQUEsSUFBSSxFQUFFLEtBRE87QUFFYnlCLFVBQUFBLEtBQUssRUFBRSxFQUZNO0FBR2JDLFVBQUFBLEtBQUssRUFBRSxDQUhNO0FBSWJ6QixVQUFBQSxLQUFLLEVBQUUsTUFKTTtBQUtiMEIsVUFBQUEsS0FBSyxFQUFFO0FBTE0sU0FuRVQ7QUEwRU54QixRQUFBQSxNQUFNLEVBQUU7QUExRUY7QUEvQ2UsS0FBZixDQUZIO0FBOEhQMEIsSUFBQUEsV0FBVyxFQUFFM0QsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDMUI0RSxNQUFBQSxHQUFHLEVBQUU7QUFBRXZFLFFBQUFBLE1BQU0sRUFBRTtBQUFFaUUsVUFBQUEsSUFBSSxFQUFFO0FBQUVDLFlBQUFBLFdBQVcsRUFBRSxDQUFmO0FBQWtCQyxZQUFBQSxTQUFTLEVBQUU7QUFBN0I7QUFBUjtBQUFWO0FBRHFCLEtBQWYsQ0E5SE47QUFpSVBiLElBQUFBLFdBQVcsRUFBRSxFQWpJTjtBQWtJUEMsSUFBQUEsT0FBTyxFQUFFLENBbElGO0FBbUlQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQ2Q7QUFGbUI7QUFuSWhCLEdBRlg7QUEwSUVDLEVBQUFBLEtBQUssRUFBRTtBQTFJVCxDQTFpQ2EsQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXHJcbiAqIFdhenVoIGFwcCAtIE1vZHVsZSBmb3IgT3ZlcnZpZXcvR2l0SHViIHZpc3VhbGl6YXRpb25zXHJcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXHJcbiAqXHJcbiAqIFRoaXMgcHJvZ3JhbSBpcyBmcmVlIHNvZnR3YXJlOyB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XHJcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XHJcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXHJcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXHJcbiAqXHJcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXHJcbiAqL1xyXG5leHBvcnQgZGVmYXVsdCBbXHJcbiAge1xyXG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1BbGVydHMtRXZvbHV0aW9uLUJ5LU9yZ2FuaXphdGlvbicsXHJcbiAgICBfc291cmNlOiB7XHJcbiAgICAgIHRpdGxlOiAnQWxlcnRzIGV2b2x1dGlvbiBieSBvcmdhbml6YXRpb24nLFxyXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHRpdGxlOiAnQWxlcnRzIGV2b2x1dGlvbiBieSBvcmdhbml6YXRpb24nLFxyXG4gICAgICAgIHR5cGU6ICdhcmVhJyxcclxuICAgICAgICBhZ2dzOiBbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMScsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXHJcbiAgICAgICAgICAgIHBhcmFtczoge30sXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzInLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAnZGF0ZV9oaXN0b2dyYW0nLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ3RpbWVzdGFtcCcsXHJcbiAgICAgICAgICAgICAgdGltZVJhbmdlOiB7XHJcbiAgICAgICAgICAgICAgICBmcm9tOiAnbm93LTdkJyxcclxuICAgICAgICAgICAgICAgIHRvOiAnbm93JyxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIHVzZU5vcm1hbGl6ZWRFc0ludGVydmFsOiB0cnVlLFxyXG4gICAgICAgICAgICAgIHNjYWxlTWV0cmljVmFsdWVzOiBmYWxzZSxcclxuICAgICAgICAgICAgICBpbnRlcnZhbDogJ2F1dG8nLFxyXG4gICAgICAgICAgICAgIGRyb3BfcGFydGlhbHM6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG1pbl9kb2NfY291bnQ6IDEsXHJcbiAgICAgICAgICAgICAgZXh0ZW5kZWRfYm91bmRzOiB7fSxcclxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJycsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICczJyxcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmdpdGh1Yi5vcmcnLFxyXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcclxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxyXG4gICAgICAgICAgICAgIHNpemU6IDUsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIHR5cGU6ICdhcmVhJyxcclxuICAgICAgICAgIGdyaWQ6IHtcclxuICAgICAgICAgICAgY2F0ZWdvcnlMaW5lczogZmFsc2UsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgY2F0ZWdvcnlBeGVzOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcclxuICAgICAgICAgICAgICB0eXBlOiAnY2F0ZWdvcnknLFxyXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcclxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxyXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcclxuICAgICAgICAgICAgICBzY2FsZToge1xyXG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBsYWJlbHM6IHtcclxuICAgICAgICAgICAgICAgIHNob3c6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxyXG4gICAgICAgICAgICAgICAgcm90YXRlOiAwLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgXSxcclxuICAgICAgICAgIHZhbHVlQXhlczogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgaWQ6ICdWYWx1ZUF4aXMtMScsXHJcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxyXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXHJcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdsZWZ0JyxcclxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxyXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcclxuICAgICAgICAgICAgICBzY2FsZToge1xyXG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXHJcbiAgICAgICAgICAgICAgICBtb2RlOiAnbm9ybWFsJyxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIGxhYmVsczoge1xyXG4gICAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIHJvdGF0ZTogMCxcclxuICAgICAgICAgICAgICAgIGZpbHRlcjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgdGl0bGU6IHtcclxuICAgICAgICAgICAgICAgIHRleHQ6ICdDb3VudCcsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIF0sXHJcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXHJcbiAgICAgICAgICAgICAgdHlwZTogJ2xpbmUnLFxyXG4gICAgICAgICAgICAgIG1vZGU6ICdub3JtYWwnLFxyXG4gICAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgIGxhYmVsOiAnQ291bnQnLFxyXG4gICAgICAgICAgICAgICAgaWQ6ICcxJyxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIGRyYXdMaW5lc0JldHdlZW5Qb2ludHM6IHRydWUsXHJcbiAgICAgICAgICAgICAgbGluZVdpZHRoOiAyLFxyXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxyXG4gICAgICAgICAgICAgIGludGVycG9sYXRlOiAnbGluZWFyJyxcclxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICBdLFxyXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcclxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcclxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxyXG4gICAgICAgICAgdGltZXM6IFtdLFxyXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXHJcbiAgICAgICAgICB0aHJlc2hvbGRMaW5lOiB7XHJcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxyXG4gICAgICAgICAgICB2YWx1ZTogMTAsXHJcbiAgICAgICAgICAgIHdpZHRoOiAxLFxyXG4gICAgICAgICAgICBzdHlsZTogJ2Z1bGwnLFxyXG4gICAgICAgICAgICBjb2xvcjogJyNFNzY2NEMnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGxhYmVsczoge30sXHJcbiAgICAgICAgICBvcmRlckJ1Y2tldHNCeVN1bTogZmFsc2UsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSksXHJcbiAgICAgIHVpU3RhdGVKU09OOiAnJyxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxyXG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1HaXRIdWItVG9wLTUtT3JnYW5pemF0aW9ucy1CeS1BbGVydHMnLFxyXG4gICAgX3NvdXJjZToge1xyXG4gICAgICB0aXRsZTogJ1RvcCA1IG9yZ2FuaXphdGlvbnMgYnkgYWxlcnRzJyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ1RvcCA1IG9yZ2FuaXphdGlvbnMgYnkgYWxlcnRzJyxcclxuICAgICAgICB0eXBlOiAncGllJyxcclxuICAgICAgICBhZ2dzOiBbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMScsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXHJcbiAgICAgICAgICAgIHBhcmFtczoge30sXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzInLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLm9yZycsXHJcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxyXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXHJcbiAgICAgICAgICAgICAgc2l6ZTogNSxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICB0eXBlOiAncGllJyxcclxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXHJcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXHJcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcclxuICAgICAgICAgIGlzRG9udXQ6IGZhbHNlLFxyXG4gICAgICAgICAgbGFiZWxzOiB7XHJcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxyXG4gICAgICAgICAgICB2YWx1ZXM6IHRydWUsXHJcbiAgICAgICAgICAgIGxhc3RfbGV2ZWw6IHRydWUsXHJcbiAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogJycsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgICAgdmVyc2lvbjogMSxcclxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XHJcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjpcclxuICAgICAgICAgICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXHJcbiAgfSxcclxuICB7XHJcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctR2l0SHViLVVzZXJzLVdpdGgtTW9yZS1BbGVydHMnLFxyXG4gICAgX3NvdXJjZToge1xyXG4gICAgICB0aXRsZTogJ1VzZXJzIHdpdGggbW9yZSBhbGVydHMnLFxyXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHRpdGxlOiAnVXNlcnMgd2l0aCBtb3JlIGFsZXJ0cycsXHJcbiAgICAgICAgdHlwZTogJ2xpbmUnLFxyXG4gICAgICAgIGFnZ3M6IFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICcxJyxcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnNCcsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5naXRodWIub3JnJyxcclxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXHJcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcclxuICAgICAgICAgICAgICBzaXplOiA1LFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMycsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5naXRodWIuYWN0b3InLFxyXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcclxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxyXG4gICAgICAgICAgICAgIHNpemU6IDUsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIHR5cGU6ICdsaW5lJyxcclxuICAgICAgICAgIGdyaWQ6IHtcclxuICAgICAgICAgICAgY2F0ZWdvcnlMaW5lczogZmFsc2UsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgY2F0ZWdvcnlBeGVzOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcclxuICAgICAgICAgICAgICB0eXBlOiAnY2F0ZWdvcnknLFxyXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcclxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxyXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcclxuICAgICAgICAgICAgICBzY2FsZToge1xyXG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBsYWJlbHM6IHtcclxuICAgICAgICAgICAgICAgIHNob3c6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgXSxcclxuICAgICAgICAgIHZhbHVlQXhlczogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgaWQ6ICdWYWx1ZUF4aXMtMScsXHJcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxyXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXHJcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdsZWZ0JyxcclxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxyXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcclxuICAgICAgICAgICAgICBzY2FsZToge1xyXG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXHJcbiAgICAgICAgICAgICAgICBtb2RlOiAnbm9ybWFsJyxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIGxhYmVsczoge1xyXG4gICAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIHJvdGF0ZTogMCxcclxuICAgICAgICAgICAgICAgIGZpbHRlcjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgdGl0bGU6IHtcclxuICAgICAgICAgICAgICAgIHRleHQ6ICdDb3VudCcsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIF0sXHJcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXHJcbiAgICAgICAgICAgICAgdHlwZTogJ2hpc3RvZ3JhbScsXHJcbiAgICAgICAgICAgICAgbW9kZTogJ3N0YWNrZWQnLFxyXG4gICAgICAgICAgICAgIGRhdGE6IHtcclxuICAgICAgICAgICAgICAgIGxhYmVsOiAnQ291bnQnLFxyXG4gICAgICAgICAgICAgICAgaWQ6ICcxJyxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyxcclxuICAgICAgICAgICAgICBkcmF3TGluZXNCZXR3ZWVuUG9pbnRzOiB0cnVlLFxyXG4gICAgICAgICAgICAgIGxpbmVXaWR0aDogMixcclxuICAgICAgICAgICAgICBpbnRlcnBvbGF0ZTogJ2xpbmVhcicsXHJcbiAgICAgICAgICAgICAgc2hvd0NpcmNsZXM6IHRydWUsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICBdLFxyXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcclxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcclxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxyXG4gICAgICAgICAgdGltZXM6IFtdLFxyXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXHJcbiAgICAgICAgICBsYWJlbHM6IHt9LFxyXG4gICAgICAgICAgdGhyZXNob2xkTGluZToge1xyXG4gICAgICAgICAgICBzaG93OiBmYWxzZSxcclxuICAgICAgICAgICAgdmFsdWU6IDEwLFxyXG4gICAgICAgICAgICB3aWR0aDogMSxcclxuICAgICAgICAgICAgc3R5bGU6ICdmdWxsJyxcclxuICAgICAgICAgICAgY29sb3I6ICcjRTc2NjRDJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgfSksXHJcbiAgICAgIHVpU3RhdGVKU09OOiAnJyxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxyXG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1HaXRIdWItQWxlcnQtQWN0aW9uLVR5cGUtQnktT3JnYW5pemF0aW9uJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdUb3AgYWxlcnRzIGJ5IGFsZXJ0IGFjdGlvbiB0eXBlIGFuZCBvcmdhbml6YXRpb24nLFxyXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHRpdGxlOiAnVG9wIGFsZXJ0cyBieSBhbGVydCBhY3Rpb24gdHlwZSBhbmQgb3JnYW5pemF0aW9uJyxcclxuICAgICAgICB0eXBlOiAncGllJyxcclxuICAgICAgICBhZ2dzOiBbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMScsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXHJcbiAgICAgICAgICAgIHBhcmFtczoge30sXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzMnLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLm9yZycsXHJcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxyXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXHJcbiAgICAgICAgICAgICAgc2l6ZTogNSxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzInLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLmFjdGlvbicsXHJcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxyXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXHJcbiAgICAgICAgICAgICAgc2l6ZTogMyxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICB0eXBlOiAncGllJyxcclxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXHJcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXHJcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcclxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXHJcbiAgICAgICAgICBsYWJlbHM6IHtcclxuICAgICAgICAgICAgc2hvdzogZmFsc2UsXHJcbiAgICAgICAgICAgIHZhbHVlczogdHJ1ZSxcclxuICAgICAgICAgICAgbGFzdF9sZXZlbDogdHJ1ZSxcclxuICAgICAgICAgICAgdHJ1bmNhdGU6IDEwMCxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgfSksXHJcbiAgICAgIHVpU3RhdGVKU09OOiAnJyxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxyXG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1HaXRIdWItQWxlcnQtU3VtbWFyeScsXHJcbiAgICBfc291cmNlOiB7XHJcbiAgICAgIHRpdGxlOiAnQWxlcnQgc3VtbWFyeScsXHJcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdGl0bGU6ICdBbGVydCBzdW1tYXJ5JyxcclxuICAgICAgICB0eXBlOiAndGFibGUnLFxyXG4gICAgICAgIGFnZ3M6IFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICcxJyxcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMicsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgIGZpZWxkOiAnYWdlbnQubmFtZScsXHJcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxyXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXHJcbiAgICAgICAgICAgICAgc2l6ZTogNTAsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzMnLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLm9yZycsXHJcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxyXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXHJcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzQnLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUuZGVzY3JpcHRpb24nLFxyXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcclxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxyXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgcGVyUGFnZTogMTAsXHJcbiAgICAgICAgICBzaG93UGFydGlhbFJvd3M6IGZhbHNlLFxyXG4gICAgICAgICAgc2hvd01ldHJpY3NBdEFsbExldmVsczogZmFsc2UsXHJcbiAgICAgICAgICBzb3J0OiB7XHJcbiAgICAgICAgICAgIGNvbHVtbkluZGV4OiBudWxsLFxyXG4gICAgICAgICAgICBkaXJlY3Rpb246IG51bGwsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgc2hvd1RvdGFsOiBmYWxzZSxcclxuICAgICAgICAgIHRvdGFsRnVuYzogJ3N1bScsXHJcbiAgICAgICAgICBwZXJjZW50YWdlQ29sOiAnJyxcclxuICAgICAgICB9LFxyXG4gICAgICB9KSxcclxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxyXG4gICAgICB9KSxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxyXG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1HaXRIdWItVG9wLVRlbi1Pcmdhbml6YXRpb25zJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdUb3AgMTAgb3JnYW5pemF0aW9ucycsXHJcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdGl0bGU6ICdUb3AgMTAgT3JnYW5pemF0aW9ucycsXHJcbiAgICAgICAgdHlwZTogJ3BpZScsXHJcbiAgICAgICAgYWdnczogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzEnLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxyXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICcyJyxcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmdpdGh1Yi5vcmcnLFxyXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcclxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxyXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxyXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnT3JnYW5pemF0aW9ucycsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgdHlwZTogJ3BpZScsXHJcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxyXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxyXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXHJcbiAgICAgICAgICBpc0RvbnV0OiB0cnVlLFxyXG4gICAgICAgICAgbGFiZWxzOiB7XHJcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxyXG4gICAgICAgICAgICB2YWx1ZXM6IHRydWUsXHJcbiAgICAgICAgICAgIGxhc3RfbGV2ZWw6IHRydWUsXHJcbiAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogMywgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXHJcbiAgICAgIH0pLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046XHJcbiAgICAgICAgICAne1wiaW5kZXhcIjpcIndhenVoLWFsZXJ0c1wiLFwiZmlsdGVyXCI6W10sXCJxdWVyeVwiOntcInF1ZXJ5XCI6XCJcIixcImxhbmd1YWdlXCI6XCJsdWNlbmVcIn19JyxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1Db3VudHJpZXMnLFxyXG4gICAgX3NvdXJjZToge1xyXG4gICAgICB0aXRsZTogJ0NvdW50cmllcycsXHJcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdGl0bGU6ICdUb3AgZ2l0aHViIGFjdG9ycyBjb3VudHJpZXMnLFxyXG4gICAgICAgIHR5cGU6ICd0YWdjbG91ZCcsXHJcbiAgICAgICAgYWdnczogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzEnLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxyXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICcyJyxcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmdpdGh1Yi5hY3Rvcl9sb2NhdGlvbi5jb3VudHJ5X2NvZGUnLFxyXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcclxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxyXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxyXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnVG9wIGNvdW50cmllcyAnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIHNjYWxlOiAnbGluZWFyJyxcclxuICAgICAgICAgIG9yaWVudGF0aW9uOiAnc2luZ2xlJyxcclxuICAgICAgICAgIG1pbkZvbnRTaXplOiAxOCxcclxuICAgICAgICAgIG1heEZvbnRTaXplOiA3MixcclxuICAgICAgICAgIHNob3dMYWJlbDogdHJ1ZSxcclxuICAgICAgICB9LFxyXG4gICAgICB9KSxcclxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxyXG4gICAgICB9KSxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxyXG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1HaXRIdWItVG9wLUV2ZW50cycsXHJcbiAgICBfc291cmNlOiB7XHJcbiAgICAgIHRpdGxlOiAnR2l0SHViIHRvcCBldmVudHMnLFxyXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHRpdGxlOiAnR2l0aHViIFRvcCBFdmVudHMnLFxyXG4gICAgICAgIHR5cGU6ICdwaWUnLFxyXG4gICAgICAgIGFnZ3M6IFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICcxJyxcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMicsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5naXRodWIuYWN0aW9uJyxcclxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXHJcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcclxuICAgICAgICAgICAgICBzaXplOiAxMCxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcclxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ0dpdGh1YiBBY3Rpb25zJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICB0eXBlOiAncGllJyxcclxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXHJcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXHJcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcclxuICAgICAgICAgIGlzRG9udXQ6IGZhbHNlLFxyXG4gICAgICAgICAgbGFiZWxzOiB7XHJcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxyXG4gICAgICAgICAgICB2YWx1ZXM6IHRydWUsXHJcbiAgICAgICAgICAgIGxhc3RfbGV2ZWw6IHRydWUsXHJcbiAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogMywgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXHJcbiAgICAgIH0pLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046XHJcbiAgICAgICAgICAne1wiaW5kZXhcIjpcIndhenVoLWFsZXJ0c1wiLFwiZmlsdGVyXCI6W10sXCJxdWVyeVwiOntcInF1ZXJ5XCI6XCJcIixcImxhbmd1YWdlXCI6XCJsdWNlbmVcIn19JyxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1TdGF0cycsXHJcbiAgICBfc291cmNlOiB7XHJcbiAgICAgIHRpdGxlOiAnR2l0SHViIFN0YXRzJyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ0dpdGh1YiBTdGF0cycsXHJcbiAgICAgICAgdHlwZTogJ21ldHJpYycsXHJcbiAgICAgICAgYWdnczogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzInLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1RvdGFsIEFsZXJ0cycsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzEnLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAndG9wX2hpdHMnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubGV2ZWwnLFxyXG4gICAgICAgICAgICAgIGFnZ3JlZ2F0ZTogJ2NvbmNhdCcsXHJcbiAgICAgICAgICAgICAgc2l6ZTogMSxcclxuICAgICAgICAgICAgICBzb3J0RmllbGQ6ICdydWxlLmxldmVsJyxcclxuICAgICAgICAgICAgICBzb3J0T3JkZXI6ICdkZXNjJyxcclxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ01heCBydWxlIGxldmVsIGRldGVjdGVkJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXHJcbiAgICAgICAgICBhZGRMZWdlbmQ6IGZhbHNlLFxyXG4gICAgICAgICAgdHlwZTogJ21ldHJpYycsXHJcbiAgICAgICAgICBtZXRyaWM6IHtcclxuICAgICAgICAgICAgcGVyY2VudGFnZU1vZGU6IGZhbHNlLFxyXG4gICAgICAgICAgICB1c2VSYW5nZXM6IGZhbHNlLFxyXG4gICAgICAgICAgICBjb2xvclNjaGVtYTogJ0dyZWVuIHRvIFJlZCcsXHJcbiAgICAgICAgICAgIG1ldHJpY0NvbG9yTW9kZTogJ05vbmUnLFxyXG4gICAgICAgICAgICBjb2xvcnNSYW5nZTogW1xyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGZyb206IDAsXHJcbiAgICAgICAgICAgICAgICB0bzogMTAwMDAsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgbGFiZWxzOiB7XHJcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgaW52ZXJ0Q29sb3JzOiBmYWxzZSxcclxuICAgICAgICAgICAgc3R5bGU6IHtcclxuICAgICAgICAgICAgICBiZ0ZpbGw6ICcjMDAwJyxcclxuICAgICAgICAgICAgICBiZ0NvbG9yOiBmYWxzZSxcclxuICAgICAgICAgICAgICBsYWJlbENvbG9yOiBmYWxzZSxcclxuICAgICAgICAgICAgICBzdWJUZXh0OiAnJyxcclxuICAgICAgICAgICAgICBmb250U2l6ZTogNjAsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogMywgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXHJcbiAgICAgIH0pLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046XHJcbiAgICAgICAgICAne1wiaW5kZXhcIjpcIndhenVoLWFsZXJ0c1wiLFwiZmlsdGVyXCI6W10sXCJxdWVyeVwiOntcInF1ZXJ5XCI6XCJcIixcImxhbmd1YWdlXCI6XCJsdWNlbmVcIn19JyxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1Pcmdhbml6YXRpb24tSGVhdG1hcCcsXHJcbiAgICBfc291cmNlOiB7XHJcbiAgICAgIHRpdGxlOiAnR2l0SHViIE9yZ2FuaXphdGlvbiBIZWF0bWFwJyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ0dpdEh1YiBPcmdhbml6YXRpb24gSGVhdG1hcCcsXHJcbiAgICAgICAgdHlwZTogJ2hlYXRtYXAnLFxyXG4gICAgICAgIGFnZ3M6IFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICcxJyxcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMicsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5naXRodWIub3JnJyxcclxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXHJcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcclxuICAgICAgICAgICAgICBzaXplOiAxMCxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzMnLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLmFjdGlvbicsXHJcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxyXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXHJcbiAgICAgICAgICAgICAgc2l6ZTogNSxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgdHlwZTogJ2hlYXRtYXAnLFxyXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcclxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcclxuICAgICAgICAgIGVuYWJsZUhvdmVyOiBmYWxzZSxcclxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxyXG4gICAgICAgICAgdGltZXM6IFtdLFxyXG4gICAgICAgICAgY29sb3JzTnVtYmVyOiA0LFxyXG4gICAgICAgICAgY29sb3JTY2hlbWE6ICdCbHVlcycsXHJcbiAgICAgICAgICBzZXRDb2xvclJhbmdlOiBmYWxzZSxcclxuICAgICAgICAgIGNvbG9yc1JhbmdlOiBbXSxcclxuICAgICAgICAgIGludmVydENvbG9yczogZmFsc2UsXHJcbiAgICAgICAgICBwZXJjZW50YWdlTW9kZTogZmFsc2UsXHJcbiAgICAgICAgICB2YWx1ZUF4ZXM6IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIHNob3c6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxyXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXHJcbiAgICAgICAgICAgICAgc2NhbGU6IHtcclxuICAgICAgICAgICAgICAgIHR5cGU6ICdsaW5lYXInLFxyXG4gICAgICAgICAgICAgICAgZGVmYXVsdFlFeHRlbnRzOiBmYWxzZSxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIGxhYmVsczoge1xyXG4gICAgICAgICAgICAgICAgc2hvdzogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICByb3RhdGU6IDAsXHJcbiAgICAgICAgICAgICAgICBvdmVyd3JpdGVDb2xvcjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJ2JsYWNrJyxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgXSxcclxuICAgICAgICB9LFxyXG4gICAgICB9KSxcclxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxyXG4gICAgICB9KSxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxyXG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1HaXRIdWItVG9wLVRlbi1Pcmdhbml6YXRpb25zJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdHaXRIdWIgdG9wIDEwIG9yZ2FuaXphdGlvbnMnLFxyXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHRpdGxlOiAnVG9wIDEwIE9yZ2FuaXphdGlvbnMnLFxyXG4gICAgICAgIHR5cGU6ICdwaWUnLFxyXG4gICAgICAgIGFnZ3M6IFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICcxJyxcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMicsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5naXRodWIub3JnJyxcclxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXHJcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcclxuICAgICAgICAgICAgICBzaXplOiAxMCxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcclxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ09yZ2FuaXphdGlvbnMnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIHR5cGU6ICdwaWUnLFxyXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcclxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcclxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxyXG4gICAgICAgICAgaXNEb251dDogdHJ1ZSxcclxuICAgICAgICAgIGxhYmVsczoge1xyXG4gICAgICAgICAgICBzaG93OiBmYWxzZSxcclxuICAgICAgICAgICAgdmFsdWVzOiB0cnVlLFxyXG4gICAgICAgICAgICBsYXN0X2xldmVsOiB0cnVlLFxyXG4gICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9LFxyXG4gICAgICB9KSxcclxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxyXG4gICAgICB9KSxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxyXG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1HaXRIdWItVG9wLVRlbi1BY3RvcnMnLFxyXG4gICAgX3NvdXJjZToge1xyXG4gICAgICB0aXRsZTogJ1RvcCAxMCBhY3RvcnMnLFxyXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHRpdGxlOiAnVG9wIDEwIEFjdG9ycycsXHJcbiAgICAgICAgdHlwZTogJ3BpZScsXHJcbiAgICAgICAgYWdnczogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzEnLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxyXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICcyJyxcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmdpdGh1Yi5hY3RvcicsXHJcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxyXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXHJcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXHJcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdBY3RvcnMnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIHR5cGU6ICdwaWUnLFxyXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcclxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcclxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxyXG4gICAgICAgICAgaXNEb251dDogdHJ1ZSxcclxuICAgICAgICAgIGxhYmVsczoge1xyXG4gICAgICAgICAgICBzaG93OiBmYWxzZSxcclxuICAgICAgICAgICAgdmFsdWVzOiB0cnVlLFxyXG4gICAgICAgICAgICBsYXN0X2xldmVsOiB0cnVlLFxyXG4gICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9LFxyXG4gICAgICB9KSxcclxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxyXG4gICAgICB9KSxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxyXG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1HaXRIdWItVG9wLVRlbi1SZXBvc2l0b3JpZXMnLFxyXG4gICAgX3NvdXJjZToge1xyXG4gICAgICB0aXRsZTogJ1RvcCAxMCByZXBvc2l0b3JpZXMnLFxyXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHRpdGxlOiAnVG9wIDEwIFJlcG9zaXRvcmllcycsXHJcbiAgICAgICAgdHlwZTogJ3BpZScsXHJcbiAgICAgICAgYWdnczogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzEnLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxyXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICcyJyxcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmdpdGh1Yi5yZXBvJyxcclxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXHJcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcclxuICAgICAgICAgICAgICBzaXplOiAxMCxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcclxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1JlcG9zaXRvcmllcycsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgdHlwZTogJ3BpZScsXHJcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxyXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxyXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXHJcbiAgICAgICAgICBpc0RvbnV0OiB0cnVlLFxyXG4gICAgICAgICAgbGFiZWxzOiB7XHJcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxyXG4gICAgICAgICAgICB2YWx1ZXM6IHRydWUsXHJcbiAgICAgICAgICAgIGxhc3RfbGV2ZWw6IHRydWUsXHJcbiAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogMywgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXHJcbiAgICAgIH0pLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046XHJcbiAgICAgICAgICAne1wiaW5kZXhcIjpcIndhenVoLWFsZXJ0c1wiLFwiZmlsdGVyXCI6W10sXCJxdWVyeVwiOntcInF1ZXJ5XCI6XCJcIixcImxhbmd1YWdlXCI6XCJsdWNlbmVcIn19JyxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1Ub3AtVGVuLUFjdGlvbnMnLFxyXG4gICAgX3NvdXJjZToge1xyXG4gICAgICB0aXRsZTogJ1RvcCAxMCBhY3Rpb25zJyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ1RvcCAxMCBBY3Rpb25zJyxcclxuICAgICAgICB0eXBlOiAncGllJyxcclxuICAgICAgICBhZ2dzOiBbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMScsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXHJcbiAgICAgICAgICAgIHBhcmFtczoge30sXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzInLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLmFjdGlvbicsXHJcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxyXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXHJcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXHJcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdBY3Rpb25zJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICB0eXBlOiAncGllJyxcclxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXHJcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXHJcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcclxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXHJcbiAgICAgICAgICBsYWJlbHM6IHtcclxuICAgICAgICAgICAgc2hvdzogZmFsc2UsXHJcbiAgICAgICAgICAgIHZhbHVlczogdHJ1ZSxcclxuICAgICAgICAgICAgbGFzdF9sZXZlbDogdHJ1ZSxcclxuICAgICAgICAgICAgdHJ1bmNhdGU6IDEwMCxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgfSksXHJcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdmlzOiB7IHBhcmFtczogeyBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9IH0gfSxcclxuICAgICAgfSksXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgICAgdmVyc2lvbjogMSxcclxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XHJcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjpcclxuICAgICAgICAgICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXHJcbiAgfSxcclxuICB7XHJcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctR2l0SHViLUFsZXJ0LUxldmVsLUV2b2x1dGlvbicsXHJcbiAgICBfc291cmNlOiB7XHJcbiAgICAgIHRpdGxlOiAnQWxlcnQgbGV2ZWwgZXZvbHV0aW9uJyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ1J1bGUgTGV2ZWwgT3ZlciBUaW1lJyxcclxuICAgICAgICB0eXBlOiAnYXJlYScsXHJcbiAgICAgICAgYWdnczogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzEnLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxyXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICcyJyxcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgdHlwZTogJ2RhdGVfaGlzdG9ncmFtJyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgZmllbGQ6ICd0aW1lc3RhbXAnLFxyXG4gICAgICAgICAgICAgIHRpbWVSYW5nZToge1xyXG4gICAgICAgICAgICAgICAgZnJvbTogJ25vdy0zMGQnLFxyXG4gICAgICAgICAgICAgICAgdG86ICdub3cnLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgdXNlTm9ybWFsaXplZEVzSW50ZXJ2YWw6IHRydWUsXHJcbiAgICAgICAgICAgICAgc2NhbGVNZXRyaWNWYWx1ZXM6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIGludGVydmFsOiAnZCcsXHJcbiAgICAgICAgICAgICAgZHJvcF9wYXJ0aWFsczogZmFsc2UsXHJcbiAgICAgICAgICAgICAgbWluX2RvY19jb3VudDogMSxcclxuICAgICAgICAgICAgICBleHRlbmRlZF9ib3VuZHM6IHt9LFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMycsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5sZXZlbCcsXHJcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxyXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXHJcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIHR5cGU6ICdhcmVhJyxcclxuICAgICAgICAgIGdyaWQ6IHtcclxuICAgICAgICAgICAgY2F0ZWdvcnlMaW5lczogZmFsc2UsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgY2F0ZWdvcnlBeGVzOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcclxuICAgICAgICAgICAgICB0eXBlOiAnY2F0ZWdvcnknLFxyXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcclxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxyXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcclxuICAgICAgICAgICAgICBzY2FsZToge1xyXG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBsYWJlbHM6IHtcclxuICAgICAgICAgICAgICAgIHNob3c6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXI6IHRydWUsXHJcbiAgICAgICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgXSxcclxuICAgICAgICAgIHZhbHVlQXhlczogW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgaWQ6ICdWYWx1ZUF4aXMtMScsXHJcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxyXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXHJcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdsZWZ0JyxcclxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxyXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcclxuICAgICAgICAgICAgICBzY2FsZToge1xyXG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXHJcbiAgICAgICAgICAgICAgICBtb2RlOiAnbm9ybWFsJyxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIGxhYmVsczoge1xyXG4gICAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIHJvdGF0ZTogMCxcclxuICAgICAgICAgICAgICAgIGZpbHRlcjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgdGl0bGU6IHtcclxuICAgICAgICAgICAgICAgIHRleHQ6ICdDb3VudCcsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIF0sXHJcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXHJcbiAgICAgICAgICAgICAgdHlwZTogJ2FyZWEnLFxyXG4gICAgICAgICAgICAgIG1vZGU6ICdzdGFja2VkJyxcclxuICAgICAgICAgICAgICBkYXRhOiB7XHJcbiAgICAgICAgICAgICAgICBsYWJlbDogJ0NvdW50JyxcclxuICAgICAgICAgICAgICAgIGlkOiAnMScsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBkcmF3TGluZXNCZXR3ZWVuUG9pbnRzOiB0cnVlLFxyXG4gICAgICAgICAgICAgIGxpbmVXaWR0aDogMixcclxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcclxuICAgICAgICAgICAgICBpbnRlcnBvbGF0ZTogJ3N0ZXAtYWZ0ZXInLFxyXG4gICAgICAgICAgICAgIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIF0sXHJcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxyXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxyXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXHJcbiAgICAgICAgICB0aW1lczogW10sXHJcbiAgICAgICAgICBhZGRUaW1lTWFya2VyOiBmYWxzZSxcclxuICAgICAgICAgIHRocmVzaG9sZExpbmU6IHtcclxuICAgICAgICAgICAgc2hvdzogZmFsc2UsXHJcbiAgICAgICAgICAgIHZhbHVlOiAxMCxcclxuICAgICAgICAgICAgd2lkdGg6IDEsXHJcbiAgICAgICAgICAgIHN0eWxlOiAnZnVsbCcsXHJcbiAgICAgICAgICAgIGNvbG9yOiAnI0U3NjY0QycsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgbGFiZWxzOiB7fSxcclxuICAgICAgICB9LFxyXG4gICAgICB9KSxcclxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxyXG4gICAgICB9KSxcclxuICAgICAgZGVzY3JpcHRpb246ICcnLFxyXG4gICAgICB2ZXJzaW9uOiAxLFxyXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcclxuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxyXG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9LFxyXG5dO1xyXG4iXX0=