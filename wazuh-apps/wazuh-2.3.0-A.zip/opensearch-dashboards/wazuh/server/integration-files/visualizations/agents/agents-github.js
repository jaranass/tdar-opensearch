"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/*
 * Wazuh app - Module for Agents/GitHub visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Overview-GitHub-Alerts-Evolution-By-Organization',
  _source: {
    title: 'Alerts evolution by organization',
    visState: JSON.stringify({
      "title": "Alerts evolution by organization",
      "type": "area",
      "aggs": [{
        "id": "1",
        "enabled": true,
        "type": "count",
        "params": {},
        "schema": "metric"
      }, {
        "id": "2",
        "enabled": true,
        "type": "date_histogram",
        "params": {
          "field": "timestamp",
          "timeRange": {
            "from": "now-7d",
            "to": "now"
          },
          "useNormalizedEsInterval": true,
          "scaleMetricValues": false,
          "interval": "auto",
          "drop_partials": false,
          "min_doc_count": 1,
          "extended_bounds": {},
          "customLabel": ""
        },
        "schema": "segment"
      }, {
        "id": "3",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.org",
          "orderBy": "1",
          "order": "desc",
          "size": 5,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "group"
      }],
      "params": {
        "type": "area",
        "grid": {
          "categoryLines": false
        },
        "categoryAxes": [{
          "id": "CategoryAxis-1",
          "type": "category",
          "position": "bottom",
          "show": true,
          "style": {},
          "scale": {
            "type": "linear"
          },
          "labels": {
            "show": true,
            "filter": true,
            "truncate": 100,
            "rotate": 0
          },
          "title": {}
        }],
        "valueAxes": [{
          "id": "ValueAxis-1",
          "name": "LeftAxis-1",
          "type": "value",
          "position": "left",
          "show": true,
          "style": {},
          "scale": {
            "type": "linear",
            "mode": "normal"
          },
          "labels": {
            "show": true,
            "rotate": 0,
            "filter": false,
            "truncate": 100
          },
          "title": {
            "text": "Count"
          }
        }],
        "seriesParams": [{
          "show": true,
          "type": "line",
          "mode": "normal",
          "data": {
            "label": "Count",
            "id": "1"
          },
          "drawLinesBetweenPoints": true,
          "lineWidth": 2,
          "showCircles": true,
          "interpolate": "linear",
          "valueAxis": "ValueAxis-1"
        }],
        "addTooltip": true,
        "addLegend": true,
        "legendPosition": "right",
        "times": [],
        "addTimeMarker": false,
        "thresholdLine": {
          "show": false,
          "value": 10,
          "width": 1,
          "style": "full",
          "color": "#E7664C"
        },
        "labels": {},
        "orderBucketsBySum": false
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-5-Organizations-By-Alerts',
  _source: {
    title: 'Top 5 organizations by alerts',
    visState: JSON.stringify({
      "title": "Top 5 organizations by alerts",
      "type": "pie",
      "aggs": [{
        "id": "1",
        "enabled": true,
        "type": "count",
        "params": {},
        "schema": "metric"
      }, {
        "id": "2",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.org",
          "orderBy": "1",
          "order": "desc",
          "size": 5,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "segment"
      }],
      "params": {
        "type": "pie",
        "addTooltip": true,
        "addLegend": true,
        "legendPosition": "right",
        "isDonut": false,
        "labels": {
          "show": false,
          "values": true,
          "last_level": true,
          "truncate": 100
        }
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Users-With-More-Alerts',
  _source: {
    title: 'Users with more alerts',
    visState: JSON.stringify({
      "title": "Users with more alerts",
      "type": "line",
      "aggs": [{
        "id": "1",
        "enabled": true,
        "type": "count",
        "params": {},
        "schema": "metric"
      }, {
        "id": "4",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.org",
          "orderBy": "1",
          "order": "desc",
          "size": 5,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "segment"
      }, {
        "id": "3",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.actor",
          "orderBy": "1",
          "order": "desc",
          "size": 5,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "group"
      }],
      "params": {
        "type": "line",
        "grid": {
          "categoryLines": false
        },
        "categoryAxes": [{
          "id": "CategoryAxis-1",
          "type": "category",
          "position": "bottom",
          "show": true,
          "style": {},
          "scale": {
            "type": "linear"
          },
          "labels": {
            "show": true,
            "filter": true,
            "truncate": 100
          },
          "title": {}
        }],
        "valueAxes": [{
          "id": "ValueAxis-1",
          "name": "LeftAxis-1",
          "type": "value",
          "position": "left",
          "show": true,
          "style": {},
          "scale": {
            "type": "linear",
            "mode": "normal"
          },
          "labels": {
            "show": true,
            "rotate": 0,
            "filter": false,
            "truncate": 100
          },
          "title": {
            "text": "Count"
          }
        }],
        "seriesParams": [{
          "show": true,
          "type": "histogram",
          "mode": "stacked",
          "data": {
            "label": "Count",
            "id": "1"
          },
          "valueAxis": "ValueAxis-1",
          "drawLinesBetweenPoints": true,
          "lineWidth": 2,
          "interpolate": "linear",
          "showCircles": true
        }],
        "addTooltip": true,
        "addLegend": true,
        "legendPosition": "right",
        "times": [],
        "addTimeMarker": false,
        "labels": {},
        "thresholdLine": {
          "show": false,
          "value": 10,
          "width": 1,
          "style": "full",
          "color": "#E7664C"
        }
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Alert-Action-Type-By-Organization',
  _source: {
    title: 'Top alerts by alert action type and organization',
    visState: JSON.stringify({
      "title": "Top alerts by alert action type and organization",
      "type": "pie",
      "aggs": [{
        "id": "1",
        "enabled": true,
        "type": "count",
        "params": {},
        "schema": "metric"
      }, {
        "id": "3",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.org",
          "orderBy": "1",
          "order": "desc",
          "size": 5,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "segment"
      }, {
        "id": "2",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.action",
          "orderBy": "1",
          "order": "desc",
          "size": 3,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "segment"
      }],
      "params": {
        "type": "pie",
        "addTooltip": true,
        "addLegend": true,
        "legendPosition": "right",
        "isDonut": true,
        "labels": {
          "show": false,
          "values": true,
          "last_level": true,
          "truncate": 100
        }
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Alert-Summary',
  _source: {
    title: 'Alert summary',
    visState: JSON.stringify({
      "title": "Alert summary",
      "type": "table",
      "aggs": [{
        "id": "1",
        "enabled": true,
        "type": "count",
        "params": {},
        "schema": "metric"
      }, {
        "id": "2",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "agent.name",
          "orderBy": "1",
          "order": "desc",
          "size": 50,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "bucket"
      }, {
        "id": "3",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.org",
          "orderBy": "1",
          "order": "desc",
          "size": 10,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "bucket"
      }, {
        "id": "4",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "rule.description",
          "orderBy": "1",
          "order": "desc",
          "size": 10,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "bucket"
      }],
      "params": {
        "perPage": 10,
        "showPartialRows": false,
        "showMetricsAtAllLevels": false,
        "sort": {
          "columnIndex": null,
          "direction": null
        },
        "showTotal": false,
        "totalFunc": "sum",
        "percentageCol": ""
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFnZW50cy1naXRodWIudHMiXSwibmFtZXMiOlsiX2lkIiwiX3NvdXJjZSIsInRpdGxlIiwidmlzU3RhdGUiLCJKU09OIiwic3RyaW5naWZ5IiwidWlTdGF0ZUpTT04iLCJkZXNjcmlwdGlvbiIsInZlcnNpb24iLCJraWJhbmFTYXZlZE9iamVjdE1ldGEiLCJzZWFyY2hTb3VyY2VKU09OIiwiX3R5cGUiLCJ2aXMiLCJwYXJhbXMiLCJzb3J0IiwiY29sdW1uSW5kZXgiLCJkaXJlY3Rpb24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO2VBRWUsQ0FDYjtBQUNFQSxFQUFBQSxHQUFHLEVBQUUsNERBRFA7QUFFRUMsRUFBQUEsT0FBTyxFQUFFO0FBQ1BDLElBQUFBLEtBQUssRUFBRSxrQ0FEQTtBQUVQQyxJQUFBQSxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ3ZCLGVBQVMsa0NBRGM7QUFFdkIsY0FBUSxNQUZlO0FBR3ZCLGNBQVEsQ0FDTjtBQUNFLGNBQU0sR0FEUjtBQUVFLG1CQUFXLElBRmI7QUFHRSxnQkFBUSxPQUhWO0FBSUUsa0JBQVUsRUFKWjtBQUtFLGtCQUFVO0FBTFosT0FETSxFQVFOO0FBQ0UsY0FBTSxHQURSO0FBRUUsbUJBQVcsSUFGYjtBQUdFLGdCQUFRLGdCQUhWO0FBSUUsa0JBQVU7QUFDUixtQkFBUyxXQUREO0FBRVIsdUJBQWE7QUFDWCxvQkFBUSxRQURHO0FBRVgsa0JBQU07QUFGSyxXQUZMO0FBTVIscUNBQTJCLElBTm5CO0FBT1IsK0JBQXFCLEtBUGI7QUFRUixzQkFBWSxNQVJKO0FBU1IsMkJBQWlCLEtBVFQ7QUFVUiwyQkFBaUIsQ0FWVDtBQVdSLDZCQUFtQixFQVhYO0FBWVIseUJBQWU7QUFaUCxTQUpaO0FBa0JFLGtCQUFVO0FBbEJaLE9BUk0sRUE0Qk47QUFDRSxjQUFNLEdBRFI7QUFFRSxtQkFBVyxJQUZiO0FBR0UsZ0JBQVEsT0FIVjtBQUlFLGtCQUFVO0FBQ1IsbUJBQVMsaUJBREQ7QUFFUixxQkFBVyxHQUZIO0FBR1IsbUJBQVMsTUFIRDtBQUlSLGtCQUFRLENBSkE7QUFLUix5QkFBZSxLQUxQO0FBTVIsOEJBQW9CLE9BTlo7QUFPUiwyQkFBaUIsS0FQVDtBQVFSLGdDQUFzQjtBQVJkLFNBSlo7QUFjRSxrQkFBVTtBQWRaLE9BNUJNLENBSGU7QUFnRHZCLGdCQUFVO0FBQ1IsZ0JBQVEsTUFEQTtBQUVSLGdCQUFRO0FBQ04sMkJBQWlCO0FBRFgsU0FGQTtBQUtSLHdCQUFnQixDQUNkO0FBQ0UsZ0JBQU0sZ0JBRFI7QUFFRSxrQkFBUSxVQUZWO0FBR0Usc0JBQVksUUFIZDtBQUlFLGtCQUFRLElBSlY7QUFLRSxtQkFBUyxFQUxYO0FBTUUsbUJBQVM7QUFDUCxvQkFBUTtBQURELFdBTlg7QUFTRSxvQkFBVTtBQUNSLG9CQUFRLElBREE7QUFFUixzQkFBVSxJQUZGO0FBR1Isd0JBQVksR0FISjtBQUlSLHNCQUFVO0FBSkYsV0FUWjtBQWVFLG1CQUFTO0FBZlgsU0FEYyxDQUxSO0FBd0JSLHFCQUFhLENBQ1g7QUFDRSxnQkFBTSxhQURSO0FBRUUsa0JBQVEsWUFGVjtBQUdFLGtCQUFRLE9BSFY7QUFJRSxzQkFBWSxNQUpkO0FBS0Usa0JBQVEsSUFMVjtBQU1FLG1CQUFTLEVBTlg7QUFPRSxtQkFBUztBQUNQLG9CQUFRLFFBREQ7QUFFUCxvQkFBUTtBQUZELFdBUFg7QUFXRSxvQkFBVTtBQUNSLG9CQUFRLElBREE7QUFFUixzQkFBVSxDQUZGO0FBR1Isc0JBQVUsS0FIRjtBQUlSLHdCQUFZO0FBSkosV0FYWjtBQWlCRSxtQkFBUztBQUNQLG9CQUFRO0FBREQ7QUFqQlgsU0FEVyxDQXhCTDtBQStDUix3QkFBZ0IsQ0FDZDtBQUNFLGtCQUFRLElBRFY7QUFFRSxrQkFBUSxNQUZWO0FBR0Usa0JBQVEsUUFIVjtBQUlFLGtCQUFRO0FBQ04scUJBQVMsT0FESDtBQUVOLGtCQUFNO0FBRkEsV0FKVjtBQVFFLG9DQUEwQixJQVI1QjtBQVNFLHVCQUFhLENBVGY7QUFVRSx5QkFBZSxJQVZqQjtBQVdFLHlCQUFlLFFBWGpCO0FBWUUsdUJBQWE7QUFaZixTQURjLENBL0NSO0FBK0RSLHNCQUFjLElBL0ROO0FBZ0VSLHFCQUFhLElBaEVMO0FBaUVSLDBCQUFrQixPQWpFVjtBQWtFUixpQkFBUyxFQWxFRDtBQW1FUix5QkFBaUIsS0FuRVQ7QUFvRVIseUJBQWlCO0FBQ2Ysa0JBQVEsS0FETztBQUVmLG1CQUFTLEVBRk07QUFHZixtQkFBUyxDQUhNO0FBSWYsbUJBQVMsTUFKTTtBQUtmLG1CQUFTO0FBTE0sU0FwRVQ7QUEyRVIsa0JBQVUsRUEzRUY7QUE0RVIsNkJBQXFCO0FBNUViO0FBaERhLEtBQWYsQ0FGSDtBQWlJUEMsSUFBQUEsV0FBVyxFQUFFLEVBaklOO0FBa0lQQyxJQUFBQSxXQUFXLEVBQUUsRUFsSU47QUFtSVBDLElBQUFBLE9BQU8sRUFBRSxDQW5JRjtBQW9JUEMsSUFBQUEscUJBQXFCLEVBQUU7QUFDckJDLE1BQUFBLGdCQUFnQixFQUFFO0FBREc7QUFwSWhCLEdBRlg7QUEwSUVDLEVBQUFBLEtBQUssRUFBRTtBQTFJVCxDQURhLEVBNkliO0FBQ0VYLEVBQUFBLEdBQUcsRUFBRSx5REFEUDtBQUVFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLCtCQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkIsZUFBUywrQkFEYztBQUV2QixjQUFRLEtBRmU7QUFHdkIsY0FBUSxDQUNOO0FBQ0UsY0FBTSxHQURSO0FBRUUsbUJBQVcsSUFGYjtBQUdFLGdCQUFRLE9BSFY7QUFJRSxrQkFBVSxFQUpaO0FBS0Usa0JBQVU7QUFMWixPQURNLEVBUU47QUFDRSxjQUFNLEdBRFI7QUFFRSxtQkFBVyxJQUZiO0FBR0UsZ0JBQVEsT0FIVjtBQUlFLGtCQUFVO0FBQ1IsbUJBQVMsaUJBREQ7QUFFUixxQkFBVyxHQUZIO0FBR1IsbUJBQVMsTUFIRDtBQUlSLGtCQUFRLENBSkE7QUFLUix5QkFBZSxLQUxQO0FBTVIsOEJBQW9CLE9BTlo7QUFPUiwyQkFBaUIsS0FQVDtBQVFSLGdDQUFzQjtBQVJkLFNBSlo7QUFjRSxrQkFBVTtBQWRaLE9BUk0sQ0FIZTtBQTRCdkIsZ0JBQVU7QUFDUixnQkFBUSxLQURBO0FBRVIsc0JBQWMsSUFGTjtBQUdSLHFCQUFhLElBSEw7QUFJUiwwQkFBa0IsT0FKVjtBQUtSLG1CQUFXLEtBTEg7QUFNUixrQkFBVTtBQUNSLGtCQUFRLEtBREE7QUFFUixvQkFBVSxJQUZGO0FBR1Isd0JBQWMsSUFITjtBQUlSLHNCQUFZO0FBSko7QUFORjtBQTVCYSxLQUFmLENBRkg7QUE0Q1BDLElBQUFBLFdBQVcsRUFBRSxFQTVDTjtBQTZDUEMsSUFBQUEsV0FBVyxFQUFFLEVBN0NOO0FBOENQQyxJQUFBQSxPQUFPLEVBQUUsQ0E5Q0Y7QUErQ1BDLElBQUFBLHFCQUFxQixFQUFFO0FBQ3JCQyxNQUFBQSxnQkFBZ0IsRUFBRTtBQURHO0FBL0NoQixHQUZYO0FBcURFQyxFQUFBQSxLQUFLLEVBQUU7QUFyRFQsQ0E3SWEsRUFvTWI7QUFDRVgsRUFBQUEsR0FBRyxFQUFFLGtEQURQO0FBRUVDLEVBQUFBLE9BQU8sRUFBRTtBQUNQQyxJQUFBQSxLQUFLLEVBQUUsd0JBREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QixlQUFTLHdCQURjO0FBRXZCLGNBQVEsTUFGZTtBQUd2QixjQUFRLENBQ047QUFDRSxjQUFNLEdBRFI7QUFFRSxtQkFBVyxJQUZiO0FBR0UsZ0JBQVEsT0FIVjtBQUlFLGtCQUFVLEVBSlo7QUFLRSxrQkFBVTtBQUxaLE9BRE0sRUFRTjtBQUNFLGNBQU0sR0FEUjtBQUVFLG1CQUFXLElBRmI7QUFHRSxnQkFBUSxPQUhWO0FBSUUsa0JBQVU7QUFDUixtQkFBUyxpQkFERDtBQUVSLHFCQUFXLEdBRkg7QUFHUixtQkFBUyxNQUhEO0FBSVIsa0JBQVEsQ0FKQTtBQUtSLHlCQUFlLEtBTFA7QUFNUiw4QkFBb0IsT0FOWjtBQU9SLDJCQUFpQixLQVBUO0FBUVIsZ0NBQXNCO0FBUmQsU0FKWjtBQWNFLGtCQUFVO0FBZFosT0FSTSxFQXdCTjtBQUNFLGNBQU0sR0FEUjtBQUVFLG1CQUFXLElBRmI7QUFHRSxnQkFBUSxPQUhWO0FBSUUsa0JBQVU7QUFDUixtQkFBUyxtQkFERDtBQUVSLHFCQUFXLEdBRkg7QUFHUixtQkFBUyxNQUhEO0FBSVIsa0JBQVEsQ0FKQTtBQUtSLHlCQUFlLEtBTFA7QUFNUiw4QkFBb0IsT0FOWjtBQU9SLDJCQUFpQixLQVBUO0FBUVIsZ0NBQXNCO0FBUmQsU0FKWjtBQWNFLGtCQUFVO0FBZFosT0F4Qk0sQ0FIZTtBQTRDdkIsZ0JBQVU7QUFDUixnQkFBUSxNQURBO0FBRVIsZ0JBQVE7QUFDTiwyQkFBaUI7QUFEWCxTQUZBO0FBS1Isd0JBQWdCLENBQ2Q7QUFDRSxnQkFBTSxnQkFEUjtBQUVFLGtCQUFRLFVBRlY7QUFHRSxzQkFBWSxRQUhkO0FBSUUsa0JBQVEsSUFKVjtBQUtFLG1CQUFTLEVBTFg7QUFNRSxtQkFBUztBQUNQLG9CQUFRO0FBREQsV0FOWDtBQVNFLG9CQUFVO0FBQ1Isb0JBQVEsSUFEQTtBQUVSLHNCQUFVLElBRkY7QUFHUix3QkFBWTtBQUhKLFdBVFo7QUFjRSxtQkFBUztBQWRYLFNBRGMsQ0FMUjtBQXVCUixxQkFBYSxDQUNYO0FBQ0UsZ0JBQU0sYUFEUjtBQUVFLGtCQUFRLFlBRlY7QUFHRSxrQkFBUSxPQUhWO0FBSUUsc0JBQVksTUFKZDtBQUtFLGtCQUFRLElBTFY7QUFNRSxtQkFBUyxFQU5YO0FBT0UsbUJBQVM7QUFDUCxvQkFBUSxRQUREO0FBRVAsb0JBQVE7QUFGRCxXQVBYO0FBV0Usb0JBQVU7QUFDUixvQkFBUSxJQURBO0FBRVIsc0JBQVUsQ0FGRjtBQUdSLHNCQUFVLEtBSEY7QUFJUix3QkFBWTtBQUpKLFdBWFo7QUFpQkUsbUJBQVM7QUFDUCxvQkFBUTtBQUREO0FBakJYLFNBRFcsQ0F2Qkw7QUE4Q1Isd0JBQWdCLENBQ2Q7QUFDRSxrQkFBUSxJQURWO0FBRUUsa0JBQVEsV0FGVjtBQUdFLGtCQUFRLFNBSFY7QUFJRSxrQkFBUTtBQUNOLHFCQUFTLE9BREg7QUFFTixrQkFBTTtBQUZBLFdBSlY7QUFRRSx1QkFBYSxhQVJmO0FBU0Usb0NBQTBCLElBVDVCO0FBVUUsdUJBQWEsQ0FWZjtBQVdFLHlCQUFlLFFBWGpCO0FBWUUseUJBQWU7QUFaakIsU0FEYyxDQTlDUjtBQThEUixzQkFBYyxJQTlETjtBQStEUixxQkFBYSxJQS9ETDtBQWdFUiwwQkFBa0IsT0FoRVY7QUFpRVIsaUJBQVMsRUFqRUQ7QUFrRVIseUJBQWlCLEtBbEVUO0FBbUVSLGtCQUFVLEVBbkVGO0FBb0VSLHlCQUFpQjtBQUNmLGtCQUFRLEtBRE87QUFFZixtQkFBUyxFQUZNO0FBR2YsbUJBQVMsQ0FITTtBQUlmLG1CQUFTLE1BSk07QUFLZixtQkFBUztBQUxNO0FBcEVUO0FBNUNhLEtBQWYsQ0FGSDtBQTJIUEMsSUFBQUEsV0FBVyxFQUFFLEVBM0hOO0FBNEhQQyxJQUFBQSxXQUFXLEVBQUUsRUE1SE47QUE2SFBDLElBQUFBLE9BQU8sRUFBRSxDQTdIRjtBQThIUEMsSUFBQUEscUJBQXFCLEVBQUU7QUFDckJDLE1BQUFBLGdCQUFnQixFQUFFO0FBREc7QUE5SGhCLEdBRlg7QUFvSUVDLEVBQUFBLEtBQUssRUFBRTtBQXBJVCxDQXBNYSxFQTBVYjtBQUNFWCxFQUFBQSxHQUFHLEVBQUUsNkRBRFA7QUFFRUMsRUFBQUEsT0FBTyxFQUFFO0FBQ1BDLElBQUFBLEtBQUssRUFBRSxrREFEQTtBQUVQQyxJQUFBQSxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ3ZCLGVBQVMsa0RBRGM7QUFFdkIsY0FBUSxLQUZlO0FBR3ZCLGNBQVEsQ0FDTjtBQUNFLGNBQU0sR0FEUjtBQUVFLG1CQUFXLElBRmI7QUFHRSxnQkFBUSxPQUhWO0FBSUUsa0JBQVUsRUFKWjtBQUtFLGtCQUFVO0FBTFosT0FETSxFQVFOO0FBQ0UsY0FBTSxHQURSO0FBRUUsbUJBQVcsSUFGYjtBQUdFLGdCQUFRLE9BSFY7QUFJRSxrQkFBVTtBQUNSLG1CQUFTLGlCQUREO0FBRVIscUJBQVcsR0FGSDtBQUdSLG1CQUFTLE1BSEQ7QUFJUixrQkFBUSxDQUpBO0FBS1IseUJBQWUsS0FMUDtBQU1SLDhCQUFvQixPQU5aO0FBT1IsMkJBQWlCLEtBUFQ7QUFRUixnQ0FBc0I7QUFSZCxTQUpaO0FBY0Usa0JBQVU7QUFkWixPQVJNLEVBd0JOO0FBQ0UsY0FBTSxHQURSO0FBRUUsbUJBQVcsSUFGYjtBQUdFLGdCQUFRLE9BSFY7QUFJRSxrQkFBVTtBQUNSLG1CQUFTLG9CQUREO0FBRVIscUJBQVcsR0FGSDtBQUdSLG1CQUFTLE1BSEQ7QUFJUixrQkFBUSxDQUpBO0FBS1IseUJBQWUsS0FMUDtBQU1SLDhCQUFvQixPQU5aO0FBT1IsMkJBQWlCLEtBUFQ7QUFRUixnQ0FBc0I7QUFSZCxTQUpaO0FBY0Usa0JBQVU7QUFkWixPQXhCTSxDQUhlO0FBNEN2QixnQkFBVTtBQUNSLGdCQUFRLEtBREE7QUFFUixzQkFBYyxJQUZOO0FBR1IscUJBQWEsSUFITDtBQUlSLDBCQUFrQixPQUpWO0FBS1IsbUJBQVcsSUFMSDtBQU1SLGtCQUFVO0FBQ1Isa0JBQVEsS0FEQTtBQUVSLG9CQUFVLElBRkY7QUFHUix3QkFBYyxJQUhOO0FBSVIsc0JBQVk7QUFKSjtBQU5GO0FBNUNhLEtBQWYsQ0FGSDtBQTREUEMsSUFBQUEsV0FBVyxFQUFFLEVBNUROO0FBNkRQQyxJQUFBQSxXQUFXLEVBQUUsRUE3RE47QUE4RFBDLElBQUFBLE9BQU8sRUFBRSxDQTlERjtBQStEUEMsSUFBQUEscUJBQXFCLEVBQUU7QUFDckJDLE1BQUFBLGdCQUFnQixFQUFFO0FBREc7QUEvRGhCLEdBRlg7QUFxRUVDLEVBQUFBLEtBQUssRUFBRTtBQXJFVCxDQTFVYSxFQWlaYjtBQUNFWCxFQUFBQSxHQUFHLEVBQUUseUNBRFA7QUFFRUMsRUFBQUEsT0FBTyxFQUFFO0FBQ1BDLElBQUFBLEtBQUssRUFBRSxlQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkIsZUFBUyxlQURjO0FBRXZCLGNBQVEsT0FGZTtBQUd2QixjQUFRLENBQ047QUFDRSxjQUFNLEdBRFI7QUFFRSxtQkFBVyxJQUZiO0FBR0UsZ0JBQVEsT0FIVjtBQUlFLGtCQUFVLEVBSlo7QUFLRSxrQkFBVTtBQUxaLE9BRE0sRUFRTjtBQUNFLGNBQU0sR0FEUjtBQUVFLG1CQUFXLElBRmI7QUFHRSxnQkFBUSxPQUhWO0FBSUUsa0JBQVU7QUFDUixtQkFBUyxZQUREO0FBRVIscUJBQVcsR0FGSDtBQUdSLG1CQUFTLE1BSEQ7QUFJUixrQkFBUSxFQUpBO0FBS1IseUJBQWUsS0FMUDtBQU1SLDhCQUFvQixPQU5aO0FBT1IsMkJBQWlCLEtBUFQ7QUFRUixnQ0FBc0I7QUFSZCxTQUpaO0FBY0Usa0JBQVU7QUFkWixPQVJNLEVBd0JOO0FBQ0UsY0FBTSxHQURSO0FBRUUsbUJBQVcsSUFGYjtBQUdFLGdCQUFRLE9BSFY7QUFJRSxrQkFBVTtBQUNSLG1CQUFTLGlCQUREO0FBRVIscUJBQVcsR0FGSDtBQUdSLG1CQUFTLE1BSEQ7QUFJUixrQkFBUSxFQUpBO0FBS1IseUJBQWUsS0FMUDtBQU1SLDhCQUFvQixPQU5aO0FBT1IsMkJBQWlCLEtBUFQ7QUFRUixnQ0FBc0I7QUFSZCxTQUpaO0FBY0Usa0JBQVU7QUFkWixPQXhCTSxFQXdDTjtBQUNFLGNBQU0sR0FEUjtBQUVFLG1CQUFXLElBRmI7QUFHRSxnQkFBUSxPQUhWO0FBSUUsa0JBQVU7QUFDUixtQkFBUyxrQkFERDtBQUVSLHFCQUFXLEdBRkg7QUFHUixtQkFBUyxNQUhEO0FBSVIsa0JBQVEsRUFKQTtBQUtSLHlCQUFlLEtBTFA7QUFNUiw4QkFBb0IsT0FOWjtBQU9SLDJCQUFpQixLQVBUO0FBUVIsZ0NBQXNCO0FBUmQsU0FKWjtBQWNFLGtCQUFVO0FBZFosT0F4Q00sQ0FIZTtBQTREdkIsZ0JBQVU7QUFDUixtQkFBVyxFQURIO0FBRVIsMkJBQW1CLEtBRlg7QUFHUixrQ0FBMEIsS0FIbEI7QUFJUixnQkFBUTtBQUNOLHlCQUFlLElBRFQ7QUFFTix1QkFBYTtBQUZQLFNBSkE7QUFRUixxQkFBYSxLQVJMO0FBU1IscUJBQWEsS0FUTDtBQVVSLHlCQUFpQjtBQVZUO0FBNURhLEtBQWYsQ0FGSDtBQTJFUEMsSUFBQUEsV0FBVyxFQUFFRixJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUMxQk8sTUFBQUEsR0FBRyxFQUFFO0FBQUVDLFFBQUFBLE1BQU0sRUFBRTtBQUFFQyxVQUFBQSxJQUFJLEVBQUU7QUFBRUMsWUFBQUEsV0FBVyxFQUFFLENBQWY7QUFBa0JDLFlBQUFBLFNBQVMsRUFBRTtBQUE3QjtBQUFSO0FBQVY7QUFEcUIsS0FBZixDQTNFTjtBQThFUFQsSUFBQUEsV0FBVyxFQUFFLEVBOUVOO0FBK0VQQyxJQUFBQSxPQUFPLEVBQUUsQ0EvRUY7QUFnRlBDLElBQUFBLHFCQUFxQixFQUFFO0FBQ3JCQyxNQUFBQSxnQkFBZ0IsRUFBRTtBQURHO0FBaEZoQixHQUZYO0FBc0ZFQyxFQUFBQSxLQUFLLEVBQUU7QUF0RlQsQ0FqWmEsQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXHJcbiAqIFdhenVoIGFwcCAtIE1vZHVsZSBmb3IgQWdlbnRzL0dpdEh1YiB2aXN1YWxpemF0aW9uc1xyXG4gKiBDb3B5cmlnaHQgKEMpIDIwMTUtMjAyMiBXYXp1aCwgSW5jLlxyXG4gKlxyXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxyXG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxyXG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxyXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxyXG4gKlxyXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxyXG4gKi9cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFtcclxuICB7XHJcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctR2l0SHViLUFsZXJ0cy1Fdm9sdXRpb24tQnktT3JnYW5pemF0aW9uJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdBbGVydHMgZXZvbHV0aW9uIGJ5IG9yZ2FuaXphdGlvbicsXHJcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgXCJ0aXRsZVwiOiBcIkFsZXJ0cyBldm9sdXRpb24gYnkgb3JnYW5pemF0aW9uXCIsXHJcbiAgICAgICAgXCJ0eXBlXCI6IFwiYXJlYVwiLFxyXG4gICAgICAgIFwiYWdnc1wiOiBbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiaWRcIjogXCIxXCIsXHJcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxyXG4gICAgICAgICAgICBcInR5cGVcIjogXCJjb3VudFwiLFxyXG4gICAgICAgICAgICBcInBhcmFtc1wiOiB7fSxcclxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJtZXRyaWNcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgXCJpZFwiOiBcIjJcIixcclxuICAgICAgICAgICAgXCJlbmFibGVkXCI6IHRydWUsXHJcbiAgICAgICAgICAgIFwidHlwZVwiOiBcImRhdGVfaGlzdG9ncmFtXCIsXHJcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHtcclxuICAgICAgICAgICAgICBcImZpZWxkXCI6IFwidGltZXN0YW1wXCIsXHJcbiAgICAgICAgICAgICAgXCJ0aW1lUmFuZ2VcIjoge1xyXG4gICAgICAgICAgICAgICAgXCJmcm9tXCI6IFwibm93LTdkXCIsXHJcbiAgICAgICAgICAgICAgICBcInRvXCI6IFwibm93XCJcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIFwidXNlTm9ybWFsaXplZEVzSW50ZXJ2YWxcIjogdHJ1ZSxcclxuICAgICAgICAgICAgICBcInNjYWxlTWV0cmljVmFsdWVzXCI6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIFwiaW50ZXJ2YWxcIjogXCJhdXRvXCIsXHJcbiAgICAgICAgICAgICAgXCJkcm9wX3BhcnRpYWxzXCI6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIFwibWluX2RvY19jb3VudFwiOiAxLFxyXG4gICAgICAgICAgICAgIFwiZXh0ZW5kZWRfYm91bmRzXCI6IHt9LFxyXG4gICAgICAgICAgICAgIFwiY3VzdG9tTGFiZWxcIjogXCJcIlxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBcInNjaGVtYVwiOiBcInNlZ21lbnRcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgXCJpZFwiOiBcIjNcIixcclxuICAgICAgICAgICAgXCJlbmFibGVkXCI6IHRydWUsXHJcbiAgICAgICAgICAgIFwidHlwZVwiOiBcInRlcm1zXCIsXHJcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHtcclxuICAgICAgICAgICAgICBcImZpZWxkXCI6IFwiZGF0YS5naXRodWIub3JnXCIsXHJcbiAgICAgICAgICAgICAgXCJvcmRlckJ5XCI6IFwiMVwiLFxyXG4gICAgICAgICAgICAgIFwib3JkZXJcIjogXCJkZXNjXCIsXHJcbiAgICAgICAgICAgICAgXCJzaXplXCI6IDUsXHJcbiAgICAgICAgICAgICAgXCJvdGhlckJ1Y2tldFwiOiBmYWxzZSxcclxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0TGFiZWxcIjogXCJPdGhlclwiLFxyXG4gICAgICAgICAgICAgIFwibWlzc2luZ0J1Y2tldFwiOiBmYWxzZSxcclxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRMYWJlbFwiOiBcIk1pc3NpbmdcIlxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBcInNjaGVtYVwiOiBcImdyb3VwXCJcclxuICAgICAgICAgIH1cclxuICAgICAgICBdLFxyXG4gICAgICAgIFwicGFyYW1zXCI6IHtcclxuICAgICAgICAgIFwidHlwZVwiOiBcImFyZWFcIixcclxuICAgICAgICAgIFwiZ3JpZFwiOiB7XHJcbiAgICAgICAgICAgIFwiY2F0ZWdvcnlMaW5lc1wiOiBmYWxzZVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwiY2F0ZWdvcnlBeGVzXCI6IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIFwiaWRcIjogXCJDYXRlZ29yeUF4aXMtMVwiLFxyXG4gICAgICAgICAgICAgIFwidHlwZVwiOiBcImNhdGVnb3J5XCIsXHJcbiAgICAgICAgICAgICAgXCJwb3NpdGlvblwiOiBcImJvdHRvbVwiLFxyXG4gICAgICAgICAgICAgIFwic2hvd1wiOiB0cnVlLFxyXG4gICAgICAgICAgICAgIFwic3R5bGVcIjoge30sXHJcbiAgICAgICAgICAgICAgXCJzY2FsZVwiOiB7XHJcbiAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJsaW5lYXJcIlxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgXCJsYWJlbHNcIjoge1xyXG4gICAgICAgICAgICAgICAgXCJzaG93XCI6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBcImZpbHRlclwiOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgXCJ0cnVuY2F0ZVwiOiAxMDAsXHJcbiAgICAgICAgICAgICAgICBcInJvdGF0ZVwiOiAwXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBcInRpdGxlXCI6IHt9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIF0sXHJcbiAgICAgICAgICBcInZhbHVlQXhlc1wiOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBcImlkXCI6IFwiVmFsdWVBeGlzLTFcIixcclxuICAgICAgICAgICAgICBcIm5hbWVcIjogXCJMZWZ0QXhpcy0xXCIsXHJcbiAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwidmFsdWVcIixcclxuICAgICAgICAgICAgICBcInBvc2l0aW9uXCI6IFwibGVmdFwiLFxyXG4gICAgICAgICAgICAgIFwic2hvd1wiOiB0cnVlLFxyXG4gICAgICAgICAgICAgIFwic3R5bGVcIjoge30sXHJcbiAgICAgICAgICAgICAgXCJzY2FsZVwiOiB7XHJcbiAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJsaW5lYXJcIixcclxuICAgICAgICAgICAgICAgIFwibW9kZVwiOiBcIm5vcm1hbFwiXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBcImxhYmVsc1wiOiB7XHJcbiAgICAgICAgICAgICAgICBcInNob3dcIjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIFwicm90YXRlXCI6IDAsXHJcbiAgICAgICAgICAgICAgICBcImZpbHRlclwiOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIFwidHJ1bmNhdGVcIjogMTAwXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBcInRpdGxlXCI6IHtcclxuICAgICAgICAgICAgICAgIFwidGV4dFwiOiBcIkNvdW50XCJcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIF0sXHJcbiAgICAgICAgICBcInNlcmllc1BhcmFtc1wiOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBcInNob3dcIjogdHJ1ZSxcclxuICAgICAgICAgICAgICBcInR5cGVcIjogXCJsaW5lXCIsXHJcbiAgICAgICAgICAgICAgXCJtb2RlXCI6IFwibm9ybWFsXCIsXHJcbiAgICAgICAgICAgICAgXCJkYXRhXCI6IHtcclxuICAgICAgICAgICAgICAgIFwibGFiZWxcIjogXCJDb3VudFwiLFxyXG4gICAgICAgICAgICAgICAgXCJpZFwiOiBcIjFcIlxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgXCJkcmF3TGluZXNCZXR3ZWVuUG9pbnRzXCI6IHRydWUsXHJcbiAgICAgICAgICAgICAgXCJsaW5lV2lkdGhcIjogMixcclxuICAgICAgICAgICAgICBcInNob3dDaXJjbGVzXCI6IHRydWUsXHJcbiAgICAgICAgICAgICAgXCJpbnRlcnBvbGF0ZVwiOiBcImxpbmVhclwiLFxyXG4gICAgICAgICAgICAgIFwidmFsdWVBeGlzXCI6IFwiVmFsdWVBeGlzLTFcIlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICBdLFxyXG4gICAgICAgICAgXCJhZGRUb29sdGlwXCI6IHRydWUsXHJcbiAgICAgICAgICBcImFkZExlZ2VuZFwiOiB0cnVlLFxyXG4gICAgICAgICAgXCJsZWdlbmRQb3NpdGlvblwiOiBcInJpZ2h0XCIsXHJcbiAgICAgICAgICBcInRpbWVzXCI6IFtdLFxyXG4gICAgICAgICAgXCJhZGRUaW1lTWFya2VyXCI6IGZhbHNlLFxyXG4gICAgICAgICAgXCJ0aHJlc2hvbGRMaW5lXCI6IHtcclxuICAgICAgICAgICAgXCJzaG93XCI6IGZhbHNlLFxyXG4gICAgICAgICAgICBcInZhbHVlXCI6IDEwLFxyXG4gICAgICAgICAgICBcIndpZHRoXCI6IDEsXHJcbiAgICAgICAgICAgIFwic3R5bGVcIjogXCJmdWxsXCIsXHJcbiAgICAgICAgICAgIFwiY29sb3JcIjogXCIjRTc2NjRDXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBcImxhYmVsc1wiOiB7fSxcclxuICAgICAgICAgIFwib3JkZXJCdWNrZXRzQnlTdW1cIjogZmFsc2VcclxuICAgICAgICB9XHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogJycsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgICAgdmVyc2lvbjogMSxcclxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XHJcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1Ub3AtNS1Pcmdhbml6YXRpb25zLUJ5LUFsZXJ0cycsXHJcbiAgICBfc291cmNlOiB7XHJcbiAgICAgIHRpdGxlOiAnVG9wIDUgb3JnYW5pemF0aW9ucyBieSBhbGVydHMnLFxyXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIFwidGl0bGVcIjogXCJUb3AgNSBvcmdhbml6YXRpb25zIGJ5IGFsZXJ0c1wiLFxyXG4gICAgICAgIFwidHlwZVwiOiBcInBpZVwiLFxyXG4gICAgICAgIFwiYWdnc1wiOiBbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiaWRcIjogXCIxXCIsXHJcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxyXG4gICAgICAgICAgICBcInR5cGVcIjogXCJjb3VudFwiLFxyXG4gICAgICAgICAgICBcInBhcmFtc1wiOiB7fSxcclxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJtZXRyaWNcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgXCJpZFwiOiBcIjJcIixcclxuICAgICAgICAgICAgXCJlbmFibGVkXCI6IHRydWUsXHJcbiAgICAgICAgICAgIFwidHlwZVwiOiBcInRlcm1zXCIsXHJcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHtcclxuICAgICAgICAgICAgICBcImZpZWxkXCI6IFwiZGF0YS5naXRodWIub3JnXCIsXHJcbiAgICAgICAgICAgICAgXCJvcmRlckJ5XCI6IFwiMVwiLFxyXG4gICAgICAgICAgICAgIFwib3JkZXJcIjogXCJkZXNjXCIsXHJcbiAgICAgICAgICAgICAgXCJzaXplXCI6IDUsXHJcbiAgICAgICAgICAgICAgXCJvdGhlckJ1Y2tldFwiOiBmYWxzZSxcclxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0TGFiZWxcIjogXCJPdGhlclwiLFxyXG4gICAgICAgICAgICAgIFwibWlzc2luZ0J1Y2tldFwiOiBmYWxzZSxcclxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRMYWJlbFwiOiBcIk1pc3NpbmdcIlxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBcInNjaGVtYVwiOiBcInNlZ21lbnRcIlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgXCJwYXJhbXNcIjoge1xyXG4gICAgICAgICAgXCJ0eXBlXCI6IFwicGllXCIsXHJcbiAgICAgICAgICBcImFkZFRvb2x0aXBcIjogdHJ1ZSxcclxuICAgICAgICAgIFwiYWRkTGVnZW5kXCI6IHRydWUsXHJcbiAgICAgICAgICBcImxlZ2VuZFBvc2l0aW9uXCI6IFwicmlnaHRcIixcclxuICAgICAgICAgIFwiaXNEb251dFwiOiBmYWxzZSxcclxuICAgICAgICAgIFwibGFiZWxzXCI6IHtcclxuICAgICAgICAgICAgXCJzaG93XCI6IGZhbHNlLFxyXG4gICAgICAgICAgICBcInZhbHVlc1wiOiB0cnVlLFxyXG4gICAgICAgICAgICBcImxhc3RfbGV2ZWxcIjogdHJ1ZSxcclxuICAgICAgICAgICAgXCJ0cnVuY2F0ZVwiOiAxMDBcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogJycsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgICAgdmVyc2lvbjogMSxcclxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XHJcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1Vc2Vycy1XaXRoLU1vcmUtQWxlcnRzJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdVc2VycyB3aXRoIG1vcmUgYWxlcnRzJyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICBcInRpdGxlXCI6IFwiVXNlcnMgd2l0aCBtb3JlIGFsZXJ0c1wiLFxyXG4gICAgICAgIFwidHlwZVwiOiBcImxpbmVcIixcclxuICAgICAgICBcImFnZ3NcIjogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBcImlkXCI6IFwiMVwiLFxyXG4gICAgICAgICAgICBcImVuYWJsZWRcIjogdHJ1ZSxcclxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwiY291bnRcIixcclxuICAgICAgICAgICAgXCJwYXJhbXNcIjoge30sXHJcbiAgICAgICAgICAgIFwic2NoZW1hXCI6IFwibWV0cmljXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiaWRcIjogXCI0XCIsXHJcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxyXG4gICAgICAgICAgICBcInR5cGVcIjogXCJ0ZXJtc1wiLFxyXG4gICAgICAgICAgICBcInBhcmFtc1wiOiB7XHJcbiAgICAgICAgICAgICAgXCJmaWVsZFwiOiBcImRhdGEuZ2l0aHViLm9yZ1wiLFxyXG4gICAgICAgICAgICAgIFwib3JkZXJCeVwiOiBcIjFcIixcclxuICAgICAgICAgICAgICBcIm9yZGVyXCI6IFwiZGVzY1wiLFxyXG4gICAgICAgICAgICAgIFwic2l6ZVwiOiA1LFxyXG4gICAgICAgICAgICAgIFwib3RoZXJCdWNrZXRcIjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgXCJvdGhlckJ1Y2tldExhYmVsXCI6IFwiT3RoZXJcIixcclxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRcIjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgXCJtaXNzaW5nQnVja2V0TGFiZWxcIjogXCJNaXNzaW5nXCJcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJzZWdtZW50XCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiaWRcIjogXCIzXCIsXHJcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxyXG4gICAgICAgICAgICBcInR5cGVcIjogXCJ0ZXJtc1wiLFxyXG4gICAgICAgICAgICBcInBhcmFtc1wiOiB7XHJcbiAgICAgICAgICAgICAgXCJmaWVsZFwiOiBcImRhdGEuZ2l0aHViLmFjdG9yXCIsXHJcbiAgICAgICAgICAgICAgXCJvcmRlckJ5XCI6IFwiMVwiLFxyXG4gICAgICAgICAgICAgIFwib3JkZXJcIjogXCJkZXNjXCIsXHJcbiAgICAgICAgICAgICAgXCJzaXplXCI6IDUsXHJcbiAgICAgICAgICAgICAgXCJvdGhlckJ1Y2tldFwiOiBmYWxzZSxcclxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0TGFiZWxcIjogXCJPdGhlclwiLFxyXG4gICAgICAgICAgICAgIFwibWlzc2luZ0J1Y2tldFwiOiBmYWxzZSxcclxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRMYWJlbFwiOiBcIk1pc3NpbmdcIlxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBcInNjaGVtYVwiOiBcImdyb3VwXCJcclxuICAgICAgICAgIH1cclxuICAgICAgICBdLFxyXG4gICAgICAgIFwicGFyYW1zXCI6IHtcclxuICAgICAgICAgIFwidHlwZVwiOiBcImxpbmVcIixcclxuICAgICAgICAgIFwiZ3JpZFwiOiB7XHJcbiAgICAgICAgICAgIFwiY2F0ZWdvcnlMaW5lc1wiOiBmYWxzZVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIFwiY2F0ZWdvcnlBeGVzXCI6IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIFwiaWRcIjogXCJDYXRlZ29yeUF4aXMtMVwiLFxyXG4gICAgICAgICAgICAgIFwidHlwZVwiOiBcImNhdGVnb3J5XCIsXHJcbiAgICAgICAgICAgICAgXCJwb3NpdGlvblwiOiBcImJvdHRvbVwiLFxyXG4gICAgICAgICAgICAgIFwic2hvd1wiOiB0cnVlLFxyXG4gICAgICAgICAgICAgIFwic3R5bGVcIjoge30sXHJcbiAgICAgICAgICAgICAgXCJzY2FsZVwiOiB7XHJcbiAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJsaW5lYXJcIlxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgXCJsYWJlbHNcIjoge1xyXG4gICAgICAgICAgICAgICAgXCJzaG93XCI6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBcImZpbHRlclwiOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgXCJ0cnVuY2F0ZVwiOiAxMDBcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIFwidGl0bGVcIjoge31cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXSxcclxuICAgICAgICAgIFwidmFsdWVBeGVzXCI6IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIFwiaWRcIjogXCJWYWx1ZUF4aXMtMVwiLFxyXG4gICAgICAgICAgICAgIFwibmFtZVwiOiBcIkxlZnRBeGlzLTFcIixcclxuICAgICAgICAgICAgICBcInR5cGVcIjogXCJ2YWx1ZVwiLFxyXG4gICAgICAgICAgICAgIFwicG9zaXRpb25cIjogXCJsZWZ0XCIsXHJcbiAgICAgICAgICAgICAgXCJzaG93XCI6IHRydWUsXHJcbiAgICAgICAgICAgICAgXCJzdHlsZVwiOiB7fSxcclxuICAgICAgICAgICAgICBcInNjYWxlXCI6IHtcclxuICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcImxpbmVhclwiLFxyXG4gICAgICAgICAgICAgICAgXCJtb2RlXCI6IFwibm9ybWFsXCJcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIFwibGFiZWxzXCI6IHtcclxuICAgICAgICAgICAgICAgIFwic2hvd1wiOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgXCJyb3RhdGVcIjogMCxcclxuICAgICAgICAgICAgICAgIFwiZmlsdGVyXCI6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgXCJ0cnVuY2F0ZVwiOiAxMDBcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIFwidGl0bGVcIjoge1xyXG4gICAgICAgICAgICAgICAgXCJ0ZXh0XCI6IFwiQ291bnRcIlxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXSxcclxuICAgICAgICAgIFwic2VyaWVzUGFyYW1zXCI6IFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIFwic2hvd1wiOiB0cnVlLFxyXG4gICAgICAgICAgICAgIFwidHlwZVwiOiBcImhpc3RvZ3JhbVwiLFxyXG4gICAgICAgICAgICAgIFwibW9kZVwiOiBcInN0YWNrZWRcIixcclxuICAgICAgICAgICAgICBcImRhdGFcIjoge1xyXG4gICAgICAgICAgICAgICAgXCJsYWJlbFwiOiBcIkNvdW50XCIsXHJcbiAgICAgICAgICAgICAgICBcImlkXCI6IFwiMVwiXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBcInZhbHVlQXhpc1wiOiBcIlZhbHVlQXhpcy0xXCIsXHJcbiAgICAgICAgICAgICAgXCJkcmF3TGluZXNCZXR3ZWVuUG9pbnRzXCI6IHRydWUsXHJcbiAgICAgICAgICAgICAgXCJsaW5lV2lkdGhcIjogMixcclxuICAgICAgICAgICAgICBcImludGVycG9sYXRlXCI6IFwibGluZWFyXCIsXHJcbiAgICAgICAgICAgICAgXCJzaG93Q2lyY2xlc1wiOiB0cnVlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIF0sXHJcbiAgICAgICAgICBcImFkZFRvb2x0aXBcIjogdHJ1ZSxcclxuICAgICAgICAgIFwiYWRkTGVnZW5kXCI6IHRydWUsXHJcbiAgICAgICAgICBcImxlZ2VuZFBvc2l0aW9uXCI6IFwicmlnaHRcIixcclxuICAgICAgICAgIFwidGltZXNcIjogW10sXHJcbiAgICAgICAgICBcImFkZFRpbWVNYXJrZXJcIjogZmFsc2UsXHJcbiAgICAgICAgICBcImxhYmVsc1wiOiB7fSxcclxuICAgICAgICAgIFwidGhyZXNob2xkTGluZVwiOiB7XHJcbiAgICAgICAgICAgIFwic2hvd1wiOiBmYWxzZSxcclxuICAgICAgICAgICAgXCJ2YWx1ZVwiOiAxMCxcclxuICAgICAgICAgICAgXCJ3aWR0aFwiOiAxLFxyXG4gICAgICAgICAgICBcInN0eWxlXCI6IFwiZnVsbFwiLFxyXG4gICAgICAgICAgICBcImNvbG9yXCI6IFwiI0U3NjY0Q1wiXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9KSxcclxuICAgICAgdWlTdGF0ZUpTT046ICcnLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046ICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1HaXRIdWItQWxlcnQtQWN0aW9uLVR5cGUtQnktT3JnYW5pemF0aW9uJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdUb3AgYWxlcnRzIGJ5IGFsZXJ0IGFjdGlvbiB0eXBlIGFuZCBvcmdhbml6YXRpb24nLFxyXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIFwidGl0bGVcIjogXCJUb3AgYWxlcnRzIGJ5IGFsZXJ0IGFjdGlvbiB0eXBlIGFuZCBvcmdhbml6YXRpb25cIixcclxuICAgICAgICBcInR5cGVcIjogXCJwaWVcIixcclxuICAgICAgICBcImFnZ3NcIjogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBcImlkXCI6IFwiMVwiLFxyXG4gICAgICAgICAgICBcImVuYWJsZWRcIjogdHJ1ZSxcclxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwiY291bnRcIixcclxuICAgICAgICAgICAgXCJwYXJhbXNcIjoge30sXHJcbiAgICAgICAgICAgIFwic2NoZW1hXCI6IFwibWV0cmljXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiaWRcIjogXCIzXCIsXHJcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxyXG4gICAgICAgICAgICBcInR5cGVcIjogXCJ0ZXJtc1wiLFxyXG4gICAgICAgICAgICBcInBhcmFtc1wiOiB7XHJcbiAgICAgICAgICAgICAgXCJmaWVsZFwiOiBcImRhdGEuZ2l0aHViLm9yZ1wiLFxyXG4gICAgICAgICAgICAgIFwib3JkZXJCeVwiOiBcIjFcIixcclxuICAgICAgICAgICAgICBcIm9yZGVyXCI6IFwiZGVzY1wiLFxyXG4gICAgICAgICAgICAgIFwic2l6ZVwiOiA1LFxyXG4gICAgICAgICAgICAgIFwib3RoZXJCdWNrZXRcIjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgXCJvdGhlckJ1Y2tldExhYmVsXCI6IFwiT3RoZXJcIixcclxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRcIjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgXCJtaXNzaW5nQnVja2V0TGFiZWxcIjogXCJNaXNzaW5nXCJcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJzZWdtZW50XCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIFwiaWRcIjogXCIyXCIsXHJcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxyXG4gICAgICAgICAgICBcInR5cGVcIjogXCJ0ZXJtc1wiLFxyXG4gICAgICAgICAgICBcInBhcmFtc1wiOiB7XHJcbiAgICAgICAgICAgICAgXCJmaWVsZFwiOiBcImRhdGEuZ2l0aHViLmFjdGlvblwiLFxyXG4gICAgICAgICAgICAgIFwib3JkZXJCeVwiOiBcIjFcIixcclxuICAgICAgICAgICAgICBcIm9yZGVyXCI6IFwiZGVzY1wiLFxyXG4gICAgICAgICAgICAgIFwic2l6ZVwiOiAzLFxyXG4gICAgICAgICAgICAgIFwib3RoZXJCdWNrZXRcIjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgXCJvdGhlckJ1Y2tldExhYmVsXCI6IFwiT3RoZXJcIixcclxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRcIjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgXCJtaXNzaW5nQnVja2V0TGFiZWxcIjogXCJNaXNzaW5nXCJcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJzZWdtZW50XCJcclxuICAgICAgICAgIH1cclxuICAgICAgICBdLFxyXG4gICAgICAgIFwicGFyYW1zXCI6IHtcclxuICAgICAgICAgIFwidHlwZVwiOiBcInBpZVwiLFxyXG4gICAgICAgICAgXCJhZGRUb29sdGlwXCI6IHRydWUsXHJcbiAgICAgICAgICBcImFkZExlZ2VuZFwiOiB0cnVlLFxyXG4gICAgICAgICAgXCJsZWdlbmRQb3NpdGlvblwiOiBcInJpZ2h0XCIsXHJcbiAgICAgICAgICBcImlzRG9udXRcIjogdHJ1ZSxcclxuICAgICAgICAgIFwibGFiZWxzXCI6IHtcclxuICAgICAgICAgICAgXCJzaG93XCI6IGZhbHNlLFxyXG4gICAgICAgICAgICBcInZhbHVlc1wiOiB0cnVlLFxyXG4gICAgICAgICAgICBcImxhc3RfbGV2ZWxcIjogdHJ1ZSxcclxuICAgICAgICAgICAgXCJ0cnVuY2F0ZVwiOiAxMDBcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogJycsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgICAgdmVyc2lvbjogMSxcclxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XHJcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1BbGVydC1TdW1tYXJ5JyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdBbGVydCBzdW1tYXJ5JyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICBcInRpdGxlXCI6IFwiQWxlcnQgc3VtbWFyeVwiLFxyXG4gICAgICAgIFwidHlwZVwiOiBcInRhYmxlXCIsXHJcbiAgICAgICAgXCJhZ2dzXCI6IFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgXCJpZFwiOiBcIjFcIixcclxuICAgICAgICAgICAgXCJlbmFibGVkXCI6IHRydWUsXHJcbiAgICAgICAgICAgIFwidHlwZVwiOiBcImNvdW50XCIsXHJcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHt9LFxyXG4gICAgICAgICAgICBcInNjaGVtYVwiOiBcIm1ldHJpY1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBcImlkXCI6IFwiMlwiLFxyXG4gICAgICAgICAgICBcImVuYWJsZWRcIjogdHJ1ZSxcclxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwidGVybXNcIixcclxuICAgICAgICAgICAgXCJwYXJhbXNcIjoge1xyXG4gICAgICAgICAgICAgIFwiZmllbGRcIjogXCJhZ2VudC5uYW1lXCIsXHJcbiAgICAgICAgICAgICAgXCJvcmRlckJ5XCI6IFwiMVwiLFxyXG4gICAgICAgICAgICAgIFwib3JkZXJcIjogXCJkZXNjXCIsXHJcbiAgICAgICAgICAgICAgXCJzaXplXCI6IDUwLFxyXG4gICAgICAgICAgICAgIFwib3RoZXJCdWNrZXRcIjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgXCJvdGhlckJ1Y2tldExhYmVsXCI6IFwiT3RoZXJcIixcclxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRcIjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgXCJtaXNzaW5nQnVja2V0TGFiZWxcIjogXCJNaXNzaW5nXCJcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJidWNrZXRcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgXCJpZFwiOiBcIjNcIixcclxuICAgICAgICAgICAgXCJlbmFibGVkXCI6IHRydWUsXHJcbiAgICAgICAgICAgIFwidHlwZVwiOiBcInRlcm1zXCIsXHJcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHtcclxuICAgICAgICAgICAgICBcImZpZWxkXCI6IFwiZGF0YS5naXRodWIub3JnXCIsXHJcbiAgICAgICAgICAgICAgXCJvcmRlckJ5XCI6IFwiMVwiLFxyXG4gICAgICAgICAgICAgIFwib3JkZXJcIjogXCJkZXNjXCIsXHJcbiAgICAgICAgICAgICAgXCJzaXplXCI6IDEwLFxyXG4gICAgICAgICAgICAgIFwib3RoZXJCdWNrZXRcIjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgXCJvdGhlckJ1Y2tldExhYmVsXCI6IFwiT3RoZXJcIixcclxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRcIjogZmFsc2UsXHJcbiAgICAgICAgICAgICAgXCJtaXNzaW5nQnVja2V0TGFiZWxcIjogXCJNaXNzaW5nXCJcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJidWNrZXRcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgXCJpZFwiOiBcIjRcIixcclxuICAgICAgICAgICAgXCJlbmFibGVkXCI6IHRydWUsXHJcbiAgICAgICAgICAgIFwidHlwZVwiOiBcInRlcm1zXCIsXHJcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHtcclxuICAgICAgICAgICAgICBcImZpZWxkXCI6IFwicnVsZS5kZXNjcmlwdGlvblwiLFxyXG4gICAgICAgICAgICAgIFwib3JkZXJCeVwiOiBcIjFcIixcclxuICAgICAgICAgICAgICBcIm9yZGVyXCI6IFwiZGVzY1wiLFxyXG4gICAgICAgICAgICAgIFwic2l6ZVwiOiAxMCxcclxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0XCI6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIFwib3RoZXJCdWNrZXRMYWJlbFwiOiBcIk90aGVyXCIsXHJcbiAgICAgICAgICAgICAgXCJtaXNzaW5nQnVja2V0XCI6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIFwibWlzc2luZ0J1Y2tldExhYmVsXCI6IFwiTWlzc2luZ1wiXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIFwic2NoZW1hXCI6IFwiYnVja2V0XCJcclxuICAgICAgICAgIH1cclxuICAgICAgICBdLFxyXG4gICAgICAgIFwicGFyYW1zXCI6IHtcclxuICAgICAgICAgIFwicGVyUGFnZVwiOiAxMCxcclxuICAgICAgICAgIFwic2hvd1BhcnRpYWxSb3dzXCI6IGZhbHNlLFxyXG4gICAgICAgICAgXCJzaG93TWV0cmljc0F0QWxsTGV2ZWxzXCI6IGZhbHNlLFxyXG4gICAgICAgICAgXCJzb3J0XCI6IHtcclxuICAgICAgICAgICAgXCJjb2x1bW5JbmRleFwiOiBudWxsLFxyXG4gICAgICAgICAgICBcImRpcmVjdGlvblwiOiBudWxsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgXCJzaG93VG90YWxcIjogZmFsc2UsXHJcbiAgICAgICAgICBcInRvdGFsRnVuY1wiOiBcInN1bVwiLFxyXG4gICAgICAgICAgXCJwZXJjZW50YWdlQ29sXCI6IFwiXCJcclxuICAgICAgICB9XHJcbiAgICAgIH0pLFxyXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogMywgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXHJcbiAgICAgIH0pLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046ICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9XHJcbl07XHJcbiJdfQ==