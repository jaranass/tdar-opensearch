"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhApiCtrl = void 0;

var _errorResponse = require("../lib/error-response");

var _json2csv = require("json2csv");

var _logger = require("../lib/logger");

var _csvKeyEquivalence = require("../../common/csv-key-equivalence");

var _apiErrorsEquivalence = require("../lib/api-errors-equivalence");

var _endpoints = _interopRequireDefault(require("../../common/api-info/endpoints"));

var _constants = require("../../common/constants");

var _queue = require("../start/queue");

var _fs = _interopRequireDefault(require("fs"));

var _manageHosts = require("../lib/manage-hosts");

var _updateRegistry = require("../lib/update-registry");

var _jwtDecode = _interopRequireDefault(require("jwt-decode"));

var _cacheApiUserHasRunAs = require("../lib/cache-api-user-has-run-as");

var _cookie = require("../lib/cookie");

var _getConfiguration = require("../lib/get-configuration");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class WazuhApiCtrl {
  constructor() {
    _defineProperty(this, "manageHosts", void 0);

    _defineProperty(this, "updateRegistry", void 0);

    this.manageHosts = new _manageHosts.ManageHosts();
    this.updateRegistry = new _updateRegistry.UpdateRegistry();
  }

  async getToken(context, request, response) {
    try {
      const {
        force,
        idHost
      } = request.body;
      const {
        username
      } = await context.wazuh.security.getCurrentUser(request, context);

      if (!force && request.headers.cookie && username === (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-user') && idHost === (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-api')) {
        const wzToken = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-token');

        if (wzToken) {
          try {
            // if the current token is not a valid jwt token we ask for a new one
            const decodedToken = (0, _jwtDecode.default)(wzToken);
            const expirationTime = decodedToken.exp - Date.now() / 1000;

            if (wzToken && expirationTime > 0) {
              return response.ok({
                body: {
                  token: wzToken
                }
              });
            }
          } catch (error) {
            (0, _logger.log)('wazuh-api:getToken', error.message || error);
          }
        }
      }

      let token;

      if ((await _cacheApiUserHasRunAs.APIUserAllowRunAs.canUse(idHost)) == _cacheApiUserHasRunAs.API_USER_STATUS_RUN_AS.ENABLED) {
        token = await context.wazuh.api.client.asCurrentUser.authenticate(idHost);
      } else {
        token = await context.wazuh.api.client.asInternalUser.authenticate(idHost);
      }

      ;
      let textSecure = '';

      if (context.wazuh.server.info.protocol === 'https') {
        textSecure = ';Secure';
      }

      return response.ok({
        headers: {
          'set-cookie': [`wz-token=${token};Path=/;HttpOnly${textSecure}`, `wz-user=${username};Path=/;HttpOnly${textSecure}`, `wz-api=${idHost};Path=/;HttpOnly`]
        },
        body: {
          token
        }
      });
    } catch (error) {
      var _error$response;

      const errorMessage = ((error.response || {}).data || {}).detail || error.message || error;
      (0, _logger.log)('wazuh-api:getToken', errorMessage);
      return (0, _errorResponse.ErrorResponse)(`Error getting the authorization token: ${errorMessage}`, 3000, (error === null || error === void 0 ? void 0 : (_error$response = error.response) === null || _error$response === void 0 ? void 0 : _error$response.status) || _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }
  /**
   * Returns if the wazuh-api configuration is working
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} status obj or ErrorResponse
   */


  async checkStoredAPI(context, request, response) {
    try {
      // Get config from wazuh.yml
      const id = request.body.id;
      const api = await this.manageHosts.getHostById(id); // Check Manage Hosts

      if (!Object.keys(api).length) {
        throw new Error('Could not find Wazuh API entry on wazuh.yml');
      }

      (0, _logger.log)('wazuh-api:checkStoredAPI', `${id} exists`, 'debug'); // Fetch needed information about the cluster and the manager itself

      const responseManagerInfo = await context.wazuh.api.client.asInternalUser.request('get', `/manager/info`, {}, {
        apiHostID: id,
        forceRefresh: true
      }); // Look for socket-related errors

      if (this.checkResponseIsDown(responseManagerInfo)) {
        return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${responseManagerInfo.data.detail || 'Wazuh not ready yet'}`, 3099, _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, response);
      } // If we have a valid response from the Wazuh API


      if (responseManagerInfo.status === _constants.HTTP_STATUS_CODES.OK && responseManagerInfo.data) {
        // Clear and update cluster information before being sent back to frontend
        delete api.cluster_info;
        const responseAgents = await context.wazuh.api.client.asInternalUser.request('GET', `/agents`, {
          params: {
            agents_list: '000'
          }
        }, {
          apiHostID: id
        });

        if (responseAgents.status === _constants.HTTP_STATUS_CODES.OK) {
          const managerName = responseAgents.data.data.affected_items[0].manager;
          const responseClusterStatus = await context.wazuh.api.client.asInternalUser.request('GET', `/cluster/status`, {}, {
            apiHostID: id
          });

          if (responseClusterStatus.status === _constants.HTTP_STATUS_CODES.OK) {
            if (responseClusterStatus.data.data.enabled === 'yes') {
              const responseClusterLocalInfo = await context.wazuh.api.client.asInternalUser.request('GET', `/cluster/local/info`, {}, {
                apiHostID: id
              });

              if (responseClusterLocalInfo.status === _constants.HTTP_STATUS_CODES.OK) {
                const clusterEnabled = responseClusterStatus.data.data.enabled === 'yes';
                api.cluster_info = {
                  status: clusterEnabled ? 'enabled' : 'disabled',
                  manager: managerName,
                  node: responseClusterLocalInfo.data.data.affected_items[0].node,
                  cluster: clusterEnabled ? responseClusterLocalInfo.data.data.affected_items[0].cluster : 'Disabled'
                };
              }
            } else {
              // Cluster mode is not active
              api.cluster_info = {
                status: 'disabled',
                manager: managerName,
                cluster: 'Disabled'
              };
            }
          } else {
            // Cluster mode is not active
            api.cluster_info = {
              status: 'disabled',
              manager: managerName,
              cluster: 'Disabled'
            };
          }

          if (api.cluster_info) {
            // Update cluster information in the wazuh-registry.json
            await this.updateRegistry.updateClusterInfo(id, api.cluster_info); // Hide Wazuh API secret, username, password

            const copied = { ...api
            };
            copied.secret = '****';
            copied.password = '****';
            return response.ok({
              body: {
                statusCode: _constants.HTTP_STATUS_CODES.OK,
                data: copied,
                idChanged: request.body.idChanged || null
              }
            });
          }
        }
      } // If we have an invalid response from the Wazuh API


      throw new Error(responseManagerInfo.data.detail || `${api.url}:${api.port} is unreachable`);
    } catch (error) {
      if (error.code === 'EPROTO') {
        return response.ok({
          body: {
            statusCode: _constants.HTTP_STATUS_CODES.OK,
            data: {
              apiIsDown: true
            }
          }
        });
      } else if (error.code === 'ECONNREFUSED') {
        return response.ok({
          body: {
            statusCode: _constants.HTTP_STATUS_CODES.OK,
            data: {
              apiIsDown: true
            }
          }
        });
      } else {
        try {
          const apis = await this.manageHosts.getHosts();

          for (const api of apis) {
            try {
              const id = Object.keys(api)[0];
              const responseManagerInfo = await context.wazuh.api.client.asInternalUser.request('GET', `/manager/info`, {}, {
                apiHostID: id
              });

              if (this.checkResponseIsDown(responseManagerInfo)) {
                return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${response.data.detail || 'Wazuh not ready yet'}`, 3099, _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, response);
              }

              if (responseManagerInfo.status === _constants.HTTP_STATUS_CODES.OK) {
                request.body.id = id;
                request.body.idChanged = id;
                return await this.checkStoredAPI(context, request, response);
              }
            } catch (error) {} // eslint-disable-line

          }
        } catch (error) {
          (0, _logger.log)('wazuh-api:checkStoredAPI', error.message || error);
          return (0, _errorResponse.ErrorResponse)(error.message || error, 3020, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
        }

        (0, _logger.log)('wazuh-api:checkStoredAPI', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 3002, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
      }
    }
  }
  /**
   * This perfoms a validation of API params
   * @param {Object} body API params
   */


  validateCheckApiParams(body) {
    if (!('username' in body)) {
      return 'Missing param: API USERNAME';
    }

    if (!('password' in body) && !('id' in body)) {
      return 'Missing param: API PASSWORD';
    }

    if (!('url' in body)) {
      return 'Missing param: API URL';
    }

    if (!('port' in body)) {
      return 'Missing param: API PORT';
    }

    if (!body.url.includes('https://') && !body.url.includes('http://')) {
      return 'protocol_error';
    }

    return false;
  }
  /**
   * This check the wazuh-api configuration received in the POST body will work
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} status obj or ErrorResponse
   */


  async checkAPI(context, request, response) {
    try {
      let apiAvailable = null; // const notValid = this.validateCheckApiParams(request.body);
      // if (notValid) return ErrorResponse(notValid, 3003, HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);

      (0, _logger.log)('wazuh-api:checkAPI', `${request.body.id} is valid`, 'debug'); // Check if a Wazuh API id is given (already stored API)

      const data = await this.manageHosts.getHostById(request.body.id);

      if (data) {
        apiAvailable = data;
      } else {
        (0, _logger.log)('wazuh-api:checkAPI', `API ${request.body.id} not found`);
        return (0, _errorResponse.ErrorResponse)(`The API ${request.body.id} was not found`, 3029, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
      }

      const options = {
        apiHostID: request.body.id
      };

      if (request.body.forceRefresh) {
        options['forceRefresh'] = request.body.forceRefresh;
      }

      let responseManagerInfo;

      try {
        responseManagerInfo = await context.wazuh.api.client.asInternalUser.request('GET', `/manager/info`, {}, options);
      } catch (error) {
        var _error$response2, _error$response2$data;

        return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${((_error$response2 = error.response) === null || _error$response2 === void 0 ? void 0 : (_error$response2$data = _error$response2.data) === null || _error$response2$data === void 0 ? void 0 : _error$response2$data.detail) || 'Wazuh not ready yet'}`, 3099, _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, response);
      }

      (0, _logger.log)('wazuh-api:checkAPI', `${request.body.id} credentials are valid`, 'debug');

      if (responseManagerInfo.status === _constants.HTTP_STATUS_CODES.OK && responseManagerInfo.data) {
        let responseAgents = await context.wazuh.api.client.asInternalUser.request('GET', `/agents`, {
          params: {
            agents_list: '000'
          }
        }, {
          apiHostID: request.body.id
        });

        if (responseAgents.status === _constants.HTTP_STATUS_CODES.OK) {
          const managerName = responseAgents.data.data.affected_items[0].manager;
          let responseCluster = await context.wazuh.api.client.asInternalUser.request('GET', `/cluster/status`, {}, {
            apiHostID: request.body.id
          }); // Check the run_as for the API user and update it

          let apiUserAllowRunAs = _cacheApiUserHasRunAs.API_USER_STATUS_RUN_AS.ALL_DISABLED;
          const responseApiUserAllowRunAs = await context.wazuh.api.client.asInternalUser.request('GET', `/security/users/me`, {}, {
            apiHostID: request.body.id
          });

          if (responseApiUserAllowRunAs.status === _constants.HTTP_STATUS_CODES.OK) {
            const allow_run_as = responseApiUserAllowRunAs.data.data.affected_items[0].allow_run_as;
            if (allow_run_as && apiAvailable && apiAvailable.run_as) // HOST AND USER ENABLED
              apiUserAllowRunAs = _cacheApiUserHasRunAs.API_USER_STATUS_RUN_AS.ENABLED;else if (!allow_run_as && apiAvailable && apiAvailable.run_as) // HOST ENABLED AND USER DISABLED
              apiUserAllowRunAs = _cacheApiUserHasRunAs.API_USER_STATUS_RUN_AS.USER_NOT_ALLOWED;else if (allow_run_as && (!apiAvailable || !apiAvailable.run_as)) // USER ENABLED AND HOST DISABLED
              apiUserAllowRunAs = _cacheApiUserHasRunAs.API_USER_STATUS_RUN_AS.HOST_DISABLED;else if (!allow_run_as && (!apiAvailable || !apiAvailable.run_as)) // HOST AND USER DISABLED
              apiUserAllowRunAs = _cacheApiUserHasRunAs.API_USER_STATUS_RUN_AS.ALL_DISABLED;
          }

          _cacheApiUserHasRunAs.CacheInMemoryAPIUserAllowRunAs.set(request.body.id, apiAvailable.username, apiUserAllowRunAs);

          if (responseCluster.status === _constants.HTTP_STATUS_CODES.OK) {
            (0, _logger.log)('wazuh-api:checkStoredAPI', `Wazuh API response is valid`, 'debug');

            if (responseCluster.data.data.enabled === 'yes') {
              // If cluster mode is active
              let responseClusterLocal = await context.wazuh.api.client.asInternalUser.request('GET', `/cluster/local/info`, {}, {
                apiHostID: request.body.id
              });

              if (responseClusterLocal.status === _constants.HTTP_STATUS_CODES.OK) {
                return response.ok({
                  body: {
                    manager: managerName,
                    node: responseClusterLocal.data.data.affected_items[0].node,
                    cluster: responseClusterLocal.data.data.affected_items[0].cluster,
                    status: 'enabled',
                    allow_run_as: apiUserAllowRunAs
                  }
                });
              }
            } else {
              // Cluster mode is not active
              return response.ok({
                body: {
                  manager: managerName,
                  cluster: 'Disabled',
                  status: 'disabled',
                  allow_run_as: apiUserAllowRunAs
                }
              });
            }
          }
        }
      }
    } catch (error) {
      (0, _logger.log)('wazuh-api:checkAPI', error.message || error);

      if (error && error.response && error.response.status === _constants.HTTP_STATUS_CODES.UNAUTHORIZED) {
        return (0, _errorResponse.ErrorResponse)(`Unathorized. Please check API credentials. ${error.response.data.message}`, _constants.HTTP_STATUS_CODES.UNAUTHORIZED, _constants.HTTP_STATUS_CODES.UNAUTHORIZED, response);
      }

      if (error && error.response && error.response.data && error.response.data.detail) {
        return (0, _errorResponse.ErrorResponse)(error.response.data.detail, error.response.status || _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, error.response.status || _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, response);
      }

      if (error.code === 'EPROTO') {
        return (0, _errorResponse.ErrorResponse)('Wrong protocol being used to connect to the Wazuh API', 3005, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
      }

      return (0, _errorResponse.ErrorResponse)(error.message || error, 3005, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }

  checkResponseIsDown(response) {
    if (response.status !== _constants.HTTP_STATUS_CODES.OK) {
      // Avoid "Error communicating with socket" like errors
      const socketErrorCodes = [1013, 1014, 1017, 1018, 1019];
      const status = (response.data || {}).status || 1;
      const isDown = socketErrorCodes.includes(status);
      isDown && (0, _logger.log)('wazuh-api:makeRequest', 'Wazuh API is online but Wazuh is not ready yet');
      return isDown;
    }

    return false;
  }
  /**
   * Check main Wazuh daemons status
   * @param {*} context Endpoint context
   * @param {*} api API entry stored in .wazuh
   * @param {*} path Optional. Wazuh API target path.
   */


  async checkDaemons(context, api, path) {
    try {
      const response = await context.wazuh.api.client.asInternalUser.request('GET', '/manager/status', {}, {
        apiHostID: api.id
      });
      const daemons = ((((response || {}).data || {}).data || {}).affected_items || [])[0] || {};
      const isCluster = ((api || {}).cluster_info || {}).status === 'enabled' && typeof daemons['wazuh-clusterd'] !== 'undefined';
      const wazuhdbExists = typeof daemons['wazuh-db'] !== 'undefined';
      const execd = daemons['wazuh-execd'] === 'running';
      const modulesd = daemons['wazuh-modulesd'] === 'running';
      const wazuhdb = wazuhdbExists ? daemons['wazuh-db'] === 'running' : true;
      const clusterd = isCluster ? daemons['wazuh-clusterd'] === 'running' : true;
      const isValid = execd && modulesd && wazuhdb && clusterd;
      isValid && (0, _logger.log)('wazuh-api:checkDaemons', `Wazuh is ready`, 'debug');

      if (path === '/ping') {
        return {
          isValid
        };
      }

      if (!isValid) {
        throw new Error('Wazuh not ready yet');
      }
    } catch (error) {
      (0, _logger.log)('wazuh-api:checkDaemons', error.message || error);
      return Promise.reject(error);
    }
  }

  sleep(timeMs) {
    // eslint-disable-next-line
    return new Promise((resolve, reject) => {
      setTimeout(resolve, timeMs);
    });
  }
  /**
   * Helper method for Dev Tools.
   * https://documentation.wazuh.com/current/user-manual/api/reference.html
   * Depending on the method and the path some parameters should be an array or not.
   * Since we allow the user to write the request using both comma-separated and array as well,
   * we need to check if it should be transformed or not.
   * @param {*} method The request method
   * @param {*} path The Wazuh API path
   */


  shouldKeepArrayAsIt(method, path) {
    // Methods that we must respect a do not transform them
    const isAgentsRestart = method === 'POST' && path === '/agents/restart';
    const isActiveResponse = method === 'PUT' && path.startsWith('/active-response');
    const isAddingAgentsToGroup = method === 'POST' && path.startsWith('/agents/group/'); // Returns true only if one of the above conditions is true

    return isAgentsRestart || isActiveResponse || isAddingAgentsToGroup;
  }
  /**
   * This performs a request over Wazuh API and returns its response
   * @param {String} method Method: GET, PUT, POST, DELETE
   * @param {String} path API route
   * @param {Object} data data and params to perform the request
   * @param {String} id API id
   * @param {Object} response
   * @returns {Object} API response or ErrorResponse
   */


  async makeRequest(context, method, path, data, id, response) {
    const devTools = !!(data || {}).devTools;

    try {
      const api = await this.manageHosts.getHostById(id);

      if (devTools) {
        delete data.devTools;
      }

      if (!Object.keys(api).length) {
        (0, _logger.log)('wazuh-api:makeRequest', 'Could not get host credentials'); //Can not get credentials from wazuh-hosts

        return (0, _errorResponse.ErrorResponse)('Could not get host credentials', 3011, _constants.HTTP_STATUS_CODES.NOT_FOUND, response);
      }

      if (!data) {
        data = {};
      }

      ;

      if (!data.headers) {
        data.headers = {};
      }

      ;
      const options = {
        apiHostID: id
      }; // Set content type application/xml if needed

      if (typeof (data || {}).body === 'string' && (data || {}).origin === 'xmleditor') {
        data.headers['content-type'] = 'application/xml';
        delete data.origin;
      }

      if (typeof (data || {}).body === 'string' && (data || {}).origin === 'json') {
        data.headers['content-type'] = 'application/json';
        delete data.origin;
      }

      if (typeof (data || {}).body === 'string' && (data || {}).origin === 'raw') {
        data.headers['content-type'] = 'application/octet-stream';
        delete data.origin;
      }

      const delay = (data || {}).delay || 0;

      if (delay) {
        (0, _queue.addJobToQueue)({
          startAt: new Date(Date.now() + delay),
          run: async () => {
            try {
              await context.wazuh.api.client.asCurrentUser.request(method, path, data, options);
            } catch (error) {
              (0, _logger.log)('queue:delayApiRequest', `An error ocurred in the delayed request: "${method} ${path}": ${error.message || error}`);
            }

            ;
          }
        });
        return response.ok({
          body: {
            error: 0,
            message: 'Success'
          }
        });
      }

      if (path === '/ping') {
        try {
          const check = await this.checkDaemons(context, api, path);
          return check;
        } catch (error) {
          const isDown = (error || {}).code === 'ECONNREFUSED';

          if (!isDown) {
            (0, _logger.log)('wazuh-api:makeRequest', 'Wazuh API is online but Wazuh is not ready yet');
            return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${error.message || 'Wazuh not ready yet'}`, 3099, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
          }
        }
      }

      (0, _logger.log)('wazuh-api:makeRequest', `${method} ${path}`, 'debug'); // Extract keys from parameters

      const dataProperties = Object.keys(data); // Transform arrays into comma-separated string if applicable.
      // The reason is that we are accepting arrays for comma-separated
      // parameters in the Dev Tools

      if (!this.shouldKeepArrayAsIt(method, path)) {
        for (const key of dataProperties) {
          if (Array.isArray(data[key])) {
            data[key] = data[key].join();
          }
        }
      }

      const responseToken = await context.wazuh.api.client.asCurrentUser.request(method, path, data, options);
      const responseIsDown = this.checkResponseIsDown(responseToken);

      if (responseIsDown) {
        return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${response.body.message || 'Wazuh not ready yet'}`, 3099, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
      }

      let responseBody = (responseToken || {}).data || {};

      if (!responseBody) {
        responseBody = typeof responseBody === 'string' && path.includes('/files') && method === 'GET' ? ' ' : false;
        response.data = responseBody;
      }

      const responseError = response.status !== _constants.HTTP_STATUS_CODES.OK ? response.status : false;

      if (!responseError && responseBody) {
        //cleanKeys(response);
        return response.ok({
          body: responseToken.data
        });
      }

      if (responseError && devTools) {
        return response.ok({
          body: response.data
        });
      }

      throw responseError && responseBody.detail ? {
        message: responseBody.detail,
        code: responseError
      } : new Error('Unexpected error fetching data from the Wazuh API');
    } catch (error) {
      if (error && error.response && error.response.status === _constants.HTTP_STATUS_CODES.UNAUTHORIZED) {
        return (0, _errorResponse.ErrorResponse)(error.message || error, error.code ? `Wazuh API error: ${error.code}` : 3013, _constants.HTTP_STATUS_CODES.UNAUTHORIZED, response);
      }

      const errorMsg = (error.response || {}).data || error.message;
      (0, _logger.log)('wazuh-api:makeRequest', errorMsg || error);

      if (devTools) {
        return response.ok({
          body: {
            error: '3013',
            message: errorMsg || error
          }
        });
      } else {
        if ((error || {}).code && _apiErrorsEquivalence.ApiErrorEquivalence[error.code]) {
          error.message = _apiErrorsEquivalence.ApiErrorEquivalence[error.code];
        }

        return (0, _errorResponse.ErrorResponse)(errorMsg.detail || error, error.code ? `Wazuh API error: ${error.code}` : 3013, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
      }
    }
  }
  /**
   * This make a request to API
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} api response or ErrorResponse
   */


  requestApi(context, request, response) {
    const idApi = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-api');

    if (idApi !== request.body.id) {
      // if the current token belongs to a different API id, we relogin to obtain a new token
      return (0, _errorResponse.ErrorResponse)(`status code 401`, _constants.HTTP_STATUS_CODES.UNAUTHORIZED, _constants.HTTP_STATUS_CODES.UNAUTHORIZED, response);
    }

    if (!request.body.method) {
      return (0, _errorResponse.ErrorResponse)('Missing param: method', 3015, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
    } else if (!request.body.method.match(/^(?:GET|PUT|POST|DELETE)$/)) {
      (0, _logger.log)('wazuh-api:makeRequest', 'Request method is not valid.'); //Method is not a valid HTTP request method

      return (0, _errorResponse.ErrorResponse)('Request method is not valid.', 3015, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
    } else if (!request.body.path) {
      return (0, _errorResponse.ErrorResponse)('Missing param: path', 3016, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
    } else if (!request.body.path.startsWith('/')) {
      (0, _logger.log)('wazuh-api:makeRequest', 'Request path is not valid.'); //Path doesn't start with '/'

      return (0, _errorResponse.ErrorResponse)('Request path is not valid.', 3015, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
    } else {
      return this.makeRequest(context, request.body.method, request.body.path, request.body.body, request.body.id, response);
    }
  }
  /**
   * Get full data on CSV format from a list Wazuh API endpoint
   * @param {Object} ctx
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} csv or ErrorResponse
   */


  async csv(context, request, response) {
    try {
      if (!request.body || !request.body.path) throw new Error('Field path is required');
      if (!request.body.id) throw new Error('Field id is required');
      const filters = Array.isArray(((request || {}).body || {}).filters) ? request.body.filters : [];
      let tmpPath = request.body.path;

      if (tmpPath && typeof tmpPath === 'string') {
        tmpPath = tmpPath[0] === '/' ? tmpPath.substr(1) : tmpPath;
      }

      if (!tmpPath) throw new Error('An error occurred parsing path field');
      (0, _logger.log)('wazuh-api:csv', `Report ${tmpPath}`, 'debug'); // Real limit, regardless the user query

      const params = {
        limit: 500
      };

      if (filters.length) {
        for (const filter of filters) {
          if (!filter.name || !filter.value) continue;
          params[filter.name] = filter.value;
        }
      }

      let itemsArray = [];
      const output = await context.wazuh.api.client.asCurrentUser.request('GET', `/${tmpPath}`, {
        params: params
      }, {
        apiHostID: request.body.id
      });
      const isList = request.body.path.includes('/lists') && request.body.filters && request.body.filters.length && request.body.filters.find(filter => filter._isCDBList);
      const totalItems = (((output || {}).data || {}).data || {}).total_affected_items;

      if (totalItems && !isList) {
        params.offset = 0;
        itemsArray.push(...output.data.data.affected_items);

        while (itemsArray.length < totalItems && params.offset < totalItems) {
          params.offset += params.limit;
          const tmpData = await context.wazuh.api.client.asCurrentUser.request('GET', `/${tmpPath}`, {
            params: params
          }, {
            apiHostID: request.body.id
          });
          itemsArray.push(...tmpData.data.data.affected_items);
        }
      }

      if (totalItems) {
        const {
          path,
          filters
        } = request.body;
        const isArrayOfLists = path.includes('/lists') && !isList;
        const isAgents = path.includes('/agents') && !path.includes('groups');
        const isAgentsOfGroup = path.startsWith('/agents/groups/');
        const isFiles = path.endsWith('/files');
        let fields = Object.keys(output.data.data.affected_items[0]);

        if (isAgents || isAgentsOfGroup) {
          if (isFiles) {
            fields = ['filename', 'hash'];
          } else {
            fields = ['id', 'status', 'name', 'ip', 'group', 'manager', 'node_name', 'dateAdd', 'version', 'lastKeepAlive', 'os.arch', 'os.build', 'os.codename', 'os.major', 'os.minor', 'os.name', 'os.platform', 'os.uname', 'os.version'];
          }
        }

        if (isArrayOfLists) {
          const flatLists = [];

          for (const list of itemsArray) {
            const {
              relative_dirname,
              items
            } = list;
            flatLists.push(...items.map(item => ({
              relative_dirname,
              key: item.key,
              value: item.value
            })));
          }

          fields = ['relative_dirname', 'key', 'value'];
          itemsArray = [...flatLists];
        }

        if (isList) {
          fields = ['key', 'value'];
          itemsArray = output.data.data.affected_items[0].items;
        }

        fields = fields.map(item => ({
          value: item,
          default: '-'
        }));
        const json2csvParser = new _json2csv.Parser({
          fields
        });
        let csv = json2csvParser.parse(itemsArray);

        for (const field of fields) {
          const {
            value
          } = field;

          if (csv.includes(value)) {
            csv = csv.replace(value, _csvKeyEquivalence.KeyEquivalence[value] || value);
          }
        }

        return response.ok({
          headers: {
            'Content-Type': 'text/csv'
          },
          body: csv
        });
      } else if (output && output.data && output.data.data && !output.data.data.total_affected_items) {
        throw new Error('No results');
      } else {
        throw new Error(`An error occurred fetching data from the Wazuh API${output && output.data && output.data.detail ? `: ${output.body.detail}` : ''}`);
      }
    } catch (error) {
      (0, _logger.log)('wazuh-api:csv', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3034, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  } // Get de list of available requests in the API


  getRequestList(context, request, response) {
    //Read a static JSON until the api call has implemented
    return response.ok({
      body: _endpoints.default
    });
  }
  /**
   * This get the timestamp field
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} timestamp field or ErrorResponse
   */


  getTimeStamp(context, request, response) {
    try {
      const source = JSON.parse(_fs.default.readFileSync(this.updateRegistry.file, 'utf8'));

      if (source.installationDate && source.lastRestart) {
        (0, _logger.log)('wazuh-api:getTimeStamp', `Installation date: ${source.installationDate}. Last restart: ${source.lastRestart}`, 'debug');
        return response.ok({
          body: {
            installationDate: source.installationDate,
            lastRestart: source.lastRestart
          }
        });
      } else {
        throw new Error('Could not fetch wazuh-version registry');
      }
    } catch (error) {
      (0, _logger.log)('wazuh-api:getTimeStamp', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || 'Could not fetch wazuh-version registry', 4001, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }
  /**
   * This get the extensions
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} extensions object or ErrorResponse
   */


  async setExtensions(context, request, response) {
    try {
      const {
        id,
        extensions
      } = request.body; // Update cluster information in the wazuh-registry.json

      await this.updateRegistry.updateAPIExtensions(id, extensions);
      return response.ok({
        body: {
          statusCode: _constants.HTTP_STATUS_CODES.OK
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-api:setExtensions', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || 'Could not set extensions', 4001, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }
  /**
   * This get the extensions
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} extensions object or ErrorResponse
   */


  getExtensions(context, request, response) {
    try {
      const source = JSON.parse(_fs.default.readFileSync(this.updateRegistry.file, 'utf8'));
      return response.ok({
        body: {
          extensions: (source.hosts[request.params.id] || {}).extensions || {}
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-api:getExtensions', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || 'Could not fetch wazuh-version registry', 4001, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }
  /**
   * This get the wazuh setup settings
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} setup info or ErrorResponse
   */


  async getSetupInfo(context, request, response) {
    try {
      const source = JSON.parse(_fs.default.readFileSync(this.updateRegistry.file, 'utf8'));
      return response.ok({
        body: {
          statusCode: _constants.HTTP_STATUS_CODES.OK,
          data: !Object.values(source).length ? '' : source
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-api:getSetupInfo', error.message || error);
      return (0, _errorResponse.ErrorResponse)(`Could not get data from wazuh-version registry due to ${error.message || error}`, 4005, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }
  /**
   * Get basic syscollector information for given agent.
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} Basic syscollector information
   */


  async getSyscollector(context, request, response) {
    try {
      const apiHostID = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-api');

      if (!request.params || !apiHostID || !request.params.agent) {
        throw new Error('Agent ID and API ID are required');
      }

      const {
        agent
      } = request.params;
      const data = await Promise.all([context.wazuh.api.client.asInternalUser.request('GET', `/syscollector/${agent}/hardware`, {}, {
        apiHostID
      }), context.wazuh.api.client.asInternalUser.request('GET', `/syscollector/${agent}/os`, {}, {
        apiHostID
      })]);
      const result = data.map(item => (item.data || {}).data || []);
      const [hardwareResponse, osResponse] = result; // Fill syscollector object

      const syscollector = {
        hardware: typeof hardwareResponse === 'object' && Object.keys(hardwareResponse).length ? { ...hardwareResponse.affected_items[0]
        } : false,
        os: typeof osResponse === 'object' && Object.keys(osResponse).length ? { ...osResponse.affected_items[0]
        } : false
      };
      return response.ok({
        body: syscollector
      });
    } catch (error) {
      (0, _logger.log)('wazuh-api:getSyscollector', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3035, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }
  /**
   * Check if user assigned roles disable Wazuh Plugin
   * @param context
   * @param request
   * @param response
   * @returns {object} Returns { isWazuhDisabled: boolean parsed integer }
   */


  async isWazuhDisabled(context, request, response) {
    try {
      const disabledRoles = (await (0, _getConfiguration.getConfiguration)())['disabled_roles'] || [];
      const logoSidebar = (await (0, _getConfiguration.getConfiguration)())['customization.logo.sidebar'];
      const data = (await context.wazuh.security.getCurrentUser(request, context)).authContext;
      const isWazuhDisabled = +(data.roles || []).some(role => disabledRoles.includes(role));
      return response.ok({
        body: {
          isWazuhDisabled,
          logoSidebar
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-api:isWazuhDisabled', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3035, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }

}

exports.WazuhApiCtrl = WazuhApiCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhenVoLWFwaS50cyJdLCJuYW1lcyI6WyJXYXp1aEFwaUN0cmwiLCJjb25zdHJ1Y3RvciIsIm1hbmFnZUhvc3RzIiwiTWFuYWdlSG9zdHMiLCJ1cGRhdGVSZWdpc3RyeSIsIlVwZGF0ZVJlZ2lzdHJ5IiwiZ2V0VG9rZW4iLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwiZm9yY2UiLCJpZEhvc3QiLCJib2R5IiwidXNlcm5hbWUiLCJ3YXp1aCIsInNlY3VyaXR5IiwiZ2V0Q3VycmVudFVzZXIiLCJoZWFkZXJzIiwiY29va2llIiwid3pUb2tlbiIsImRlY29kZWRUb2tlbiIsImV4cGlyYXRpb25UaW1lIiwiZXhwIiwiRGF0ZSIsIm5vdyIsIm9rIiwidG9rZW4iLCJlcnJvciIsIm1lc3NhZ2UiLCJBUElVc2VyQWxsb3dSdW5BcyIsImNhblVzZSIsIkFQSV9VU0VSX1NUQVRVU19SVU5fQVMiLCJFTkFCTEVEIiwiYXBpIiwiY2xpZW50IiwiYXNDdXJyZW50VXNlciIsImF1dGhlbnRpY2F0ZSIsImFzSW50ZXJuYWxVc2VyIiwidGV4dFNlY3VyZSIsInNlcnZlciIsImluZm8iLCJwcm90b2NvbCIsImVycm9yTWVzc2FnZSIsImRhdGEiLCJkZXRhaWwiLCJzdGF0dXMiLCJIVFRQX1NUQVRVU19DT0RFUyIsIklOVEVSTkFMX1NFUlZFUl9FUlJPUiIsImNoZWNrU3RvcmVkQVBJIiwiaWQiLCJnZXRIb3N0QnlJZCIsIk9iamVjdCIsImtleXMiLCJsZW5ndGgiLCJFcnJvciIsInJlc3BvbnNlTWFuYWdlckluZm8iLCJhcGlIb3N0SUQiLCJmb3JjZVJlZnJlc2giLCJjaGVja1Jlc3BvbnNlSXNEb3duIiwiU0VSVklDRV9VTkFWQUlMQUJMRSIsIk9LIiwiY2x1c3Rlcl9pbmZvIiwicmVzcG9uc2VBZ2VudHMiLCJwYXJhbXMiLCJhZ2VudHNfbGlzdCIsIm1hbmFnZXJOYW1lIiwiYWZmZWN0ZWRfaXRlbXMiLCJtYW5hZ2VyIiwicmVzcG9uc2VDbHVzdGVyU3RhdHVzIiwiZW5hYmxlZCIsInJlc3BvbnNlQ2x1c3RlckxvY2FsSW5mbyIsImNsdXN0ZXJFbmFibGVkIiwibm9kZSIsImNsdXN0ZXIiLCJ1cGRhdGVDbHVzdGVySW5mbyIsImNvcGllZCIsInNlY3JldCIsInBhc3N3b3JkIiwic3RhdHVzQ29kZSIsImlkQ2hhbmdlZCIsInVybCIsInBvcnQiLCJjb2RlIiwiYXBpSXNEb3duIiwiYXBpcyIsImdldEhvc3RzIiwidmFsaWRhdGVDaGVja0FwaVBhcmFtcyIsImluY2x1ZGVzIiwiY2hlY2tBUEkiLCJhcGlBdmFpbGFibGUiLCJvcHRpb25zIiwicmVzcG9uc2VDbHVzdGVyIiwiYXBpVXNlckFsbG93UnVuQXMiLCJBTExfRElTQUJMRUQiLCJyZXNwb25zZUFwaVVzZXJBbGxvd1J1bkFzIiwiYWxsb3dfcnVuX2FzIiwicnVuX2FzIiwiVVNFUl9OT1RfQUxMT1dFRCIsIkhPU1RfRElTQUJMRUQiLCJDYWNoZUluTWVtb3J5QVBJVXNlckFsbG93UnVuQXMiLCJzZXQiLCJyZXNwb25zZUNsdXN0ZXJMb2NhbCIsIlVOQVVUSE9SSVpFRCIsIkJBRF9SRVFVRVNUIiwic29ja2V0RXJyb3JDb2RlcyIsImlzRG93biIsImNoZWNrRGFlbW9ucyIsInBhdGgiLCJkYWVtb25zIiwiaXNDbHVzdGVyIiwid2F6dWhkYkV4aXN0cyIsImV4ZWNkIiwibW9kdWxlc2QiLCJ3YXp1aGRiIiwiY2x1c3RlcmQiLCJpc1ZhbGlkIiwiUHJvbWlzZSIsInJlamVjdCIsInNsZWVwIiwidGltZU1zIiwicmVzb2x2ZSIsInNldFRpbWVvdXQiLCJzaG91bGRLZWVwQXJyYXlBc0l0IiwibWV0aG9kIiwiaXNBZ2VudHNSZXN0YXJ0IiwiaXNBY3RpdmVSZXNwb25zZSIsInN0YXJ0c1dpdGgiLCJpc0FkZGluZ0FnZW50c1RvR3JvdXAiLCJtYWtlUmVxdWVzdCIsImRldlRvb2xzIiwiTk9UX0ZPVU5EIiwib3JpZ2luIiwiZGVsYXkiLCJzdGFydEF0IiwicnVuIiwiY2hlY2siLCJkYXRhUHJvcGVydGllcyIsImtleSIsIkFycmF5IiwiaXNBcnJheSIsImpvaW4iLCJyZXNwb25zZVRva2VuIiwicmVzcG9uc2VJc0Rvd24iLCJyZXNwb25zZUJvZHkiLCJyZXNwb25zZUVycm9yIiwiZXJyb3JNc2ciLCJBcGlFcnJvckVxdWl2YWxlbmNlIiwicmVxdWVzdEFwaSIsImlkQXBpIiwibWF0Y2giLCJjc3YiLCJmaWx0ZXJzIiwidG1wUGF0aCIsInN1YnN0ciIsImxpbWl0IiwiZmlsdGVyIiwibmFtZSIsInZhbHVlIiwiaXRlbXNBcnJheSIsIm91dHB1dCIsImlzTGlzdCIsImZpbmQiLCJfaXNDREJMaXN0IiwidG90YWxJdGVtcyIsInRvdGFsX2FmZmVjdGVkX2l0ZW1zIiwib2Zmc2V0IiwicHVzaCIsInRtcERhdGEiLCJpc0FycmF5T2ZMaXN0cyIsImlzQWdlbnRzIiwiaXNBZ2VudHNPZkdyb3VwIiwiaXNGaWxlcyIsImVuZHNXaXRoIiwiZmllbGRzIiwiZmxhdExpc3RzIiwibGlzdCIsInJlbGF0aXZlX2Rpcm5hbWUiLCJpdGVtcyIsIm1hcCIsIml0ZW0iLCJkZWZhdWx0IiwianNvbjJjc3ZQYXJzZXIiLCJQYXJzZXIiLCJwYXJzZSIsImZpZWxkIiwicmVwbGFjZSIsIktleUVxdWl2YWxlbmNlIiwiZ2V0UmVxdWVzdExpc3QiLCJhcGlSZXF1ZXN0TGlzdCIsImdldFRpbWVTdGFtcCIsInNvdXJjZSIsIkpTT04iLCJmcyIsInJlYWRGaWxlU3luYyIsImZpbGUiLCJpbnN0YWxsYXRpb25EYXRlIiwibGFzdFJlc3RhcnQiLCJzZXRFeHRlbnNpb25zIiwiZXh0ZW5zaW9ucyIsInVwZGF0ZUFQSUV4dGVuc2lvbnMiLCJnZXRFeHRlbnNpb25zIiwiaG9zdHMiLCJnZXRTZXR1cEluZm8iLCJ2YWx1ZXMiLCJnZXRTeXNjb2xsZWN0b3IiLCJhZ2VudCIsImFsbCIsInJlc3VsdCIsImhhcmR3YXJlUmVzcG9uc2UiLCJvc1Jlc3BvbnNlIiwic3lzY29sbGVjdG9yIiwiaGFyZHdhcmUiLCJvcyIsImlzV2F6dWhEaXNhYmxlZCIsImRpc2FibGVkUm9sZXMiLCJsb2dvU2lkZWJhciIsImF1dGhDb250ZXh0Iiwicm9sZXMiLCJzb21lIiwicm9sZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQWFBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUVBOztBQUNBOztBQUVBOzs7Ozs7QUFFTyxNQUFNQSxZQUFOLENBQW1CO0FBSXhCQyxFQUFBQSxXQUFXLEdBQUc7QUFBQTs7QUFBQTs7QUFDWixTQUFLQyxXQUFMLEdBQW1CLElBQUlDLHdCQUFKLEVBQW5CO0FBQ0EsU0FBS0MsY0FBTCxHQUFzQixJQUFJQyw4QkFBSixFQUF0QjtBQUNEOztBQUVhLFFBQVJDLFFBQVEsQ0FBQ0MsT0FBRCxFQUFpQ0MsT0FBakMsRUFBdUVDLFFBQXZFLEVBQXNIO0FBQ2xJLFFBQUk7QUFDRixZQUFNO0FBQUVDLFFBQUFBLEtBQUY7QUFBU0MsUUFBQUE7QUFBVCxVQUFvQkgsT0FBTyxDQUFDSSxJQUFsQztBQUNBLFlBQU07QUFBRUMsUUFBQUE7QUFBRixVQUFlLE1BQU1OLE9BQU8sQ0FBQ08sS0FBUixDQUFjQyxRQUFkLENBQXVCQyxjQUF2QixDQUFzQ1IsT0FBdEMsRUFBK0NELE9BQS9DLENBQTNCOztBQUNBLFVBQUksQ0FBQ0csS0FBRCxJQUFVRixPQUFPLENBQUNTLE9BQVIsQ0FBZ0JDLE1BQTFCLElBQW9DTCxRQUFRLEtBQUssa0NBQXFCTCxPQUFPLENBQUNTLE9BQVIsQ0FBZ0JDLE1BQXJDLEVBQTZDLFNBQTdDLENBQWpELElBQTRHUCxNQUFNLEtBQUssa0NBQXFCSCxPQUFPLENBQUNTLE9BQVIsQ0FBZ0JDLE1BQXJDLEVBQTRDLFFBQTVDLENBQTNILEVBQWtMO0FBQ2hMLGNBQU1DLE9BQU8sR0FBRyxrQ0FBcUJYLE9BQU8sQ0FBQ1MsT0FBUixDQUFnQkMsTUFBckMsRUFBNkMsVUFBN0MsQ0FBaEI7O0FBQ0EsWUFBSUMsT0FBSixFQUFhO0FBQ1gsY0FBSTtBQUFFO0FBQ0osa0JBQU1DLFlBQVksR0FBRyx3QkFBVUQsT0FBVixDQUFyQjtBQUNBLGtCQUFNRSxjQUFjLEdBQUlELFlBQVksQ0FBQ0UsR0FBYixHQUFvQkMsSUFBSSxDQUFDQyxHQUFMLEtBQWEsSUFBekQ7O0FBQ0EsZ0JBQUlMLE9BQU8sSUFBSUUsY0FBYyxHQUFHLENBQWhDLEVBQW1DO0FBQ2pDLHFCQUFPWixRQUFRLENBQUNnQixFQUFULENBQVk7QUFDakJiLGdCQUFBQSxJQUFJLEVBQUU7QUFBRWMsa0JBQUFBLEtBQUssRUFBRVA7QUFBVDtBQURXLGVBQVosQ0FBUDtBQUdEO0FBQ0YsV0FSRCxDQVFFLE9BQU9RLEtBQVAsRUFBYztBQUNkLDZCQUFJLG9CQUFKLEVBQTBCQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQTNDO0FBQ0Q7QUFDRjtBQUNGOztBQUNELFVBQUlELEtBQUo7O0FBQ0EsVUFBSSxPQUFNRyx3Q0FBa0JDLE1BQWxCLENBQXlCbkIsTUFBekIsQ0FBTixLQUEwQ29CLDZDQUF1QkMsT0FBckUsRUFBOEU7QUFDNUVOLFFBQUFBLEtBQUssR0FBRyxNQUFNbkIsT0FBTyxDQUFDTyxLQUFSLENBQWNtQixHQUFkLENBQWtCQyxNQUFsQixDQUF5QkMsYUFBekIsQ0FBdUNDLFlBQXZDLENBQW9EekIsTUFBcEQsQ0FBZDtBQUNELE9BRkQsTUFFTztBQUNMZSxRQUFBQSxLQUFLLEdBQUcsTUFBTW5CLE9BQU8sQ0FBQ08sS0FBUixDQUFjbUIsR0FBZCxDQUFrQkMsTUFBbEIsQ0FBeUJHLGNBQXpCLENBQXdDRCxZQUF4QyxDQUFxRHpCLE1BQXJELENBQWQ7QUFDRDs7QUFBQTtBQUVELFVBQUkyQixVQUFVLEdBQUMsRUFBZjs7QUFDQSxVQUFHL0IsT0FBTyxDQUFDTyxLQUFSLENBQWN5QixNQUFkLENBQXFCQyxJQUFyQixDQUEwQkMsUUFBMUIsS0FBdUMsT0FBMUMsRUFBa0Q7QUFDaERILFFBQUFBLFVBQVUsR0FBRyxTQUFiO0FBQ0Q7O0FBRUQsYUFBTzdCLFFBQVEsQ0FBQ2dCLEVBQVQsQ0FBWTtBQUNqQlIsUUFBQUEsT0FBTyxFQUFFO0FBQ1Asd0JBQWMsQ0FDWCxZQUFXUyxLQUFNLG1CQUFrQlksVUFBVyxFQURuQyxFQUVYLFdBQVV6QixRQUFTLG1CQUFrQnlCLFVBQVcsRUFGckMsRUFHWCxVQUFTM0IsTUFBTyxrQkFITDtBQURQLFNBRFE7QUFRakJDLFFBQUFBLElBQUksRUFBRTtBQUFFYyxVQUFBQTtBQUFGO0FBUlcsT0FBWixDQUFQO0FBVUQsS0F6Q0QsQ0F5Q0UsT0FBT0MsS0FBUCxFQUFjO0FBQUE7O0FBQ2QsWUFBTWUsWUFBWSxHQUFHLENBQUMsQ0FBQ2YsS0FBSyxDQUFDbEIsUUFBTixJQUFrQixFQUFuQixFQUF1QmtDLElBQXZCLElBQStCLEVBQWhDLEVBQW9DQyxNQUFwQyxJQUE4Q2pCLEtBQUssQ0FBQ0MsT0FBcEQsSUFBK0RELEtBQXBGO0FBQ0EsdUJBQUksb0JBQUosRUFBMEJlLFlBQTFCO0FBQ0EsYUFBTyxrQ0FDSiwwQ0FBeUNBLFlBQWEsRUFEbEQsRUFFTCxJQUZLLEVBR0wsQ0FBQWYsS0FBSyxTQUFMLElBQUFBLEtBQUssV0FBTCwrQkFBQUEsS0FBSyxDQUFFbEIsUUFBUCxvRUFBaUJvQyxNQUFqQixLQUEyQkMsNkJBQWtCQyxxQkFIeEMsRUFJTHRDLFFBSkssQ0FBUDtBQU1EO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ3NCLFFBQWR1QyxjQUFjLENBQUN6QyxPQUFELEVBQWlDQyxPQUFqQyxFQUF1RUMsUUFBdkUsRUFBc0g7QUFDeEksUUFBSTtBQUNGO0FBQ0EsWUFBTXdDLEVBQUUsR0FBR3pDLE9BQU8sQ0FBQ0ksSUFBUixDQUFhcUMsRUFBeEI7QUFDQSxZQUFNaEIsR0FBRyxHQUFHLE1BQU0sS0FBSy9CLFdBQUwsQ0FBaUJnRCxXQUFqQixDQUE2QkQsRUFBN0IsQ0FBbEIsQ0FIRSxDQUlGOztBQUNBLFVBQUksQ0FBQ0UsTUFBTSxDQUFDQyxJQUFQLENBQVluQixHQUFaLEVBQWlCb0IsTUFBdEIsRUFBOEI7QUFDNUIsY0FBTSxJQUFJQyxLQUFKLENBQVUsNkNBQVYsQ0FBTjtBQUNEOztBQUVELHVCQUFJLDBCQUFKLEVBQWlDLEdBQUVMLEVBQUcsU0FBdEMsRUFBZ0QsT0FBaEQsRUFURSxDQVdGOztBQUNBLFlBQU1NLG1CQUFtQixHQUFHLE1BQU1oRCxPQUFPLENBQUNPLEtBQVIsQ0FBY21CLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCRyxjQUF6QixDQUF3QzdCLE9BQXhDLENBQ2hDLEtBRGdDLEVBRS9CLGVBRitCLEVBR2hDLEVBSGdDLEVBSWhDO0FBQUVnRCxRQUFBQSxTQUFTLEVBQUVQLEVBQWI7QUFBaUJRLFFBQUFBLFlBQVksRUFBRTtBQUEvQixPQUpnQyxDQUFsQyxDQVpFLENBbUJGOztBQUNBLFVBQUksS0FBS0MsbUJBQUwsQ0FBeUJILG1CQUF6QixDQUFKLEVBQW1EO0FBQ2pELGVBQU8sa0NBQ0osZUFBY0EsbUJBQW1CLENBQUNaLElBQXBCLENBQXlCQyxNQUF6QixJQUFtQyxxQkFBc0IsRUFEbkUsRUFFTCxJQUZLLEVBR0xFLDZCQUFrQmEsbUJBSGIsRUFJTGxELFFBSkssQ0FBUDtBQU1ELE9BM0JDLENBNkJGOzs7QUFDQSxVQUFJOEMsbUJBQW1CLENBQUNWLE1BQXBCLEtBQStCQyw2QkFBa0JjLEVBQWpELElBQXVETCxtQkFBbUIsQ0FBQ1osSUFBL0UsRUFBcUY7QUFDbkY7QUFDQSxlQUFPVixHQUFHLENBQUM0QixZQUFYO0FBQ0EsY0FBTUMsY0FBYyxHQUFHLE1BQU12RCxPQUFPLENBQUNPLEtBQVIsQ0FBY21CLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCRyxjQUF6QixDQUF3QzdCLE9BQXhDLENBQzNCLEtBRDJCLEVBRTFCLFNBRjBCLEVBRzNCO0FBQUV1RCxVQUFBQSxNQUFNLEVBQUU7QUFBRUMsWUFBQUEsV0FBVyxFQUFFO0FBQWY7QUFBVixTQUgyQixFQUkzQjtBQUFFUixVQUFBQSxTQUFTLEVBQUVQO0FBQWIsU0FKMkIsQ0FBN0I7O0FBT0EsWUFBSWEsY0FBYyxDQUFDakIsTUFBZixLQUEwQkMsNkJBQWtCYyxFQUFoRCxFQUFvRDtBQUNsRCxnQkFBTUssV0FBVyxHQUFHSCxjQUFjLENBQUNuQixJQUFmLENBQW9CQSxJQUFwQixDQUF5QnVCLGNBQXpCLENBQXdDLENBQXhDLEVBQTJDQyxPQUEvRDtBQUVBLGdCQUFNQyxxQkFBcUIsR0FBRyxNQUFNN0QsT0FBTyxDQUFDTyxLQUFSLENBQWNtQixHQUFkLENBQWtCQyxNQUFsQixDQUF5QkcsY0FBekIsQ0FBd0M3QixPQUF4QyxDQUNsQyxLQURrQyxFQUVqQyxpQkFGaUMsRUFHbEMsRUFIa0MsRUFJbEM7QUFBRWdELFlBQUFBLFNBQVMsRUFBRVA7QUFBYixXQUprQyxDQUFwQzs7QUFNQSxjQUFJbUIscUJBQXFCLENBQUN2QixNQUF0QixLQUFpQ0MsNkJBQWtCYyxFQUF2RCxFQUEyRDtBQUN6RCxnQkFBSVEscUJBQXFCLENBQUN6QixJQUF0QixDQUEyQkEsSUFBM0IsQ0FBZ0MwQixPQUFoQyxLQUE0QyxLQUFoRCxFQUF1RDtBQUNyRCxvQkFBTUMsd0JBQXdCLEdBQUcsTUFBTS9ELE9BQU8sQ0FBQ08sS0FBUixDQUFjbUIsR0FBZCxDQUFrQkMsTUFBbEIsQ0FBeUJHLGNBQXpCLENBQXdDN0IsT0FBeEMsQ0FDckMsS0FEcUMsRUFFcEMscUJBRm9DLEVBR3JDLEVBSHFDLEVBSXJDO0FBQUVnRCxnQkFBQUEsU0FBUyxFQUFFUDtBQUFiLGVBSnFDLENBQXZDOztBQU1BLGtCQUFJcUIsd0JBQXdCLENBQUN6QixNQUF6QixLQUFvQ0MsNkJBQWtCYyxFQUExRCxFQUE4RDtBQUM1RCxzQkFBTVcsY0FBYyxHQUFHSCxxQkFBcUIsQ0FBQ3pCLElBQXRCLENBQTJCQSxJQUEzQixDQUFnQzBCLE9BQWhDLEtBQTRDLEtBQW5FO0FBQ0FwQyxnQkFBQUEsR0FBRyxDQUFDNEIsWUFBSixHQUFtQjtBQUNqQmhCLGtCQUFBQSxNQUFNLEVBQUUwQixjQUFjLEdBQUcsU0FBSCxHQUFlLFVBRHBCO0FBRWpCSixrQkFBQUEsT0FBTyxFQUFFRixXQUZRO0FBR2pCTyxrQkFBQUEsSUFBSSxFQUFFRix3QkFBd0IsQ0FBQzNCLElBQXpCLENBQThCQSxJQUE5QixDQUFtQ3VCLGNBQW5DLENBQWtELENBQWxELEVBQXFETSxJQUgxQztBQUlqQkMsa0JBQUFBLE9BQU8sRUFBRUYsY0FBYyxHQUNuQkQsd0JBQXdCLENBQUMzQixJQUF6QixDQUE4QkEsSUFBOUIsQ0FBbUN1QixjQUFuQyxDQUFrRCxDQUFsRCxFQUFxRE8sT0FEbEMsR0FFbkI7QUFOYSxpQkFBbkI7QUFRRDtBQUNGLGFBbEJELE1Ba0JPO0FBQ0w7QUFDQXhDLGNBQUFBLEdBQUcsQ0FBQzRCLFlBQUosR0FBbUI7QUFDakJoQixnQkFBQUEsTUFBTSxFQUFFLFVBRFM7QUFFakJzQixnQkFBQUEsT0FBTyxFQUFFRixXQUZRO0FBR2pCUSxnQkFBQUEsT0FBTyxFQUFFO0FBSFEsZUFBbkI7QUFLRDtBQUNGLFdBM0JELE1BMkJPO0FBQ0w7QUFDQXhDLFlBQUFBLEdBQUcsQ0FBQzRCLFlBQUosR0FBbUI7QUFDakJoQixjQUFBQSxNQUFNLEVBQUUsVUFEUztBQUVqQnNCLGNBQUFBLE9BQU8sRUFBRUYsV0FGUTtBQUdqQlEsY0FBQUEsT0FBTyxFQUFFO0FBSFEsYUFBbkI7QUFLRDs7QUFFRCxjQUFJeEMsR0FBRyxDQUFDNEIsWUFBUixFQUFzQjtBQUNwQjtBQUNBLGtCQUFNLEtBQUt6RCxjQUFMLENBQW9Cc0UsaUJBQXBCLENBQXNDekIsRUFBdEMsRUFBMENoQixHQUFHLENBQUM0QixZQUE5QyxDQUFOLENBRm9CLENBSXBCOztBQUNBLGtCQUFNYyxNQUFNLEdBQUcsRUFBRSxHQUFHMUM7QUFBTCxhQUFmO0FBQ0EwQyxZQUFBQSxNQUFNLENBQUNDLE1BQVAsR0FBZ0IsTUFBaEI7QUFDQUQsWUFBQUEsTUFBTSxDQUFDRSxRQUFQLEdBQWtCLE1BQWxCO0FBRUEsbUJBQU9wRSxRQUFRLENBQUNnQixFQUFULENBQVk7QUFDakJiLGNBQUFBLElBQUksRUFBRTtBQUNKa0UsZ0JBQUFBLFVBQVUsRUFBRWhDLDZCQUFrQmMsRUFEMUI7QUFFSmpCLGdCQUFBQSxJQUFJLEVBQUVnQyxNQUZGO0FBR0pJLGdCQUFBQSxTQUFTLEVBQUV2RSxPQUFPLENBQUNJLElBQVIsQ0FBYW1FLFNBQWIsSUFBMEI7QUFIakM7QUFEVyxhQUFaLENBQVA7QUFPRDtBQUNGO0FBQ0YsT0F2R0MsQ0F5R0Y7OztBQUNBLFlBQU0sSUFBSXpCLEtBQUosQ0FBVUMsbUJBQW1CLENBQUNaLElBQXBCLENBQXlCQyxNQUF6QixJQUFvQyxHQUFFWCxHQUFHLENBQUMrQyxHQUFJLElBQUcvQyxHQUFHLENBQUNnRCxJQUFLLGlCQUFwRSxDQUFOO0FBQ0QsS0EzR0QsQ0EyR0UsT0FBT3RELEtBQVAsRUFBYztBQUNkLFVBQUlBLEtBQUssQ0FBQ3VELElBQU4sS0FBZSxRQUFuQixFQUE2QjtBQUMzQixlQUFPekUsUUFBUSxDQUFDZ0IsRUFBVCxDQUFZO0FBQ2pCYixVQUFBQSxJQUFJLEVBQUU7QUFDSmtFLFlBQUFBLFVBQVUsRUFBRWhDLDZCQUFrQmMsRUFEMUI7QUFFSmpCLFlBQUFBLElBQUksRUFBRTtBQUFFd0MsY0FBQUEsU0FBUyxFQUFFO0FBQWI7QUFGRjtBQURXLFNBQVosQ0FBUDtBQU1ELE9BUEQsTUFPTyxJQUFJeEQsS0FBSyxDQUFDdUQsSUFBTixLQUFlLGNBQW5CLEVBQW1DO0FBQ3hDLGVBQU96RSxRQUFRLENBQUNnQixFQUFULENBQVk7QUFDakJiLFVBQUFBLElBQUksRUFBRTtBQUNKa0UsWUFBQUEsVUFBVSxFQUFFaEMsNkJBQWtCYyxFQUQxQjtBQUVKakIsWUFBQUEsSUFBSSxFQUFFO0FBQUV3QyxjQUFBQSxTQUFTLEVBQUU7QUFBYjtBQUZGO0FBRFcsU0FBWixDQUFQO0FBTUQsT0FQTSxNQU9BO0FBQ0wsWUFBSTtBQUNGLGdCQUFNQyxJQUFJLEdBQUcsTUFBTSxLQUFLbEYsV0FBTCxDQUFpQm1GLFFBQWpCLEVBQW5COztBQUNBLGVBQUssTUFBTXBELEdBQVgsSUFBa0JtRCxJQUFsQixFQUF3QjtBQUN0QixnQkFBSTtBQUNGLG9CQUFNbkMsRUFBRSxHQUFHRSxNQUFNLENBQUNDLElBQVAsQ0FBWW5CLEdBQVosRUFBaUIsQ0FBakIsQ0FBWDtBQUVBLG9CQUFNc0IsbUJBQW1CLEdBQUcsTUFBTWhELE9BQU8sQ0FBQ08sS0FBUixDQUFjbUIsR0FBZCxDQUFrQkMsTUFBbEIsQ0FBeUJHLGNBQXpCLENBQXdDN0IsT0FBeEMsQ0FDaEMsS0FEZ0MsRUFFL0IsZUFGK0IsRUFHaEMsRUFIZ0MsRUFJaEM7QUFBRWdELGdCQUFBQSxTQUFTLEVBQUVQO0FBQWIsZUFKZ0MsQ0FBbEM7O0FBT0Esa0JBQUksS0FBS1MsbUJBQUwsQ0FBeUJILG1CQUF6QixDQUFKLEVBQW1EO0FBQ2pELHVCQUFPLGtDQUNKLGVBQWM5QyxRQUFRLENBQUNrQyxJQUFULENBQWNDLE1BQWQsSUFBd0IscUJBQXNCLEVBRHhELEVBRUwsSUFGSyxFQUdMRSw2QkFBa0JhLG1CQUhiLEVBSUxsRCxRQUpLLENBQVA7QUFNRDs7QUFDRCxrQkFBSThDLG1CQUFtQixDQUFDVixNQUFwQixLQUErQkMsNkJBQWtCYyxFQUFyRCxFQUF5RDtBQUN2RHBELGdCQUFBQSxPQUFPLENBQUNJLElBQVIsQ0FBYXFDLEVBQWIsR0FBa0JBLEVBQWxCO0FBQ0F6QyxnQkFBQUEsT0FBTyxDQUFDSSxJQUFSLENBQWFtRSxTQUFiLEdBQXlCOUIsRUFBekI7QUFDQSx1QkFBTyxNQUFNLEtBQUtELGNBQUwsQ0FBb0J6QyxPQUFwQixFQUE2QkMsT0FBN0IsRUFBc0NDLFFBQXRDLENBQWI7QUFDRDtBQUNGLGFBdkJELENBdUJFLE9BQU9rQixLQUFQLEVBQWMsQ0FBRyxDQXhCRyxDQXdCRjs7QUFDckI7QUFDRixTQTVCRCxDQTRCRSxPQUFPQSxLQUFQLEVBQWM7QUFDZCwyQkFBSSwwQkFBSixFQUFnQ0EsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUFqRDtBQUNBLGlCQUFPLGtDQUNMQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBRFosRUFFTCxJQUZLLEVBR0xtQiw2QkFBa0JDLHFCQUhiLEVBSUx0QyxRQUpLLENBQVA7QUFNRDs7QUFDRCx5QkFBSSwwQkFBSixFQUFnQ2tCLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBakQ7QUFDQSxlQUFPLGtDQUNMQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBRFosRUFFTCxJQUZLLEVBR0xtQiw2QkFBa0JDLHFCQUhiLEVBSUx0QyxRQUpLLENBQVA7QUFNRDtBQUNGO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTs7O0FBQ0U2RSxFQUFBQSxzQkFBc0IsQ0FBQzFFLElBQUQsRUFBTztBQUMzQixRQUFJLEVBQUUsY0FBY0EsSUFBaEIsQ0FBSixFQUEyQjtBQUN6QixhQUFPLDZCQUFQO0FBQ0Q7O0FBRUQsUUFBSSxFQUFFLGNBQWNBLElBQWhCLEtBQXlCLEVBQUUsUUFBUUEsSUFBVixDQUE3QixFQUE4QztBQUM1QyxhQUFPLDZCQUFQO0FBQ0Q7O0FBRUQsUUFBSSxFQUFFLFNBQVNBLElBQVgsQ0FBSixFQUFzQjtBQUNwQixhQUFPLHdCQUFQO0FBQ0Q7O0FBRUQsUUFBSSxFQUFFLFVBQVVBLElBQVosQ0FBSixFQUF1QjtBQUNyQixhQUFPLHlCQUFQO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDQSxJQUFJLENBQUNvRSxHQUFMLENBQVNPLFFBQVQsQ0FBa0IsVUFBbEIsQ0FBRCxJQUFrQyxDQUFDM0UsSUFBSSxDQUFDb0UsR0FBTCxDQUFTTyxRQUFULENBQWtCLFNBQWxCLENBQXZDLEVBQXFFO0FBQ25FLGFBQU8sZ0JBQVA7QUFDRDs7QUFFRCxXQUFPLEtBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDZ0IsUUFBUkMsUUFBUSxDQUFDakYsT0FBRCxFQUFpQ0MsT0FBakMsRUFBdUVDLFFBQXZFLEVBQXNIO0FBQ2xJLFFBQUk7QUFDRixVQUFJZ0YsWUFBWSxHQUFHLElBQW5CLENBREUsQ0FFRjtBQUNBOztBQUNBLHVCQUFJLG9CQUFKLEVBQTJCLEdBQUVqRixPQUFPLENBQUNJLElBQVIsQ0FBYXFDLEVBQUcsV0FBN0MsRUFBeUQsT0FBekQsRUFKRSxDQUtGOztBQUNBLFlBQU1OLElBQUksR0FBRyxNQUFNLEtBQUt6QyxXQUFMLENBQWlCZ0QsV0FBakIsQ0FBNkIxQyxPQUFPLENBQUNJLElBQVIsQ0FBYXFDLEVBQTFDLENBQW5COztBQUNBLFVBQUlOLElBQUosRUFBVTtBQUNSOEMsUUFBQUEsWUFBWSxHQUFHOUMsSUFBZjtBQUNELE9BRkQsTUFFTztBQUNMLHlCQUFJLG9CQUFKLEVBQTJCLE9BQU1uQyxPQUFPLENBQUNJLElBQVIsQ0FBYXFDLEVBQUcsWUFBakQ7QUFDQSxlQUFPLGtDQUNKLFdBQVV6QyxPQUFPLENBQUNJLElBQVIsQ0FBYXFDLEVBQUcsZ0JBRHRCLEVBRUwsSUFGSyxFQUdMSCw2QkFBa0JDLHFCQUhiLEVBSUx0QyxRQUpLLENBQVA7QUFNRDs7QUFDRCxZQUFNaUYsT0FBTyxHQUFHO0FBQUVsQyxRQUFBQSxTQUFTLEVBQUVoRCxPQUFPLENBQUNJLElBQVIsQ0FBYXFDO0FBQTFCLE9BQWhCOztBQUNBLFVBQUl6QyxPQUFPLENBQUNJLElBQVIsQ0FBYTZDLFlBQWpCLEVBQStCO0FBQzdCaUMsUUFBQUEsT0FBTyxDQUFDLGNBQUQsQ0FBUCxHQUEwQmxGLE9BQU8sQ0FBQ0ksSUFBUixDQUFhNkMsWUFBdkM7QUFDRDs7QUFDRCxVQUFJRixtQkFBSjs7QUFDQSxVQUFJO0FBQ0ZBLFFBQUFBLG1CQUFtQixHQUFHLE1BQU1oRCxPQUFPLENBQUNPLEtBQVIsQ0FBY21CLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCRyxjQUF6QixDQUF3QzdCLE9BQXhDLENBQzFCLEtBRDBCLEVBRXpCLGVBRnlCLEVBRzFCLEVBSDBCLEVBSTFCa0YsT0FKMEIsQ0FBNUI7QUFNRCxPQVBELENBT0UsT0FBTy9ELEtBQVAsRUFBYztBQUFBOztBQUNkLGVBQU8sa0NBQ0osZUFBYyxxQkFBQUEsS0FBSyxDQUFDbEIsUUFBTiwrRkFBZ0JrQyxJQUFoQixnRkFBc0JDLE1BQXRCLEtBQWdDLHFCQUFzQixFQURoRSxFQUVMLElBRkssRUFHTEUsNkJBQWtCYSxtQkFIYixFQUlMbEQsUUFKSyxDQUFQO0FBTUQ7O0FBRUQsdUJBQUksb0JBQUosRUFBMkIsR0FBRUQsT0FBTyxDQUFDSSxJQUFSLENBQWFxQyxFQUFHLHdCQUE3QyxFQUFzRSxPQUF0RTs7QUFDQSxVQUFJTSxtQkFBbUIsQ0FBQ1YsTUFBcEIsS0FBK0JDLDZCQUFrQmMsRUFBakQsSUFBdURMLG1CQUFtQixDQUFDWixJQUEvRSxFQUFxRjtBQUNuRixZQUFJbUIsY0FBYyxHQUFHLE1BQU12RCxPQUFPLENBQUNPLEtBQVIsQ0FBY21CLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCRyxjQUF6QixDQUF3QzdCLE9BQXhDLENBQ3pCLEtBRHlCLEVBRXhCLFNBRndCLEVBR3pCO0FBQUV1RCxVQUFBQSxNQUFNLEVBQUU7QUFBRUMsWUFBQUEsV0FBVyxFQUFFO0FBQWY7QUFBVixTQUh5QixFQUl6QjtBQUFFUixVQUFBQSxTQUFTLEVBQUVoRCxPQUFPLENBQUNJLElBQVIsQ0FBYXFDO0FBQTFCLFNBSnlCLENBQTNCOztBQU9BLFlBQUlhLGNBQWMsQ0FBQ2pCLE1BQWYsS0FBMEJDLDZCQUFrQmMsRUFBaEQsRUFBb0Q7QUFDbEQsZ0JBQU1LLFdBQVcsR0FBR0gsY0FBYyxDQUFDbkIsSUFBZixDQUFvQkEsSUFBcEIsQ0FBeUJ1QixjQUF6QixDQUF3QyxDQUF4QyxFQUEyQ0MsT0FBL0Q7QUFFQSxjQUFJd0IsZUFBZSxHQUFHLE1BQU1wRixPQUFPLENBQUNPLEtBQVIsQ0FBY21CLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCRyxjQUF6QixDQUF3QzdCLE9BQXhDLENBQzFCLEtBRDBCLEVBRXpCLGlCQUZ5QixFQUcxQixFQUgwQixFQUkxQjtBQUFFZ0QsWUFBQUEsU0FBUyxFQUFFaEQsT0FBTyxDQUFDSSxJQUFSLENBQWFxQztBQUExQixXQUowQixDQUE1QixDQUhrRCxDQVVsRDs7QUFDQSxjQUFJMkMsaUJBQWlCLEdBQUc3RCw2Q0FBdUI4RCxZQUEvQztBQUNBLGdCQUFNQyx5QkFBeUIsR0FBRyxNQUFNdkYsT0FBTyxDQUFDTyxLQUFSLENBQWNtQixHQUFkLENBQWtCQyxNQUFsQixDQUF5QkcsY0FBekIsQ0FBd0M3QixPQUF4QyxDQUN0QyxLQURzQyxFQUVyQyxvQkFGcUMsRUFHdEMsRUFIc0MsRUFJdEM7QUFBRWdELFlBQUFBLFNBQVMsRUFBRWhELE9BQU8sQ0FBQ0ksSUFBUixDQUFhcUM7QUFBMUIsV0FKc0MsQ0FBeEM7O0FBTUEsY0FBSTZDLHlCQUF5QixDQUFDakQsTUFBMUIsS0FBcUNDLDZCQUFrQmMsRUFBM0QsRUFBK0Q7QUFDN0Qsa0JBQU1tQyxZQUFZLEdBQUdELHlCQUF5QixDQUFDbkQsSUFBMUIsQ0FBK0JBLElBQS9CLENBQW9DdUIsY0FBcEMsQ0FBbUQsQ0FBbkQsRUFBc0Q2QixZQUEzRTtBQUVBLGdCQUFJQSxZQUFZLElBQUlOLFlBQWhCLElBQWdDQSxZQUFZLENBQUNPLE1BQWpELEVBQ0U7QUFDQUosY0FBQUEsaUJBQWlCLEdBQUc3RCw2Q0FBdUJDLE9BQTNDLENBRkYsS0FHSyxJQUFJLENBQUMrRCxZQUFELElBQWlCTixZQUFqQixJQUFpQ0EsWUFBWSxDQUFDTyxNQUFsRCxFQUNIO0FBQ0FKLGNBQUFBLGlCQUFpQixHQUFHN0QsNkNBQXVCa0UsZ0JBQTNDLENBRkcsS0FHQSxJQUFJRixZQUFZLEtBQUssQ0FBQ04sWUFBRCxJQUFpQixDQUFDQSxZQUFZLENBQUNPLE1BQXBDLENBQWhCLEVBQ0g7QUFDQUosY0FBQUEsaUJBQWlCLEdBQUc3RCw2Q0FBdUJtRSxhQUEzQyxDQUZHLEtBR0EsSUFBSSxDQUFDSCxZQUFELEtBQWtCLENBQUNOLFlBQUQsSUFBaUIsQ0FBQ0EsWUFBWSxDQUFDTyxNQUFqRCxDQUFKLEVBQ0g7QUFDQUosY0FBQUEsaUJBQWlCLEdBQUc3RCw2Q0FBdUI4RCxZQUEzQztBQUNIOztBQUNETSwrREFBK0JDLEdBQS9CLENBQ0U1RixPQUFPLENBQUNJLElBQVIsQ0FBYXFDLEVBRGYsRUFFRXdDLFlBQVksQ0FBQzVFLFFBRmYsRUFHRStFLGlCQUhGOztBQU1BLGNBQUlELGVBQWUsQ0FBQzlDLE1BQWhCLEtBQTJCQyw2QkFBa0JjLEVBQWpELEVBQXFEO0FBQ25ELDZCQUFJLDBCQUFKLEVBQWlDLDZCQUFqQyxFQUErRCxPQUEvRDs7QUFDQSxnQkFBSStCLGVBQWUsQ0FBQ2hELElBQWhCLENBQXFCQSxJQUFyQixDQUEwQjBCLE9BQTFCLEtBQXNDLEtBQTFDLEVBQWlEO0FBQy9DO0FBQ0Esa0JBQUlnQyxvQkFBb0IsR0FBRyxNQUFNOUYsT0FBTyxDQUFDTyxLQUFSLENBQWNtQixHQUFkLENBQWtCQyxNQUFsQixDQUF5QkcsY0FBekIsQ0FBd0M3QixPQUF4QyxDQUMvQixLQUQrQixFQUU5QixxQkFGOEIsRUFHL0IsRUFIK0IsRUFJL0I7QUFBRWdELGdCQUFBQSxTQUFTLEVBQUVoRCxPQUFPLENBQUNJLElBQVIsQ0FBYXFDO0FBQTFCLGVBSitCLENBQWpDOztBQU9BLGtCQUFJb0Qsb0JBQW9CLENBQUN4RCxNQUFyQixLQUFnQ0MsNkJBQWtCYyxFQUF0RCxFQUEwRDtBQUN4RCx1QkFBT25ELFFBQVEsQ0FBQ2dCLEVBQVQsQ0FBWTtBQUNqQmIsa0JBQUFBLElBQUksRUFBRTtBQUNKdUQsb0JBQUFBLE9BQU8sRUFBRUYsV0FETDtBQUVKTyxvQkFBQUEsSUFBSSxFQUFFNkIsb0JBQW9CLENBQUMxRCxJQUFyQixDQUEwQkEsSUFBMUIsQ0FBK0J1QixjQUEvQixDQUE4QyxDQUE5QyxFQUFpRE0sSUFGbkQ7QUFHSkMsb0JBQUFBLE9BQU8sRUFBRTRCLG9CQUFvQixDQUFDMUQsSUFBckIsQ0FBMEJBLElBQTFCLENBQStCdUIsY0FBL0IsQ0FBOEMsQ0FBOUMsRUFBaURPLE9BSHREO0FBSUo1QixvQkFBQUEsTUFBTSxFQUFFLFNBSko7QUFLSmtELG9CQUFBQSxZQUFZLEVBQUVIO0FBTFY7QUFEVyxpQkFBWixDQUFQO0FBU0Q7QUFDRixhQXBCRCxNQW9CTztBQUNMO0FBQ0EscUJBQU9uRixRQUFRLENBQUNnQixFQUFULENBQVk7QUFDakJiLGdCQUFBQSxJQUFJLEVBQUU7QUFDSnVELGtCQUFBQSxPQUFPLEVBQUVGLFdBREw7QUFFSlEsa0JBQUFBLE9BQU8sRUFBRSxVQUZMO0FBR0o1QixrQkFBQUEsTUFBTSxFQUFFLFVBSEo7QUFJSmtELGtCQUFBQSxZQUFZLEVBQUVIO0FBSlY7QUFEVyxlQUFaLENBQVA7QUFRRDtBQUNGO0FBQ0Y7QUFDRjtBQUNGLEtBNUhELENBNEhFLE9BQU9qRSxLQUFQLEVBQWM7QUFDZCx1QkFBSSxvQkFBSixFQUEwQkEsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUEzQzs7QUFFQSxVQUFJQSxLQUFLLElBQUlBLEtBQUssQ0FBQ2xCLFFBQWYsSUFBMkJrQixLQUFLLENBQUNsQixRQUFOLENBQWVvQyxNQUFmLEtBQTBCQyw2QkFBa0J3RCxZQUEzRSxFQUF5RjtBQUN2RixlQUFPLGtDQUNKLDhDQUE2QzNFLEtBQUssQ0FBQ2xCLFFBQU4sQ0FBZWtDLElBQWYsQ0FBb0JmLE9BQVEsRUFEckUsRUFFTGtCLDZCQUFrQndELFlBRmIsRUFHTHhELDZCQUFrQndELFlBSGIsRUFJTDdGLFFBSkssQ0FBUDtBQU1EOztBQUNELFVBQUlrQixLQUFLLElBQUlBLEtBQUssQ0FBQ2xCLFFBQWYsSUFBMkJrQixLQUFLLENBQUNsQixRQUFOLENBQWVrQyxJQUExQyxJQUFrRGhCLEtBQUssQ0FBQ2xCLFFBQU4sQ0FBZWtDLElBQWYsQ0FBb0JDLE1BQTFFLEVBQWtGO0FBQ2hGLGVBQU8sa0NBQ0xqQixLQUFLLENBQUNsQixRQUFOLENBQWVrQyxJQUFmLENBQW9CQyxNQURmLEVBRUxqQixLQUFLLENBQUNsQixRQUFOLENBQWVvQyxNQUFmLElBQXlCQyw2QkFBa0JhLG1CQUZ0QyxFQUdMaEMsS0FBSyxDQUFDbEIsUUFBTixDQUFlb0MsTUFBZixJQUF5QkMsNkJBQWtCYSxtQkFIdEMsRUFJTGxELFFBSkssQ0FBUDtBQU1EOztBQUNELFVBQUlrQixLQUFLLENBQUN1RCxJQUFOLEtBQWUsUUFBbkIsRUFBNkI7QUFDM0IsZUFBTyxrQ0FDTCx1REFESyxFQUVMLElBRkssRUFHTHBDLDZCQUFrQnlELFdBSGIsRUFJTDlGLFFBSkssQ0FBUDtBQU1EOztBQUNELGFBQU8sa0NBQ0xrQixLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBRFosRUFFTCxJQUZLLEVBR0xtQiw2QkFBa0JDLHFCQUhiLEVBSUx0QyxRQUpLLENBQVA7QUFNRDtBQUNGOztBQUVEaUQsRUFBQUEsbUJBQW1CLENBQUNqRCxRQUFELEVBQVc7QUFDNUIsUUFBSUEsUUFBUSxDQUFDb0MsTUFBVCxLQUFvQkMsNkJBQWtCYyxFQUExQyxFQUE4QztBQUM1QztBQUNBLFlBQU00QyxnQkFBZ0IsR0FBRyxDQUFDLElBQUQsRUFBTyxJQUFQLEVBQWEsSUFBYixFQUFtQixJQUFuQixFQUF5QixJQUF6QixDQUF6QjtBQUNBLFlBQU0zRCxNQUFNLEdBQUcsQ0FBQ3BDLFFBQVEsQ0FBQ2tDLElBQVQsSUFBaUIsRUFBbEIsRUFBc0JFLE1BQXRCLElBQWdDLENBQS9DO0FBQ0EsWUFBTTRELE1BQU0sR0FBR0QsZ0JBQWdCLENBQUNqQixRQUFqQixDQUEwQjFDLE1BQTFCLENBQWY7QUFFQTRELE1BQUFBLE1BQU0sSUFBSSxpQkFBSSx1QkFBSixFQUE2QixnREFBN0IsQ0FBVjtBQUVBLGFBQU9BLE1BQVA7QUFDRDs7QUFDRCxXQUFPLEtBQVA7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ29CLFFBQVpDLFlBQVksQ0FBQ25HLE9BQUQsRUFBVTBCLEdBQVYsRUFBZTBFLElBQWYsRUFBcUI7QUFDckMsUUFBSTtBQUNGLFlBQU1sRyxRQUFRLEdBQUcsTUFBTUYsT0FBTyxDQUFDTyxLQUFSLENBQWNtQixHQUFkLENBQWtCQyxNQUFsQixDQUF5QkcsY0FBekIsQ0FBd0M3QixPQUF4QyxDQUNyQixLQURxQixFQUVyQixpQkFGcUIsRUFHckIsRUFIcUIsRUFJckI7QUFBRWdELFFBQUFBLFNBQVMsRUFBRXZCLEdBQUcsQ0FBQ2dCO0FBQWpCLE9BSnFCLENBQXZCO0FBT0EsWUFBTTJELE9BQU8sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDbkcsUUFBUSxJQUFJLEVBQWIsRUFBaUJrQyxJQUFqQixJQUF5QixFQUExQixFQUE4QkEsSUFBOUIsSUFBc0MsRUFBdkMsRUFBMkN1QixjQUEzQyxJQUE2RCxFQUE5RCxFQUFrRSxDQUFsRSxLQUF3RSxFQUF4RjtBQUVBLFlBQU0yQyxTQUFTLEdBQ2IsQ0FBQyxDQUFDNUUsR0FBRyxJQUFJLEVBQVIsRUFBWTRCLFlBQVosSUFBNEIsRUFBN0IsRUFBaUNoQixNQUFqQyxLQUE0QyxTQUE1QyxJQUNBLE9BQU8rRCxPQUFPLENBQUMsZ0JBQUQsQ0FBZCxLQUFxQyxXQUZ2QztBQUdBLFlBQU1FLGFBQWEsR0FBRyxPQUFPRixPQUFPLENBQUMsVUFBRCxDQUFkLEtBQStCLFdBQXJEO0FBRUEsWUFBTUcsS0FBSyxHQUFHSCxPQUFPLENBQUMsYUFBRCxDQUFQLEtBQTJCLFNBQXpDO0FBQ0EsWUFBTUksUUFBUSxHQUFHSixPQUFPLENBQUMsZ0JBQUQsQ0FBUCxLQUE4QixTQUEvQztBQUNBLFlBQU1LLE9BQU8sR0FBR0gsYUFBYSxHQUFHRixPQUFPLENBQUMsVUFBRCxDQUFQLEtBQXdCLFNBQTNCLEdBQXVDLElBQXBFO0FBQ0EsWUFBTU0sUUFBUSxHQUFHTCxTQUFTLEdBQUdELE9BQU8sQ0FBQyxnQkFBRCxDQUFQLEtBQThCLFNBQWpDLEdBQTZDLElBQXZFO0FBRUEsWUFBTU8sT0FBTyxHQUFHSixLQUFLLElBQUlDLFFBQVQsSUFBcUJDLE9BQXJCLElBQWdDQyxRQUFoRDtBQUVBQyxNQUFBQSxPQUFPLElBQUksaUJBQUksd0JBQUosRUFBK0IsZ0JBQS9CLEVBQWdELE9BQWhELENBQVg7O0FBRUEsVUFBSVIsSUFBSSxLQUFLLE9BQWIsRUFBc0I7QUFDcEIsZUFBTztBQUFFUSxVQUFBQTtBQUFGLFNBQVA7QUFDRDs7QUFFRCxVQUFJLENBQUNBLE9BQUwsRUFBYztBQUNaLGNBQU0sSUFBSTdELEtBQUosQ0FBVSxxQkFBVixDQUFOO0FBQ0Q7QUFDRixLQS9CRCxDQStCRSxPQUFPM0IsS0FBUCxFQUFjO0FBQ2QsdUJBQUksd0JBQUosRUFBOEJBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBL0M7QUFDQSxhQUFPeUYsT0FBTyxDQUFDQyxNQUFSLENBQWUxRixLQUFmLENBQVA7QUFDRDtBQUNGOztBQUVEMkYsRUFBQUEsS0FBSyxDQUFDQyxNQUFELEVBQVM7QUFDWjtBQUNBLFdBQU8sSUFBSUgsT0FBSixDQUFZLENBQUNJLE9BQUQsRUFBVUgsTUFBVixLQUFxQjtBQUN0Q0ksTUFBQUEsVUFBVSxDQUFDRCxPQUFELEVBQVVELE1BQVYsQ0FBVjtBQUNELEtBRk0sQ0FBUDtBQUdEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDRUcsRUFBQUEsbUJBQW1CLENBQUNDLE1BQUQsRUFBU2hCLElBQVQsRUFBZTtBQUNoQztBQUNBLFVBQU1pQixlQUFlLEdBQUdELE1BQU0sS0FBSyxNQUFYLElBQXFCaEIsSUFBSSxLQUFLLGlCQUF0RDtBQUNBLFVBQU1rQixnQkFBZ0IsR0FBR0YsTUFBTSxLQUFLLEtBQVgsSUFBb0JoQixJQUFJLENBQUNtQixVQUFMLENBQWdCLGtCQUFoQixDQUE3QztBQUNBLFVBQU1DLHFCQUFxQixHQUFHSixNQUFNLEtBQUssTUFBWCxJQUFxQmhCLElBQUksQ0FBQ21CLFVBQUwsQ0FBZ0IsZ0JBQWhCLENBQW5ELENBSmdDLENBTWhDOztBQUNBLFdBQU9GLGVBQWUsSUFBSUMsZ0JBQW5CLElBQXVDRSxxQkFBOUM7QUFDRDtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ21CLFFBQVhDLFdBQVcsQ0FBQ3pILE9BQUQsRUFBVW9ILE1BQVYsRUFBa0JoQixJQUFsQixFQUF3QmhFLElBQXhCLEVBQThCTSxFQUE5QixFQUFrQ3hDLFFBQWxDLEVBQTRDO0FBRTNELFVBQU13SCxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUN0RixJQUFJLElBQUksRUFBVCxFQUFhc0YsUUFBaEM7O0FBQ0EsUUFBSTtBQUNGLFlBQU1oRyxHQUFHLEdBQUcsTUFBTSxLQUFLL0IsV0FBTCxDQUFpQmdELFdBQWpCLENBQTZCRCxFQUE3QixDQUFsQjs7QUFDQSxVQUFJZ0YsUUFBSixFQUFjO0FBQ1osZUFBT3RGLElBQUksQ0FBQ3NGLFFBQVo7QUFDRDs7QUFFRCxVQUFJLENBQUM5RSxNQUFNLENBQUNDLElBQVAsQ0FBWW5CLEdBQVosRUFBaUJvQixNQUF0QixFQUE4QjtBQUM1Qix5QkFBSSx1QkFBSixFQUE2QixnQ0FBN0IsRUFENEIsQ0FFNUI7O0FBQ0EsZUFBTyxrQ0FDTCxnQ0FESyxFQUVMLElBRkssRUFHTFAsNkJBQWtCb0YsU0FIYixFQUlMekgsUUFKSyxDQUFQO0FBTUQ7O0FBRUQsVUFBSSxDQUFDa0MsSUFBTCxFQUFXO0FBQ1RBLFFBQUFBLElBQUksR0FBRyxFQUFQO0FBQ0Q7O0FBQUE7O0FBRUQsVUFBSSxDQUFDQSxJQUFJLENBQUMxQixPQUFWLEVBQW1CO0FBQ2pCMEIsUUFBQUEsSUFBSSxDQUFDMUIsT0FBTCxHQUFlLEVBQWY7QUFDRDs7QUFBQTtBQUVELFlBQU15RSxPQUFPLEdBQUc7QUFDZGxDLFFBQUFBLFNBQVMsRUFBRVA7QUFERyxPQUFoQixDQXpCRSxDQTZCRjs7QUFDQSxVQUFJLE9BQU8sQ0FBQ04sSUFBSSxJQUFJLEVBQVQsRUFBYS9CLElBQXBCLEtBQTZCLFFBQTdCLElBQXlDLENBQUMrQixJQUFJLElBQUksRUFBVCxFQUFhd0YsTUFBYixLQUF3QixXQUFyRSxFQUFrRjtBQUNoRnhGLFFBQUFBLElBQUksQ0FBQzFCLE9BQUwsQ0FBYSxjQUFiLElBQStCLGlCQUEvQjtBQUNBLGVBQU8wQixJQUFJLENBQUN3RixNQUFaO0FBQ0Q7O0FBRUQsVUFBSSxPQUFPLENBQUN4RixJQUFJLElBQUksRUFBVCxFQUFhL0IsSUFBcEIsS0FBNkIsUUFBN0IsSUFBeUMsQ0FBQytCLElBQUksSUFBSSxFQUFULEVBQWF3RixNQUFiLEtBQXdCLE1BQXJFLEVBQTZFO0FBQzNFeEYsUUFBQUEsSUFBSSxDQUFDMUIsT0FBTCxDQUFhLGNBQWIsSUFBK0Isa0JBQS9CO0FBQ0EsZUFBTzBCLElBQUksQ0FBQ3dGLE1BQVo7QUFDRDs7QUFFRCxVQUFJLE9BQU8sQ0FBQ3hGLElBQUksSUFBSSxFQUFULEVBQWEvQixJQUFwQixLQUE2QixRQUE3QixJQUF5QyxDQUFDK0IsSUFBSSxJQUFJLEVBQVQsRUFBYXdGLE1BQWIsS0FBd0IsS0FBckUsRUFBNEU7QUFDMUV4RixRQUFBQSxJQUFJLENBQUMxQixPQUFMLENBQWEsY0FBYixJQUErQiwwQkFBL0I7QUFDQSxlQUFPMEIsSUFBSSxDQUFDd0YsTUFBWjtBQUNEOztBQUNELFlBQU1DLEtBQUssR0FBRyxDQUFDekYsSUFBSSxJQUFJLEVBQVQsRUFBYXlGLEtBQWIsSUFBc0IsQ0FBcEM7O0FBQ0EsVUFBSUEsS0FBSixFQUFXO0FBQ1Qsa0NBQWM7QUFDWkMsVUFBQUEsT0FBTyxFQUFFLElBQUk5RyxJQUFKLENBQVNBLElBQUksQ0FBQ0MsR0FBTCxLQUFhNEcsS0FBdEIsQ0FERztBQUVaRSxVQUFBQSxHQUFHLEVBQUUsWUFBWTtBQUNmLGdCQUFHO0FBQ0Qsb0JBQU0vSCxPQUFPLENBQUNPLEtBQVIsQ0FBY21CLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCQyxhQUF6QixDQUF1QzNCLE9BQXZDLENBQStDbUgsTUFBL0MsRUFBdURoQixJQUF2RCxFQUE2RGhFLElBQTdELEVBQW1FK0MsT0FBbkUsQ0FBTjtBQUNELGFBRkQsQ0FFQyxPQUFNL0QsS0FBTixFQUFZO0FBQ1gsK0JBQUksdUJBQUosRUFBNkIsNkNBQTRDZ0csTUFBTyxJQUFHaEIsSUFBSyxNQUFLaEYsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUFNLEVBQXBIO0FBQ0Q7O0FBQUE7QUFDRjtBQVJXLFNBQWQ7QUFVQSxlQUFPbEIsUUFBUSxDQUFDZ0IsRUFBVCxDQUFZO0FBQ2pCYixVQUFBQSxJQUFJLEVBQUU7QUFBRWUsWUFBQUEsS0FBSyxFQUFFLENBQVQ7QUFBWUMsWUFBQUEsT0FBTyxFQUFFO0FBQXJCO0FBRFcsU0FBWixDQUFQO0FBR0Q7O0FBRUQsVUFBSStFLElBQUksS0FBSyxPQUFiLEVBQXNCO0FBQ3BCLFlBQUk7QUFDRixnQkFBTTRCLEtBQUssR0FBRyxNQUFNLEtBQUs3QixZQUFMLENBQWtCbkcsT0FBbEIsRUFBMkIwQixHQUEzQixFQUFnQzBFLElBQWhDLENBQXBCO0FBQ0EsaUJBQU80QixLQUFQO0FBQ0QsU0FIRCxDQUdFLE9BQU81RyxLQUFQLEVBQWM7QUFDZCxnQkFBTThFLE1BQU0sR0FBRyxDQUFDOUUsS0FBSyxJQUFJLEVBQVYsRUFBY3VELElBQWQsS0FBdUIsY0FBdEM7O0FBQ0EsY0FBSSxDQUFDdUIsTUFBTCxFQUFhO0FBQ1gsNkJBQUksdUJBQUosRUFBNkIsZ0RBQTdCO0FBQ0EsbUJBQU8sa0NBQ0osZUFBYzlFLEtBQUssQ0FBQ0MsT0FBTixJQUFpQixxQkFBc0IsRUFEakQsRUFFTCxJQUZLLEVBR0xrQiw2QkFBa0JDLHFCQUhiLEVBSUx0QyxRQUpLLENBQVA7QUFNRDtBQUNGO0FBQ0Y7O0FBRUQsdUJBQUksdUJBQUosRUFBOEIsR0FBRWtILE1BQU8sSUFBR2hCLElBQUssRUFBL0MsRUFBa0QsT0FBbEQsRUEvRUUsQ0FpRkY7O0FBQ0EsWUFBTTZCLGNBQWMsR0FBR3JGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZVCxJQUFaLENBQXZCLENBbEZFLENBb0ZGO0FBQ0E7QUFDQTs7QUFDQSxVQUFJLENBQUMsS0FBSytFLG1CQUFMLENBQXlCQyxNQUF6QixFQUFpQ2hCLElBQWpDLENBQUwsRUFBNkM7QUFDM0MsYUFBSyxNQUFNOEIsR0FBWCxJQUFrQkQsY0FBbEIsRUFBa0M7QUFDaEMsY0FBSUUsS0FBSyxDQUFDQyxPQUFOLENBQWNoRyxJQUFJLENBQUM4RixHQUFELENBQWxCLENBQUosRUFBOEI7QUFDNUI5RixZQUFBQSxJQUFJLENBQUM4RixHQUFELENBQUosR0FBWTlGLElBQUksQ0FBQzhGLEdBQUQsQ0FBSixDQUFVRyxJQUFWLEVBQVo7QUFDRDtBQUNGO0FBQ0Y7O0FBRUQsWUFBTUMsYUFBYSxHQUFHLE1BQU10SSxPQUFPLENBQUNPLEtBQVIsQ0FBY21CLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCQyxhQUF6QixDQUF1QzNCLE9BQXZDLENBQStDbUgsTUFBL0MsRUFBdURoQixJQUF2RCxFQUE2RGhFLElBQTdELEVBQW1FK0MsT0FBbkUsQ0FBNUI7QUFDQSxZQUFNb0QsY0FBYyxHQUFHLEtBQUtwRixtQkFBTCxDQUF5Qm1GLGFBQXpCLENBQXZCOztBQUNBLFVBQUlDLGNBQUosRUFBb0I7QUFDbEIsZUFBTyxrQ0FDSixlQUFjckksUUFBUSxDQUFDRyxJQUFULENBQWNnQixPQUFkLElBQXlCLHFCQUFzQixFQUR6RCxFQUVMLElBRkssRUFHTGtCLDZCQUFrQkMscUJBSGIsRUFJTHRDLFFBSkssQ0FBUDtBQU1EOztBQUNELFVBQUlzSSxZQUFZLEdBQUcsQ0FBQ0YsYUFBYSxJQUFJLEVBQWxCLEVBQXNCbEcsSUFBdEIsSUFBOEIsRUFBakQ7O0FBQ0EsVUFBSSxDQUFDb0csWUFBTCxFQUFtQjtBQUNqQkEsUUFBQUEsWUFBWSxHQUNWLE9BQU9BLFlBQVAsS0FBd0IsUUFBeEIsSUFBb0NwQyxJQUFJLENBQUNwQixRQUFMLENBQWMsUUFBZCxDQUFwQyxJQUErRG9DLE1BQU0sS0FBSyxLQUExRSxHQUNJLEdBREosR0FFSSxLQUhOO0FBSUFsSCxRQUFBQSxRQUFRLENBQUNrQyxJQUFULEdBQWdCb0csWUFBaEI7QUFDRDs7QUFDRCxZQUFNQyxhQUFhLEdBQUd2SSxRQUFRLENBQUNvQyxNQUFULEtBQW9CQyw2QkFBa0JjLEVBQXRDLEdBQTJDbkQsUUFBUSxDQUFDb0MsTUFBcEQsR0FBNkQsS0FBbkY7O0FBRUEsVUFBSSxDQUFDbUcsYUFBRCxJQUFrQkQsWUFBdEIsRUFBb0M7QUFDbEM7QUFDQSxlQUFPdEksUUFBUSxDQUFDZ0IsRUFBVCxDQUFZO0FBQ2pCYixVQUFBQSxJQUFJLEVBQUVpSSxhQUFhLENBQUNsRztBQURILFNBQVosQ0FBUDtBQUdEOztBQUVELFVBQUlxRyxhQUFhLElBQUlmLFFBQXJCLEVBQStCO0FBQzdCLGVBQU94SCxRQUFRLENBQUNnQixFQUFULENBQVk7QUFDakJiLFVBQUFBLElBQUksRUFBRUgsUUFBUSxDQUFDa0M7QUFERSxTQUFaLENBQVA7QUFHRDs7QUFDRCxZQUFNcUcsYUFBYSxJQUFJRCxZQUFZLENBQUNuRyxNQUE5QixHQUNGO0FBQUVoQixRQUFBQSxPQUFPLEVBQUVtSCxZQUFZLENBQUNuRyxNQUF4QjtBQUFnQ3NDLFFBQUFBLElBQUksRUFBRThEO0FBQXRDLE9BREUsR0FFRixJQUFJMUYsS0FBSixDQUFVLG1EQUFWLENBRko7QUFHRCxLQWxJRCxDQWtJRSxPQUFPM0IsS0FBUCxFQUFjO0FBQ2QsVUFBSUEsS0FBSyxJQUFJQSxLQUFLLENBQUNsQixRQUFmLElBQTJCa0IsS0FBSyxDQUFDbEIsUUFBTixDQUFlb0MsTUFBZixLQUEwQkMsNkJBQWtCd0QsWUFBM0UsRUFBeUY7QUFDdkYsZUFBTyxrQ0FDTDNFLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FEWixFQUVMQSxLQUFLLENBQUN1RCxJQUFOLEdBQWMsb0JBQW1CdkQsS0FBSyxDQUFDdUQsSUFBSyxFQUE1QyxHQUFnRCxJQUYzQyxFQUdMcEMsNkJBQWtCd0QsWUFIYixFQUlMN0YsUUFKSyxDQUFQO0FBTUQ7O0FBQ0QsWUFBTXdJLFFBQVEsR0FBRyxDQUFDdEgsS0FBSyxDQUFDbEIsUUFBTixJQUFrQixFQUFuQixFQUF1QmtDLElBQXZCLElBQStCaEIsS0FBSyxDQUFDQyxPQUF0RDtBQUNBLHVCQUFJLHVCQUFKLEVBQTZCcUgsUUFBUSxJQUFJdEgsS0FBekM7O0FBQ0EsVUFBSXNHLFFBQUosRUFBYztBQUNaLGVBQU94SCxRQUFRLENBQUNnQixFQUFULENBQVk7QUFDakJiLFVBQUFBLElBQUksRUFBRTtBQUFFZSxZQUFBQSxLQUFLLEVBQUUsTUFBVDtBQUFpQkMsWUFBQUEsT0FBTyxFQUFFcUgsUUFBUSxJQUFJdEg7QUFBdEM7QUFEVyxTQUFaLENBQVA7QUFHRCxPQUpELE1BSU87QUFDTCxZQUFJLENBQUNBLEtBQUssSUFBSSxFQUFWLEVBQWN1RCxJQUFkLElBQXNCZ0UsMENBQW9CdkgsS0FBSyxDQUFDdUQsSUFBMUIsQ0FBMUIsRUFBMkQ7QUFDekR2RCxVQUFBQSxLQUFLLENBQUNDLE9BQU4sR0FBZ0JzSCwwQ0FBb0J2SCxLQUFLLENBQUN1RCxJQUExQixDQUFoQjtBQUNEOztBQUNELGVBQU8sa0NBQ0wrRCxRQUFRLENBQUNyRyxNQUFULElBQW1CakIsS0FEZCxFQUVMQSxLQUFLLENBQUN1RCxJQUFOLEdBQWMsb0JBQW1CdkQsS0FBSyxDQUFDdUQsSUFBSyxFQUE1QyxHQUFnRCxJQUYzQyxFQUdMcEMsNkJBQWtCQyxxQkFIYixFQUlMdEMsUUFKSyxDQUFQO0FBTUQ7QUFDRjtBQUNGO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFMEksRUFBQUEsVUFBVSxDQUFDNUksT0FBRCxFQUFpQ0MsT0FBakMsRUFBdUVDLFFBQXZFLEVBQXNIO0FBRTlILFVBQU0ySSxLQUFLLEdBQUcsa0NBQXFCNUksT0FBTyxDQUFDUyxPQUFSLENBQWdCQyxNQUFyQyxFQUE2QyxRQUE3QyxDQUFkOztBQUNBLFFBQUlrSSxLQUFLLEtBQUs1SSxPQUFPLENBQUNJLElBQVIsQ0FBYXFDLEVBQTNCLEVBQStCO0FBQUU7QUFDL0IsYUFBTyxrQ0FDSixpQkFESSxFQUVMSCw2QkFBa0J3RCxZQUZiLEVBR0x4RCw2QkFBa0J3RCxZQUhiLEVBSUw3RixRQUpLLENBQVA7QUFNRDs7QUFDRCxRQUFJLENBQUNELE9BQU8sQ0FBQ0ksSUFBUixDQUFhK0csTUFBbEIsRUFBMEI7QUFDeEIsYUFBTyxrQ0FBYyx1QkFBZCxFQUF1QyxJQUF2QyxFQUE2QzdFLDZCQUFrQnlELFdBQS9ELEVBQTRFOUYsUUFBNUUsQ0FBUDtBQUNELEtBRkQsTUFFTyxJQUFJLENBQUNELE9BQU8sQ0FBQ0ksSUFBUixDQUFhK0csTUFBYixDQUFvQjBCLEtBQXBCLENBQTBCLDJCQUExQixDQUFMLEVBQTZEO0FBQ2xFLHVCQUFJLHVCQUFKLEVBQTZCLDhCQUE3QixFQURrRSxDQUVsRTs7QUFDQSxhQUFPLGtDQUFjLDhCQUFkLEVBQThDLElBQTlDLEVBQW9EdkcsNkJBQWtCeUQsV0FBdEUsRUFBbUY5RixRQUFuRixDQUFQO0FBQ0QsS0FKTSxNQUlBLElBQUksQ0FBQ0QsT0FBTyxDQUFDSSxJQUFSLENBQWErRixJQUFsQixFQUF3QjtBQUM3QixhQUFPLGtDQUFjLHFCQUFkLEVBQXFDLElBQXJDLEVBQTJDN0QsNkJBQWtCeUQsV0FBN0QsRUFBMEU5RixRQUExRSxDQUFQO0FBQ0QsS0FGTSxNQUVBLElBQUksQ0FBQ0QsT0FBTyxDQUFDSSxJQUFSLENBQWErRixJQUFiLENBQWtCbUIsVUFBbEIsQ0FBNkIsR0FBN0IsQ0FBTCxFQUF3QztBQUM3Qyx1QkFBSSx1QkFBSixFQUE2Qiw0QkFBN0IsRUFENkMsQ0FFN0M7O0FBQ0EsYUFBTyxrQ0FBYyw0QkFBZCxFQUE0QyxJQUE1QyxFQUFrRGhGLDZCQUFrQnlELFdBQXBFLEVBQWlGOUYsUUFBakYsQ0FBUDtBQUNELEtBSk0sTUFJQTtBQUVMLGFBQU8sS0FBS3VILFdBQUwsQ0FDTHpILE9BREssRUFFTEMsT0FBTyxDQUFDSSxJQUFSLENBQWErRyxNQUZSLEVBR0xuSCxPQUFPLENBQUNJLElBQVIsQ0FBYStGLElBSFIsRUFJTG5HLE9BQU8sQ0FBQ0ksSUFBUixDQUFhQSxJQUpSLEVBS0xKLE9BQU8sQ0FBQ0ksSUFBUixDQUFhcUMsRUFMUixFQU1MeEMsUUFOSyxDQUFQO0FBUUQ7QUFDRjtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDVyxRQUFINkksR0FBRyxDQUFDL0ksT0FBRCxFQUFpQ0MsT0FBakMsRUFBdUVDLFFBQXZFLEVBQXNIO0FBQzdILFFBQUk7QUFDRixVQUFJLENBQUNELE9BQU8sQ0FBQ0ksSUFBVCxJQUFpQixDQUFDSixPQUFPLENBQUNJLElBQVIsQ0FBYStGLElBQW5DLEVBQXlDLE1BQU0sSUFBSXJELEtBQUosQ0FBVSx3QkFBVixDQUFOO0FBQ3pDLFVBQUksQ0FBQzlDLE9BQU8sQ0FBQ0ksSUFBUixDQUFhcUMsRUFBbEIsRUFBc0IsTUFBTSxJQUFJSyxLQUFKLENBQVUsc0JBQVYsQ0FBTjtBQUV0QixZQUFNaUcsT0FBTyxHQUFHYixLQUFLLENBQUNDLE9BQU4sQ0FBYyxDQUFDLENBQUNuSSxPQUFPLElBQUksRUFBWixFQUFnQkksSUFBaEIsSUFBd0IsRUFBekIsRUFBNkIySSxPQUEzQyxJQUFzRC9JLE9BQU8sQ0FBQ0ksSUFBUixDQUFhMkksT0FBbkUsR0FBNkUsRUFBN0Y7QUFFQSxVQUFJQyxPQUFPLEdBQUdoSixPQUFPLENBQUNJLElBQVIsQ0FBYStGLElBQTNCOztBQUVBLFVBQUk2QyxPQUFPLElBQUksT0FBT0EsT0FBUCxLQUFtQixRQUFsQyxFQUE0QztBQUMxQ0EsUUFBQUEsT0FBTyxHQUFHQSxPQUFPLENBQUMsQ0FBRCxDQUFQLEtBQWUsR0FBZixHQUFxQkEsT0FBTyxDQUFDQyxNQUFSLENBQWUsQ0FBZixDQUFyQixHQUF5Q0QsT0FBbkQ7QUFDRDs7QUFFRCxVQUFJLENBQUNBLE9BQUwsRUFBYyxNQUFNLElBQUlsRyxLQUFKLENBQVUsc0NBQVYsQ0FBTjtBQUVkLHVCQUFJLGVBQUosRUFBc0IsVUFBU2tHLE9BQVEsRUFBdkMsRUFBMEMsT0FBMUMsRUFkRSxDQWVGOztBQUNBLFlBQU16RixNQUFNLEdBQUc7QUFBRTJGLFFBQUFBLEtBQUssRUFBRTtBQUFULE9BQWY7O0FBRUEsVUFBSUgsT0FBTyxDQUFDbEcsTUFBWixFQUFvQjtBQUNsQixhQUFLLE1BQU1zRyxNQUFYLElBQXFCSixPQUFyQixFQUE4QjtBQUM1QixjQUFJLENBQUNJLE1BQU0sQ0FBQ0MsSUFBUixJQUFnQixDQUFDRCxNQUFNLENBQUNFLEtBQTVCLEVBQW1DO0FBQ25DOUYsVUFBQUEsTUFBTSxDQUFDNEYsTUFBTSxDQUFDQyxJQUFSLENBQU4sR0FBc0JELE1BQU0sQ0FBQ0UsS0FBN0I7QUFDRDtBQUNGOztBQUVELFVBQUlDLFVBQVUsR0FBRyxFQUFqQjtBQUVBLFlBQU1DLE1BQU0sR0FBRyxNQUFNeEosT0FBTyxDQUFDTyxLQUFSLENBQWNtQixHQUFkLENBQWtCQyxNQUFsQixDQUF5QkMsYUFBekIsQ0FBdUMzQixPQUF2QyxDQUNuQixLQURtQixFQUVsQixJQUFHZ0osT0FBUSxFQUZPLEVBR25CO0FBQUV6RixRQUFBQSxNQUFNLEVBQUVBO0FBQVYsT0FIbUIsRUFJbkI7QUFBRVAsUUFBQUEsU0FBUyxFQUFFaEQsT0FBTyxDQUFDSSxJQUFSLENBQWFxQztBQUExQixPQUptQixDQUFyQjtBQU9BLFlBQU0rRyxNQUFNLEdBQUd4SixPQUFPLENBQUNJLElBQVIsQ0FBYStGLElBQWIsQ0FBa0JwQixRQUFsQixDQUEyQixRQUEzQixLQUF3Qy9FLE9BQU8sQ0FBQ0ksSUFBUixDQUFhMkksT0FBckQsSUFBZ0UvSSxPQUFPLENBQUNJLElBQVIsQ0FBYTJJLE9BQWIsQ0FBcUJsRyxNQUFyRixJQUErRjdDLE9BQU8sQ0FBQ0ksSUFBUixDQUFhMkksT0FBYixDQUFxQlUsSUFBckIsQ0FBMEJOLE1BQU0sSUFBSUEsTUFBTSxDQUFDTyxVQUEzQyxDQUE5RztBQUVBLFlBQU1DLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQ0osTUFBTSxJQUFJLEVBQVgsRUFBZXBILElBQWYsSUFBdUIsRUFBeEIsRUFBNEJBLElBQTVCLElBQW9DLEVBQXJDLEVBQXlDeUgsb0JBQTVEOztBQUVBLFVBQUlELFVBQVUsSUFBSSxDQUFDSCxNQUFuQixFQUEyQjtBQUN6QmpHLFFBQUFBLE1BQU0sQ0FBQ3NHLE1BQVAsR0FBZ0IsQ0FBaEI7QUFDQVAsUUFBQUEsVUFBVSxDQUFDUSxJQUFYLENBQWdCLEdBQUdQLE1BQU0sQ0FBQ3BILElBQVAsQ0FBWUEsSUFBWixDQUFpQnVCLGNBQXBDOztBQUNBLGVBQU80RixVQUFVLENBQUN6RyxNQUFYLEdBQW9COEcsVUFBcEIsSUFBa0NwRyxNQUFNLENBQUNzRyxNQUFQLEdBQWdCRixVQUF6RCxFQUFxRTtBQUNuRXBHLFVBQUFBLE1BQU0sQ0FBQ3NHLE1BQVAsSUFBaUJ0RyxNQUFNLENBQUMyRixLQUF4QjtBQUNBLGdCQUFNYSxPQUFPLEdBQUcsTUFBTWhLLE9BQU8sQ0FBQ08sS0FBUixDQUFjbUIsR0FBZCxDQUFrQkMsTUFBbEIsQ0FBeUJDLGFBQXpCLENBQXVDM0IsT0FBdkMsQ0FDcEIsS0FEb0IsRUFFbkIsSUFBR2dKLE9BQVEsRUFGUSxFQUdwQjtBQUFFekYsWUFBQUEsTUFBTSxFQUFFQTtBQUFWLFdBSG9CLEVBSXBCO0FBQUVQLFlBQUFBLFNBQVMsRUFBRWhELE9BQU8sQ0FBQ0ksSUFBUixDQUFhcUM7QUFBMUIsV0FKb0IsQ0FBdEI7QUFNQTZHLFVBQUFBLFVBQVUsQ0FBQ1EsSUFBWCxDQUFnQixHQUFHQyxPQUFPLENBQUM1SCxJQUFSLENBQWFBLElBQWIsQ0FBa0J1QixjQUFyQztBQUNEO0FBQ0Y7O0FBRUQsVUFBSWlHLFVBQUosRUFBZ0I7QUFDZCxjQUFNO0FBQUV4RCxVQUFBQSxJQUFGO0FBQVE0QyxVQUFBQTtBQUFSLFlBQW9CL0ksT0FBTyxDQUFDSSxJQUFsQztBQUNBLGNBQU00SixjQUFjLEdBQ2xCN0QsSUFBSSxDQUFDcEIsUUFBTCxDQUFjLFFBQWQsS0FBMkIsQ0FBQ3lFLE1BRDlCO0FBRUEsY0FBTVMsUUFBUSxHQUFHOUQsSUFBSSxDQUFDcEIsUUFBTCxDQUFjLFNBQWQsS0FBNEIsQ0FBQ29CLElBQUksQ0FBQ3BCLFFBQUwsQ0FBYyxRQUFkLENBQTlDO0FBQ0EsY0FBTW1GLGVBQWUsR0FBRy9ELElBQUksQ0FBQ21CLFVBQUwsQ0FBZ0IsaUJBQWhCLENBQXhCO0FBQ0EsY0FBTTZDLE9BQU8sR0FBR2hFLElBQUksQ0FBQ2lFLFFBQUwsQ0FBYyxRQUFkLENBQWhCO0FBQ0EsWUFBSUMsTUFBTSxHQUFHMUgsTUFBTSxDQUFDQyxJQUFQLENBQVkyRyxNQUFNLENBQUNwSCxJQUFQLENBQVlBLElBQVosQ0FBaUJ1QixjQUFqQixDQUFnQyxDQUFoQyxDQUFaLENBQWI7O0FBRUEsWUFBSXVHLFFBQVEsSUFBSUMsZUFBaEIsRUFBaUM7QUFDL0IsY0FBSUMsT0FBSixFQUFhO0FBQ1hFLFlBQUFBLE1BQU0sR0FBRyxDQUFDLFVBQUQsRUFBYSxNQUFiLENBQVQ7QUFDRCxXQUZELE1BRU87QUFDTEEsWUFBQUEsTUFBTSxHQUFHLENBQ1AsSUFETyxFQUVQLFFBRk8sRUFHUCxNQUhPLEVBSVAsSUFKTyxFQUtQLE9BTE8sRUFNUCxTQU5PLEVBT1AsV0FQTyxFQVFQLFNBUk8sRUFTUCxTQVRPLEVBVVAsZUFWTyxFQVdQLFNBWE8sRUFZUCxVQVpPLEVBYVAsYUFiTyxFQWNQLFVBZE8sRUFlUCxVQWZPLEVBZ0JQLFNBaEJPLEVBaUJQLGFBakJPLEVBa0JQLFVBbEJPLEVBbUJQLFlBbkJPLENBQVQ7QUFxQkQ7QUFDRjs7QUFFRCxZQUFJTCxjQUFKLEVBQW9CO0FBQ2xCLGdCQUFNTSxTQUFTLEdBQUcsRUFBbEI7O0FBQ0EsZUFBSyxNQUFNQyxJQUFYLElBQW1CakIsVUFBbkIsRUFBK0I7QUFDN0Isa0JBQU07QUFBRWtCLGNBQUFBLGdCQUFGO0FBQW9CQyxjQUFBQTtBQUFwQixnQkFBOEJGLElBQXBDO0FBQ0FELFlBQUFBLFNBQVMsQ0FBQ1IsSUFBVixDQUFlLEdBQUdXLEtBQUssQ0FBQ0MsR0FBTixDQUFVQyxJQUFJLEtBQUs7QUFBRUgsY0FBQUEsZ0JBQUY7QUFBb0J2QyxjQUFBQSxHQUFHLEVBQUUwQyxJQUFJLENBQUMxQyxHQUE5QjtBQUFtQ29CLGNBQUFBLEtBQUssRUFBRXNCLElBQUksQ0FBQ3RCO0FBQS9DLGFBQUwsQ0FBZCxDQUFsQjtBQUNEOztBQUNEZ0IsVUFBQUEsTUFBTSxHQUFHLENBQUMsa0JBQUQsRUFBcUIsS0FBckIsRUFBNEIsT0FBNUIsQ0FBVDtBQUNBZixVQUFBQSxVQUFVLEdBQUcsQ0FBQyxHQUFHZ0IsU0FBSixDQUFiO0FBQ0Q7O0FBRUQsWUFBSWQsTUFBSixFQUFZO0FBQ1ZhLFVBQUFBLE1BQU0sR0FBRyxDQUFDLEtBQUQsRUFBUSxPQUFSLENBQVQ7QUFDQWYsVUFBQUEsVUFBVSxHQUFHQyxNQUFNLENBQUNwSCxJQUFQLENBQVlBLElBQVosQ0FBaUJ1QixjQUFqQixDQUFnQyxDQUFoQyxFQUFtQytHLEtBQWhEO0FBQ0Q7O0FBQ0RKLFFBQUFBLE1BQU0sR0FBR0EsTUFBTSxDQUFDSyxHQUFQLENBQVdDLElBQUksS0FBSztBQUFFdEIsVUFBQUEsS0FBSyxFQUFFc0IsSUFBVDtBQUFlQyxVQUFBQSxPQUFPLEVBQUU7QUFBeEIsU0FBTCxDQUFmLENBQVQ7QUFFQSxjQUFNQyxjQUFjLEdBQUcsSUFBSUMsZ0JBQUosQ0FBVztBQUFFVCxVQUFBQTtBQUFGLFNBQVgsQ0FBdkI7QUFFQSxZQUFJdkIsR0FBRyxHQUFHK0IsY0FBYyxDQUFDRSxLQUFmLENBQXFCekIsVUFBckIsQ0FBVjs7QUFDQSxhQUFLLE1BQU0wQixLQUFYLElBQW9CWCxNQUFwQixFQUE0QjtBQUMxQixnQkFBTTtBQUFFaEIsWUFBQUE7QUFBRixjQUFZMkIsS0FBbEI7O0FBQ0EsY0FBSWxDLEdBQUcsQ0FBQy9ELFFBQUosQ0FBYXNFLEtBQWIsQ0FBSixFQUF5QjtBQUN2QlAsWUFBQUEsR0FBRyxHQUFHQSxHQUFHLENBQUNtQyxPQUFKLENBQVk1QixLQUFaLEVBQW1CNkIsa0NBQWU3QixLQUFmLEtBQXlCQSxLQUE1QyxDQUFOO0FBQ0Q7QUFDRjs7QUFFRCxlQUFPcEosUUFBUSxDQUFDZ0IsRUFBVCxDQUFZO0FBQ2pCUixVQUFBQSxPQUFPLEVBQUU7QUFBRSw0QkFBZ0I7QUFBbEIsV0FEUTtBQUVqQkwsVUFBQUEsSUFBSSxFQUFFMEk7QUFGVyxTQUFaLENBQVA7QUFJRCxPQW5FRCxNQW1FTyxJQUFJUyxNQUFNLElBQUlBLE1BQU0sQ0FBQ3BILElBQWpCLElBQXlCb0gsTUFBTSxDQUFDcEgsSUFBUCxDQUFZQSxJQUFyQyxJQUE2QyxDQUFDb0gsTUFBTSxDQUFDcEgsSUFBUCxDQUFZQSxJQUFaLENBQWlCeUgsb0JBQW5FLEVBQXlGO0FBQzlGLGNBQU0sSUFBSTlHLEtBQUosQ0FBVSxZQUFWLENBQU47QUFDRCxPQUZNLE1BRUE7QUFDTCxjQUFNLElBQUlBLEtBQUosQ0FBVyxxREFBb0R5RyxNQUFNLElBQUlBLE1BQU0sQ0FBQ3BILElBQWpCLElBQXlCb0gsTUFBTSxDQUFDcEgsSUFBUCxDQUFZQyxNQUFyQyxHQUErQyxLQUFJbUgsTUFBTSxDQUFDbkosSUFBUCxDQUFZZ0MsTUFBTyxFQUF0RSxHQUEwRSxFQUFHLEVBQTVJLENBQU47QUFDRDtBQUNGLEtBN0hELENBNkhFLE9BQU9qQixLQUFQLEVBQWM7QUFDZCx1QkFBSSxlQUFKLEVBQXFCQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQXRDO0FBQ0EsYUFBTyxrQ0FDTEEsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQURaLEVBRUwsSUFGSyxFQUdMbUIsNkJBQWtCQyxxQkFIYixFQUlMdEMsUUFKSyxDQUFQO0FBTUQ7QUFDRixHQTkyQnVCLENBZzNCeEI7OztBQUNBa0wsRUFBQUEsY0FBYyxDQUFDcEwsT0FBRCxFQUFpQ0MsT0FBakMsRUFBdUVDLFFBQXZFLEVBQXNIO0FBQ2xJO0FBQ0EsV0FBT0EsUUFBUSxDQUFDZ0IsRUFBVCxDQUFZO0FBQ2pCYixNQUFBQSxJQUFJLEVBQUVnTDtBQURXLEtBQVosQ0FBUDtBQUdEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFQyxFQUFBQSxZQUFZLENBQUN0TCxPQUFELEVBQWlDQyxPQUFqQyxFQUF1RUMsUUFBdkUsRUFBc0g7QUFDaEksUUFBSTtBQUNGLFlBQU1xTCxNQUFNLEdBQUdDLElBQUksQ0FBQ1IsS0FBTCxDQUFXUyxZQUFHQyxZQUFILENBQWdCLEtBQUs3TCxjQUFMLENBQW9COEwsSUFBcEMsRUFBMEMsTUFBMUMsQ0FBWCxDQUFmOztBQUNBLFVBQUlKLE1BQU0sQ0FBQ0ssZ0JBQVAsSUFBMkJMLE1BQU0sQ0FBQ00sV0FBdEMsRUFBbUQ7QUFDakQseUJBQ0Usd0JBREYsRUFFRyxzQkFBcUJOLE1BQU0sQ0FBQ0ssZ0JBQWlCLG1CQUFrQkwsTUFBTSxDQUFDTSxXQUFZLEVBRnJGLEVBR0UsT0FIRjtBQUtBLGVBQU8zTCxRQUFRLENBQUNnQixFQUFULENBQVk7QUFDakJiLFVBQUFBLElBQUksRUFBRTtBQUNKdUwsWUFBQUEsZ0JBQWdCLEVBQUVMLE1BQU0sQ0FBQ0ssZ0JBRHJCO0FBRUpDLFlBQUFBLFdBQVcsRUFBRU4sTUFBTSxDQUFDTTtBQUZoQjtBQURXLFNBQVosQ0FBUDtBQU1ELE9BWkQsTUFZTztBQUNMLGNBQU0sSUFBSTlJLEtBQUosQ0FBVSx3Q0FBVixDQUFOO0FBQ0Q7QUFDRixLQWpCRCxDQWlCRSxPQUFPM0IsS0FBUCxFQUFjO0FBQ2QsdUJBQUksd0JBQUosRUFBOEJBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBL0M7QUFDQSxhQUFPLGtDQUNMQSxLQUFLLENBQUNDLE9BQU4sSUFBaUIsd0NBRFosRUFFTCxJQUZLLEVBR0xrQiw2QkFBa0JDLHFCQUhiLEVBSUx0QyxRQUpLLENBQVA7QUFNRDtBQUNGO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNxQixRQUFiNEwsYUFBYSxDQUFDOUwsT0FBRCxFQUFpQ0MsT0FBakMsRUFBdUVDLFFBQXZFLEVBQXNIO0FBQ3ZJLFFBQUk7QUFDRixZQUFNO0FBQUV3QyxRQUFBQSxFQUFGO0FBQU1xSixRQUFBQTtBQUFOLFVBQXFCOUwsT0FBTyxDQUFDSSxJQUFuQyxDQURFLENBRUY7O0FBQ0EsWUFBTSxLQUFLUixjQUFMLENBQW9CbU0sbUJBQXBCLENBQXdDdEosRUFBeEMsRUFBNENxSixVQUE1QyxDQUFOO0FBQ0EsYUFBTzdMLFFBQVEsQ0FBQ2dCLEVBQVQsQ0FBWTtBQUNqQmIsUUFBQUEsSUFBSSxFQUFFO0FBQ0prRSxVQUFBQSxVQUFVLEVBQUVoQyw2QkFBa0JjO0FBRDFCO0FBRFcsT0FBWixDQUFQO0FBS0QsS0FURCxDQVNFLE9BQU9qQyxLQUFQLEVBQWM7QUFDZCx1QkFBSSx5QkFBSixFQUErQkEsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUFoRDtBQUNBLGFBQU8sa0NBQ0xBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQiwwQkFEWixFQUVMLElBRkssRUFHTGtCLDZCQUFrQkMscUJBSGIsRUFJTHRDLFFBSkssQ0FBUDtBQU1EO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0UrTCxFQUFBQSxhQUFhLENBQUNqTSxPQUFELEVBQWlDQyxPQUFqQyxFQUF1RUMsUUFBdkUsRUFBc0g7QUFDakksUUFBSTtBQUNGLFlBQU1xTCxNQUFNLEdBQUdDLElBQUksQ0FBQ1IsS0FBTCxDQUNiUyxZQUFHQyxZQUFILENBQWdCLEtBQUs3TCxjQUFMLENBQW9COEwsSUFBcEMsRUFBMEMsTUFBMUMsQ0FEYSxDQUFmO0FBR0EsYUFBT3pMLFFBQVEsQ0FBQ2dCLEVBQVQsQ0FBWTtBQUNqQmIsUUFBQUEsSUFBSSxFQUFFO0FBQ0owTCxVQUFBQSxVQUFVLEVBQUUsQ0FBQ1IsTUFBTSxDQUFDVyxLQUFQLENBQWFqTSxPQUFPLENBQUN1RCxNQUFSLENBQWVkLEVBQTVCLEtBQW1DLEVBQXBDLEVBQXdDcUosVUFBeEMsSUFBc0Q7QUFEOUQ7QUFEVyxPQUFaLENBQVA7QUFLRCxLQVRELENBU0UsT0FBTzNLLEtBQVAsRUFBYztBQUNkLHVCQUFJLHlCQUFKLEVBQStCQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQWhEO0FBQ0EsYUFBTyxrQ0FDTEEsS0FBSyxDQUFDQyxPQUFOLElBQWlCLHdDQURaLEVBRUwsSUFGSyxFQUdMa0IsNkJBQWtCQyxxQkFIYixFQUlMdEMsUUFKSyxDQUFQO0FBTUQ7QUFDRjtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDb0IsUUFBWmlNLFlBQVksQ0FBQ25NLE9BQUQsRUFBaUNDLE9BQWpDLEVBQXVFQyxRQUF2RSxFQUFzSDtBQUN0SSxRQUFJO0FBQ0YsWUFBTXFMLE1BQU0sR0FBR0MsSUFBSSxDQUFDUixLQUFMLENBQVdTLFlBQUdDLFlBQUgsQ0FBZ0IsS0FBSzdMLGNBQUwsQ0FBb0I4TCxJQUFwQyxFQUEwQyxNQUExQyxDQUFYLENBQWY7QUFDQSxhQUFPekwsUUFBUSxDQUFDZ0IsRUFBVCxDQUFZO0FBQ2pCYixRQUFBQSxJQUFJLEVBQUU7QUFDSmtFLFVBQUFBLFVBQVUsRUFBRWhDLDZCQUFrQmMsRUFEMUI7QUFFSmpCLFVBQUFBLElBQUksRUFBRSxDQUFDUSxNQUFNLENBQUN3SixNQUFQLENBQWNiLE1BQWQsRUFBc0J6SSxNQUF2QixHQUFnQyxFQUFoQyxHQUFxQ3lJO0FBRnZDO0FBRFcsT0FBWixDQUFQO0FBTUQsS0FSRCxDQVFFLE9BQU9uSyxLQUFQLEVBQWM7QUFDZCx1QkFBSSx3QkFBSixFQUE4QkEsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUEvQztBQUNBLGFBQU8sa0NBQ0oseURBQXdEQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQU0sRUFEM0UsRUFFTCxJQUZLLEVBR0xtQiw2QkFBa0JDLHFCQUhiLEVBSUx0QyxRQUpLLENBQVA7QUFNRDtBQUNGO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUN1QixRQUFmbU0sZUFBZSxDQUFDck0sT0FBRCxFQUFpQ0MsT0FBakMsRUFBdUVDLFFBQXZFLEVBQXNIO0FBQ3pJLFFBQUk7QUFDRixZQUFNK0MsU0FBUyxHQUFHLGtDQUFxQmhELE9BQU8sQ0FBQ1MsT0FBUixDQUFnQkMsTUFBckMsRUFBNEMsUUFBNUMsQ0FBbEI7O0FBQ0EsVUFBSSxDQUFDVixPQUFPLENBQUN1RCxNQUFULElBQW1CLENBQUNQLFNBQXBCLElBQWlDLENBQUNoRCxPQUFPLENBQUN1RCxNQUFSLENBQWU4SSxLQUFyRCxFQUE0RDtBQUMxRCxjQUFNLElBQUl2SixLQUFKLENBQVUsa0NBQVYsQ0FBTjtBQUNEOztBQUVELFlBQU07QUFBRXVKLFFBQUFBO0FBQUYsVUFBWXJNLE9BQU8sQ0FBQ3VELE1BQTFCO0FBRUEsWUFBTXBCLElBQUksR0FBRyxNQUFNeUUsT0FBTyxDQUFDMEYsR0FBUixDQUFZLENBQzdCdk0sT0FBTyxDQUFDTyxLQUFSLENBQWNtQixHQUFkLENBQWtCQyxNQUFsQixDQUF5QkcsY0FBekIsQ0FBd0M3QixPQUF4QyxDQUFnRCxLQUFoRCxFQUF3RCxpQkFBZ0JxTSxLQUFNLFdBQTlFLEVBQTBGLEVBQTFGLEVBQThGO0FBQUVySixRQUFBQTtBQUFGLE9BQTlGLENBRDZCLEVBRTdCakQsT0FBTyxDQUFDTyxLQUFSLENBQWNtQixHQUFkLENBQWtCQyxNQUFsQixDQUF5QkcsY0FBekIsQ0FBd0M3QixPQUF4QyxDQUFnRCxLQUFoRCxFQUF3RCxpQkFBZ0JxTSxLQUFNLEtBQTlFLEVBQW9GLEVBQXBGLEVBQXdGO0FBQUVySixRQUFBQTtBQUFGLE9BQXhGLENBRjZCLENBQVosQ0FBbkI7QUFLQSxZQUFNdUosTUFBTSxHQUFHcEssSUFBSSxDQUFDdUksR0FBTCxDQUFTQyxJQUFJLElBQUksQ0FBQ0EsSUFBSSxDQUFDeEksSUFBTCxJQUFhLEVBQWQsRUFBa0JBLElBQWxCLElBQTBCLEVBQTNDLENBQWY7QUFDQSxZQUFNLENBQUNxSyxnQkFBRCxFQUFtQkMsVUFBbkIsSUFBaUNGLE1BQXZDLENBZEUsQ0FnQkY7O0FBQ0EsWUFBTUcsWUFBWSxHQUFHO0FBQ25CQyxRQUFBQSxRQUFRLEVBQ04sT0FBT0gsZ0JBQVAsS0FBNEIsUUFBNUIsSUFBd0M3SixNQUFNLENBQUNDLElBQVAsQ0FBWTRKLGdCQUFaLEVBQThCM0osTUFBdEUsR0FDSSxFQUFFLEdBQUcySixnQkFBZ0IsQ0FBQzlJLGNBQWpCLENBQWdDLENBQWhDO0FBQUwsU0FESixHQUVJLEtBSmE7QUFLbkJrSixRQUFBQSxFQUFFLEVBQ0EsT0FBT0gsVUFBUCxLQUFzQixRQUF0QixJQUFrQzlKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZNkosVUFBWixFQUF3QjVKLE1BQTFELEdBQ0ksRUFBRSxHQUFHNEosVUFBVSxDQUFDL0ksY0FBWCxDQUEwQixDQUExQjtBQUFMLFNBREosR0FFSTtBQVJhLE9BQXJCO0FBV0EsYUFBT3pELFFBQVEsQ0FBQ2dCLEVBQVQsQ0FBWTtBQUNqQmIsUUFBQUEsSUFBSSxFQUFFc007QUFEVyxPQUFaLENBQVA7QUFHRCxLQS9CRCxDQStCRSxPQUFPdkwsS0FBUCxFQUFjO0FBQ2QsdUJBQUksMkJBQUosRUFBaUNBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBbEQ7QUFDQSxhQUFPLGtDQUNMQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBRFosRUFFTCxJQUZLLEVBR0xtQiw2QkFBa0JDLHFCQUhiLEVBSUx0QyxRQUpLLENBQVA7QUFNRDtBQUNGO0FBQ0Q7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUN1QixRQUFmNE0sZUFBZSxDQUFDOU0sT0FBRCxFQUFpQ0MsT0FBakMsRUFBdUVDLFFBQXZFLEVBQXNIO0FBQ3pJLFFBQUk7QUFFRixZQUFNNk0sYUFBYSxHQUFHLENBQUUsTUFBTSx5Q0FBUixFQUE2QixnQkFBN0IsS0FBa0QsRUFBeEU7QUFDQSxZQUFNQyxXQUFXLEdBQUcsQ0FBRSxNQUFNLHlDQUFSLEVBQTZCLDRCQUE3QixDQUFwQjtBQUNBLFlBQU01SyxJQUFJLEdBQUcsQ0FBQyxNQUFNcEMsT0FBTyxDQUFDTyxLQUFSLENBQWNDLFFBQWQsQ0FBdUJDLGNBQXZCLENBQXNDUixPQUF0QyxFQUErQ0QsT0FBL0MsQ0FBUCxFQUFnRWlOLFdBQTdFO0FBRUEsWUFBTUgsZUFBZSxHQUFHLENBQUMsQ0FBQzFLLElBQUksQ0FBQzhLLEtBQUwsSUFBYyxFQUFmLEVBQW1CQyxJQUFuQixDQUF5QkMsSUFBRCxJQUFVTCxhQUFhLENBQUMvSCxRQUFkLENBQXVCb0ksSUFBdkIsQ0FBbEMsQ0FBekI7QUFFQSxhQUFPbE4sUUFBUSxDQUFDZ0IsRUFBVCxDQUFZO0FBQ2pCYixRQUFBQSxJQUFJLEVBQUU7QUFBRXlNLFVBQUFBLGVBQUY7QUFBbUJFLFVBQUFBO0FBQW5CO0FBRFcsT0FBWixDQUFQO0FBR0QsS0FYRCxDQVdFLE9BQU81TCxLQUFQLEVBQWM7QUFDZCx1QkFBSSwyQkFBSixFQUFpQ0EsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUFsRDtBQUNBLGFBQU8sa0NBQ0xBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FEWixFQUVMLElBRkssRUFHTG1CLDZCQUFrQkMscUJBSGIsRUFJTHRDLFFBSkssQ0FBUDtBQU1EO0FBRUY7O0FBN2pDdUIiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxyXG4gKiBXYXp1aCBhcHAgLSBDbGFzcyBmb3IgV2F6dWgtQVBJIGZ1bmN0aW9uc1xyXG4gKiBDb3B5cmlnaHQgKEMpIDIwMTUtMjAyMiBXYXp1aCwgSW5jLlxyXG4gKlxyXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxyXG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxyXG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxyXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxyXG4gKlxyXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxyXG4gKi9cclxuXHJcbi8vIFJlcXVpcmUgc29tZSBsaWJyYXJpZXNcclxuaW1wb3J0IHsgRXJyb3JSZXNwb25zZSB9IGZyb20gJy4uL2xpYi9lcnJvci1yZXNwb25zZSc7XHJcbmltcG9ydCB7IFBhcnNlciB9IGZyb20gJ2pzb24yY3N2JztcclxuaW1wb3J0IHsgbG9nIH0gZnJvbSAnLi4vbGliL2xvZ2dlcic7XHJcbmltcG9ydCB7IEtleUVxdWl2YWxlbmNlIH0gZnJvbSAnLi4vLi4vY29tbW9uL2Nzdi1rZXktZXF1aXZhbGVuY2UnO1xyXG5pbXBvcnQgeyBBcGlFcnJvckVxdWl2YWxlbmNlIH0gZnJvbSAnLi4vbGliL2FwaS1lcnJvcnMtZXF1aXZhbGVuY2UnO1xyXG5pbXBvcnQgYXBpUmVxdWVzdExpc3QgZnJvbSAnLi4vLi4vY29tbW9uL2FwaS1pbmZvL2VuZHBvaW50cyc7XHJcbmltcG9ydCB7IEhUVFBfU1RBVFVTX0NPREVTIH0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XHJcbmltcG9ydCB7IGFkZEpvYlRvUXVldWUgfSBmcm9tICcuLi9zdGFydC9xdWV1ZSc7XHJcbmltcG9ydCBmcyBmcm9tICdmcyc7XHJcbmltcG9ydCB7IE1hbmFnZUhvc3RzIH0gZnJvbSAnLi4vbGliL21hbmFnZS1ob3N0cyc7XHJcbmltcG9ydCB7IFVwZGF0ZVJlZ2lzdHJ5IH0gZnJvbSAnLi4vbGliL3VwZGF0ZS1yZWdpc3RyeSc7XHJcbmltcG9ydCBqd3REZWNvZGUgZnJvbSAnand0LWRlY29kZSc7XHJcbmltcG9ydCB7IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCwgUmVxdWVzdEhhbmRsZXJDb250ZXh0LCBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSB9IGZyb20gJ3NyYy9jb3JlL3NlcnZlcic7XHJcbmltcG9ydCB7IEFQSVVzZXJBbGxvd1J1bkFzLCBDYWNoZUluTWVtb3J5QVBJVXNlckFsbG93UnVuQXMsIEFQSV9VU0VSX1NUQVRVU19SVU5fQVMgfSBmcm9tICcuLi9saWIvY2FjaGUtYXBpLXVzZXItaGFzLXJ1bi1hcyc7XHJcbmltcG9ydCB7IGdldENvb2tpZVZhbHVlQnlOYW1lIH0gZnJvbSAnLi4vbGliL2Nvb2tpZSc7XHJcbmltcG9ydCB7IFNlY3VyaXR5T2JqIH0gZnJvbSAnLi4vbGliL3NlY3VyaXR5LWZhY3RvcnknO1xyXG5pbXBvcnQgeyBnZXRDb25maWd1cmF0aW9uIH0gZnJvbSAnLi4vbGliL2dldC1jb25maWd1cmF0aW9uJztcclxuXHJcbmV4cG9ydCBjbGFzcyBXYXp1aEFwaUN0cmwge1xyXG4gIG1hbmFnZUhvc3RzOiBNYW5hZ2VIb3N0c1xyXG4gIHVwZGF0ZVJlZ2lzdHJ5OiBVcGRhdGVSZWdpc3RyeVxyXG5cclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICAgIHRoaXMubWFuYWdlSG9zdHMgPSBuZXcgTWFuYWdlSG9zdHMoKTtcclxuICAgIHRoaXMudXBkYXRlUmVnaXN0cnkgPSBuZXcgVXBkYXRlUmVnaXN0cnkoKTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFRva2VuKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnkpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHsgZm9yY2UsIGlkSG9zdCB9ID0gcmVxdWVzdC5ib2R5O1xyXG4gICAgICBjb25zdCB7IHVzZXJuYW1lIH0gPSBhd2FpdCBjb250ZXh0LndhenVoLnNlY3VyaXR5LmdldEN1cnJlbnRVc2VyKHJlcXVlc3QsIGNvbnRleHQpO1xyXG4gICAgICBpZiAoIWZvcmNlICYmIHJlcXVlc3QuaGVhZGVycy5jb29raWUgJiYgdXNlcm5hbWUgPT09IGdldENvb2tpZVZhbHVlQnlOYW1lKHJlcXVlc3QuaGVhZGVycy5jb29raWUsICd3ei11c2VyJykgJiYgaWRIb3N0ID09PSBnZXRDb29raWVWYWx1ZUJ5TmFtZShyZXF1ZXN0LmhlYWRlcnMuY29va2llLCd3ei1hcGknKSkge1xyXG4gICAgICAgIGNvbnN0IHd6VG9rZW4gPSBnZXRDb29raWVWYWx1ZUJ5TmFtZShyZXF1ZXN0LmhlYWRlcnMuY29va2llLCAnd3otdG9rZW4nKTtcclxuICAgICAgICBpZiAod3pUb2tlbikge1xyXG4gICAgICAgICAgdHJ5IHsgLy8gaWYgdGhlIGN1cnJlbnQgdG9rZW4gaXMgbm90IGEgdmFsaWQgand0IHRva2VuIHdlIGFzayBmb3IgYSBuZXcgb25lXHJcbiAgICAgICAgICAgIGNvbnN0IGRlY29kZWRUb2tlbiA9IGp3dERlY29kZSh3elRva2VuKTtcclxuICAgICAgICAgICAgY29uc3QgZXhwaXJhdGlvblRpbWUgPSAoZGVjb2RlZFRva2VuLmV4cCAtIChEYXRlLm5vdygpIC8gMTAwMCkpO1xyXG4gICAgICAgICAgICBpZiAod3pUb2tlbiAmJiBleHBpcmF0aW9uVGltZSA+IDApIHtcclxuICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgICAgICAgICAgYm9keTogeyB0b2tlbjogd3pUb2tlbiB9XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGxvZygnd2F6dWgtYXBpOmdldFRva2VuJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGxldCB0b2tlbjtcclxuICAgICAgaWYgKGF3YWl0IEFQSVVzZXJBbGxvd1J1bkFzLmNhblVzZShpZEhvc3QpID09IEFQSV9VU0VSX1NUQVRVU19SVU5fQVMuRU5BQkxFRCkge1xyXG4gICAgICAgIHRva2VuID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIuYXV0aGVudGljYXRlKGlkSG9zdCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdG9rZW4gPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNJbnRlcm5hbFVzZXIuYXV0aGVudGljYXRlKGlkSG9zdCk7XHJcbiAgICAgIH07XHJcblxyXG4gICAgICBsZXQgdGV4dFNlY3VyZT0nJztcclxuICAgICAgaWYoY29udGV4dC53YXp1aC5zZXJ2ZXIuaW5mby5wcm90b2NvbCA9PT0gJ2h0dHBzJyl7XHJcbiAgICAgICAgdGV4dFNlY3VyZSA9ICc7U2VjdXJlJztcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAnc2V0LWNvb2tpZSc6IFtcclxuICAgICAgICAgICAgYHd6LXRva2VuPSR7dG9rZW59O1BhdGg9LztIdHRwT25seSR7dGV4dFNlY3VyZX1gLFxyXG4gICAgICAgICAgICBgd3otdXNlcj0ke3VzZXJuYW1lfTtQYXRoPS87SHR0cE9ubHkke3RleHRTZWN1cmV9YCxcclxuICAgICAgICAgICAgYHd6LWFwaT0ke2lkSG9zdH07UGF0aD0vO0h0dHBPbmx5YCxcclxuICAgICAgICAgIF0sXHJcbiAgICAgICAgfSxcclxuICAgICAgICBib2R5OiB7IHRva2VuIH1cclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSAoKGVycm9yLnJlc3BvbnNlIHx8IHt9KS5kYXRhIHx8IHt9KS5kZXRhaWwgfHwgZXJyb3IubWVzc2FnZSB8fCBlcnJvcjtcclxuICAgICAgbG9nKCd3YXp1aC1hcGk6Z2V0VG9rZW4nLCBlcnJvck1lc3NhZ2UpO1xyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcclxuICAgICAgICBgRXJyb3IgZ2V0dGluZyB0aGUgYXV0aG9yaXphdGlvbiB0b2tlbjogJHtlcnJvck1lc3NhZ2V9YCxcclxuICAgICAgICAzMDAwLFxyXG4gICAgICAgIGVycm9yPy5yZXNwb25zZT8uc3RhdHVzIHx8IEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcclxuICAgICAgICByZXNwb25zZVxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyBpZiB0aGUgd2F6dWgtYXBpIGNvbmZpZ3VyYXRpb24gaXMgd29ya2luZ1xyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcclxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSBzdGF0dXMgb2JqIG9yIEVycm9yUmVzcG9uc2VcclxuICAgKi9cclxuICBhc3luYyBjaGVja1N0b3JlZEFQSShjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCwgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5KSB7XHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBHZXQgY29uZmlnIGZyb20gd2F6dWgueW1sXHJcbiAgICAgIGNvbnN0IGlkID0gcmVxdWVzdC5ib2R5LmlkO1xyXG4gICAgICBjb25zdCBhcGkgPSBhd2FpdCB0aGlzLm1hbmFnZUhvc3RzLmdldEhvc3RCeUlkKGlkKTtcclxuICAgICAgLy8gQ2hlY2sgTWFuYWdlIEhvc3RzXHJcbiAgICAgIGlmICghT2JqZWN0LmtleXMoYXBpKS5sZW5ndGgpIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0NvdWxkIG5vdCBmaW5kIFdhenVoIEFQSSBlbnRyeSBvbiB3YXp1aC55bWwnKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgbG9nKCd3YXp1aC1hcGk6Y2hlY2tTdG9yZWRBUEknLCBgJHtpZH0gZXhpc3RzYCwgJ2RlYnVnJyk7XHJcblxyXG4gICAgICAvLyBGZXRjaCBuZWVkZWQgaW5mb3JtYXRpb24gYWJvdXQgdGhlIGNsdXN0ZXIgYW5kIHRoZSBtYW5hZ2VyIGl0c2VsZlxyXG4gICAgICBjb25zdCByZXNwb25zZU1hbmFnZXJJbmZvID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoXHJcbiAgICAgICAgJ2dldCcsXHJcbiAgICAgICAgYC9tYW5hZ2VyL2luZm9gLFxyXG4gICAgICAgIHt9LFxyXG4gICAgICAgIHsgYXBpSG9zdElEOiBpZCwgZm9yY2VSZWZyZXNoOiB0cnVlIH1cclxuICAgICAgKTtcclxuXHJcbiAgICAgIC8vIExvb2sgZm9yIHNvY2tldC1yZWxhdGVkIGVycm9yc1xyXG4gICAgICBpZiAodGhpcy5jaGVja1Jlc3BvbnNlSXNEb3duKHJlc3BvbnNlTWFuYWdlckluZm8pKSB7XHJcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXHJcbiAgICAgICAgICBgRVJST1IzMDk5IC0gJHtyZXNwb25zZU1hbmFnZXJJbmZvLmRhdGEuZGV0YWlsIHx8ICdXYXp1aCBub3QgcmVhZHkgeWV0J31gLFxyXG4gICAgICAgICAgMzA5OSxcclxuICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLlNFUlZJQ0VfVU5BVkFJTEFCTEUsXHJcbiAgICAgICAgICByZXNwb25zZVxyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIElmIHdlIGhhdmUgYSB2YWxpZCByZXNwb25zZSBmcm9tIHRoZSBXYXp1aCBBUElcclxuICAgICAgaWYgKHJlc3BvbnNlTWFuYWdlckluZm8uc3RhdHVzID09PSBIVFRQX1NUQVRVU19DT0RFUy5PSyAmJiByZXNwb25zZU1hbmFnZXJJbmZvLmRhdGEpIHtcclxuICAgICAgICAvLyBDbGVhciBhbmQgdXBkYXRlIGNsdXN0ZXIgaW5mb3JtYXRpb24gYmVmb3JlIGJlaW5nIHNlbnQgYmFjayB0byBmcm9udGVuZFxyXG4gICAgICAgIGRlbGV0ZSBhcGkuY2x1c3Rlcl9pbmZvO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlQWdlbnRzID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoXHJcbiAgICAgICAgICAnR0VUJyxcclxuICAgICAgICAgIGAvYWdlbnRzYCxcclxuICAgICAgICAgIHsgcGFyYW1zOiB7IGFnZW50c19saXN0OiAnMDAwJyB9IH0sXHJcbiAgICAgICAgICB7IGFwaUhvc3RJRDogaWQgfVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZUFnZW50cy5zdGF0dXMgPT09IEhUVFBfU1RBVFVTX0NPREVTLk9LKSB7XHJcbiAgICAgICAgICBjb25zdCBtYW5hZ2VyTmFtZSA9IHJlc3BvbnNlQWdlbnRzLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc1swXS5tYW5hZ2VyO1xyXG5cclxuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlQ2x1c3RlclN0YXR1cyA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KFxyXG4gICAgICAgICAgICAnR0VUJyxcclxuICAgICAgICAgICAgYC9jbHVzdGVyL3N0YXR1c2AsXHJcbiAgICAgICAgICAgIHt9LFxyXG4gICAgICAgICAgICB7IGFwaUhvc3RJRDogaWQgfVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgIGlmIChyZXNwb25zZUNsdXN0ZXJTdGF0dXMuc3RhdHVzID09PSBIVFRQX1NUQVRVU19DT0RFUy5PSykge1xyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2VDbHVzdGVyU3RhdHVzLmRhdGEuZGF0YS5lbmFibGVkID09PSAneWVzJykge1xyXG4gICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlQ2x1c3RlckxvY2FsSW5mbyA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KFxyXG4gICAgICAgICAgICAgICAgJ0dFVCcsXHJcbiAgICAgICAgICAgICAgICBgL2NsdXN0ZXIvbG9jYWwvaW5mb2AsXHJcbiAgICAgICAgICAgICAgICB7fSxcclxuICAgICAgICAgICAgICAgIHsgYXBpSG9zdElEOiBpZCB9XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICBpZiAocmVzcG9uc2VDbHVzdGVyTG9jYWxJbmZvLnN0YXR1cyA9PT0gSFRUUF9TVEFUVVNfQ09ERVMuT0spIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGNsdXN0ZXJFbmFibGVkID0gcmVzcG9uc2VDbHVzdGVyU3RhdHVzLmRhdGEuZGF0YS5lbmFibGVkID09PSAneWVzJztcclxuICAgICAgICAgICAgICAgIGFwaS5jbHVzdGVyX2luZm8gPSB7XHJcbiAgICAgICAgICAgICAgICAgIHN0YXR1czogY2x1c3RlckVuYWJsZWQgPyAnZW5hYmxlZCcgOiAnZGlzYWJsZWQnLFxyXG4gICAgICAgICAgICAgICAgICBtYW5hZ2VyOiBtYW5hZ2VyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgbm9kZTogcmVzcG9uc2VDbHVzdGVyTG9jYWxJbmZvLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc1swXS5ub2RlLFxyXG4gICAgICAgICAgICAgICAgICBjbHVzdGVyOiBjbHVzdGVyRW5hYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgID8gcmVzcG9uc2VDbHVzdGVyTG9jYWxJbmZvLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc1swXS5jbHVzdGVyXHJcbiAgICAgICAgICAgICAgICAgICAgOiAnRGlzYWJsZWQnLFxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgLy8gQ2x1c3RlciBtb2RlIGlzIG5vdCBhY3RpdmVcclxuICAgICAgICAgICAgICBhcGkuY2x1c3Rlcl9pbmZvID0ge1xyXG4gICAgICAgICAgICAgICAgc3RhdHVzOiAnZGlzYWJsZWQnLFxyXG4gICAgICAgICAgICAgICAgbWFuYWdlcjogbWFuYWdlck5hbWUsXHJcbiAgICAgICAgICAgICAgICBjbHVzdGVyOiAnRGlzYWJsZWQnLFxyXG4gICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIC8vIENsdXN0ZXIgbW9kZSBpcyBub3QgYWN0aXZlXHJcbiAgICAgICAgICAgIGFwaS5jbHVzdGVyX2luZm8gPSB7XHJcbiAgICAgICAgICAgICAgc3RhdHVzOiAnZGlzYWJsZWQnLFxyXG4gICAgICAgICAgICAgIG1hbmFnZXI6IG1hbmFnZXJOYW1lLFxyXG4gICAgICAgICAgICAgIGNsdXN0ZXI6ICdEaXNhYmxlZCcsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgaWYgKGFwaS5jbHVzdGVyX2luZm8pIHtcclxuICAgICAgICAgICAgLy8gVXBkYXRlIGNsdXN0ZXIgaW5mb3JtYXRpb24gaW4gdGhlIHdhenVoLXJlZ2lzdHJ5Lmpzb25cclxuICAgICAgICAgICAgYXdhaXQgdGhpcy51cGRhdGVSZWdpc3RyeS51cGRhdGVDbHVzdGVySW5mbyhpZCwgYXBpLmNsdXN0ZXJfaW5mbyk7XHJcblxyXG4gICAgICAgICAgICAvLyBIaWRlIFdhenVoIEFQSSBzZWNyZXQsIHVzZXJuYW1lLCBwYXNzd29yZFxyXG4gICAgICAgICAgICBjb25zdCBjb3BpZWQgPSB7IC4uLmFwaSB9O1xyXG4gICAgICAgICAgICBjb3BpZWQuc2VjcmV0ID0gJyoqKionO1xyXG4gICAgICAgICAgICBjb3BpZWQucGFzc3dvcmQgPSAnKioqKic7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgICAgICAgIGJvZHk6IHtcclxuICAgICAgICAgICAgICAgIHN0YXR1c0NvZGU6IEhUVFBfU1RBVFVTX0NPREVTLk9LLFxyXG4gICAgICAgICAgICAgICAgZGF0YTogY29waWVkLFxyXG4gICAgICAgICAgICAgICAgaWRDaGFuZ2VkOiByZXF1ZXN0LmJvZHkuaWRDaGFuZ2VkIHx8IG51bGwsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBJZiB3ZSBoYXZlIGFuIGludmFsaWQgcmVzcG9uc2UgZnJvbSB0aGUgV2F6dWggQVBJXHJcbiAgICAgIHRocm93IG5ldyBFcnJvcihyZXNwb25zZU1hbmFnZXJJbmZvLmRhdGEuZGV0YWlsIHx8IGAke2FwaS51cmx9OiR7YXBpLnBvcnR9IGlzIHVucmVhY2hhYmxlYCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBpZiAoZXJyb3IuY29kZSA9PT0gJ0VQUk9UTycpIHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgICAgYm9keToge1xyXG4gICAgICAgICAgICBzdGF0dXNDb2RlOiBIVFRQX1NUQVRVU19DT0RFUy5PSyxcclxuICAgICAgICAgICAgZGF0YTogeyBhcGlJc0Rvd246IHRydWUgfSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSBpZiAoZXJyb3IuY29kZSA9PT0gJ0VDT05OUkVGVVNFRCcpIHtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgICAgYm9keToge1xyXG4gICAgICAgICAgICBzdGF0dXNDb2RlOiBIVFRQX1NUQVRVU19DT0RFUy5PSyxcclxuICAgICAgICAgICAgZGF0YTogeyBhcGlJc0Rvd246IHRydWUgfSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGNvbnN0IGFwaXMgPSBhd2FpdCB0aGlzLm1hbmFnZUhvc3RzLmdldEhvc3RzKCk7XHJcbiAgICAgICAgICBmb3IgKGNvbnN0IGFwaSBvZiBhcGlzKSB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgaWQgPSBPYmplY3Qua2V5cyhhcGkpWzBdO1xyXG5cclxuICAgICAgICAgICAgICBjb25zdCByZXNwb25zZU1hbmFnZXJJbmZvID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoXHJcbiAgICAgICAgICAgICAgICAnR0VUJyxcclxuICAgICAgICAgICAgICAgIGAvbWFuYWdlci9pbmZvYCxcclxuICAgICAgICAgICAgICAgIHt9LFxyXG4gICAgICAgICAgICAgICAgeyBhcGlIb3N0SUQ6IGlkIH1cclxuICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgICBpZiAodGhpcy5jaGVja1Jlc3BvbnNlSXNEb3duKHJlc3BvbnNlTWFuYWdlckluZm8pKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcclxuICAgICAgICAgICAgICAgICAgYEVSUk9SMzA5OSAtICR7cmVzcG9uc2UuZGF0YS5kZXRhaWwgfHwgJ1dhenVoIG5vdCByZWFkeSB5ZXQnfWAsXHJcbiAgICAgICAgICAgICAgICAgIDMwOTksXHJcbiAgICAgICAgICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLlNFUlZJQ0VfVU5BVkFJTEFCTEUsXHJcbiAgICAgICAgICAgICAgICAgIHJlc3BvbnNlXHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBpZiAocmVzcG9uc2VNYW5hZ2VySW5mby5zdGF0dXMgPT09IEhUVFBfU1RBVFVTX0NPREVTLk9LKSB7XHJcbiAgICAgICAgICAgICAgICByZXF1ZXN0LmJvZHkuaWQgPSBpZDtcclxuICAgICAgICAgICAgICAgIHJlcXVlc3QuYm9keS5pZENoYW5nZWQgPSBpZDtcclxuICAgICAgICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLmNoZWNrU3RvcmVkQVBJKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7IH0gLy8gZXNsaW50LWRpc2FibGUtbGluZVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICBsb2coJ3dhenVoLWFwaTpjaGVja1N0b3JlZEFQSScsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xyXG4gICAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXHJcbiAgICAgICAgICAgIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsXHJcbiAgICAgICAgICAgIDMwMjAsXHJcbiAgICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcclxuICAgICAgICAgICAgcmVzcG9uc2VcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxvZygnd2F6dWgtYXBpOmNoZWNrU3RvcmVkQVBJJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXHJcbiAgICAgICAgICBlcnJvci5tZXNzYWdlIHx8IGVycm9yLFxyXG4gICAgICAgICAgMzAwMixcclxuICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcclxuICAgICAgICAgIHJlc3BvbnNlXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogVGhpcyBwZXJmb21zIGEgdmFsaWRhdGlvbiBvZiBBUEkgcGFyYW1zXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGJvZHkgQVBJIHBhcmFtc1xyXG4gICAqL1xyXG4gIHZhbGlkYXRlQ2hlY2tBcGlQYXJhbXMoYm9keSkge1xyXG4gICAgaWYgKCEoJ3VzZXJuYW1lJyBpbiBib2R5KSkge1xyXG4gICAgICByZXR1cm4gJ01pc3NpbmcgcGFyYW06IEFQSSBVU0VSTkFNRSc7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCEoJ3Bhc3N3b3JkJyBpbiBib2R5KSAmJiAhKCdpZCcgaW4gYm9keSkpIHtcclxuICAgICAgcmV0dXJuICdNaXNzaW5nIHBhcmFtOiBBUEkgUEFTU1dPUkQnO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghKCd1cmwnIGluIGJvZHkpKSB7XHJcbiAgICAgIHJldHVybiAnTWlzc2luZyBwYXJhbTogQVBJIFVSTCc7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCEoJ3BvcnQnIGluIGJvZHkpKSB7XHJcbiAgICAgIHJldHVybiAnTWlzc2luZyBwYXJhbTogQVBJIFBPUlQnO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghYm9keS51cmwuaW5jbHVkZXMoJ2h0dHBzOi8vJykgJiYgIWJvZHkudXJsLmluY2x1ZGVzKCdodHRwOi8vJykpIHtcclxuICAgICAgcmV0dXJuICdwcm90b2NvbF9lcnJvcic7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogVGhpcyBjaGVjayB0aGUgd2F6dWgtYXBpIGNvbmZpZ3VyYXRpb24gcmVjZWl2ZWQgaW4gdGhlIFBPU1QgYm9keSB3aWxsIHdvcmtcclxuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXHJcbiAgICogQHJldHVybnMge09iamVjdH0gc3RhdHVzIG9iaiBvciBFcnJvclJlc3BvbnNlXHJcbiAgICovXHJcbiAgYXN5bmMgY2hlY2tBUEkoY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IGFwaUF2YWlsYWJsZSA9IG51bGw7XHJcbiAgICAgIC8vIGNvbnN0IG5vdFZhbGlkID0gdGhpcy52YWxpZGF0ZUNoZWNrQXBpUGFyYW1zKHJlcXVlc3QuYm9keSk7XHJcbiAgICAgIC8vIGlmIChub3RWYWxpZCkgcmV0dXJuIEVycm9yUmVzcG9uc2Uobm90VmFsaWQsIDMwMDMsIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUiwgcmVzcG9uc2UpO1xyXG4gICAgICBsb2coJ3dhenVoLWFwaTpjaGVja0FQSScsIGAke3JlcXVlc3QuYm9keS5pZH0gaXMgdmFsaWRgLCAnZGVidWcnKTtcclxuICAgICAgLy8gQ2hlY2sgaWYgYSBXYXp1aCBBUEkgaWQgaXMgZ2l2ZW4gKGFscmVhZHkgc3RvcmVkIEFQSSlcclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHRoaXMubWFuYWdlSG9zdHMuZ2V0SG9zdEJ5SWQocmVxdWVzdC5ib2R5LmlkKTtcclxuICAgICAgaWYgKGRhdGEpIHtcclxuICAgICAgICBhcGlBdmFpbGFibGUgPSBkYXRhO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGxvZygnd2F6dWgtYXBpOmNoZWNrQVBJJywgYEFQSSAke3JlcXVlc3QuYm9keS5pZH0gbm90IGZvdW5kYCk7XHJcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXHJcbiAgICAgICAgICBgVGhlIEFQSSAke3JlcXVlc3QuYm9keS5pZH0gd2FzIG5vdCBmb3VuZGAsXHJcbiAgICAgICAgICAzMDI5LFxyXG4gICAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLFxyXG4gICAgICAgICAgcmVzcG9uc2VcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IG9wdGlvbnMgPSB7IGFwaUhvc3RJRDogcmVxdWVzdC5ib2R5LmlkIH07XHJcbiAgICAgIGlmIChyZXF1ZXN0LmJvZHkuZm9yY2VSZWZyZXNoKSB7XHJcbiAgICAgICAgb3B0aW9uc1snZm9yY2VSZWZyZXNoJ10gPSByZXF1ZXN0LmJvZHkuZm9yY2VSZWZyZXNoO1xyXG4gICAgICB9XHJcbiAgICAgIGxldCByZXNwb25zZU1hbmFnZXJJbmZvO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHJlc3BvbnNlTWFuYWdlckluZm8gPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNJbnRlcm5hbFVzZXIucmVxdWVzdChcclxuICAgICAgICAgICdHRVQnLFxyXG4gICAgICAgICAgYC9tYW5hZ2VyL2luZm9gLFxyXG4gICAgICAgICAge30sXHJcbiAgICAgICAgICBvcHRpb25zXHJcbiAgICAgICAgKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcclxuICAgICAgICAgIGBFUlJPUjMwOTkgLSAke2Vycm9yLnJlc3BvbnNlPy5kYXRhPy5kZXRhaWwgfHwgJ1dhenVoIG5vdCByZWFkeSB5ZXQnfWAsXHJcbiAgICAgICAgICAzMDk5LFxyXG4gICAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuU0VSVklDRV9VTkFWQUlMQUJMRSxcclxuICAgICAgICAgIHJlc3BvbnNlXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgbG9nKCd3YXp1aC1hcGk6Y2hlY2tBUEknLCBgJHtyZXF1ZXN0LmJvZHkuaWR9IGNyZWRlbnRpYWxzIGFyZSB2YWxpZGAsICdkZWJ1ZycpO1xyXG4gICAgICBpZiAocmVzcG9uc2VNYW5hZ2VySW5mby5zdGF0dXMgPT09IEhUVFBfU1RBVFVTX0NPREVTLk9LICYmIHJlc3BvbnNlTWFuYWdlckluZm8uZGF0YSkge1xyXG4gICAgICAgIGxldCByZXNwb25zZUFnZW50cyA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KFxyXG4gICAgICAgICAgJ0dFVCcsXHJcbiAgICAgICAgICBgL2FnZW50c2AsXHJcbiAgICAgICAgICB7IHBhcmFtczogeyBhZ2VudHNfbGlzdDogJzAwMCcgfSB9LFxyXG4gICAgICAgICAgeyBhcGlIb3N0SUQ6IHJlcXVlc3QuYm9keS5pZCB9XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgaWYgKHJlc3BvbnNlQWdlbnRzLnN0YXR1cyA9PT0gSFRUUF9TVEFUVVNfQ09ERVMuT0spIHtcclxuICAgICAgICAgIGNvbnN0IG1hbmFnZXJOYW1lID0gcmVzcG9uc2VBZ2VudHMuZGF0YS5kYXRhLmFmZmVjdGVkX2l0ZW1zWzBdLm1hbmFnZXI7XHJcblxyXG4gICAgICAgICAgbGV0IHJlc3BvbnNlQ2x1c3RlciA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KFxyXG4gICAgICAgICAgICAnR0VUJyxcclxuICAgICAgICAgICAgYC9jbHVzdGVyL3N0YXR1c2AsXHJcbiAgICAgICAgICAgIHt9LFxyXG4gICAgICAgICAgICB7IGFwaUhvc3RJRDogcmVxdWVzdC5ib2R5LmlkIH1cclxuICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgLy8gQ2hlY2sgdGhlIHJ1bl9hcyBmb3IgdGhlIEFQSSB1c2VyIGFuZCB1cGRhdGUgaXRcclxuICAgICAgICAgIGxldCBhcGlVc2VyQWxsb3dSdW5BcyA9IEFQSV9VU0VSX1NUQVRVU19SVU5fQVMuQUxMX0RJU0FCTEVEO1xyXG4gICAgICAgICAgY29uc3QgcmVzcG9uc2VBcGlVc2VyQWxsb3dSdW5BcyA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KFxyXG4gICAgICAgICAgICAnR0VUJyxcclxuICAgICAgICAgICAgYC9zZWN1cml0eS91c2Vycy9tZWAsXHJcbiAgICAgICAgICAgIHt9LFxyXG4gICAgICAgICAgICB7IGFwaUhvc3RJRDogcmVxdWVzdC5ib2R5LmlkIH1cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBpZiAocmVzcG9uc2VBcGlVc2VyQWxsb3dSdW5Bcy5zdGF0dXMgPT09IEhUVFBfU1RBVFVTX0NPREVTLk9LKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGFsbG93X3J1bl9hcyA9IHJlc3BvbnNlQXBpVXNlckFsbG93UnVuQXMuZGF0YS5kYXRhLmFmZmVjdGVkX2l0ZW1zWzBdLmFsbG93X3J1bl9hcztcclxuXHJcbiAgICAgICAgICAgIGlmIChhbGxvd19ydW5fYXMgJiYgYXBpQXZhaWxhYmxlICYmIGFwaUF2YWlsYWJsZS5ydW5fYXMpXHJcbiAgICAgICAgICAgICAgLy8gSE9TVCBBTkQgVVNFUiBFTkFCTEVEXHJcbiAgICAgICAgICAgICAgYXBpVXNlckFsbG93UnVuQXMgPSBBUElfVVNFUl9TVEFUVVNfUlVOX0FTLkVOQUJMRUQ7XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKCFhbGxvd19ydW5fYXMgJiYgYXBpQXZhaWxhYmxlICYmIGFwaUF2YWlsYWJsZS5ydW5fYXMpXHJcbiAgICAgICAgICAgICAgLy8gSE9TVCBFTkFCTEVEIEFORCBVU0VSIERJU0FCTEVEXHJcbiAgICAgICAgICAgICAgYXBpVXNlckFsbG93UnVuQXMgPSBBUElfVVNFUl9TVEFUVVNfUlVOX0FTLlVTRVJfTk9UX0FMTE9XRUQ7XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKGFsbG93X3J1bl9hcyAmJiAoIWFwaUF2YWlsYWJsZSB8fCAhYXBpQXZhaWxhYmxlLnJ1bl9hcykpXHJcbiAgICAgICAgICAgICAgLy8gVVNFUiBFTkFCTEVEIEFORCBIT1NUIERJU0FCTEVEXHJcbiAgICAgICAgICAgICAgYXBpVXNlckFsbG93UnVuQXMgPSBBUElfVVNFUl9TVEFUVVNfUlVOX0FTLkhPU1RfRElTQUJMRUQ7XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKCFhbGxvd19ydW5fYXMgJiYgKCFhcGlBdmFpbGFibGUgfHwgIWFwaUF2YWlsYWJsZS5ydW5fYXMpKVxyXG4gICAgICAgICAgICAgIC8vIEhPU1QgQU5EIFVTRVIgRElTQUJMRURcclxuICAgICAgICAgICAgICBhcGlVc2VyQWxsb3dSdW5BcyA9IEFQSV9VU0VSX1NUQVRVU19SVU5fQVMuQUxMX0RJU0FCTEVEO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgQ2FjaGVJbk1lbW9yeUFQSVVzZXJBbGxvd1J1bkFzLnNldChcclxuICAgICAgICAgICAgcmVxdWVzdC5ib2R5LmlkLFxyXG4gICAgICAgICAgICBhcGlBdmFpbGFibGUudXNlcm5hbWUsXHJcbiAgICAgICAgICAgIGFwaVVzZXJBbGxvd1J1bkFzXHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgIGlmIChyZXNwb25zZUNsdXN0ZXIuc3RhdHVzID09PSBIVFRQX1NUQVRVU19DT0RFUy5PSykge1xyXG4gICAgICAgICAgICBsb2coJ3dhenVoLWFwaTpjaGVja1N0b3JlZEFQSScsIGBXYXp1aCBBUEkgcmVzcG9uc2UgaXMgdmFsaWRgLCAnZGVidWcnKTtcclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlQ2x1c3Rlci5kYXRhLmRhdGEuZW5hYmxlZCA9PT0gJ3llcycpIHtcclxuICAgICAgICAgICAgICAvLyBJZiBjbHVzdGVyIG1vZGUgaXMgYWN0aXZlXHJcbiAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlQ2x1c3RlckxvY2FsID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoXHJcbiAgICAgICAgICAgICAgICAnR0VUJyxcclxuICAgICAgICAgICAgICAgIGAvY2x1c3Rlci9sb2NhbC9pbmZvYCxcclxuICAgICAgICAgICAgICAgIHt9LFxyXG4gICAgICAgICAgICAgICAgeyBhcGlIb3N0SUQ6IHJlcXVlc3QuYm9keS5pZCB9XHJcbiAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlQ2x1c3RlckxvY2FsLnN0YXR1cyA9PT0gSFRUUF9TVEFUVVNfQ09ERVMuT0spIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgICAgICAgICAgIGJvZHk6IHtcclxuICAgICAgICAgICAgICAgICAgICBtYW5hZ2VyOiBtYW5hZ2VyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBub2RlOiByZXNwb25zZUNsdXN0ZXJMb2NhbC5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXNbMF0ubm9kZSxcclxuICAgICAgICAgICAgICAgICAgICBjbHVzdGVyOiByZXNwb25zZUNsdXN0ZXJMb2NhbC5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXNbMF0uY2x1c3RlcixcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6ICdlbmFibGVkJyxcclxuICAgICAgICAgICAgICAgICAgICBhbGxvd19ydW5fYXM6IGFwaVVzZXJBbGxvd1J1bkFzLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIC8vIENsdXN0ZXIgbW9kZSBpcyBub3QgYWN0aXZlXHJcbiAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICAgICAgICAgIGJvZHk6IHtcclxuICAgICAgICAgICAgICAgICAgbWFuYWdlcjogbWFuYWdlck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgIGNsdXN0ZXI6ICdEaXNhYmxlZCcsXHJcbiAgICAgICAgICAgICAgICAgIHN0YXR1czogJ2Rpc2FibGVkJyxcclxuICAgICAgICAgICAgICAgICAgYWxsb3dfcnVuX2FzOiBhcGlVc2VyQWxsb3dSdW5BcyxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGxvZygnd2F6dWgtYXBpOmNoZWNrQVBJJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcblxyXG4gICAgICBpZiAoZXJyb3IgJiYgZXJyb3IucmVzcG9uc2UgJiYgZXJyb3IucmVzcG9uc2Uuc3RhdHVzID09PSBIVFRQX1NUQVRVU19DT0RFUy5VTkFVVEhPUklaRUQpIHtcclxuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcclxuICAgICAgICAgIGBVbmF0aG9yaXplZC4gUGxlYXNlIGNoZWNrIEFQSSBjcmVkZW50aWFscy4gJHtlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2V9YCxcclxuICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLlVOQVVUSE9SSVpFRCxcclxuICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLlVOQVVUSE9SSVpFRCxcclxuICAgICAgICAgIHJlc3BvbnNlXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgICBpZiAoZXJyb3IgJiYgZXJyb3IucmVzcG9uc2UgJiYgZXJyb3IucmVzcG9uc2UuZGF0YSAmJiBlcnJvci5yZXNwb25zZS5kYXRhLmRldGFpbCkge1xyXG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxyXG4gICAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YS5kZXRhaWwsXHJcbiAgICAgICAgICBlcnJvci5yZXNwb25zZS5zdGF0dXMgfHwgSFRUUF9TVEFUVVNfQ09ERVMuU0VSVklDRV9VTkFWQUlMQUJMRSxcclxuICAgICAgICAgIGVycm9yLnJlc3BvbnNlLnN0YXR1cyB8fCBIVFRQX1NUQVRVU19DT0RFUy5TRVJWSUNFX1VOQVZBSUxBQkxFLFxyXG4gICAgICAgICAgcmVzcG9uc2VcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChlcnJvci5jb2RlID09PSAnRVBST1RPJykge1xyXG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxyXG4gICAgICAgICAgJ1dyb25nIHByb3RvY29sIGJlaW5nIHVzZWQgdG8gY29ubmVjdCB0byB0aGUgV2F6dWggQVBJJyxcclxuICAgICAgICAgIDMwMDUsXHJcbiAgICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5CQURfUkVRVUVTVCxcclxuICAgICAgICAgIHJlc3BvbnNlXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcclxuICAgICAgICBlcnJvci5tZXNzYWdlIHx8IGVycm9yLFxyXG4gICAgICAgIDMwMDUsXHJcbiAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLFxyXG4gICAgICAgIHJlc3BvbnNlXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjaGVja1Jlc3BvbnNlSXNEb3duKHJlc3BvbnNlKSB7XHJcbiAgICBpZiAocmVzcG9uc2Uuc3RhdHVzICE9PSBIVFRQX1NUQVRVU19DT0RFUy5PSykge1xyXG4gICAgICAvLyBBdm9pZCBcIkVycm9yIGNvbW11bmljYXRpbmcgd2l0aCBzb2NrZXRcIiBsaWtlIGVycm9yc1xyXG4gICAgICBjb25zdCBzb2NrZXRFcnJvckNvZGVzID0gWzEwMTMsIDEwMTQsIDEwMTcsIDEwMTgsIDEwMTldO1xyXG4gICAgICBjb25zdCBzdGF0dXMgPSAocmVzcG9uc2UuZGF0YSB8fCB7fSkuc3RhdHVzIHx8IDE7XHJcbiAgICAgIGNvbnN0IGlzRG93biA9IHNvY2tldEVycm9yQ29kZXMuaW5jbHVkZXMoc3RhdHVzKTtcclxuXHJcbiAgICAgIGlzRG93biAmJiBsb2coJ3dhenVoLWFwaTptYWtlUmVxdWVzdCcsICdXYXp1aCBBUEkgaXMgb25saW5lIGJ1dCBXYXp1aCBpcyBub3QgcmVhZHkgeWV0Jyk7XHJcblxyXG4gICAgICByZXR1cm4gaXNEb3duO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQ2hlY2sgbWFpbiBXYXp1aCBkYWVtb25zIHN0YXR1c1xyXG4gICAqIEBwYXJhbSB7Kn0gY29udGV4dCBFbmRwb2ludCBjb250ZXh0XHJcbiAgICogQHBhcmFtIHsqfSBhcGkgQVBJIGVudHJ5IHN0b3JlZCBpbiAud2F6dWhcclxuICAgKiBAcGFyYW0geyp9IHBhdGggT3B0aW9uYWwuIFdhenVoIEFQSSB0YXJnZXQgcGF0aC5cclxuICAgKi9cclxuICBhc3luYyBjaGVja0RhZW1vbnMoY29udGV4dCwgYXBpLCBwYXRoKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KFxyXG4gICAgICAgICdHRVQnLFxyXG4gICAgICAgICcvbWFuYWdlci9zdGF0dXMnLFxyXG4gICAgICAgIHt9LFxyXG4gICAgICAgIHsgYXBpSG9zdElEOiBhcGkuaWQgfVxyXG4gICAgICApO1xyXG5cclxuICAgICAgY29uc3QgZGFlbW9ucyA9ICgoKChyZXNwb25zZSB8fCB7fSkuZGF0YSB8fCB7fSkuZGF0YSB8fCB7fSkuYWZmZWN0ZWRfaXRlbXMgfHwgW10pWzBdIHx8IHt9O1xyXG5cclxuICAgICAgY29uc3QgaXNDbHVzdGVyID1cclxuICAgICAgICAoKGFwaSB8fCB7fSkuY2x1c3Rlcl9pbmZvIHx8IHt9KS5zdGF0dXMgPT09ICdlbmFibGVkJyAmJlxyXG4gICAgICAgIHR5cGVvZiBkYWVtb25zWyd3YXp1aC1jbHVzdGVyZCddICE9PSAndW5kZWZpbmVkJztcclxuICAgICAgY29uc3Qgd2F6dWhkYkV4aXN0cyA9IHR5cGVvZiBkYWVtb25zWyd3YXp1aC1kYiddICE9PSAndW5kZWZpbmVkJztcclxuXHJcbiAgICAgIGNvbnN0IGV4ZWNkID0gZGFlbW9uc1snd2F6dWgtZXhlY2QnXSA9PT0gJ3J1bm5pbmcnO1xyXG4gICAgICBjb25zdCBtb2R1bGVzZCA9IGRhZW1vbnNbJ3dhenVoLW1vZHVsZXNkJ10gPT09ICdydW5uaW5nJztcclxuICAgICAgY29uc3Qgd2F6dWhkYiA9IHdhenVoZGJFeGlzdHMgPyBkYWVtb25zWyd3YXp1aC1kYiddID09PSAncnVubmluZycgOiB0cnVlO1xyXG4gICAgICBjb25zdCBjbHVzdGVyZCA9IGlzQ2x1c3RlciA/IGRhZW1vbnNbJ3dhenVoLWNsdXN0ZXJkJ10gPT09ICdydW5uaW5nJyA6IHRydWU7XHJcblxyXG4gICAgICBjb25zdCBpc1ZhbGlkID0gZXhlY2QgJiYgbW9kdWxlc2QgJiYgd2F6dWhkYiAmJiBjbHVzdGVyZDtcclxuXHJcbiAgICAgIGlzVmFsaWQgJiYgbG9nKCd3YXp1aC1hcGk6Y2hlY2tEYWVtb25zJywgYFdhenVoIGlzIHJlYWR5YCwgJ2RlYnVnJyk7XHJcblxyXG4gICAgICBpZiAocGF0aCA9PT0gJy9waW5nJykge1xyXG4gICAgICAgIHJldHVybiB7IGlzVmFsaWQgfTtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKCFpc1ZhbGlkKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdXYXp1aCBub3QgcmVhZHkgeWV0Jyk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGxvZygnd2F6dWgtYXBpOmNoZWNrRGFlbW9ucycsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xyXG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc2xlZXAodGltZU1zKSB7XHJcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgIHNldFRpbWVvdXQocmVzb2x2ZSwgdGltZU1zKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogSGVscGVyIG1ldGhvZCBmb3IgRGV2IFRvb2xzLlxyXG4gICAqIGh0dHBzOi8vZG9jdW1lbnRhdGlvbi53YXp1aC5jb20vY3VycmVudC91c2VyLW1hbnVhbC9hcGkvcmVmZXJlbmNlLmh0bWxcclxuICAgKiBEZXBlbmRpbmcgb24gdGhlIG1ldGhvZCBhbmQgdGhlIHBhdGggc29tZSBwYXJhbWV0ZXJzIHNob3VsZCBiZSBhbiBhcnJheSBvciBub3QuXHJcbiAgICogU2luY2Ugd2UgYWxsb3cgdGhlIHVzZXIgdG8gd3JpdGUgdGhlIHJlcXVlc3QgdXNpbmcgYm90aCBjb21tYS1zZXBhcmF0ZWQgYW5kIGFycmF5IGFzIHdlbGwsXHJcbiAgICogd2UgbmVlZCB0byBjaGVjayBpZiBpdCBzaG91bGQgYmUgdHJhbnNmb3JtZWQgb3Igbm90LlxyXG4gICAqIEBwYXJhbSB7Kn0gbWV0aG9kIFRoZSByZXF1ZXN0IG1ldGhvZFxyXG4gICAqIEBwYXJhbSB7Kn0gcGF0aCBUaGUgV2F6dWggQVBJIHBhdGhcclxuICAgKi9cclxuICBzaG91bGRLZWVwQXJyYXlBc0l0KG1ldGhvZCwgcGF0aCkge1xyXG4gICAgLy8gTWV0aG9kcyB0aGF0IHdlIG11c3QgcmVzcGVjdCBhIGRvIG5vdCB0cmFuc2Zvcm0gdGhlbVxyXG4gICAgY29uc3QgaXNBZ2VudHNSZXN0YXJ0ID0gbWV0aG9kID09PSAnUE9TVCcgJiYgcGF0aCA9PT0gJy9hZ2VudHMvcmVzdGFydCc7XHJcbiAgICBjb25zdCBpc0FjdGl2ZVJlc3BvbnNlID0gbWV0aG9kID09PSAnUFVUJyAmJiBwYXRoLnN0YXJ0c1dpdGgoJy9hY3RpdmUtcmVzcG9uc2UnKTtcclxuICAgIGNvbnN0IGlzQWRkaW5nQWdlbnRzVG9Hcm91cCA9IG1ldGhvZCA9PT0gJ1BPU1QnICYmIHBhdGguc3RhcnRzV2l0aCgnL2FnZW50cy9ncm91cC8nKTtcclxuXHJcbiAgICAvLyBSZXR1cm5zIHRydWUgb25seSBpZiBvbmUgb2YgdGhlIGFib3ZlIGNvbmRpdGlvbnMgaXMgdHJ1ZVxyXG4gICAgcmV0dXJuIGlzQWdlbnRzUmVzdGFydCB8fCBpc0FjdGl2ZVJlc3BvbnNlIHx8IGlzQWRkaW5nQWdlbnRzVG9Hcm91cDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFRoaXMgcGVyZm9ybXMgYSByZXF1ZXN0IG92ZXIgV2F6dWggQVBJIGFuZCByZXR1cm5zIGl0cyByZXNwb25zZVxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtZXRob2QgTWV0aG9kOiBHRVQsIFBVVCwgUE9TVCwgREVMRVRFXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHBhdGggQVBJIHJvdXRlXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEgZGF0YSBhbmQgcGFyYW1zIHRvIHBlcmZvcm0gdGhlIHJlcXVlc3RcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gaWQgQVBJIGlkXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXHJcbiAgICogQHJldHVybnMge09iamVjdH0gQVBJIHJlc3BvbnNlIG9yIEVycm9yUmVzcG9uc2VcclxuICAgKi9cclxuICBhc3luYyBtYWtlUmVxdWVzdChjb250ZXh0LCBtZXRob2QsIHBhdGgsIGRhdGEsIGlkLCByZXNwb25zZSkge1xyXG5cclxuICAgIGNvbnN0IGRldlRvb2xzID0gISEoZGF0YSB8fCB7fSkuZGV2VG9vbHM7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBhcGkgPSBhd2FpdCB0aGlzLm1hbmFnZUhvc3RzLmdldEhvc3RCeUlkKGlkKTtcclxuICAgICAgaWYgKGRldlRvb2xzKSB7XHJcbiAgICAgICAgZGVsZXRlIGRhdGEuZGV2VG9vbHM7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICghT2JqZWN0LmtleXMoYXBpKS5sZW5ndGgpIHtcclxuICAgICAgICBsb2coJ3dhenVoLWFwaTptYWtlUmVxdWVzdCcsICdDb3VsZCBub3QgZ2V0IGhvc3QgY3JlZGVudGlhbHMnKTtcclxuICAgICAgICAvL0NhbiBub3QgZ2V0IGNyZWRlbnRpYWxzIGZyb20gd2F6dWgtaG9zdHNcclxuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcclxuICAgICAgICAgICdDb3VsZCBub3QgZ2V0IGhvc3QgY3JlZGVudGlhbHMnLFxyXG4gICAgICAgICAgMzAxMSxcclxuICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLk5PVF9GT1VORCxcclxuICAgICAgICAgIHJlc3BvbnNlXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKCFkYXRhKSB7XHJcbiAgICAgICAgZGF0YSA9IHt9O1xyXG4gICAgICB9O1xyXG5cclxuICAgICAgaWYgKCFkYXRhLmhlYWRlcnMpIHtcclxuICAgICAgICBkYXRhLmhlYWRlcnMgPSB7fTtcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IG9wdGlvbnMgPSB7XHJcbiAgICAgICAgYXBpSG9zdElEOiBpZFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgLy8gU2V0IGNvbnRlbnQgdHlwZSBhcHBsaWNhdGlvbi94bWwgaWYgbmVlZGVkXHJcbiAgICAgIGlmICh0eXBlb2YgKGRhdGEgfHwge30pLmJvZHkgPT09ICdzdHJpbmcnICYmIChkYXRhIHx8IHt9KS5vcmlnaW4gPT09ICd4bWxlZGl0b3InKSB7XHJcbiAgICAgICAgZGF0YS5oZWFkZXJzWydjb250ZW50LXR5cGUnXSA9ICdhcHBsaWNhdGlvbi94bWwnO1xyXG4gICAgICAgIGRlbGV0ZSBkYXRhLm9yaWdpbjtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKHR5cGVvZiAoZGF0YSB8fCB7fSkuYm9keSA9PT0gJ3N0cmluZycgJiYgKGRhdGEgfHwge30pLm9yaWdpbiA9PT0gJ2pzb24nKSB7XHJcbiAgICAgICAgZGF0YS5oZWFkZXJzWydjb250ZW50LXR5cGUnXSA9ICdhcHBsaWNhdGlvbi9qc29uJztcclxuICAgICAgICBkZWxldGUgZGF0YS5vcmlnaW47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICh0eXBlb2YgKGRhdGEgfHwge30pLmJvZHkgPT09ICdzdHJpbmcnICYmIChkYXRhIHx8IHt9KS5vcmlnaW4gPT09ICdyYXcnKSB7XHJcbiAgICAgICAgZGF0YS5oZWFkZXJzWydjb250ZW50LXR5cGUnXSA9ICdhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW0nO1xyXG4gICAgICAgIGRlbGV0ZSBkYXRhLm9yaWdpbjtcclxuICAgICAgfVxyXG4gICAgICBjb25zdCBkZWxheSA9IChkYXRhIHx8IHt9KS5kZWxheSB8fCAwO1xyXG4gICAgICBpZiAoZGVsYXkpIHtcclxuICAgICAgICBhZGRKb2JUb1F1ZXVlKHtcclxuICAgICAgICAgIHN0YXJ0QXQ6IG5ldyBEYXRlKERhdGUubm93KCkgKyBkZWxheSksXHJcbiAgICAgICAgICBydW46IGFzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgdHJ5e1xyXG4gICAgICAgICAgICAgIGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QobWV0aG9kLCBwYXRoLCBkYXRhLCBvcHRpb25zKTtcclxuICAgICAgICAgICAgfWNhdGNoKGVycm9yKXtcclxuICAgICAgICAgICAgICBsb2coJ3F1ZXVlOmRlbGF5QXBpUmVxdWVzdCcsYEFuIGVycm9yIG9jdXJyZWQgaW4gdGhlIGRlbGF5ZWQgcmVxdWVzdDogXCIke21ldGhvZH0gJHtwYXRofVwiOiAke2Vycm9yLm1lc3NhZ2UgfHwgZXJyb3J9YCk7XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICAgIGJvZHk6IHsgZXJyb3I6IDAsIG1lc3NhZ2U6ICdTdWNjZXNzJyB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChwYXRoID09PSAnL3BpbmcnKSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGNvbnN0IGNoZWNrID0gYXdhaXQgdGhpcy5jaGVja0RhZW1vbnMoY29udGV4dCwgYXBpLCBwYXRoKTtcclxuICAgICAgICAgIHJldHVybiBjaGVjaztcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgY29uc3QgaXNEb3duID0gKGVycm9yIHx8IHt9KS5jb2RlID09PSAnRUNPTk5SRUZVU0VEJztcclxuICAgICAgICAgIGlmICghaXNEb3duKSB7XHJcbiAgICAgICAgICAgIGxvZygnd2F6dWgtYXBpOm1ha2VSZXF1ZXN0JywgJ1dhenVoIEFQSSBpcyBvbmxpbmUgYnV0IFdhenVoIGlzIG5vdCByZWFkeSB5ZXQnKTtcclxuICAgICAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXHJcbiAgICAgICAgICAgICAgYEVSUk9SMzA5OSAtICR7ZXJyb3IubWVzc2FnZSB8fCAnV2F6dWggbm90IHJlYWR5IHlldCd9YCxcclxuICAgICAgICAgICAgICAzMDk5LFxyXG4gICAgICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcclxuICAgICAgICAgICAgICByZXNwb25zZVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgbG9nKCd3YXp1aC1hcGk6bWFrZVJlcXVlc3QnLCBgJHttZXRob2R9ICR7cGF0aH1gLCAnZGVidWcnKTtcclxuXHJcbiAgICAgIC8vIEV4dHJhY3Qga2V5cyBmcm9tIHBhcmFtZXRlcnNcclxuICAgICAgY29uc3QgZGF0YVByb3BlcnRpZXMgPSBPYmplY3Qua2V5cyhkYXRhKTtcclxuXHJcbiAgICAgIC8vIFRyYW5zZm9ybSBhcnJheXMgaW50byBjb21tYS1zZXBhcmF0ZWQgc3RyaW5nIGlmIGFwcGxpY2FibGUuXHJcbiAgICAgIC8vIFRoZSByZWFzb24gaXMgdGhhdCB3ZSBhcmUgYWNjZXB0aW5nIGFycmF5cyBmb3IgY29tbWEtc2VwYXJhdGVkXHJcbiAgICAgIC8vIHBhcmFtZXRlcnMgaW4gdGhlIERldiBUb29sc1xyXG4gICAgICBpZiAoIXRoaXMuc2hvdWxkS2VlcEFycmF5QXNJdChtZXRob2QsIHBhdGgpKSB7XHJcbiAgICAgICAgZm9yIChjb25zdCBrZXkgb2YgZGF0YVByb3BlcnRpZXMpIHtcclxuICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGRhdGFba2V5XSkpIHtcclxuICAgICAgICAgICAgZGF0YVtrZXldID0gZGF0YVtrZXldLmpvaW4oKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlVG9rZW4gPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KG1ldGhvZCwgcGF0aCwgZGF0YSwgb3B0aW9ucyk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlSXNEb3duID0gdGhpcy5jaGVja1Jlc3BvbnNlSXNEb3duKHJlc3BvbnNlVG9rZW4pO1xyXG4gICAgICBpZiAocmVzcG9uc2VJc0Rvd24pIHtcclxuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcclxuICAgICAgICAgIGBFUlJPUjMwOTkgLSAke3Jlc3BvbnNlLmJvZHkubWVzc2FnZSB8fCAnV2F6dWggbm90IHJlYWR5IHlldCd9YCxcclxuICAgICAgICAgIDMwOTksXHJcbiAgICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5JTlRFUk5BTF9TRVJWRVJfRVJST1IsXHJcbiAgICAgICAgICByZXNwb25zZVxyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuICAgICAgbGV0IHJlc3BvbnNlQm9keSA9IChyZXNwb25zZVRva2VuIHx8IHt9KS5kYXRhIHx8IHt9O1xyXG4gICAgICBpZiAoIXJlc3BvbnNlQm9keSkge1xyXG4gICAgICAgIHJlc3BvbnNlQm9keSA9XHJcbiAgICAgICAgICB0eXBlb2YgcmVzcG9uc2VCb2R5ID09PSAnc3RyaW5nJyAmJiBwYXRoLmluY2x1ZGVzKCcvZmlsZXMnKSAmJiBtZXRob2QgPT09ICdHRVQnXHJcbiAgICAgICAgICAgID8gJyAnXHJcbiAgICAgICAgICAgIDogZmFsc2U7XHJcbiAgICAgICAgcmVzcG9uc2UuZGF0YSA9IHJlc3BvbnNlQm9keTtcclxuICAgICAgfVxyXG4gICAgICBjb25zdCByZXNwb25zZUVycm9yID0gcmVzcG9uc2Uuc3RhdHVzICE9PSBIVFRQX1NUQVRVU19DT0RFUy5PSyA/IHJlc3BvbnNlLnN0YXR1cyA6IGZhbHNlO1xyXG5cclxuICAgICAgaWYgKCFyZXNwb25zZUVycm9yICYmIHJlc3BvbnNlQm9keSkge1xyXG4gICAgICAgIC8vY2xlYW5LZXlzKHJlc3BvbnNlKTtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgICAgYm9keTogcmVzcG9uc2VUb2tlbi5kYXRhXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChyZXNwb25zZUVycm9yICYmIGRldlRvb2xzKSB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICAgIGJvZHk6IHJlc3BvbnNlLmRhdGFcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgICB0aHJvdyByZXNwb25zZUVycm9yICYmIHJlc3BvbnNlQm9keS5kZXRhaWxcclxuICAgICAgICA/IHsgbWVzc2FnZTogcmVzcG9uc2VCb2R5LmRldGFpbCwgY29kZTogcmVzcG9uc2VFcnJvciB9XHJcbiAgICAgICAgOiBuZXcgRXJyb3IoJ1VuZXhwZWN0ZWQgZXJyb3IgZmV0Y2hpbmcgZGF0YSBmcm9tIHRoZSBXYXp1aCBBUEknKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGlmIChlcnJvciAmJiBlcnJvci5yZXNwb25zZSAmJiBlcnJvci5yZXNwb25zZS5zdGF0dXMgPT09IEhUVFBfU1RBVFVTX0NPREVTLlVOQVVUSE9SSVpFRCkge1xyXG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxyXG4gICAgICAgICAgZXJyb3IubWVzc2FnZSB8fCBlcnJvcixcclxuICAgICAgICAgIGVycm9yLmNvZGUgPyBgV2F6dWggQVBJIGVycm9yOiAke2Vycm9yLmNvZGV9YCA6IDMwMTMsXHJcbiAgICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5VTkFVVEhPUklaRUQsXHJcbiAgICAgICAgICByZXNwb25zZVxyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgZXJyb3JNc2cgPSAoZXJyb3IucmVzcG9uc2UgfHwge30pLmRhdGEgfHwgZXJyb3IubWVzc2FnZVxyXG4gICAgICBsb2coJ3dhenVoLWFwaTptYWtlUmVxdWVzdCcsIGVycm9yTXNnIHx8IGVycm9yKTtcclxuICAgICAgaWYgKGRldlRvb2xzKSB7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICAgIGJvZHk6IHsgZXJyb3I6ICczMDEzJywgbWVzc2FnZTogZXJyb3JNc2cgfHwgZXJyb3IgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGlmICgoZXJyb3IgfHwge30pLmNvZGUgJiYgQXBpRXJyb3JFcXVpdmFsZW5jZVtlcnJvci5jb2RlXSkge1xyXG4gICAgICAgICAgZXJyb3IubWVzc2FnZSA9IEFwaUVycm9yRXF1aXZhbGVuY2VbZXJyb3IuY29kZV07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxyXG4gICAgICAgICAgZXJyb3JNc2cuZGV0YWlsIHx8IGVycm9yLFxyXG4gICAgICAgICAgZXJyb3IuY29kZSA/IGBXYXp1aCBBUEkgZXJyb3I6ICR7ZXJyb3IuY29kZX1gIDogMzAxMyxcclxuICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcclxuICAgICAgICAgIHJlc3BvbnNlXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogVGhpcyBtYWtlIGEgcmVxdWVzdCB0byBBUElcclxuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXHJcbiAgICogQHJldHVybnMge09iamVjdH0gYXBpIHJlc3BvbnNlIG9yIEVycm9yUmVzcG9uc2VcclxuICAgKi9cclxuICByZXF1ZXN0QXBpKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnkpIHtcclxuXHJcbiAgICBjb25zdCBpZEFwaSA9IGdldENvb2tpZVZhbHVlQnlOYW1lKHJlcXVlc3QuaGVhZGVycy5jb29raWUsICd3ei1hcGknKTtcclxuICAgIGlmIChpZEFwaSAhPT0gcmVxdWVzdC5ib2R5LmlkKSB7IC8vIGlmIHRoZSBjdXJyZW50IHRva2VuIGJlbG9uZ3MgdG8gYSBkaWZmZXJlbnQgQVBJIGlkLCB3ZSByZWxvZ2luIHRvIG9idGFpbiBhIG5ldyB0b2tlblxyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcclxuICAgICAgICBgc3RhdHVzIGNvZGUgNDAxYCxcclxuICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5VTkFVVEhPUklaRUQsXHJcbiAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuVU5BVVRIT1JJWkVELFxyXG4gICAgICAgIHJlc3BvbnNlXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgICBpZiAoIXJlcXVlc3QuYm9keS5tZXRob2QpIHtcclxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoJ01pc3NpbmcgcGFyYW06IG1ldGhvZCcsIDMwMTUsIEhUVFBfU1RBVFVTX0NPREVTLkJBRF9SRVFVRVNULCByZXNwb25zZSk7XHJcbiAgICB9IGVsc2UgaWYgKCFyZXF1ZXN0LmJvZHkubWV0aG9kLm1hdGNoKC9eKD86R0VUfFBVVHxQT1NUfERFTEVURSkkLykpIHtcclxuICAgICAgbG9nKCd3YXp1aC1hcGk6bWFrZVJlcXVlc3QnLCAnUmVxdWVzdCBtZXRob2QgaXMgbm90IHZhbGlkLicpO1xyXG4gICAgICAvL01ldGhvZCBpcyBub3QgYSB2YWxpZCBIVFRQIHJlcXVlc3QgbWV0aG9kXHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdSZXF1ZXN0IG1ldGhvZCBpcyBub3QgdmFsaWQuJywgMzAxNSwgSFRUUF9TVEFUVVNfQ09ERVMuQkFEX1JFUVVFU1QsIHJlc3BvbnNlKTtcclxuICAgIH0gZWxzZSBpZiAoIXJlcXVlc3QuYm9keS5wYXRoKSB7XHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdNaXNzaW5nIHBhcmFtOiBwYXRoJywgMzAxNiwgSFRUUF9TVEFUVVNfQ09ERVMuQkFEX1JFUVVFU1QsIHJlc3BvbnNlKTtcclxuICAgIH0gZWxzZSBpZiAoIXJlcXVlc3QuYm9keS5wYXRoLnN0YXJ0c1dpdGgoJy8nKSkge1xyXG4gICAgICBsb2coJ3dhenVoLWFwaTptYWtlUmVxdWVzdCcsICdSZXF1ZXN0IHBhdGggaXMgbm90IHZhbGlkLicpO1xyXG4gICAgICAvL1BhdGggZG9lc24ndCBzdGFydCB3aXRoICcvJ1xyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZSgnUmVxdWVzdCBwYXRoIGlzIG5vdCB2YWxpZC4nLCAzMDE1LCBIVFRQX1NUQVRVU19DT0RFUy5CQURfUkVRVUVTVCwgcmVzcG9uc2UpO1xyXG4gICAgfSBlbHNlIHtcclxuXHJcbiAgICAgIHJldHVybiB0aGlzLm1ha2VSZXF1ZXN0KFxyXG4gICAgICAgIGNvbnRleHQsXHJcbiAgICAgICAgcmVxdWVzdC5ib2R5Lm1ldGhvZCxcclxuICAgICAgICByZXF1ZXN0LmJvZHkucGF0aCxcclxuICAgICAgICByZXF1ZXN0LmJvZHkuYm9keSxcclxuICAgICAgICByZXF1ZXN0LmJvZHkuaWQsXHJcbiAgICAgICAgcmVzcG9uc2VcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEdldCBmdWxsIGRhdGEgb24gQ1NWIGZvcm1hdCBmcm9tIGEgbGlzdCBXYXp1aCBBUEkgZW5kcG9pbnRcclxuICAgKiBAcGFyYW0ge09iamVjdH0gY3R4XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcclxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSBjc3Ygb3IgRXJyb3JSZXNwb25zZVxyXG4gICAqL1xyXG4gIGFzeW5jIGNzdihjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCwgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5KSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoIXJlcXVlc3QuYm9keSB8fCAhcmVxdWVzdC5ib2R5LnBhdGgpIHRocm93IG5ldyBFcnJvcignRmllbGQgcGF0aCBpcyByZXF1aXJlZCcpO1xyXG4gICAgICBpZiAoIXJlcXVlc3QuYm9keS5pZCkgdGhyb3cgbmV3IEVycm9yKCdGaWVsZCBpZCBpcyByZXF1aXJlZCcpO1xyXG5cclxuICAgICAgY29uc3QgZmlsdGVycyA9IEFycmF5LmlzQXJyYXkoKChyZXF1ZXN0IHx8IHt9KS5ib2R5IHx8IHt9KS5maWx0ZXJzKSA/IHJlcXVlc3QuYm9keS5maWx0ZXJzIDogW107XHJcblxyXG4gICAgICBsZXQgdG1wUGF0aCA9IHJlcXVlc3QuYm9keS5wYXRoO1xyXG5cclxuICAgICAgaWYgKHRtcFBhdGggJiYgdHlwZW9mIHRtcFBhdGggPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgICAgdG1wUGF0aCA9IHRtcFBhdGhbMF0gPT09ICcvJyA/IHRtcFBhdGguc3Vic3RyKDEpIDogdG1wUGF0aDtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKCF0bXBQYXRoKSB0aHJvdyBuZXcgRXJyb3IoJ0FuIGVycm9yIG9jY3VycmVkIHBhcnNpbmcgcGF0aCBmaWVsZCcpO1xyXG5cclxuICAgICAgbG9nKCd3YXp1aC1hcGk6Y3N2JywgYFJlcG9ydCAke3RtcFBhdGh9YCwgJ2RlYnVnJyk7XHJcbiAgICAgIC8vIFJlYWwgbGltaXQsIHJlZ2FyZGxlc3MgdGhlIHVzZXIgcXVlcnlcclxuICAgICAgY29uc3QgcGFyYW1zID0geyBsaW1pdDogNTAwIH07XHJcblxyXG4gICAgICBpZiAoZmlsdGVycy5sZW5ndGgpIHtcclxuICAgICAgICBmb3IgKGNvbnN0IGZpbHRlciBvZiBmaWx0ZXJzKSB7XHJcbiAgICAgICAgICBpZiAoIWZpbHRlci5uYW1lIHx8ICFmaWx0ZXIudmFsdWUpIGNvbnRpbnVlO1xyXG4gICAgICAgICAgcGFyYW1zW2ZpbHRlci5uYW1lXSA9IGZpbHRlci52YWx1ZTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGxldCBpdGVtc0FycmF5ID0gW107XHJcblxyXG4gICAgICBjb25zdCBvdXRwdXQgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxyXG4gICAgICAgICdHRVQnLFxyXG4gICAgICAgIGAvJHt0bXBQYXRofWAsXHJcbiAgICAgICAgeyBwYXJhbXM6IHBhcmFtcyB9LFxyXG4gICAgICAgIHsgYXBpSG9zdElEOiByZXF1ZXN0LmJvZHkuaWQgfVxyXG4gICAgICApO1xyXG5cclxuICAgICAgY29uc3QgaXNMaXN0ID0gcmVxdWVzdC5ib2R5LnBhdGguaW5jbHVkZXMoJy9saXN0cycpICYmIHJlcXVlc3QuYm9keS5maWx0ZXJzICYmIHJlcXVlc3QuYm9keS5maWx0ZXJzLmxlbmd0aCAmJiByZXF1ZXN0LmJvZHkuZmlsdGVycy5maW5kKGZpbHRlciA9PiBmaWx0ZXIuX2lzQ0RCTGlzdCk7XHJcblxyXG4gICAgICBjb25zdCB0b3RhbEl0ZW1zID0gKCgob3V0cHV0IHx8IHt9KS5kYXRhIHx8IHt9KS5kYXRhIHx8IHt9KS50b3RhbF9hZmZlY3RlZF9pdGVtcztcclxuXHJcbiAgICAgIGlmICh0b3RhbEl0ZW1zICYmICFpc0xpc3QpIHtcclxuICAgICAgICBwYXJhbXMub2Zmc2V0ID0gMDtcclxuICAgICAgICBpdGVtc0FycmF5LnB1c2goLi4ub3V0cHV0LmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtcyk7XHJcbiAgICAgICAgd2hpbGUgKGl0ZW1zQXJyYXkubGVuZ3RoIDwgdG90YWxJdGVtcyAmJiBwYXJhbXMub2Zmc2V0IDwgdG90YWxJdGVtcykge1xyXG4gICAgICAgICAgcGFyYW1zLm9mZnNldCArPSBwYXJhbXMubGltaXQ7XHJcbiAgICAgICAgICBjb25zdCB0bXBEYXRhID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdChcclxuICAgICAgICAgICAgJ0dFVCcsXHJcbiAgICAgICAgICAgIGAvJHt0bXBQYXRofWAsXHJcbiAgICAgICAgICAgIHsgcGFyYW1zOiBwYXJhbXMgfSxcclxuICAgICAgICAgICAgeyBhcGlIb3N0SUQ6IHJlcXVlc3QuYm9keS5pZCB9XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgaXRlbXNBcnJheS5wdXNoKC4uLnRtcERhdGEuZGF0YS5kYXRhLmFmZmVjdGVkX2l0ZW1zKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICh0b3RhbEl0ZW1zKSB7XHJcbiAgICAgICAgY29uc3QgeyBwYXRoLCBmaWx0ZXJzIH0gPSByZXF1ZXN0LmJvZHk7XHJcbiAgICAgICAgY29uc3QgaXNBcnJheU9mTGlzdHMgPVxyXG4gICAgICAgICAgcGF0aC5pbmNsdWRlcygnL2xpc3RzJykgJiYgIWlzTGlzdDtcclxuICAgICAgICBjb25zdCBpc0FnZW50cyA9IHBhdGguaW5jbHVkZXMoJy9hZ2VudHMnKSAmJiAhcGF0aC5pbmNsdWRlcygnZ3JvdXBzJyk7XHJcbiAgICAgICAgY29uc3QgaXNBZ2VudHNPZkdyb3VwID0gcGF0aC5zdGFydHNXaXRoKCcvYWdlbnRzL2dyb3Vwcy8nKTtcclxuICAgICAgICBjb25zdCBpc0ZpbGVzID0gcGF0aC5lbmRzV2l0aCgnL2ZpbGVzJyk7XHJcbiAgICAgICAgbGV0IGZpZWxkcyA9IE9iamVjdC5rZXlzKG91dHB1dC5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXNbMF0pO1xyXG5cclxuICAgICAgICBpZiAoaXNBZ2VudHMgfHwgaXNBZ2VudHNPZkdyb3VwKSB7XHJcbiAgICAgICAgICBpZiAoaXNGaWxlcykge1xyXG4gICAgICAgICAgICBmaWVsZHMgPSBbJ2ZpbGVuYW1lJywgJ2hhc2gnXTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGZpZWxkcyA9IFtcclxuICAgICAgICAgICAgICAnaWQnLFxyXG4gICAgICAgICAgICAgICdzdGF0dXMnLFxyXG4gICAgICAgICAgICAgICduYW1lJyxcclxuICAgICAgICAgICAgICAnaXAnLFxyXG4gICAgICAgICAgICAgICdncm91cCcsXHJcbiAgICAgICAgICAgICAgJ21hbmFnZXInLFxyXG4gICAgICAgICAgICAgICdub2RlX25hbWUnLFxyXG4gICAgICAgICAgICAgICdkYXRlQWRkJyxcclxuICAgICAgICAgICAgICAndmVyc2lvbicsXHJcbiAgICAgICAgICAgICAgJ2xhc3RLZWVwQWxpdmUnLFxyXG4gICAgICAgICAgICAgICdvcy5hcmNoJyxcclxuICAgICAgICAgICAgICAnb3MuYnVpbGQnLFxyXG4gICAgICAgICAgICAgICdvcy5jb2RlbmFtZScsXHJcbiAgICAgICAgICAgICAgJ29zLm1ham9yJyxcclxuICAgICAgICAgICAgICAnb3MubWlub3InLFxyXG4gICAgICAgICAgICAgICdvcy5uYW1lJyxcclxuICAgICAgICAgICAgICAnb3MucGxhdGZvcm0nLFxyXG4gICAgICAgICAgICAgICdvcy51bmFtZScsXHJcbiAgICAgICAgICAgICAgJ29zLnZlcnNpb24nLFxyXG4gICAgICAgICAgICBdO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKGlzQXJyYXlPZkxpc3RzKSB7XHJcbiAgICAgICAgICBjb25zdCBmbGF0TGlzdHMgPSBbXTtcclxuICAgICAgICAgIGZvciAoY29uc3QgbGlzdCBvZiBpdGVtc0FycmF5KSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHsgcmVsYXRpdmVfZGlybmFtZSwgaXRlbXMgfSA9IGxpc3Q7XHJcbiAgICAgICAgICAgIGZsYXRMaXN0cy5wdXNoKC4uLml0ZW1zLm1hcChpdGVtID0+ICh7IHJlbGF0aXZlX2Rpcm5hbWUsIGtleTogaXRlbS5rZXksIHZhbHVlOiBpdGVtLnZhbHVlIH0pKSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBmaWVsZHMgPSBbJ3JlbGF0aXZlX2Rpcm5hbWUnLCAna2V5JywgJ3ZhbHVlJ107XHJcbiAgICAgICAgICBpdGVtc0FycmF5ID0gWy4uLmZsYXRMaXN0c107XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoaXNMaXN0KSB7XHJcbiAgICAgICAgICBmaWVsZHMgPSBbJ2tleScsICd2YWx1ZSddO1xyXG4gICAgICAgICAgaXRlbXNBcnJheSA9IG91dHB1dC5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXNbMF0uaXRlbXM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZpZWxkcyA9IGZpZWxkcy5tYXAoaXRlbSA9PiAoeyB2YWx1ZTogaXRlbSwgZGVmYXVsdDogJy0nIH0pKTtcclxuXHJcbiAgICAgICAgY29uc3QganNvbjJjc3ZQYXJzZXIgPSBuZXcgUGFyc2VyKHsgZmllbGRzIH0pO1xyXG5cclxuICAgICAgICBsZXQgY3N2ID0ganNvbjJjc3ZQYXJzZXIucGFyc2UoaXRlbXNBcnJheSk7XHJcbiAgICAgICAgZm9yIChjb25zdCBmaWVsZCBvZiBmaWVsZHMpIHtcclxuICAgICAgICAgIGNvbnN0IHsgdmFsdWUgfSA9IGZpZWxkO1xyXG4gICAgICAgICAgaWYgKGNzdi5pbmNsdWRlcyh2YWx1ZSkpIHtcclxuICAgICAgICAgICAgY3N2ID0gY3N2LnJlcGxhY2UodmFsdWUsIEtleUVxdWl2YWxlbmNlW3ZhbHVlXSB8fCB2YWx1ZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ3RleHQvY3N2JyB9LFxyXG4gICAgICAgICAgYm9keTogY3N2XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSBpZiAob3V0cHV0ICYmIG91dHB1dC5kYXRhICYmIG91dHB1dC5kYXRhLmRhdGEgJiYgIW91dHB1dC5kYXRhLmRhdGEudG90YWxfYWZmZWN0ZWRfaXRlbXMpIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIHJlc3VsdHMnKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEFuIGVycm9yIG9jY3VycmVkIGZldGNoaW5nIGRhdGEgZnJvbSB0aGUgV2F6dWggQVBJJHtvdXRwdXQgJiYgb3V0cHV0LmRhdGEgJiYgb3V0cHV0LmRhdGEuZGV0YWlsID8gYDogJHtvdXRwdXQuYm9keS5kZXRhaWx9YCA6ICcnfWApO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3dhenVoLWFwaTpjc3YnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXHJcbiAgICAgICAgZXJyb3IubWVzc2FnZSB8fCBlcnJvcixcclxuICAgICAgICAzMDM0LFxyXG4gICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcclxuICAgICAgICByZXNwb25zZVxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gR2V0IGRlIGxpc3Qgb2YgYXZhaWxhYmxlIHJlcXVlc3RzIGluIHRoZSBBUElcclxuICBnZXRSZXF1ZXN0TGlzdChjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCwgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5KSB7XHJcbiAgICAvL1JlYWQgYSBzdGF0aWMgSlNPTiB1bnRpbCB0aGUgYXBpIGNhbGwgaGFzIGltcGxlbWVudGVkXHJcbiAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICBib2R5OiBhcGlSZXF1ZXN0TGlzdFxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBUaGlzIGdldCB0aGUgdGltZXN0YW1wIGZpZWxkXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxyXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IHRpbWVzdGFtcCBmaWVsZCBvciBFcnJvclJlc3BvbnNlXHJcbiAgICovXHJcbiAgZ2V0VGltZVN0YW1wKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnkpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHNvdXJjZSA9IEpTT04ucGFyc2UoZnMucmVhZEZpbGVTeW5jKHRoaXMudXBkYXRlUmVnaXN0cnkuZmlsZSwgJ3V0ZjgnKSk7XHJcbiAgICAgIGlmIChzb3VyY2UuaW5zdGFsbGF0aW9uRGF0ZSAmJiBzb3VyY2UubGFzdFJlc3RhcnQpIHtcclxuICAgICAgICBsb2coXHJcbiAgICAgICAgICAnd2F6dWgtYXBpOmdldFRpbWVTdGFtcCcsXHJcbiAgICAgICAgICBgSW5zdGFsbGF0aW9uIGRhdGU6ICR7c291cmNlLmluc3RhbGxhdGlvbkRhdGV9LiBMYXN0IHJlc3RhcnQ6ICR7c291cmNlLmxhc3RSZXN0YXJ0fWAsXHJcbiAgICAgICAgICAnZGVidWcnXHJcbiAgICAgICAgKTtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgICAgYm9keToge1xyXG4gICAgICAgICAgICBpbnN0YWxsYXRpb25EYXRlOiBzb3VyY2UuaW5zdGFsbGF0aW9uRGF0ZSxcclxuICAgICAgICAgICAgbGFzdFJlc3RhcnQ6IHNvdXJjZS5sYXN0UmVzdGFydCxcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0NvdWxkIG5vdCBmZXRjaCB3YXp1aC12ZXJzaW9uIHJlZ2lzdHJ5Jyk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGxvZygnd2F6dWgtYXBpOmdldFRpbWVTdGFtcCcsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcclxuICAgICAgICBlcnJvci5tZXNzYWdlIHx8ICdDb3VsZCBub3QgZmV0Y2ggd2F6dWgtdmVyc2lvbiByZWdpc3RyeScsXHJcbiAgICAgICAgNDAwMSxcclxuICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5JTlRFUk5BTF9TRVJWRVJfRVJST1IsXHJcbiAgICAgICAgcmVzcG9uc2VcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFRoaXMgZ2V0IHRoZSBleHRlbnNpb25zXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxyXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IGV4dGVuc2lvbnMgb2JqZWN0IG9yIEVycm9yUmVzcG9uc2VcclxuICAgKi9cclxuICBhc3luYyBzZXRFeHRlbnNpb25zKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnkpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHsgaWQsIGV4dGVuc2lvbnMgfSA9IHJlcXVlc3QuYm9keTtcclxuICAgICAgLy8gVXBkYXRlIGNsdXN0ZXIgaW5mb3JtYXRpb24gaW4gdGhlIHdhenVoLXJlZ2lzdHJ5Lmpzb25cclxuICAgICAgYXdhaXQgdGhpcy51cGRhdGVSZWdpc3RyeS51cGRhdGVBUElFeHRlbnNpb25zKGlkLCBleHRlbnNpb25zKTtcclxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICBzdGF0dXNDb2RlOiBIVFRQX1NUQVRVU19DT0RFUy5PSyxcclxuICAgICAgICB9LFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGxvZygnd2F6dWgtYXBpOnNldEV4dGVuc2lvbnMnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXHJcbiAgICAgICAgZXJyb3IubWVzc2FnZSB8fCAnQ291bGQgbm90IHNldCBleHRlbnNpb25zJyxcclxuICAgICAgICA0MDAxLFxyXG4gICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcclxuICAgICAgICByZXNwb25zZVxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogVGhpcyBnZXQgdGhlIGV4dGVuc2lvbnNcclxuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXHJcbiAgICogQHJldHVybnMge09iamVjdH0gZXh0ZW5zaW9ucyBvYmplY3Qgb3IgRXJyb3JSZXNwb25zZVxyXG4gICAqL1xyXG4gIGdldEV4dGVuc2lvbnMoY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3Qgc291cmNlID0gSlNPTi5wYXJzZShcclxuICAgICAgICBmcy5yZWFkRmlsZVN5bmModGhpcy51cGRhdGVSZWdpc3RyeS5maWxlLCAndXRmOCcpXHJcbiAgICAgICk7XHJcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgYm9keToge1xyXG4gICAgICAgICAgZXh0ZW5zaW9uczogKHNvdXJjZS5ob3N0c1tyZXF1ZXN0LnBhcmFtcy5pZF0gfHwge30pLmV4dGVuc2lvbnMgfHwge31cclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgbG9nKCd3YXp1aC1hcGk6Z2V0RXh0ZW5zaW9ucycsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcclxuICAgICAgICBlcnJvci5tZXNzYWdlIHx8ICdDb3VsZCBub3QgZmV0Y2ggd2F6dWgtdmVyc2lvbiByZWdpc3RyeScsXHJcbiAgICAgICAgNDAwMSxcclxuICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5JTlRFUk5BTF9TRVJWRVJfRVJST1IsXHJcbiAgICAgICAgcmVzcG9uc2VcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFRoaXMgZ2V0IHRoZSB3YXp1aCBzZXR1cCBzZXR0aW5nc1xyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcclxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSBzZXR1cCBpbmZvIG9yIEVycm9yUmVzcG9uc2VcclxuICAgKi9cclxuICBhc3luYyBnZXRTZXR1cEluZm8oY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3Qgc291cmNlID0gSlNPTi5wYXJzZShmcy5yZWFkRmlsZVN5bmModGhpcy51cGRhdGVSZWdpc3RyeS5maWxlLCAndXRmOCcpKTtcclxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICBzdGF0dXNDb2RlOiBIVFRQX1NUQVRVU19DT0RFUy5PSyxcclxuICAgICAgICAgIGRhdGE6ICFPYmplY3QudmFsdWVzKHNvdXJjZSkubGVuZ3RoID8gJycgOiBzb3VyY2UsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3dhenVoLWFwaTpnZXRTZXR1cEluZm8nLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXHJcbiAgICAgICAgYENvdWxkIG5vdCBnZXQgZGF0YSBmcm9tIHdhenVoLXZlcnNpb24gcmVnaXN0cnkgZHVlIHRvICR7ZXJyb3IubWVzc2FnZSB8fCBlcnJvcn1gLFxyXG4gICAgICAgIDQwMDUsXHJcbiAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLFxyXG4gICAgICAgIHJlc3BvbnNlXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBHZXQgYmFzaWMgc3lzY29sbGVjdG9yIGluZm9ybWF0aW9uIGZvciBnaXZlbiBhZ2VudC5cclxuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXHJcbiAgICogQHJldHVybnMge09iamVjdH0gQmFzaWMgc3lzY29sbGVjdG9yIGluZm9ybWF0aW9uXHJcbiAgICovXHJcbiAgYXN5bmMgZ2V0U3lzY29sbGVjdG9yKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnkpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGFwaUhvc3RJRCA9IGdldENvb2tpZVZhbHVlQnlOYW1lKHJlcXVlc3QuaGVhZGVycy5jb29raWUsJ3d6LWFwaScpO1xyXG4gICAgICBpZiAoIXJlcXVlc3QucGFyYW1zIHx8ICFhcGlIb3N0SUQgfHwgIXJlcXVlc3QucGFyYW1zLmFnZW50KSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdBZ2VudCBJRCBhbmQgQVBJIElEIGFyZSByZXF1aXJlZCcpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCB7IGFnZW50IH0gPSByZXF1ZXN0LnBhcmFtcztcclxuXHJcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoJ0dFVCcsIGAvc3lzY29sbGVjdG9yLyR7YWdlbnR9L2hhcmR3YXJlYCwge30sIHsgYXBpSG9zdElEIH0pLFxyXG4gICAgICAgIGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KCdHRVQnLCBgL3N5c2NvbGxlY3Rvci8ke2FnZW50fS9vc2AsIHt9LCB7IGFwaUhvc3RJRCB9KVxyXG4gICAgICBdKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGRhdGEubWFwKGl0ZW0gPT4gKGl0ZW0uZGF0YSB8fCB7fSkuZGF0YSB8fCBbXSk7XHJcbiAgICAgIGNvbnN0IFtoYXJkd2FyZVJlc3BvbnNlLCBvc1Jlc3BvbnNlXSA9IHJlc3VsdDtcclxuXHJcbiAgICAgIC8vIEZpbGwgc3lzY29sbGVjdG9yIG9iamVjdFxyXG4gICAgICBjb25zdCBzeXNjb2xsZWN0b3IgPSB7XHJcbiAgICAgICAgaGFyZHdhcmU6XHJcbiAgICAgICAgICB0eXBlb2YgaGFyZHdhcmVSZXNwb25zZSA9PT0gJ29iamVjdCcgJiYgT2JqZWN0LmtleXMoaGFyZHdhcmVSZXNwb25zZSkubGVuZ3RoXHJcbiAgICAgICAgICAgID8geyAuLi5oYXJkd2FyZVJlc3BvbnNlLmFmZmVjdGVkX2l0ZW1zWzBdIH1cclxuICAgICAgICAgICAgOiBmYWxzZSxcclxuICAgICAgICBvczpcclxuICAgICAgICAgIHR5cGVvZiBvc1Jlc3BvbnNlID09PSAnb2JqZWN0JyAmJiBPYmplY3Qua2V5cyhvc1Jlc3BvbnNlKS5sZW5ndGhcclxuICAgICAgICAgICAgPyB7IC4uLm9zUmVzcG9uc2UuYWZmZWN0ZWRfaXRlbXNbMF0gfVxyXG4gICAgICAgICAgICA6IGZhbHNlLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICBib2R5OiBzeXNjb2xsZWN0b3JcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3dhenVoLWFwaTpnZXRTeXNjb2xsZWN0b3InLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXHJcbiAgICAgICAgZXJyb3IubWVzc2FnZSB8fCBlcnJvcixcclxuICAgICAgICAzMDM1LFxyXG4gICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcclxuICAgICAgICByZXNwb25zZVxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH1cclxuICAvKipcclxuICAgKiBDaGVjayBpZiB1c2VyIGFzc2lnbmVkIHJvbGVzIGRpc2FibGUgV2F6dWggUGx1Z2luXHJcbiAgICogQHBhcmFtIGNvbnRleHRcclxuICAgKiBAcGFyYW0gcmVxdWVzdFxyXG4gICAqIEBwYXJhbSByZXNwb25zZVxyXG4gICAqIEByZXR1cm5zIHtvYmplY3R9IFJldHVybnMgeyBpc1dhenVoRGlzYWJsZWQ6IGJvb2xlYW4gcGFyc2VkIGludGVnZXIgfVxyXG4gICAqL1xyXG4gIGFzeW5jIGlzV2F6dWhEaXNhYmxlZChjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCwgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5KSB7XHJcbiAgICB0cnkge1xyXG5cclxuICAgICAgY29uc3QgZGlzYWJsZWRSb2xlcyA9ICggYXdhaXQgZ2V0Q29uZmlndXJhdGlvbigpIClbJ2Rpc2FibGVkX3JvbGVzJ10gfHwgW107XHJcbiAgICAgIGNvbnN0IGxvZ29TaWRlYmFyID0gKCBhd2FpdCBnZXRDb25maWd1cmF0aW9uKCkgKVsnY3VzdG9taXphdGlvbi5sb2dvLnNpZGViYXInXTtcclxuICAgICAgY29uc3QgZGF0YSA9IChhd2FpdCBjb250ZXh0LndhenVoLnNlY3VyaXR5LmdldEN1cnJlbnRVc2VyKHJlcXVlc3QsIGNvbnRleHQpKS5hdXRoQ29udGV4dDtcclxuXHJcbiAgICAgIGNvbnN0IGlzV2F6dWhEaXNhYmxlZCA9ICsoZGF0YS5yb2xlcyB8fCBbXSkuc29tZSgocm9sZSkgPT4gZGlzYWJsZWRSb2xlcy5pbmNsdWRlcyhyb2xlKSk7XHJcblxyXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgIGJvZHk6IHsgaXNXYXp1aERpc2FibGVkLCBsb2dvU2lkZWJhciB9XHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgbG9nKCd3YXp1aC1hcGk6aXNXYXp1aERpc2FibGVkJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxyXG4gICAgICAgIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsXHJcbiAgICAgICAgMzAzNSxcclxuICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5JTlRFUk5BTF9TRVJWRVJfRVJST1IsXHJcbiAgICAgICAgcmVzcG9uc2VcclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgfVxyXG59XHJcbiJdfQ==