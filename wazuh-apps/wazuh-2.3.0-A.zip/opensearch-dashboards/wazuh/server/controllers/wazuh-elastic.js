"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhElasticCtrl = void 0;

var _errorResponse = require("../lib/error-response");

var _logger = require("../lib/logger");

var _getConfiguration = require("../lib/get-configuration");

var _visualizations = require("../integration-files/visualizations");

var _generateAlertsScript = require("../lib/generate-alerts/generate-alerts-script");

var _constants = require("../../common/constants");

var _jwtDecode = _interopRequireDefault(require("jwt-decode"));

var _manageHosts = require("../lib/manage-hosts");

var _cookie = require("../lib/cookie");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class WazuhElasticCtrl {
  constructor() {
    _defineProperty(this, "wzSampleAlertsIndexPrefix", void 0);

    _defineProperty(this, "manageHosts", void 0);

    this.wzSampleAlertsIndexPrefix = this.getSampleAlertPrefix();
    this.manageHosts = new _manageHosts.ManageHosts();
  }
  /**
   * This returns the index according the category
   * @param {string} category
   */


  buildSampleIndexByCategory(category) {
    return `${this.wzSampleAlertsIndexPrefix}sample-${category}`;
  }
  /**
   * This returns the defined config for sample alerts prefix or the default value.
   */


  getSampleAlertPrefix() {
    const config = (0, _getConfiguration.getConfiguration)();
    return config['alerts.sample.prefix'] || _constants.WAZUH_SAMPLE_ALERT_PREFIX;
  }
  /**
   * This retrieves a template from Elasticsearch
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} template or ErrorResponse
   */


  async getTemplate(context, request, response) {
    try {
      const data = await context.core.opensearch.client.asInternalUser.cat.templates();
      const templates = data.body;

      if (!templates || typeof templates !== 'string') {
        throw new Error('An unknown error occurred when fetching templates from Elasticseach');
      }

      const lastChar = request.params.pattern[request.params.pattern.length - 1]; // Split into separate patterns

      const tmpdata = templates.match(/\[.*\]/g);
      const tmparray = [];

      for (let item of tmpdata) {
        // A template might use more than one pattern
        if (item.includes(',')) {
          item = item.substr(1).slice(0, -1);
          const subItems = item.split(',');

          for (const subitem of subItems) {
            tmparray.push(`[${subitem.trim()}]`);
          }
        } else {
          tmparray.push(item);
        }
      } // Ensure we are handling just patterns


      const array = tmparray.filter(item => item.includes('[') && item.includes(']'));
      const pattern = lastChar === '*' ? request.params.pattern.slice(0, -1) : request.params.pattern;
      const isIncluded = array.filter(item => {
        item = item.slice(1, -1);
        const lastChar = item[item.length - 1];
        item = lastChar === '*' ? item.slice(0, -1) : item;
        return item.includes(pattern) || pattern.includes(item);
      });
      (0, _logger.log)('wazuh-elastic:getTemplate', `Template is valid: ${isIncluded && Array.isArray(isIncluded) && isIncluded.length ? 'yes' : 'no'}`, 'debug');
      return isIncluded && Array.isArray(isIncluded) && isIncluded.length ? response.ok({
        body: {
          statusCode: 200,
          status: true,
          data: `Template found for ${request.params.pattern}`
        }
      }) : response.ok({
        body: {
          statusCode: 200,
          status: false,
          data: `No template found for ${request.params.pattern}`
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:getTemplate', error.message || error);
      return (0, _errorResponse.ErrorResponse)(`Could not retrieve templates from Elasticsearch due to ${error.message || error}`, 4002, 500, response);
    }
  }
  /**
   * This check index-pattern
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} status obj or ErrorResponse
   */


  async checkPattern(context, request, response) {
    try {
      const data = await context.core.savedObjects.client.find({
        type: 'index-pattern'
      });
      const existsIndexPattern = data.saved_objects.find(item => item.attributes.title === request.params.pattern);
      (0, _logger.log)('wazuh-elastic:checkPattern', `Index pattern found: ${existsIndexPattern ? existsIndexPattern.attributes.title : 'no'}`, 'debug');
      return existsIndexPattern ? response.ok({
        body: {
          statusCode: 200,
          status: true,
          data: 'Index pattern found'
        }
      }) : response.ok({
        body: {
          statusCode: 500,
          status: false,
          error: 10020,
          message: 'Index pattern not found'
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:checkPattern', error.message || error);
      return (0, _errorResponse.ErrorResponse)(`Something went wrong retrieving index-patterns from Elasticsearch due to ${error.message || error}`, 4003, 500, response);
    }
  }
  /**
   * This get the fields keys
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Array<Object>} fields or ErrorResponse
   */


  async getFieldTop(context, request, response) {
    try {
      // Top field payload
      let payload = {
        size: 1,
        query: {
          bool: {
            must: [],
            must_not: {
              term: {
                'agent.id': '000'
              }
            },
            filter: [{
              range: {
                timestamp: {}
              }
            }]
          }
        },
        aggs: {
          '2': {
            terms: {
              field: '',
              size: 1,
              order: {
                _count: 'desc'
              }
            }
          }
        }
      }; // Set up time interval, default to Last 24h

      const timeGTE = 'now-1d';
      const timeLT = 'now';
      payload.query.bool.filter[0].range['timestamp']['gte'] = timeGTE;
      payload.query.bool.filter[0].range['timestamp']['lt'] = timeLT; // Set up match for default cluster name

      payload.query.bool.must.push(request.params.mode === 'cluster' ? {
        match: {
          'cluster.name': request.params.cluster
        }
      } : {
        match: {
          'manager.name': request.params.cluster
        }
      });
      if (request.query.agentsList) payload.query.bool.filter.push({
        terms: {
          'agent.id': request.query.agentsList.split(',')
        }
      });
      payload.aggs['2'].terms.field = request.params.field;
      const data = await context.core.opensearch.client.asCurrentUser.search({
        size: 1,
        index: request.params.pattern,
        body: payload
      });
      return data.body.hits.total.value === 0 || typeof data.body.aggregations['2'].buckets[0] === 'undefined' ? response.ok({
        body: {
          statusCode: 200,
          data: ''
        }
      }) : response.ok({
        body: {
          statusCode: 200,
          data: data.body.aggregations['2'].buckets[0].key
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:getFieldTop', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 4004, 500, response);
    }
  }
  /**
   * Checks one by one if the requesting user has enough privileges to use
   * an index pattern from the list.
   * @param {Array<Object>} list List of index patterns
   * @param {Object} req
   * @returns {Array<Object>} List of allowed index
   */


  async filterAllowedIndexPatternList(context, list, req) {
    //TODO: review if necesary to delete
    let finalList = [];

    for (let item of list) {
      let results = false,
          forbidden = false;

      try {
        results = await context.core.opensearch.client.asCurrentUser.search({
          index: item.title
        });
      } catch (error) {
        forbidden = true;
      }

      if ((((results || {}).body || {}).hits || {}).total.value >= 1 || !forbidden && (((results || {}).body || {}).hits || {}).total === 0) {
        finalList.push(item);
      }
    }

    return finalList;
  }
  /**
   * Checks for minimum index pattern fields in a list of index patterns.
   * @param {Array<Object>} indexPatternList List of index patterns
   */


  validateIndexPattern(indexPatternList) {
    const minimum = ['timestamp', 'rule.groups', 'manager.name', 'agent.id'];
    let list = [];

    for (const index of indexPatternList) {
      let valid, parsed;

      try {
        parsed = JSON.parse(index.attributes.fields);
      } catch (error) {
        continue;
      }

      valid = parsed.filter(item => minimum.includes(item.name));

      if (valid.length === 4) {
        list.push({
          id: index.id,
          title: index.attributes.title
        });
      }
    }

    return list;
  }
  /**
   * Returns current security platform
   * @param {Object} req
   * @param {Object} reply
   * @returns {String}
   */


  async getCurrentPlatform(context, request, response) {
    try {
      return response.ok({
        body: {
          platform: context.wazuh.security.platform
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:getCurrentPlatform', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 4011, 500, response);
    }
  }
  /**
   * Replaces visualizations main fields to fit a certain pattern.
   * @param {Array<Object>} app_objects Object containing raw visualizations.
   * @param {String} id Index-pattern id to use in the visualizations. Eg: 'wazuh-alerts'
   */


  async buildVisualizationsRaw(app_objects, id, namespace = false) {
    try {
      const config = (0, _getConfiguration.getConfiguration)();
      let monitoringPattern = (config || {})['wazuh.monitoring.pattern'] || _constants.WAZUH_MONITORING_PATTERN;
      (0, _logger.log)('wazuh-elastic:buildVisualizationsRaw', `Building ${app_objects.length} visualizations`, 'debug');
      (0, _logger.log)('wazuh-elastic:buildVisualizationsRaw', `Index pattern ID: ${id}`, 'debug');
      const visArray = [];
      let aux_source, bulk_content;

      for (let element of app_objects) {
        aux_source = JSON.parse(JSON.stringify(element._source)); // Replace index-pattern for visualizations

        if (aux_source && aux_source.kibanaSavedObjectMeta && aux_source.kibanaSavedObjectMeta.searchSourceJSON && typeof aux_source.kibanaSavedObjectMeta.searchSourceJSON === 'string') {
          const defaultStr = aux_source.kibanaSavedObjectMeta.searchSourceJSON;
          const isMonitoring = defaultStr.includes('wazuh-monitoring');

          if (isMonitoring) {
            if (namespace && namespace !== 'default') {
              if (monitoringPattern.includes(namespace) && monitoringPattern.includes('index-pattern:')) {
                monitoringPattern = monitoringPattern.split('index-pattern:')[1];
              }
            }

            aux_source.kibanaSavedObjectMeta.searchSourceJSON = defaultStr.replace(/wazuh-monitoring/g, monitoringPattern[monitoringPattern.length - 1] === '*' || namespace && namespace !== 'default' ? monitoringPattern : monitoringPattern + '*');
          } else {
            aux_source.kibanaSavedObjectMeta.searchSourceJSON = defaultStr.replace(/wazuh-alerts/g, id);
          }
        } // Replace index-pattern for selector visualizations


        if (typeof (aux_source || {}).visState === 'string') {
          aux_source.visState = aux_source.visState.replace(/wazuh-alerts/g, id);
        } // Bulk source


        bulk_content = {};
        bulk_content[element._type] = aux_source;
        visArray.push({
          attributes: bulk_content.visualization,
          type: element._type,
          id: element._id,
          _version: bulk_content.visualization.version
        });
      }

      return visArray;
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:buildVisualizationsRaw', error.message || error);
      return Promise.reject(error);
    }
  }
  /**
   * Replaces cluster visualizations main fields.
   * @param {Array<Object>} app_objects Object containing raw visualizations.
   * @param {String} id Index-pattern id to use in the visualizations. Eg: 'wazuh-alerts'
   * @param {Array<String>} nodes Array of node names. Eg: ['node01', 'node02']
   * @param {String} name Cluster name. Eg: 'wazuh'
   * @param {String} master_node Master node name. Eg: 'node01'
   */


  buildClusterVisualizationsRaw(app_objects, id, nodes = [], name, master_node, pattern_name = '*') {
    try {
      const visArray = [];
      let aux_source, bulk_content;

      for (const element of app_objects) {
        // Stringify and replace index-pattern for visualizations
        aux_source = JSON.stringify(element._source);
        aux_source = aux_source.replace(/wazuh-alerts/g, id);
        aux_source = JSON.parse(aux_source); // Bulk source

        bulk_content = {};
        bulk_content[element._type] = aux_source;
        const visState = JSON.parse(bulk_content.visualization.visState);
        const title = visState.title;

        if (visState.type && visState.type === 'timelion') {
          let query = '';

          if (title === 'Wazuh App Cluster Overview') {
            for (const node of nodes) {
              query += `.es(index=${pattern_name},q="cluster.name: ${name} AND cluster.node: ${node.name}").label("${node.name}"),`;
            }

            query = query.substring(0, query.length - 1);
          } else if (title === 'Wazuh App Cluster Overview Manager') {
            query += `.es(index=${pattern_name},q="cluster.name: ${name}").label("${name} cluster")`;
          } else {
            if (title.startsWith('Wazuh App Statistics')) {
              const {
                searchSourceJSON
              } = bulk_content.visualization.kibanaSavedObjectMeta;
              bulk_content.visualization.kibanaSavedObjectMeta.searchSourceJSON = searchSourceJSON.replace('wazuh-statistics-*', pattern_name);
            }

            if (title.startsWith('Wazuh App Statistics') && name !== '-' && name !== 'all' && visState.params.expression.includes('q=')) {
              const expressionRegex = /q='\*'/gi;

              const _visState = bulk_content.visualization.visStateByNode ? JSON.parse(bulk_content.visualization.visStateByNode) : visState;

              query += _visState.params.expression.replace(/wazuh-statistics-\*/g, pattern_name).replace(expressionRegex, `q="nodeName.keyword:${name} AND apiName.keyword:${master_node}"`).replace("NODE_NAME", name);
            } else if (title.startsWith('Wazuh App Statistics')) {
              const expressionRegex = /q='\*'/gi;
              query += visState.params.expression.replace(/wazuh-statistics-\*/g, pattern_name).replace(expressionRegex, `q="apiName.keyword:${master_node}"`);
            } else {
              query = visState.params.expression;
            }
          }

          visState.params.expression = query.replace(/'/g, "\"");
          bulk_content.visualization.visState = JSON.stringify(visState);
        }

        visArray.push({
          attributes: bulk_content.visualization,
          type: element._type,
          id: element._id,
          _version: bulk_content.visualization.version
        });
      }

      return visArray;
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:buildClusterVisualizationsRaw', error.message || error);
      return Promise.reject(error);
    }
  }
  /**
   * This creates a visualization of data in req
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} vis obj or ErrorResponse
   */


  async createVis(context, request, response) {
    try {
      if (!request.params.tab.includes('overview-') && !request.params.tab.includes('agents-')) {
        throw new Error('Missing parameters creating visualizations');
      }

      const tabPrefix = request.params.tab.includes('overview') ? 'overview' : 'agents';
      const tabSplit = request.params.tab.split('-');
      const tabSufix = tabSplit[1];
      const file = tabPrefix === 'overview' ? _visualizations.OverviewVisualizations[tabSufix] : _visualizations.AgentsVisualizations[tabSufix];

      if (!file) {
        return response.notFound({
          body: {
            message: `Visualizations not found for ${request.params.tab}`
          }
        });
      }

      (0, _logger.log)('wazuh-elastic:createVis', `${tabPrefix}[${tabSufix}] with index pattern ${request.params.pattern}`, 'debug');
      const raw = await this.buildVisualizationsRaw(file, request.params.pattern);
      return response.ok({
        body: {
          acknowledge: true,
          raw: raw
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:createVis', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 4007, 500, response);
    }
  }
  /**
   * This creates a visualization of cluster
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} vis obj or ErrorResponse
   */


  async createClusterVis(context, request, response) {
    try {
      if (!request.params.pattern || !request.params.tab || !request.body || !request.body.nodes || !request.body.nodes.affected_items || !request.body.nodes.name || request.params.tab && !request.params.tab.includes('cluster-')) {
        throw new Error('Missing parameters creating visualizations');
      }

      const type = request.params.tab.split('-')[1];
      const file = _visualizations.ClusterVisualizations[type];
      const nodes = request.body.nodes.affected_items;
      const name = request.body.nodes.name;
      const masterNode = request.body.nodes.master_node;
      const {
        id: patternID,
        title: patternName
      } = request.body.pattern;
      const raw = await this.buildClusterVisualizationsRaw(file, patternID, nodes, name, masterNode, patternName);
      return response.ok({
        body: {
          acknowledge: true,
          raw: raw
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:createClusterVis', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 4009, 500, response);
    }
  }
  /**
   * This checks if there is sample alerts
   * GET /elastic/samplealerts
   * @param {*} context
   * @param {*} request
   * @param {*} response
   * {alerts: [...]} or ErrorResponse
   */


  async haveSampleAlerts(context, request, response) {
    try {
      // Check if wazuh sample alerts index exists
      const results = await Promise.all(Object.keys(_constants.WAZUH_SAMPLE_ALERTS_CATEGORIES_TYPE_ALERTS).map(category => context.core.opensearch.client.asCurrentUser.indices.exists({
        index: this.buildSampleIndexByCategory(category)
      })));
      return response.ok({
        body: {
          sampleAlertsInstalled: results.some(result => result.body)
        }
      });
    } catch (error) {
      return (0, _errorResponse.ErrorResponse)('Sample Alerts category not valid', 1000, 500, response);
    }
  }
  /**
   * This creates sample alerts in wazuh-sample-alerts
   * GET /elastic/samplealerts/{category}
   * @param {*} context
   * @param {*} request
   * @param {*} response
   * {alerts: [...]} or ErrorResponse
   */


  async haveSampleAlertsOfCategory(context, request, response) {
    try {
      const sampleAlertsIndex = this.buildSampleIndexByCategory(request.params.category); // Check if wazuh sample alerts index exists

      const existsSampleIndex = await context.core.opensearch.client.asCurrentUser.indices.exists({
        index: sampleAlertsIndex
      });
      return response.ok({
        body: {
          index: sampleAlertsIndex,
          exists: existsSampleIndex.body
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:haveSampleAlertsOfCategory', `Error checking if there are sample alerts indices: ${error.message || error}`);
      const [statusCode, errorMessage] = this.getErrorDetails(error);
      return (0, _errorResponse.ErrorResponse)(`Error checking if there are sample alerts indices: ${errorMessage || error}`, 1000, statusCode, response);
    }
  }
  /**
   * This creates sample alerts in wazuh-sample-alerts
   * POST /elastic/samplealerts/{category}
   * {
   *   "manager": {
   *      "name": "manager_name"
   *    },
   *    cluster: {
   *      name: "mycluster",
   *      node: "mynode"
   *    }
   * }
   * @param {*} context
   * @param {*} request
   * @param {*} response
   * {index: string, alerts: [...], count: number} or ErrorResponse
   */


  async createSampleAlerts(context, request, response) {
    const sampleAlertsIndex = this.buildSampleIndexByCategory(request.params.category);

    try {
      // Check if user has administrator role in token
      const token = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-token');

      if (!token) {
        return (0, _errorResponse.ErrorResponse)('No token provided', 401, 401, response);
      }

      ;
      const decodedToken = (0, _jwtDecode.default)(token);

      if (!decodedToken) {
        return (0, _errorResponse.ErrorResponse)('No permissions in token', 401, 401, response);
      }

      ;

      if (!decodedToken.rbac_roles || !decodedToken.rbac_roles.includes(_constants.WAZUH_ROLE_ADMINISTRATOR_ID)) {
        return (0, _errorResponse.ErrorResponse)('No administrator role', 401, 401, response);
      }

      ; // Check the provided token is valid

      const apiHostID = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-api');

      if (!apiHostID) {
        return (0, _errorResponse.ErrorResponse)('No API id provided', 401, 401, response);
      }

      ;
      const responseTokenIsWorking = await context.wazuh.api.client.asCurrentUser.request('GET', `//`, {}, {
        apiHostID
      });

      if (responseTokenIsWorking.status !== 200) {
        return (0, _errorResponse.ErrorResponse)('Token is not valid', 500, 500, response);
      }

      ;
      const bulkPrefix = JSON.stringify({
        index: {
          _index: sampleAlertsIndex
        }
      });
      const alertGenerateParams = request.body && request.body.params || {};

      const sampleAlerts = _constants.WAZUH_SAMPLE_ALERTS_CATEGORIES_TYPE_ALERTS[request.params.category].map(typeAlert => (0, _generateAlertsScript.generateAlerts)({ ...typeAlert,
        ...alertGenerateParams
      }, request.body.alerts || typeAlert.alerts || _constants.WAZUH_SAMPLE_ALERTS_DEFAULT_NUMBER_ALERTS)).flat();

      const bulk = sampleAlerts.map(sampleAlert => `${bulkPrefix}\n${JSON.stringify(sampleAlert)}\n`).join(''); // Index alerts
      // Check if wazuh sample alerts index exists

      const existsSampleIndex = await context.core.opensearch.client.asCurrentUser.indices.exists({
        index: sampleAlertsIndex
      });

      if (!existsSampleIndex.body) {
        // Create wazuh sample alerts index
        const configuration = {
          settings: {
            index: {
              number_of_shards: _constants.WAZUH_SAMPLE_ALERTS_INDEX_SHARDS,
              number_of_replicas: _constants.WAZUH_SAMPLE_ALERTS_INDEX_REPLICAS
            }
          }
        };
        await context.core.opensearch.client.asCurrentUser.indices.create({
          index: sampleAlertsIndex,
          body: configuration
        });
        (0, _logger.log)('wazuh-elastic:createSampleAlerts', `Created ${sampleAlertsIndex} index`, 'debug');
      }

      await context.core.opensearch.client.asCurrentUser.bulk({
        index: sampleAlertsIndex,
        body: bulk
      });
      (0, _logger.log)('wazuh-elastic:createSampleAlerts', `Added sample alerts to ${sampleAlertsIndex} index`, 'debug');
      return response.ok({
        body: {
          index: sampleAlertsIndex,
          alertCount: sampleAlerts.length
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:createSampleAlerts', `Error adding sample alerts to ${sampleAlertsIndex} index: ${error.message || error}`);
      const [statusCode, errorMessage] = this.getErrorDetails(error);
      return (0, _errorResponse.ErrorResponse)(errorMessage || error, 1000, statusCode, response);
    }
  }
  /**
   * This deletes sample alerts
   * @param {*} context
   * @param {*} request
   * @param {*} response
   * {result: "deleted", index: string} or ErrorResponse
   */


  async deleteSampleAlerts(context, request, response) {
    // Delete Wazuh sample alert index
    const sampleAlertsIndex = this.buildSampleIndexByCategory(request.params.category);

    try {
      // Check if user has administrator role in token
      const token = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-token');

      if (!token) {
        return (0, _errorResponse.ErrorResponse)('No token provided', 401, 401, response);
      }

      ;
      const decodedToken = (0, _jwtDecode.default)(token);

      if (!decodedToken) {
        return (0, _errorResponse.ErrorResponse)('No permissions in token', 401, 401, response);
      }

      ;

      if (!decodedToken.rbac_roles || !decodedToken.rbac_roles.includes(_constants.WAZUH_ROLE_ADMINISTRATOR_ID)) {
        return (0, _errorResponse.ErrorResponse)('No administrator role', 401, 401, response);
      }

      ; // Check the provided token is valid

      const apiHostID = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-api');

      if (!apiHostID) {
        return (0, _errorResponse.ErrorResponse)('No API id provided', 401, 401, response);
      }

      ;
      const responseTokenIsWorking = await context.wazuh.api.client.asCurrentUser.request('GET', `//`, {}, {
        apiHostID
      });

      if (responseTokenIsWorking.status !== 200) {
        return (0, _errorResponse.ErrorResponse)('Token is not valid', 500, 500, response);
      }

      ; // Check if Wazuh sample alerts index exists

      const existsSampleIndex = await context.core.opensearch.client.asCurrentUser.indices.exists({
        index: sampleAlertsIndex
      });

      if (existsSampleIndex.body) {
        // Delete Wazuh sample alerts index
        await context.core.opensearch.client.asCurrentUser.indices.delete({
          index: sampleAlertsIndex
        });
        (0, _logger.log)('wazuh-elastic:deleteSampleAlerts', `Deleted ${sampleAlertsIndex} index`, 'debug');
        return response.ok({
          body: {
            result: 'deleted',
            index: sampleAlertsIndex
          }
        });
      } else {
        return (0, _errorResponse.ErrorResponse)(`${sampleAlertsIndex} index doesn't exist`, 1000, 500, response);
      }
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:deleteSampleAlerts', `Error deleting sample alerts of ${sampleAlertsIndex} index: ${error.message || error}`);
      const [statusCode, errorMessage] = this.getErrorDetails(error);
      return (0, _errorResponse.ErrorResponse)(errorMessage || error, 1000, statusCode, response);
    }
  }

  async alerts(context, request, response) {
    try {
      const data = await context.core.opensearch.client.asCurrentUser.search(request.body);
      return response.ok({
        body: data.body
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:alerts', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 4010, 500, response);
    }
  } // Check if there are indices for Statistics


  async existStatisticsIndices(context, request, response) {
    try {
      const config = (0, _getConfiguration.getConfiguration)();
      const statisticsPattern = `${config['cron.prefix'] || 'wazuh'}-${config['cron.statistics.index.name'] || 'statistics'}*`; //TODO: replace by default as constants instead hardcoded ('wazuh' and 'statistics')

      const existIndex = await context.core.opensearch.client.asCurrentUser.indices.exists({
        index: statisticsPattern,
        allow_no_indices: false
      });
      return response.ok({
        body: existIndex.body
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:existsStatisticsIndices', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 1000, 500, response);
    }
  }

  getErrorDetails(error) {
    var _error$meta;

    const statusCode = (error === null || error === void 0 ? void 0 : (_error$meta = error.meta) === null || _error$meta === void 0 ? void 0 : _error$meta.statusCode) || 500;
    let errorMessage = error.message;

    if (statusCode === 403) {
      var _error$meta2, _error$meta2$body, _error$meta2$body$err;

      errorMessage = (error === null || error === void 0 ? void 0 : (_error$meta2 = error.meta) === null || _error$meta2 === void 0 ? void 0 : (_error$meta2$body = _error$meta2.body) === null || _error$meta2$body === void 0 ? void 0 : (_error$meta2$body$err = _error$meta2$body.error) === null || _error$meta2$body$err === void 0 ? void 0 : _error$meta2$body$err.reason) || 'Permission denied';
    }

    return [statusCode, errorMessage];
  }

}

exports.WazuhElasticCtrl = WazuhElasticCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhenVoLWVsYXN0aWMudHMiXSwibmFtZXMiOlsiV2F6dWhFbGFzdGljQ3RybCIsImNvbnN0cnVjdG9yIiwid3pTYW1wbGVBbGVydHNJbmRleFByZWZpeCIsImdldFNhbXBsZUFsZXJ0UHJlZml4IiwibWFuYWdlSG9zdHMiLCJNYW5hZ2VIb3N0cyIsImJ1aWxkU2FtcGxlSW5kZXhCeUNhdGVnb3J5IiwiY2F0ZWdvcnkiLCJjb25maWciLCJXQVpVSF9TQU1QTEVfQUxFUlRfUFJFRklYIiwiZ2V0VGVtcGxhdGUiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwiZGF0YSIsImNvcmUiLCJvcGVuc2VhcmNoIiwiY2xpZW50IiwiYXNJbnRlcm5hbFVzZXIiLCJjYXQiLCJ0ZW1wbGF0ZXMiLCJib2R5IiwiRXJyb3IiLCJsYXN0Q2hhciIsInBhcmFtcyIsInBhdHRlcm4iLCJsZW5ndGgiLCJ0bXBkYXRhIiwibWF0Y2giLCJ0bXBhcnJheSIsIml0ZW0iLCJpbmNsdWRlcyIsInN1YnN0ciIsInNsaWNlIiwic3ViSXRlbXMiLCJzcGxpdCIsInN1Yml0ZW0iLCJwdXNoIiwidHJpbSIsImFycmF5IiwiZmlsdGVyIiwiaXNJbmNsdWRlZCIsIkFycmF5IiwiaXNBcnJheSIsIm9rIiwic3RhdHVzQ29kZSIsInN0YXR1cyIsImVycm9yIiwibWVzc2FnZSIsImNoZWNrUGF0dGVybiIsInNhdmVkT2JqZWN0cyIsImZpbmQiLCJ0eXBlIiwiZXhpc3RzSW5kZXhQYXR0ZXJuIiwic2F2ZWRfb2JqZWN0cyIsImF0dHJpYnV0ZXMiLCJ0aXRsZSIsImdldEZpZWxkVG9wIiwicGF5bG9hZCIsInNpemUiLCJxdWVyeSIsImJvb2wiLCJtdXN0IiwibXVzdF9ub3QiLCJ0ZXJtIiwicmFuZ2UiLCJ0aW1lc3RhbXAiLCJhZ2dzIiwidGVybXMiLCJmaWVsZCIsIm9yZGVyIiwiX2NvdW50IiwidGltZUdURSIsInRpbWVMVCIsIm1vZGUiLCJjbHVzdGVyIiwiYWdlbnRzTGlzdCIsImFzQ3VycmVudFVzZXIiLCJzZWFyY2giLCJpbmRleCIsImhpdHMiLCJ0b3RhbCIsInZhbHVlIiwiYWdncmVnYXRpb25zIiwiYnVja2V0cyIsImtleSIsImZpbHRlckFsbG93ZWRJbmRleFBhdHRlcm5MaXN0IiwibGlzdCIsInJlcSIsImZpbmFsTGlzdCIsInJlc3VsdHMiLCJmb3JiaWRkZW4iLCJ2YWxpZGF0ZUluZGV4UGF0dGVybiIsImluZGV4UGF0dGVybkxpc3QiLCJtaW5pbXVtIiwidmFsaWQiLCJwYXJzZWQiLCJKU09OIiwicGFyc2UiLCJmaWVsZHMiLCJuYW1lIiwiaWQiLCJnZXRDdXJyZW50UGxhdGZvcm0iLCJwbGF0Zm9ybSIsIndhenVoIiwic2VjdXJpdHkiLCJidWlsZFZpc3VhbGl6YXRpb25zUmF3IiwiYXBwX29iamVjdHMiLCJuYW1lc3BhY2UiLCJtb25pdG9yaW5nUGF0dGVybiIsIldBWlVIX01PTklUT1JJTkdfUEFUVEVSTiIsInZpc0FycmF5IiwiYXV4X3NvdXJjZSIsImJ1bGtfY29udGVudCIsImVsZW1lbnQiLCJzdHJpbmdpZnkiLCJfc291cmNlIiwia2liYW5hU2F2ZWRPYmplY3RNZXRhIiwic2VhcmNoU291cmNlSlNPTiIsImRlZmF1bHRTdHIiLCJpc01vbml0b3JpbmciLCJyZXBsYWNlIiwidmlzU3RhdGUiLCJfdHlwZSIsInZpc3VhbGl6YXRpb24iLCJfaWQiLCJfdmVyc2lvbiIsInZlcnNpb24iLCJQcm9taXNlIiwicmVqZWN0IiwiYnVpbGRDbHVzdGVyVmlzdWFsaXphdGlvbnNSYXciLCJub2RlcyIsIm1hc3Rlcl9ub2RlIiwicGF0dGVybl9uYW1lIiwibm9kZSIsInN1YnN0cmluZyIsInN0YXJ0c1dpdGgiLCJleHByZXNzaW9uIiwiZXhwcmVzc2lvblJlZ2V4IiwiX3Zpc1N0YXRlIiwidmlzU3RhdGVCeU5vZGUiLCJjcmVhdGVWaXMiLCJ0YWIiLCJ0YWJQcmVmaXgiLCJ0YWJTcGxpdCIsInRhYlN1Zml4IiwiZmlsZSIsIk92ZXJ2aWV3VmlzdWFsaXphdGlvbnMiLCJBZ2VudHNWaXN1YWxpemF0aW9ucyIsIm5vdEZvdW5kIiwicmF3IiwiYWNrbm93bGVkZ2UiLCJjcmVhdGVDbHVzdGVyVmlzIiwiYWZmZWN0ZWRfaXRlbXMiLCJDbHVzdGVyVmlzdWFsaXphdGlvbnMiLCJtYXN0ZXJOb2RlIiwicGF0dGVybklEIiwicGF0dGVybk5hbWUiLCJoYXZlU2FtcGxlQWxlcnRzIiwiYWxsIiwiT2JqZWN0Iiwia2V5cyIsIldBWlVIX1NBTVBMRV9BTEVSVFNfQ0FURUdPUklFU19UWVBFX0FMRVJUUyIsIm1hcCIsImluZGljZXMiLCJleGlzdHMiLCJzYW1wbGVBbGVydHNJbnN0YWxsZWQiLCJzb21lIiwicmVzdWx0IiwiaGF2ZVNhbXBsZUFsZXJ0c09mQ2F0ZWdvcnkiLCJzYW1wbGVBbGVydHNJbmRleCIsImV4aXN0c1NhbXBsZUluZGV4IiwiZXJyb3JNZXNzYWdlIiwiZ2V0RXJyb3JEZXRhaWxzIiwiY3JlYXRlU2FtcGxlQWxlcnRzIiwidG9rZW4iLCJoZWFkZXJzIiwiY29va2llIiwiZGVjb2RlZFRva2VuIiwicmJhY19yb2xlcyIsIldBWlVIX1JPTEVfQURNSU5JU1RSQVRPUl9JRCIsImFwaUhvc3RJRCIsInJlc3BvbnNlVG9rZW5Jc1dvcmtpbmciLCJhcGkiLCJidWxrUHJlZml4IiwiX2luZGV4IiwiYWxlcnRHZW5lcmF0ZVBhcmFtcyIsInNhbXBsZUFsZXJ0cyIsInR5cGVBbGVydCIsImFsZXJ0cyIsIldBWlVIX1NBTVBMRV9BTEVSVFNfREVGQVVMVF9OVU1CRVJfQUxFUlRTIiwiZmxhdCIsImJ1bGsiLCJzYW1wbGVBbGVydCIsImpvaW4iLCJjb25maWd1cmF0aW9uIiwic2V0dGluZ3MiLCJudW1iZXJfb2Zfc2hhcmRzIiwiV0FaVUhfU0FNUExFX0FMRVJUU19JTkRFWF9TSEFSRFMiLCJudW1iZXJfb2ZfcmVwbGljYXMiLCJXQVpVSF9TQU1QTEVfQUxFUlRTX0lOREVYX1JFUExJQ0FTIiwiY3JlYXRlIiwiYWxlcnRDb3VudCIsImRlbGV0ZVNhbXBsZUFsZXJ0cyIsImRlbGV0ZSIsImV4aXN0U3RhdGlzdGljc0luZGljZXMiLCJzdGF0aXN0aWNzUGF0dGVybiIsImV4aXN0SW5kZXgiLCJhbGxvd19ub19pbmRpY2VzIiwibWV0YSIsInJlYXNvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQVdBOztBQUNBOztBQUNBOztBQUNBOztBQU1BOztBQUNBOztBQUNBOztBQUNBOztBQUVBOzs7Ozs7QUFHTyxNQUFNQSxnQkFBTixDQUF1QjtBQUc1QkMsRUFBQUEsV0FBVyxHQUFHO0FBQUE7O0FBQUE7O0FBQ1osU0FBS0MseUJBQUwsR0FBaUMsS0FBS0Msb0JBQUwsRUFBakM7QUFDQSxTQUFLQyxXQUFMLEdBQW1CLElBQUlDLHdCQUFKLEVBQW5CO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTs7O0FBQ0VDLEVBQUFBLDBCQUEwQixDQUFDQyxRQUFELEVBQTJCO0FBQ25ELFdBQVEsR0FBRSxLQUFLTCx5QkFBMEIsVUFBU0ssUUFBUyxFQUEzRDtBQUNEO0FBRUQ7QUFDRjtBQUNBOzs7QUFDRUosRUFBQUEsb0JBQW9CLEdBQVc7QUFDN0IsVUFBTUssTUFBTSxHQUFHLHlDQUFmO0FBQ0EsV0FBT0EsTUFBTSxDQUFDLHNCQUFELENBQU4sSUFBa0NDLG9DQUF6QztBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNtQixRQUFYQyxXQUFXLENBQUNDLE9BQUQsRUFBaUNDLE9BQWpDLEVBQTRGQyxRQUE1RixFQUEySTtBQUMxSixRQUFJO0FBQ0YsWUFBTUMsSUFBSSxHQUFHLE1BQU1ILE9BQU8sQ0FBQ0ksSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUF4QixDQUErQkMsY0FBL0IsQ0FBOENDLEdBQTlDLENBQWtEQyxTQUFsRCxFQUFuQjtBQUVBLFlBQU1BLFNBQVMsR0FBR04sSUFBSSxDQUFDTyxJQUF2Qjs7QUFDQSxVQUFJLENBQUNELFNBQUQsSUFBYyxPQUFPQSxTQUFQLEtBQXFCLFFBQXZDLEVBQWlEO0FBQy9DLGNBQU0sSUFBSUUsS0FBSixDQUNKLHFFQURJLENBQU47QUFHRDs7QUFFRCxZQUFNQyxRQUFRLEdBQUdYLE9BQU8sQ0FBQ1ksTUFBUixDQUFlQyxPQUFmLENBQXVCYixPQUFPLENBQUNZLE1BQVIsQ0FBZUMsT0FBZixDQUF1QkMsTUFBdkIsR0FBZ0MsQ0FBdkQsQ0FBakIsQ0FWRSxDQVlGOztBQUNBLFlBQU1DLE9BQU8sR0FBR1AsU0FBUyxDQUFDUSxLQUFWLENBQWdCLFNBQWhCLENBQWhCO0FBQ0EsWUFBTUMsUUFBUSxHQUFHLEVBQWpCOztBQUNBLFdBQUssSUFBSUMsSUFBVCxJQUFpQkgsT0FBakIsRUFBMEI7QUFDeEI7QUFDQSxZQUFJRyxJQUFJLENBQUNDLFFBQUwsQ0FBYyxHQUFkLENBQUosRUFBd0I7QUFDdEJELFVBQUFBLElBQUksR0FBR0EsSUFBSSxDQUFDRSxNQUFMLENBQVksQ0FBWixFQUFlQyxLQUFmLENBQXFCLENBQXJCLEVBQXdCLENBQUMsQ0FBekIsQ0FBUDtBQUNBLGdCQUFNQyxRQUFRLEdBQUdKLElBQUksQ0FBQ0ssS0FBTCxDQUFXLEdBQVgsQ0FBakI7O0FBQ0EsZUFBSyxNQUFNQyxPQUFYLElBQXNCRixRQUF0QixFQUFnQztBQUM5QkwsWUFBQUEsUUFBUSxDQUFDUSxJQUFULENBQWUsSUFBR0QsT0FBTyxDQUFDRSxJQUFSLEVBQWUsR0FBakM7QUFDRDtBQUNGLFNBTkQsTUFNTztBQUNMVCxVQUFBQSxRQUFRLENBQUNRLElBQVQsQ0FBY1AsSUFBZDtBQUNEO0FBQ0YsT0ExQkMsQ0E0QkY7OztBQUNBLFlBQU1TLEtBQUssR0FBR1YsUUFBUSxDQUFDVyxNQUFULENBQ1pWLElBQUksSUFBSUEsSUFBSSxDQUFDQyxRQUFMLENBQWMsR0FBZCxLQUFzQkQsSUFBSSxDQUFDQyxRQUFMLENBQWMsR0FBZCxDQURsQixDQUFkO0FBSUEsWUFBTU4sT0FBTyxHQUNYRixRQUFRLEtBQUssR0FBYixHQUFtQlgsT0FBTyxDQUFDWSxNQUFSLENBQWVDLE9BQWYsQ0FBdUJRLEtBQXZCLENBQTZCLENBQTdCLEVBQWdDLENBQUMsQ0FBakMsQ0FBbkIsR0FBeURyQixPQUFPLENBQUNZLE1BQVIsQ0FBZUMsT0FEMUU7QUFFQSxZQUFNZ0IsVUFBVSxHQUFHRixLQUFLLENBQUNDLE1BQU4sQ0FBYVYsSUFBSSxJQUFJO0FBQ3RDQSxRQUFBQSxJQUFJLEdBQUdBLElBQUksQ0FBQ0csS0FBTCxDQUFXLENBQVgsRUFBYyxDQUFDLENBQWYsQ0FBUDtBQUNBLGNBQU1WLFFBQVEsR0FBR08sSUFBSSxDQUFDQSxJQUFJLENBQUNKLE1BQUwsR0FBYyxDQUFmLENBQXJCO0FBQ0FJLFFBQUFBLElBQUksR0FBR1AsUUFBUSxLQUFLLEdBQWIsR0FBbUJPLElBQUksQ0FBQ0csS0FBTCxDQUFXLENBQVgsRUFBYyxDQUFDLENBQWYsQ0FBbkIsR0FBdUNILElBQTlDO0FBQ0EsZUFBT0EsSUFBSSxDQUFDQyxRQUFMLENBQWNOLE9BQWQsS0FBMEJBLE9BQU8sQ0FBQ00sUUFBUixDQUFpQkQsSUFBakIsQ0FBakM7QUFDRCxPQUxrQixDQUFuQjtBQU1BLHVCQUNFLDJCQURGLEVBRUcsc0JBQXFCVyxVQUFVLElBQUlDLEtBQUssQ0FBQ0MsT0FBTixDQUFjRixVQUFkLENBQWQsSUFBMkNBLFVBQVUsQ0FBQ2YsTUFBdEQsR0FDbEIsS0FEa0IsR0FFbEIsSUFDSCxFQUxILEVBTUUsT0FORjtBQVFBLGFBQU9lLFVBQVUsSUFBSUMsS0FBSyxDQUFDQyxPQUFOLENBQWNGLFVBQWQsQ0FBZCxJQUEyQ0EsVUFBVSxDQUFDZixNQUF0RCxHQUNIYixRQUFRLENBQUMrQixFQUFULENBQVk7QUFDWnZCLFFBQUFBLElBQUksRUFBRTtBQUNKd0IsVUFBQUEsVUFBVSxFQUFFLEdBRFI7QUFFSkMsVUFBQUEsTUFBTSxFQUFFLElBRko7QUFHSmhDLFVBQUFBLElBQUksRUFBRyxzQkFBcUJGLE9BQU8sQ0FBQ1ksTUFBUixDQUFlQyxPQUFRO0FBSC9DO0FBRE0sT0FBWixDQURHLEdBUUhaLFFBQVEsQ0FBQytCLEVBQVQsQ0FBWTtBQUNadkIsUUFBQUEsSUFBSSxFQUFFO0FBQ0p3QixVQUFBQSxVQUFVLEVBQUUsR0FEUjtBQUVKQyxVQUFBQSxNQUFNLEVBQUUsS0FGSjtBQUdKaEMsVUFBQUEsSUFBSSxFQUFHLHlCQUF3QkYsT0FBTyxDQUFDWSxNQUFSLENBQWVDLE9BQVE7QUFIbEQ7QUFETSxPQUFaLENBUko7QUFlRCxLQWhFRCxDQWdFRSxPQUFPc0IsS0FBUCxFQUFjO0FBQ2QsdUJBQUksMkJBQUosRUFBaUNBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBbEQ7QUFDQSxhQUFPLGtDQUNKLDBEQUF5REEsS0FBSyxDQUFDQyxPQUFOLElBQzFERCxLQUFNLEVBRkQsRUFHTCxJQUhLLEVBSUwsR0FKSyxFQUtMbEMsUUFMSyxDQUFQO0FBT0Q7QUFDRjtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDb0IsUUFBWm9DLFlBQVksQ0FBQ3RDLE9BQUQsRUFBaUNDLE9BQWpDLEVBQTRGQyxRQUE1RixFQUEySTtBQUMzSixRQUFJO0FBQ0YsWUFBTUMsSUFBSSxHQUFHLE1BQU1ILE9BQU8sQ0FBQ0ksSUFBUixDQUFhbUMsWUFBYixDQUEwQmpDLE1BQTFCLENBQWlDa0MsSUFBakMsQ0FBNkU7QUFBRUMsUUFBQUEsSUFBSSxFQUFFO0FBQVIsT0FBN0UsQ0FBbkI7QUFFQSxZQUFNQyxrQkFBa0IsR0FBR3ZDLElBQUksQ0FBQ3dDLGFBQUwsQ0FBbUJILElBQW5CLENBQ3pCckIsSUFBSSxJQUFJQSxJQUFJLENBQUN5QixVQUFMLENBQWdCQyxLQUFoQixLQUEwQjVDLE9BQU8sQ0FBQ1ksTUFBUixDQUFlQyxPQUR4QixDQUEzQjtBQUdBLHVCQUNFLDRCQURGLEVBRUcsd0JBQXVCNEIsa0JBQWtCLEdBQUdBLGtCQUFrQixDQUFDRSxVQUFuQixDQUE4QkMsS0FBakMsR0FBeUMsSUFBSyxFQUYxRixFQUdFLE9BSEY7QUFLQSxhQUFPSCxrQkFBa0IsR0FDckJ4QyxRQUFRLENBQUMrQixFQUFULENBQVk7QUFDWnZCLFFBQUFBLElBQUksRUFBRTtBQUFFd0IsVUFBQUEsVUFBVSxFQUFFLEdBQWQ7QUFBbUJDLFVBQUFBLE1BQU0sRUFBRSxJQUEzQjtBQUFpQ2hDLFVBQUFBLElBQUksRUFBRTtBQUF2QztBQURNLE9BQVosQ0FEcUIsR0FJckJELFFBQVEsQ0FBQytCLEVBQVQsQ0FBWTtBQUNadkIsUUFBQUEsSUFBSSxFQUFFO0FBQ0p3QixVQUFBQSxVQUFVLEVBQUUsR0FEUjtBQUVKQyxVQUFBQSxNQUFNLEVBQUUsS0FGSjtBQUdKQyxVQUFBQSxLQUFLLEVBQUUsS0FISDtBQUlKQyxVQUFBQSxPQUFPLEVBQUU7QUFKTDtBQURNLE9BQVosQ0FKSjtBQVlELEtBdkJELENBdUJFLE9BQU9ELEtBQVAsRUFBYztBQUNkLHVCQUFJLDRCQUFKLEVBQWtDQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQW5EO0FBQ0EsYUFBTyxrQ0FDSiw0RUFBMkVBLEtBQUssQ0FBQ0MsT0FBTixJQUM1RUQsS0FBTSxFQUZELEVBR0wsSUFISyxFQUlMLEdBSkssRUFLTGxDLFFBTEssQ0FBUDtBQU9EO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ21CLFFBQVg0QyxXQUFXLENBQUM5QyxPQUFELEVBQWlDQyxPQUFqQyxFQUFrS0MsUUFBbEssRUFBaU47QUFDaE8sUUFBSTtBQUNGO0FBQ0EsVUFBSTZDLE9BQU8sR0FBRztBQUNaQyxRQUFBQSxJQUFJLEVBQUUsQ0FETTtBQUVaQyxRQUFBQSxLQUFLLEVBQUU7QUFDTEMsVUFBQUEsSUFBSSxFQUFFO0FBQ0pDLFlBQUFBLElBQUksRUFBRSxFQURGO0FBRUpDLFlBQUFBLFFBQVEsRUFBRTtBQUNSQyxjQUFBQSxJQUFJLEVBQUU7QUFDSiw0QkFBWTtBQURSO0FBREUsYUFGTjtBQU9KeEIsWUFBQUEsTUFBTSxFQUFFLENBQ047QUFDRXlCLGNBQUFBLEtBQUssRUFBRTtBQUFFQyxnQkFBQUEsU0FBUyxFQUFFO0FBQWI7QUFEVCxhQURNO0FBUEo7QUFERCxTQUZLO0FBaUJaQyxRQUFBQSxJQUFJLEVBQUU7QUFDSixlQUFLO0FBQ0hDLFlBQUFBLEtBQUssRUFBRTtBQUNMQyxjQUFBQSxLQUFLLEVBQUUsRUFERjtBQUVMVixjQUFBQSxJQUFJLEVBQUUsQ0FGRDtBQUdMVyxjQUFBQSxLQUFLLEVBQUU7QUFBRUMsZ0JBQUFBLE1BQU0sRUFBRTtBQUFWO0FBSEY7QUFESjtBQUREO0FBakJNLE9BQWQsQ0FGRSxDQThCRjs7QUFDQSxZQUFNQyxPQUFPLEdBQUcsUUFBaEI7QUFDQSxZQUFNQyxNQUFNLEdBQUcsS0FBZjtBQUNBZixNQUFBQSxPQUFPLENBQUNFLEtBQVIsQ0FBY0MsSUFBZCxDQUFtQnJCLE1BQW5CLENBQTBCLENBQTFCLEVBQTZCeUIsS0FBN0IsQ0FBbUMsV0FBbkMsRUFBZ0QsS0FBaEQsSUFBeURPLE9BQXpEO0FBQ0FkLE1BQUFBLE9BQU8sQ0FBQ0UsS0FBUixDQUFjQyxJQUFkLENBQW1CckIsTUFBbkIsQ0FBMEIsQ0FBMUIsRUFBNkJ5QixLQUE3QixDQUFtQyxXQUFuQyxFQUFnRCxJQUFoRCxJQUF3RFEsTUFBeEQsQ0FsQ0UsQ0FvQ0Y7O0FBQ0FmLE1BQUFBLE9BQU8sQ0FBQ0UsS0FBUixDQUFjQyxJQUFkLENBQW1CQyxJQUFuQixDQUF3QnpCLElBQXhCLENBQ0V6QixPQUFPLENBQUNZLE1BQVIsQ0FBZWtELElBQWYsS0FBd0IsU0FBeEIsR0FDSTtBQUFFOUMsUUFBQUEsS0FBSyxFQUFFO0FBQUUsMEJBQWdCaEIsT0FBTyxDQUFDWSxNQUFSLENBQWVtRDtBQUFqQztBQUFULE9BREosR0FFSTtBQUFFL0MsUUFBQUEsS0FBSyxFQUFFO0FBQUUsMEJBQWdCaEIsT0FBTyxDQUFDWSxNQUFSLENBQWVtRDtBQUFqQztBQUFULE9BSE47QUFNQSxVQUFHL0QsT0FBTyxDQUFDZ0QsS0FBUixDQUFjZ0IsVUFBakIsRUFDRWxCLE9BQU8sQ0FBQ0UsS0FBUixDQUFjQyxJQUFkLENBQW1CckIsTUFBbkIsQ0FBMEJILElBQTFCLENBQ0U7QUFDRStCLFFBQUFBLEtBQUssRUFBRTtBQUNMLHNCQUFZeEQsT0FBTyxDQUFDZ0QsS0FBUixDQUFjZ0IsVUFBZCxDQUF5QnpDLEtBQXpCLENBQStCLEdBQS9CO0FBRFA7QUFEVCxPQURGO0FBT0Z1QixNQUFBQSxPQUFPLENBQUNTLElBQVIsQ0FBYSxHQUFiLEVBQWtCQyxLQUFsQixDQUF3QkMsS0FBeEIsR0FBZ0N6RCxPQUFPLENBQUNZLE1BQVIsQ0FBZTZDLEtBQS9DO0FBRUEsWUFBTXZELElBQUksR0FBRyxNQUFNSCxPQUFPLENBQUNJLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0I0RCxhQUEvQixDQUE2Q0MsTUFBN0MsQ0FBb0Q7QUFDckVuQixRQUFBQSxJQUFJLEVBQUUsQ0FEK0Q7QUFFckVvQixRQUFBQSxLQUFLLEVBQUVuRSxPQUFPLENBQUNZLE1BQVIsQ0FBZUMsT0FGK0M7QUFHckVKLFFBQUFBLElBQUksRUFBRXFDO0FBSCtELE9BQXBELENBQW5CO0FBTUEsYUFBTzVDLElBQUksQ0FBQ08sSUFBTCxDQUFVMkQsSUFBVixDQUFlQyxLQUFmLENBQXFCQyxLQUFyQixLQUErQixDQUEvQixJQUNMLE9BQU9wRSxJQUFJLENBQUNPLElBQUwsQ0FBVThELFlBQVYsQ0FBdUIsR0FBdkIsRUFBNEJDLE9BQTVCLENBQW9DLENBQXBDLENBQVAsS0FBa0QsV0FEN0MsR0FFSHZFLFFBQVEsQ0FBQytCLEVBQVQsQ0FBWTtBQUNadkIsUUFBQUEsSUFBSSxFQUFFO0FBQUV3QixVQUFBQSxVQUFVLEVBQUUsR0FBZDtBQUFtQi9CLFVBQUFBLElBQUksRUFBRTtBQUF6QjtBQURNLE9BQVosQ0FGRyxHQUtIRCxRQUFRLENBQUMrQixFQUFULENBQVk7QUFDWnZCLFFBQUFBLElBQUksRUFBRTtBQUNKd0IsVUFBQUEsVUFBVSxFQUFFLEdBRFI7QUFFSi9CLFVBQUFBLElBQUksRUFBRUEsSUFBSSxDQUFDTyxJQUFMLENBQVU4RCxZQUFWLENBQXVCLEdBQXZCLEVBQTRCQyxPQUE1QixDQUFvQyxDQUFwQyxFQUF1Q0M7QUFGekM7QUFETSxPQUFaLENBTEo7QUFXRCxLQXRFRCxDQXNFRSxPQUFPdEMsS0FBUCxFQUFjO0FBQ2QsdUJBQUksMkJBQUosRUFBaUNBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBbEQ7QUFDQSxhQUFPLGtDQUFjQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQS9CLEVBQXNDLElBQXRDLEVBQTRDLEdBQTVDLEVBQWlEbEMsUUFBakQsQ0FBUDtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ3FDLFFBQTdCeUUsNkJBQTZCLENBQUMzRSxPQUFELEVBQVU0RSxJQUFWLEVBQWdCQyxHQUFoQixFQUFxQjtBQUN0RDtBQUNBLFFBQUlDLFNBQVMsR0FBRyxFQUFoQjs7QUFDQSxTQUFLLElBQUkzRCxJQUFULElBQWlCeUQsSUFBakIsRUFBdUI7QUFDckIsVUFBSUcsT0FBTyxHQUFHLEtBQWQ7QUFBQSxVQUNFQyxTQUFTLEdBQUcsS0FEZDs7QUFFQSxVQUFJO0FBQ0ZELFFBQUFBLE9BQU8sR0FBRyxNQUFNL0UsT0FBTyxDQUFDSSxJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCNEQsYUFBL0IsQ0FBNkNDLE1BQTdDLENBQW9EO0FBQ2xFQyxVQUFBQSxLQUFLLEVBQUVqRCxJQUFJLENBQUMwQjtBQURzRCxTQUFwRCxDQUFoQjtBQUdELE9BSkQsQ0FJRSxPQUFPVCxLQUFQLEVBQWM7QUFDZDRDLFFBQUFBLFNBQVMsR0FBRyxJQUFaO0FBQ0Q7O0FBQ0QsVUFDRSxDQUFDLENBQUMsQ0FBQ0QsT0FBTyxJQUFJLEVBQVosRUFBZ0JyRSxJQUFoQixJQUF3QixFQUF6QixFQUE2QjJELElBQTdCLElBQXFDLEVBQXRDLEVBQTBDQyxLQUExQyxDQUFnREMsS0FBaEQsSUFBeUQsQ0FBekQsSUFDQyxDQUFDUyxTQUFELElBQWMsQ0FBQyxDQUFDLENBQUNELE9BQU8sSUFBSSxFQUFaLEVBQWdCckUsSUFBaEIsSUFBd0IsRUFBekIsRUFBNkIyRCxJQUE3QixJQUFxQyxFQUF0QyxFQUEwQ0MsS0FBMUMsS0FBb0QsQ0FGckUsRUFHRTtBQUNBUSxRQUFBQSxTQUFTLENBQUNwRCxJQUFWLENBQWVQLElBQWY7QUFDRDtBQUNGOztBQUNELFdBQU8yRCxTQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTs7O0FBQ0VHLEVBQUFBLG9CQUFvQixDQUFDQyxnQkFBRCxFQUFtQjtBQUNyQyxVQUFNQyxPQUFPLEdBQUcsQ0FBQyxXQUFELEVBQWMsYUFBZCxFQUE2QixjQUE3QixFQUE2QyxVQUE3QyxDQUFoQjtBQUNBLFFBQUlQLElBQUksR0FBRyxFQUFYOztBQUNBLFNBQUssTUFBTVIsS0FBWCxJQUFvQmMsZ0JBQXBCLEVBQXNDO0FBQ3BDLFVBQUlFLEtBQUosRUFBV0MsTUFBWDs7QUFDQSxVQUFJO0FBQ0ZBLFFBQUFBLE1BQU0sR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVduQixLQUFLLENBQUN4QixVQUFOLENBQWlCNEMsTUFBNUIsQ0FBVDtBQUNELE9BRkQsQ0FFRSxPQUFPcEQsS0FBUCxFQUFjO0FBQ2Q7QUFDRDs7QUFFRGdELE1BQUFBLEtBQUssR0FBR0MsTUFBTSxDQUFDeEQsTUFBUCxDQUFjVixJQUFJLElBQUlnRSxPQUFPLENBQUMvRCxRQUFSLENBQWlCRCxJQUFJLENBQUNzRSxJQUF0QixDQUF0QixDQUFSOztBQUNBLFVBQUlMLEtBQUssQ0FBQ3JFLE1BQU4sS0FBaUIsQ0FBckIsRUFBd0I7QUFDdEI2RCxRQUFBQSxJQUFJLENBQUNsRCxJQUFMLENBQVU7QUFDUmdFLFVBQUFBLEVBQUUsRUFBRXRCLEtBQUssQ0FBQ3NCLEVBREY7QUFFUjdDLFVBQUFBLEtBQUssRUFBRXVCLEtBQUssQ0FBQ3hCLFVBQU4sQ0FBaUJDO0FBRmhCLFNBQVY7QUFJRDtBQUNGOztBQUNELFdBQU8rQixJQUFQO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUMwQixRQUFsQmUsa0JBQWtCLENBQUMzRixPQUFELEVBQWlDQyxPQUFqQyxFQUF5RkMsUUFBekYsRUFBd0k7QUFDOUosUUFBSTtBQUNGLGFBQU9BLFFBQVEsQ0FBQytCLEVBQVQsQ0FBWTtBQUNqQnZCLFFBQUFBLElBQUksRUFBRTtBQUNKa0YsVUFBQUEsUUFBUSxFQUFFNUYsT0FBTyxDQUFDNkYsS0FBUixDQUFjQyxRQUFkLENBQXVCRjtBQUQ3QjtBQURXLE9BQVosQ0FBUDtBQUtELEtBTkQsQ0FNRSxPQUFPeEQsS0FBUCxFQUFjO0FBQ2QsdUJBQUksa0NBQUosRUFBd0NBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBekQ7QUFDQSxhQUFPLGtDQUFjQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQS9CLEVBQXNDLElBQXRDLEVBQTRDLEdBQTVDLEVBQWlEbEMsUUFBakQsQ0FBUDtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBOzs7QUFDOEIsUUFBdEI2RixzQkFBc0IsQ0FBQ0MsV0FBRCxFQUFjTixFQUFkLEVBQWtCTyxTQUFTLEdBQUcsS0FBOUIsRUFBcUM7QUFDL0QsUUFBSTtBQUNGLFlBQU1wRyxNQUFNLEdBQUcseUNBQWY7QUFDQSxVQUFJcUcsaUJBQWlCLEdBQ25CLENBQUNyRyxNQUFNLElBQUksRUFBWCxFQUFlLDBCQUFmLEtBQThDc0csbUNBRGhEO0FBRUEsdUJBQ0Usc0NBREYsRUFFRyxZQUFXSCxXQUFXLENBQUNqRixNQUFPLGlCQUZqQyxFQUdFLE9BSEY7QUFLQSx1QkFDRSxzQ0FERixFQUVHLHFCQUFvQjJFLEVBQUcsRUFGMUIsRUFHRSxPQUhGO0FBS0EsWUFBTVUsUUFBUSxHQUFHLEVBQWpCO0FBQ0EsVUFBSUMsVUFBSixFQUFnQkMsWUFBaEI7O0FBQ0EsV0FBSyxJQUFJQyxPQUFULElBQW9CUCxXQUFwQixFQUFpQztBQUMvQkssUUFBQUEsVUFBVSxHQUFHZixJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDa0IsU0FBTCxDQUFlRCxPQUFPLENBQUNFLE9BQXZCLENBQVgsQ0FBYixDQUQrQixDQUcvQjs7QUFDQSxZQUNFSixVQUFVLElBQ1ZBLFVBQVUsQ0FBQ0sscUJBRFgsSUFFQUwsVUFBVSxDQUFDSyxxQkFBWCxDQUFpQ0MsZ0JBRmpDLElBR0EsT0FBT04sVUFBVSxDQUFDSyxxQkFBWCxDQUFpQ0MsZ0JBQXhDLEtBQTZELFFBSi9ELEVBS0U7QUFDQSxnQkFBTUMsVUFBVSxHQUFHUCxVQUFVLENBQUNLLHFCQUFYLENBQWlDQyxnQkFBcEQ7QUFFQSxnQkFBTUUsWUFBWSxHQUFHRCxVQUFVLENBQUN4RixRQUFYLENBQW9CLGtCQUFwQixDQUFyQjs7QUFDQSxjQUFJeUYsWUFBSixFQUFrQjtBQUNoQixnQkFBSVosU0FBUyxJQUFJQSxTQUFTLEtBQUssU0FBL0IsRUFBMEM7QUFDeEMsa0JBQ0VDLGlCQUFpQixDQUFDOUUsUUFBbEIsQ0FBMkI2RSxTQUEzQixLQUNBQyxpQkFBaUIsQ0FBQzlFLFFBQWxCLENBQTJCLGdCQUEzQixDQUZGLEVBR0U7QUFDQThFLGdCQUFBQSxpQkFBaUIsR0FBR0EsaUJBQWlCLENBQUMxRSxLQUFsQixDQUNsQixnQkFEa0IsRUFFbEIsQ0FGa0IsQ0FBcEI7QUFHRDtBQUNGOztBQUNENkUsWUFBQUEsVUFBVSxDQUFDSyxxQkFBWCxDQUFpQ0MsZ0JBQWpDLEdBQW9EQyxVQUFVLENBQUNFLE9BQVgsQ0FDbEQsbUJBRGtELEVBRWxEWixpQkFBaUIsQ0FBQ0EsaUJBQWlCLENBQUNuRixNQUFsQixHQUEyQixDQUE1QixDQUFqQixLQUFvRCxHQUFwRCxJQUNHa0YsU0FBUyxJQUFJQSxTQUFTLEtBQUssU0FEOUIsR0FFSUMsaUJBRkosR0FHSUEsaUJBQWlCLEdBQUcsR0FMMEIsQ0FBcEQ7QUFPRCxXQWxCRCxNQWtCTztBQUNMRyxZQUFBQSxVQUFVLENBQUNLLHFCQUFYLENBQWlDQyxnQkFBakMsR0FBb0RDLFVBQVUsQ0FBQ0UsT0FBWCxDQUNsRCxlQURrRCxFQUVsRHBCLEVBRmtELENBQXBEO0FBSUQ7QUFDRixTQXJDOEIsQ0F1Qy9COzs7QUFDQSxZQUFJLE9BQU8sQ0FBQ1csVUFBVSxJQUFJLEVBQWYsRUFBbUJVLFFBQTFCLEtBQXVDLFFBQTNDLEVBQXFEO0FBQ25EVixVQUFBQSxVQUFVLENBQUNVLFFBQVgsR0FBc0JWLFVBQVUsQ0FBQ1UsUUFBWCxDQUFvQkQsT0FBcEIsQ0FDcEIsZUFEb0IsRUFFcEJwQixFQUZvQixDQUF0QjtBQUlELFNBN0M4QixDQStDL0I7OztBQUNBWSxRQUFBQSxZQUFZLEdBQUcsRUFBZjtBQUNBQSxRQUFBQSxZQUFZLENBQUNDLE9BQU8sQ0FBQ1MsS0FBVCxDQUFaLEdBQThCWCxVQUE5QjtBQUVBRCxRQUFBQSxRQUFRLENBQUMxRSxJQUFULENBQWM7QUFDWmtCLFVBQUFBLFVBQVUsRUFBRTBELFlBQVksQ0FBQ1csYUFEYjtBQUVaeEUsVUFBQUEsSUFBSSxFQUFFOEQsT0FBTyxDQUFDUyxLQUZGO0FBR1p0QixVQUFBQSxFQUFFLEVBQUVhLE9BQU8sQ0FBQ1csR0FIQTtBQUlaQyxVQUFBQSxRQUFRLEVBQUViLFlBQVksQ0FBQ1csYUFBYixDQUEyQkc7QUFKekIsU0FBZDtBQU1EOztBQUNELGFBQU9oQixRQUFQO0FBQ0QsS0EzRUQsQ0EyRUUsT0FBT2hFLEtBQVAsRUFBYztBQUNkLHVCQUFJLHNDQUFKLEVBQTRDQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQTdEO0FBQ0EsYUFBT2lGLE9BQU8sQ0FBQ0MsTUFBUixDQUFlbEYsS0FBZixDQUFQO0FBQ0Q7QUFDRjtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFbUYsRUFBQUEsNkJBQTZCLENBQzNCdkIsV0FEMkIsRUFFM0JOLEVBRjJCLEVBRzNCOEIsS0FBSyxHQUFHLEVBSG1CLEVBSTNCL0IsSUFKMkIsRUFLM0JnQyxXQUwyQixFQU0zQkMsWUFBWSxHQUFHLEdBTlksRUFPM0I7QUFDQSxRQUFJO0FBQ0YsWUFBTXRCLFFBQVEsR0FBRyxFQUFqQjtBQUNBLFVBQUlDLFVBQUosRUFBZ0JDLFlBQWhCOztBQUVBLFdBQUssTUFBTUMsT0FBWCxJQUFzQlAsV0FBdEIsRUFBbUM7QUFDakM7QUFDQUssUUFBQUEsVUFBVSxHQUFHZixJQUFJLENBQUNrQixTQUFMLENBQWVELE9BQU8sQ0FBQ0UsT0FBdkIsQ0FBYjtBQUNBSixRQUFBQSxVQUFVLEdBQUdBLFVBQVUsQ0FBQ1MsT0FBWCxDQUFtQixlQUFuQixFQUFvQ3BCLEVBQXBDLENBQWI7QUFDQVcsUUFBQUEsVUFBVSxHQUFHZixJQUFJLENBQUNDLEtBQUwsQ0FBV2MsVUFBWCxDQUFiLENBSmlDLENBTWpDOztBQUNBQyxRQUFBQSxZQUFZLEdBQUcsRUFBZjtBQUNBQSxRQUFBQSxZQUFZLENBQUNDLE9BQU8sQ0FBQ1MsS0FBVCxDQUFaLEdBQThCWCxVQUE5QjtBQUVBLGNBQU1VLFFBQVEsR0FBR3pCLElBQUksQ0FBQ0MsS0FBTCxDQUFXZSxZQUFZLENBQUNXLGFBQWIsQ0FBMkJGLFFBQXRDLENBQWpCO0FBQ0EsY0FBTWxFLEtBQUssR0FBR2tFLFFBQVEsQ0FBQ2xFLEtBQXZCOztBQUVBLFlBQUlrRSxRQUFRLENBQUN0RSxJQUFULElBQWlCc0UsUUFBUSxDQUFDdEUsSUFBVCxLQUFrQixVQUF2QyxFQUFtRDtBQUNqRCxjQUFJUSxLQUFLLEdBQUcsRUFBWjs7QUFDQSxjQUFJSixLQUFLLEtBQUssNEJBQWQsRUFBNEM7QUFDMUMsaUJBQUssTUFBTThFLElBQVgsSUFBbUJILEtBQW5CLEVBQTBCO0FBQ3hCdkUsY0FBQUEsS0FBSyxJQUFLLGFBQVl5RSxZQUFhLHFCQUFvQmpDLElBQUssc0JBQXFCa0MsSUFBSSxDQUFDbEMsSUFBSyxhQUFZa0MsSUFBSSxDQUFDbEMsSUFBSyxLQUFqSDtBQUNEOztBQUNEeEMsWUFBQUEsS0FBSyxHQUFHQSxLQUFLLENBQUMyRSxTQUFOLENBQWdCLENBQWhCLEVBQW1CM0UsS0FBSyxDQUFDbEMsTUFBTixHQUFlLENBQWxDLENBQVI7QUFDRCxXQUxELE1BS08sSUFBSThCLEtBQUssS0FBSyxvQ0FBZCxFQUFvRDtBQUN6REksWUFBQUEsS0FBSyxJQUFLLGFBQVl5RSxZQUFhLHFCQUFvQmpDLElBQUssYUFBWUEsSUFBSyxZQUE3RTtBQUNELFdBRk0sTUFFQTtBQUNMLGdCQUFJNUMsS0FBSyxDQUFDZ0YsVUFBTixDQUFpQixzQkFBakIsQ0FBSixFQUE4QztBQUM1QyxvQkFBTTtBQUFFbEIsZ0JBQUFBO0FBQUYsa0JBQXVCTCxZQUFZLENBQUNXLGFBQWIsQ0FBMkJQLHFCQUF4RDtBQUNBSixjQUFBQSxZQUFZLENBQUNXLGFBQWIsQ0FBMkJQLHFCQUEzQixDQUFpREMsZ0JBQWpELEdBQW9FQSxnQkFBZ0IsQ0FBQ0csT0FBakIsQ0FBeUIsb0JBQXpCLEVBQStDWSxZQUEvQyxDQUFwRTtBQUNEOztBQUNELGdCQUFJN0UsS0FBSyxDQUFDZ0YsVUFBTixDQUFpQixzQkFBakIsS0FBNENwQyxJQUFJLEtBQUssR0FBckQsSUFBNERBLElBQUksS0FBSyxLQUFyRSxJQUE4RXNCLFFBQVEsQ0FBQ2xHLE1BQVQsQ0FBZ0JpSCxVQUFoQixDQUEyQjFHLFFBQTNCLENBQW9DLElBQXBDLENBQWxGLEVBQTZIO0FBQzNILG9CQUFNMkcsZUFBZSxHQUFHLFVBQXhCOztBQUNBLG9CQUFNQyxTQUFTLEdBQUcxQixZQUFZLENBQUNXLGFBQWIsQ0FBMkJnQixjQUEzQixHQUNkM0MsSUFBSSxDQUFDQyxLQUFMLENBQVdlLFlBQVksQ0FBQ1csYUFBYixDQUEyQmdCLGNBQXRDLENBRGMsR0FFZGxCLFFBRko7O0FBR0E5RCxjQUFBQSxLQUFLLElBQUkrRSxTQUFTLENBQUNuSCxNQUFWLENBQWlCaUgsVUFBakIsQ0FBNEJoQixPQUE1QixDQUFvQyxzQkFBcEMsRUFBNERZLFlBQTVELEVBQTBFWixPQUExRSxDQUFrRmlCLGVBQWxGLEVBQW9HLHVCQUFzQnRDLElBQUssd0JBQXVCZ0MsV0FBWSxHQUFsSyxFQUNOWCxPQURNLENBQ0UsV0FERixFQUNlckIsSUFEZixDQUFUO0FBRUQsYUFQRCxNQU9PLElBQUk1QyxLQUFLLENBQUNnRixVQUFOLENBQWlCLHNCQUFqQixDQUFKLEVBQThDO0FBQ25ELG9CQUFNRSxlQUFlLEdBQUcsVUFBeEI7QUFDQTlFLGNBQUFBLEtBQUssSUFBSThELFFBQVEsQ0FBQ2xHLE1BQVQsQ0FBZ0JpSCxVQUFoQixDQUEyQmhCLE9BQTNCLENBQW1DLHNCQUFuQyxFQUEyRFksWUFBM0QsRUFBeUVaLE9BQXpFLENBQWlGaUIsZUFBakYsRUFBbUcsc0JBQXFCTixXQUFZLEdBQXBJLENBQVQ7QUFDRCxhQUhNLE1BR0E7QUFDTHhFLGNBQUFBLEtBQUssR0FBRzhELFFBQVEsQ0FBQ2xHLE1BQVQsQ0FBZ0JpSCxVQUF4QjtBQUNEO0FBQ0Y7O0FBRURmLFVBQUFBLFFBQVEsQ0FBQ2xHLE1BQVQsQ0FBZ0JpSCxVQUFoQixHQUE2QjdFLEtBQUssQ0FBQzZELE9BQU4sQ0FBYyxJQUFkLEVBQW9CLElBQXBCLENBQTdCO0FBQ0FSLFVBQUFBLFlBQVksQ0FBQ1csYUFBYixDQUEyQkYsUUFBM0IsR0FBc0N6QixJQUFJLENBQUNrQixTQUFMLENBQWVPLFFBQWYsQ0FBdEM7QUFDRDs7QUFFRFgsUUFBQUEsUUFBUSxDQUFDMUUsSUFBVCxDQUFjO0FBQ1prQixVQUFBQSxVQUFVLEVBQUUwRCxZQUFZLENBQUNXLGFBRGI7QUFFWnhFLFVBQUFBLElBQUksRUFBRThELE9BQU8sQ0FBQ1MsS0FGRjtBQUdadEIsVUFBQUEsRUFBRSxFQUFFYSxPQUFPLENBQUNXLEdBSEE7QUFJWkMsVUFBQUEsUUFBUSxFQUFFYixZQUFZLENBQUNXLGFBQWIsQ0FBMkJHO0FBSnpCLFNBQWQ7QUFNRDs7QUFFRCxhQUFPaEIsUUFBUDtBQUNELEtBM0RELENBMkRFLE9BQU9oRSxLQUFQLEVBQWM7QUFDZCx1QkFDRSw2Q0FERixFQUVFQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBRm5CO0FBSUEsYUFBT2lGLE9BQU8sQ0FBQ0MsTUFBUixDQUFlbEYsS0FBZixDQUFQO0FBQ0Q7QUFDRjtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDaUIsUUFBVDhGLFNBQVMsQ0FBQ2xJLE9BQUQsRUFBaUNDLE9BQWpDLEVBQXlHQyxRQUF6RyxFQUF3SjtBQUNySyxRQUFJO0FBQ0YsVUFDRyxDQUFDRCxPQUFPLENBQUNZLE1BQVIsQ0FBZXNILEdBQWYsQ0FBbUIvRyxRQUFuQixDQUE0QixXQUE1QixDQUFELElBQ0MsQ0FBQ25CLE9BQU8sQ0FBQ1ksTUFBUixDQUFlc0gsR0FBZixDQUFtQi9HLFFBQW5CLENBQTRCLFNBQTVCLENBRkwsRUFHRTtBQUNBLGNBQU0sSUFBSVQsS0FBSixDQUFVLDRDQUFWLENBQU47QUFDRDs7QUFFRCxZQUFNeUgsU0FBUyxHQUFHbkksT0FBTyxDQUFDWSxNQUFSLENBQWVzSCxHQUFmLENBQW1CL0csUUFBbkIsQ0FBNEIsVUFBNUIsSUFDZCxVQURjLEdBRWQsUUFGSjtBQUlBLFlBQU1pSCxRQUFRLEdBQUdwSSxPQUFPLENBQUNZLE1BQVIsQ0FBZXNILEdBQWYsQ0FBbUIzRyxLQUFuQixDQUF5QixHQUF6QixDQUFqQjtBQUNBLFlBQU04RyxRQUFRLEdBQUdELFFBQVEsQ0FBQyxDQUFELENBQXpCO0FBRUEsWUFBTUUsSUFBSSxHQUNSSCxTQUFTLEtBQUssVUFBZCxHQUNJSSx1Q0FBdUJGLFFBQXZCLENBREosR0FFSUcscUNBQXFCSCxRQUFyQixDQUhOOztBQUlBLFVBQUksQ0FBQ0MsSUFBTCxFQUFXO0FBQ1QsZUFBT3JJLFFBQVEsQ0FBQ3dJLFFBQVQsQ0FBa0I7QUFBQ2hJLFVBQUFBLElBQUksRUFBQztBQUFDMkIsWUFBQUEsT0FBTyxFQUFHLGdDQUErQnBDLE9BQU8sQ0FBQ1ksTUFBUixDQUFlc0gsR0FBSTtBQUE3RDtBQUFOLFNBQWxCLENBQVA7QUFDRDs7QUFDRCx1QkFBSSx5QkFBSixFQUFnQyxHQUFFQyxTQUFVLElBQUdFLFFBQVMsd0JBQXVCckksT0FBTyxDQUFDWSxNQUFSLENBQWVDLE9BQVEsRUFBdEcsRUFBeUcsT0FBekc7QUFDQSxZQUFNNkgsR0FBRyxHQUFHLE1BQU0sS0FBSzVDLHNCQUFMLENBQ2hCd0MsSUFEZ0IsRUFFaEJ0SSxPQUFPLENBQUNZLE1BQVIsQ0FBZUMsT0FGQyxDQUFsQjtBQUlBLGFBQU9aLFFBQVEsQ0FBQytCLEVBQVQsQ0FBWTtBQUNqQnZCLFFBQUFBLElBQUksRUFBRTtBQUFFa0ksVUFBQUEsV0FBVyxFQUFFLElBQWY7QUFBcUJELFVBQUFBLEdBQUcsRUFBRUE7QUFBMUI7QUFEVyxPQUFaLENBQVA7QUFHRCxLQTlCRCxDQThCRSxPQUFPdkcsS0FBUCxFQUFjO0FBQ2QsdUJBQUkseUJBQUosRUFBK0JBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBaEQ7QUFDQSxhQUFPLGtDQUFjQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQS9CLEVBQXNDLElBQXRDLEVBQTRDLEdBQTVDLEVBQWlEbEMsUUFBakQsQ0FBUDtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ3dCLFFBQWhCMkksZ0JBQWdCLENBQUM3SSxPQUFELEVBQWlDQyxPQUFqQyxFQUF1SEMsUUFBdkgsRUFBc0s7QUFDMUwsUUFBSTtBQUNGLFVBQ0UsQ0FBQ0QsT0FBTyxDQUFDWSxNQUFSLENBQWVDLE9BQWhCLElBQ0EsQ0FBQ2IsT0FBTyxDQUFDWSxNQUFSLENBQWVzSCxHQURoQixJQUVBLENBQUNsSSxPQUFPLENBQUNTLElBRlQsSUFHQSxDQUFDVCxPQUFPLENBQUNTLElBQVIsQ0FBYThHLEtBSGQsSUFJQSxDQUFDdkgsT0FBTyxDQUFDUyxJQUFSLENBQWE4RyxLQUFiLENBQW1Cc0IsY0FKcEIsSUFLQSxDQUFDN0ksT0FBTyxDQUFDUyxJQUFSLENBQWE4RyxLQUFiLENBQW1CL0IsSUFMcEIsSUFNQ3hGLE9BQU8sQ0FBQ1ksTUFBUixDQUFlc0gsR0FBZixJQUFzQixDQUFDbEksT0FBTyxDQUFDWSxNQUFSLENBQWVzSCxHQUFmLENBQW1CL0csUUFBbkIsQ0FBNEIsVUFBNUIsQ0FQMUIsRUFRRTtBQUNBLGNBQU0sSUFBSVQsS0FBSixDQUFVLDRDQUFWLENBQU47QUFDRDs7QUFFRCxZQUFNOEIsSUFBSSxHQUFHeEMsT0FBTyxDQUFDWSxNQUFSLENBQWVzSCxHQUFmLENBQW1CM0csS0FBbkIsQ0FBeUIsR0FBekIsRUFBOEIsQ0FBOUIsQ0FBYjtBQUVBLFlBQU0rRyxJQUFJLEdBQUdRLHNDQUFzQnRHLElBQXRCLENBQWI7QUFDQSxZQUFNK0UsS0FBSyxHQUFHdkgsT0FBTyxDQUFDUyxJQUFSLENBQWE4RyxLQUFiLENBQW1Cc0IsY0FBakM7QUFDQSxZQUFNckQsSUFBSSxHQUFHeEYsT0FBTyxDQUFDUyxJQUFSLENBQWE4RyxLQUFiLENBQW1CL0IsSUFBaEM7QUFDQSxZQUFNdUQsVUFBVSxHQUFHL0ksT0FBTyxDQUFDUyxJQUFSLENBQWE4RyxLQUFiLENBQW1CQyxXQUF0QztBQUVBLFlBQU07QUFBRS9CLFFBQUFBLEVBQUUsRUFBRXVELFNBQU47QUFBaUJwRyxRQUFBQSxLQUFLLEVBQUVxRztBQUF4QixVQUF3Q2pKLE9BQU8sQ0FBQ1MsSUFBUixDQUFhSSxPQUEzRDtBQUVBLFlBQU02SCxHQUFHLEdBQUcsTUFBTSxLQUFLcEIsNkJBQUwsQ0FDaEJnQixJQURnQixFQUVoQlUsU0FGZ0IsRUFHaEJ6QixLQUhnQixFQUloQi9CLElBSmdCLEVBS2hCdUQsVUFMZ0IsRUFNaEJFLFdBTmdCLENBQWxCO0FBU0EsYUFBT2hKLFFBQVEsQ0FBQytCLEVBQVQsQ0FBWTtBQUNqQnZCLFFBQUFBLElBQUksRUFBRTtBQUFFa0ksVUFBQUEsV0FBVyxFQUFFLElBQWY7QUFBcUJELFVBQUFBLEdBQUcsRUFBRUE7QUFBMUI7QUFEVyxPQUFaLENBQVA7QUFHRCxLQWxDRCxDQWtDRSxPQUFPdkcsS0FBUCxFQUFjO0FBQ2QsdUJBQUksZ0NBQUosRUFBc0NBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBdkQ7QUFDQSxhQUFPLGtDQUFjQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQS9CLEVBQXNDLElBQXRDLEVBQTRDLEdBQTVDLEVBQWlEbEMsUUFBakQsQ0FBUDtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDd0IsUUFBaEJpSixnQkFBZ0IsQ0FBQ25KLE9BQUQsRUFBaUNDLE9BQWpDLEVBQXVFQyxRQUF2RSxFQUFzSDtBQUMxSSxRQUFJO0FBQ0Y7QUFDQSxZQUFNNkUsT0FBTyxHQUFHLE1BQU1zQyxPQUFPLENBQUMrQixHQUFSLENBQVlDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZQyxxREFBWixFQUMvQkMsR0FEK0IsQ0FDMUI1SixRQUFELElBQWNJLE9BQU8sQ0FBQ0ksSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUF4QixDQUErQjRELGFBQS9CLENBQTZDdUYsT0FBN0MsQ0FBcURDLE1BQXJELENBQTREO0FBQzdFdEYsUUFBQUEsS0FBSyxFQUFFLEtBQUt6RSwwQkFBTCxDQUFnQ0MsUUFBaEM7QUFEc0UsT0FBNUQsQ0FEYSxDQUFaLENBQXRCO0FBSUEsYUFBT00sUUFBUSxDQUFDK0IsRUFBVCxDQUFZO0FBQ2pCdkIsUUFBQUEsSUFBSSxFQUFFO0FBQUVpSixVQUFBQSxxQkFBcUIsRUFBRTVFLE9BQU8sQ0FBQzZFLElBQVIsQ0FBYUMsTUFBTSxJQUFJQSxNQUFNLENBQUNuSixJQUE5QjtBQUF6QjtBQURXLE9BQVosQ0FBUDtBQUdELEtBVEQsQ0FTRSxPQUFPMEIsS0FBUCxFQUFjO0FBQ2QsYUFBTyxrQ0FBYyxrQ0FBZCxFQUFrRCxJQUFsRCxFQUF3RCxHQUF4RCxFQUE2RGxDLFFBQTdELENBQVA7QUFDRDtBQUNGO0FBQ0Q7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ2tDLFFBQTFCNEosMEJBQTBCLENBQUM5SixPQUFELEVBQWlDQyxPQUFqQyxFQUE2RkMsUUFBN0YsRUFBNEk7QUFDMUssUUFBSTtBQUNGLFlBQU02SixpQkFBaUIsR0FBRyxLQUFLcEssMEJBQUwsQ0FBZ0NNLE9BQU8sQ0FBQ1ksTUFBUixDQUFlakIsUUFBL0MsQ0FBMUIsQ0FERSxDQUVGOztBQUNBLFlBQU1vSyxpQkFBaUIsR0FBRyxNQUFNaEssT0FBTyxDQUFDSSxJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCNEQsYUFBL0IsQ0FBNkN1RixPQUE3QyxDQUFxREMsTUFBckQsQ0FBNEQ7QUFDMUZ0RixRQUFBQSxLQUFLLEVBQUUyRjtBQURtRixPQUE1RCxDQUFoQztBQUdBLGFBQU83SixRQUFRLENBQUMrQixFQUFULENBQVk7QUFDakJ2QixRQUFBQSxJQUFJLEVBQUU7QUFBRTBELFVBQUFBLEtBQUssRUFBRTJGLGlCQUFUO0FBQTRCTCxVQUFBQSxNQUFNLEVBQUVNLGlCQUFpQixDQUFDdEo7QUFBdEQ7QUFEVyxPQUFaLENBQVA7QUFHRCxLQVRELENBU0UsT0FBTzBCLEtBQVAsRUFBYztBQUNkLHVCQUNFLDBDQURGLEVBRUcsc0RBQXFEQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQU0sRUFGL0U7QUFLQSxZQUFNLENBQUNGLFVBQUQsRUFBYStILFlBQWIsSUFBNkIsS0FBS0MsZUFBTCxDQUFxQjlILEtBQXJCLENBQW5DO0FBQ0EsYUFBTyxrQ0FBZSxzREFBcUQ2SCxZQUFZLElBQUk3SCxLQUFNLEVBQTFGLEVBQTZGLElBQTdGLEVBQW1HRixVQUFuRyxFQUErR2hDLFFBQS9HLENBQVA7QUFDRDtBQUNGO0FBQ0Q7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQzBCLFFBQWxCaUssa0JBQWtCLENBQUNuSyxPQUFELEVBQWlDQyxPQUFqQyxFQUE2RkMsUUFBN0YsRUFBNEk7QUFDbEssVUFBTTZKLGlCQUFpQixHQUFHLEtBQUtwSywwQkFBTCxDQUFnQ00sT0FBTyxDQUFDWSxNQUFSLENBQWVqQixRQUEvQyxDQUExQjs7QUFFQSxRQUFJO0FBQ0Y7QUFDQSxZQUFNd0ssS0FBSyxHQUFHLGtDQUFxQm5LLE9BQU8sQ0FBQ29LLE9BQVIsQ0FBZ0JDLE1BQXJDLEVBQTZDLFVBQTdDLENBQWQ7O0FBQ0EsVUFBSSxDQUFDRixLQUFMLEVBQVk7QUFDVixlQUFPLGtDQUFjLG1CQUFkLEVBQW1DLEdBQW5DLEVBQXdDLEdBQXhDLEVBQTZDbEssUUFBN0MsQ0FBUDtBQUNEOztBQUFBO0FBQ0QsWUFBTXFLLFlBQVksR0FBRyx3QkFBVUgsS0FBVixDQUFyQjs7QUFDQSxVQUFJLENBQUNHLFlBQUwsRUFBbUI7QUFDakIsZUFBTyxrQ0FBYyx5QkFBZCxFQUF5QyxHQUF6QyxFQUE4QyxHQUE5QyxFQUFtRHJLLFFBQW5ELENBQVA7QUFDRDs7QUFBQTs7QUFDRCxVQUFJLENBQUNxSyxZQUFZLENBQUNDLFVBQWQsSUFBNEIsQ0FBQ0QsWUFBWSxDQUFDQyxVQUFiLENBQXdCcEosUUFBeEIsQ0FBaUNxSixzQ0FBakMsQ0FBakMsRUFBZ0c7QUFDOUYsZUFBTyxrQ0FBYyx1QkFBZCxFQUF1QyxHQUF2QyxFQUE0QyxHQUE1QyxFQUFpRHZLLFFBQWpELENBQVA7QUFDRDs7QUFBQSxPQVpDLENBYUY7O0FBQ0EsWUFBTXdLLFNBQVMsR0FBRyxrQ0FBcUJ6SyxPQUFPLENBQUNvSyxPQUFSLENBQWdCQyxNQUFyQyxFQUE2QyxRQUE3QyxDQUFsQjs7QUFDQSxVQUFJLENBQUNJLFNBQUwsRUFBZ0I7QUFDZCxlQUFPLGtDQUFjLG9CQUFkLEVBQW9DLEdBQXBDLEVBQXlDLEdBQXpDLEVBQThDeEssUUFBOUMsQ0FBUDtBQUNEOztBQUFBO0FBQ0QsWUFBTXlLLHNCQUFzQixHQUFHLE1BQU0zSyxPQUFPLENBQUM2RixLQUFSLENBQWMrRSxHQUFkLENBQWtCdEssTUFBbEIsQ0FBeUI0RCxhQUF6QixDQUF1Q2pFLE9BQXZDLENBQStDLEtBQS9DLEVBQXVELElBQXZELEVBQTRELEVBQTVELEVBQWdFO0FBQUV5SyxRQUFBQTtBQUFGLE9BQWhFLENBQXJDOztBQUNBLFVBQUlDLHNCQUFzQixDQUFDeEksTUFBdkIsS0FBa0MsR0FBdEMsRUFBMkM7QUFDekMsZUFBTyxrQ0FBYyxvQkFBZCxFQUFvQyxHQUFwQyxFQUF5QyxHQUF6QyxFQUE4Q2pDLFFBQTlDLENBQVA7QUFDRDs7QUFBQTtBQUVELFlBQU0ySyxVQUFVLEdBQUd2RixJQUFJLENBQUNrQixTQUFMLENBQWU7QUFDaENwQyxRQUFBQSxLQUFLLEVBQUU7QUFDTDBHLFVBQUFBLE1BQU0sRUFBRWY7QUFESDtBQUR5QixPQUFmLENBQW5CO0FBS0EsWUFBTWdCLG1CQUFtQixHQUFHOUssT0FBTyxDQUFDUyxJQUFSLElBQWdCVCxPQUFPLENBQUNTLElBQVIsQ0FBYUcsTUFBN0IsSUFBdUMsRUFBbkU7O0FBRUEsWUFBTW1LLFlBQVksR0FBR3pCLHNEQUEyQ3RKLE9BQU8sQ0FBQ1ksTUFBUixDQUFlakIsUUFBMUQsRUFBb0U0SixHQUFwRSxDQUF5RXlCLFNBQUQsSUFBZSwwQ0FBZSxFQUFFLEdBQUdBLFNBQUw7QUFBZ0IsV0FBR0Y7QUFBbkIsT0FBZixFQUF5RDlLLE9BQU8sQ0FBQ1MsSUFBUixDQUFhd0ssTUFBYixJQUF1QkQsU0FBUyxDQUFDQyxNQUFqQyxJQUEyQ0Msb0RBQXBHLENBQXZGLEVBQXVPQyxJQUF2TyxFQUFyQjs7QUFDQSxZQUFNQyxJQUFJLEdBQUdMLFlBQVksQ0FBQ3hCLEdBQWIsQ0FBaUI4QixXQUFXLElBQUssR0FBRVQsVUFBVyxLQUFJdkYsSUFBSSxDQUFDa0IsU0FBTCxDQUFlOEUsV0FBZixDQUE0QixJQUE5RSxFQUFtRkMsSUFBbkYsQ0FBd0YsRUFBeEYsQ0FBYixDQS9CRSxDQWlDRjtBQUVBOztBQUNBLFlBQU12QixpQkFBaUIsR0FBRyxNQUFNaEssT0FBTyxDQUFDSSxJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCNEQsYUFBL0IsQ0FBNkN1RixPQUE3QyxDQUFxREMsTUFBckQsQ0FBNEQ7QUFDMUZ0RixRQUFBQSxLQUFLLEVBQUUyRjtBQURtRixPQUE1RCxDQUFoQzs7QUFHQSxVQUFJLENBQUNDLGlCQUFpQixDQUFDdEosSUFBdkIsRUFBNkI7QUFDM0I7QUFFQSxjQUFNOEssYUFBYSxHQUFHO0FBQ3BCQyxVQUFBQSxRQUFRLEVBQUU7QUFDUnJILFlBQUFBLEtBQUssRUFBRTtBQUNMc0gsY0FBQUEsZ0JBQWdCLEVBQUVDLDJDQURiO0FBRUxDLGNBQUFBLGtCQUFrQixFQUFFQztBQUZmO0FBREM7QUFEVSxTQUF0QjtBQVNBLGNBQU03TCxPQUFPLENBQUNJLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0I0RCxhQUEvQixDQUE2Q3VGLE9BQTdDLENBQXFEcUMsTUFBckQsQ0FBNEQ7QUFDaEUxSCxVQUFBQSxLQUFLLEVBQUUyRixpQkFEeUQ7QUFFaEVySixVQUFBQSxJQUFJLEVBQUU4SztBQUYwRCxTQUE1RCxDQUFOO0FBSUEseUJBQ0Usa0NBREYsRUFFRyxXQUFVekIsaUJBQWtCLFFBRi9CLEVBR0UsT0FIRjtBQUtEOztBQUVELFlBQU0vSixPQUFPLENBQUNJLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0I0RCxhQUEvQixDQUE2Q21ILElBQTdDLENBQWtEO0FBQ3REakgsUUFBQUEsS0FBSyxFQUFFMkYsaUJBRCtDO0FBRXREckosUUFBQUEsSUFBSSxFQUFFMks7QUFGZ0QsT0FBbEQsQ0FBTjtBQUlBLHVCQUNFLGtDQURGLEVBRUcsMEJBQXlCdEIsaUJBQWtCLFFBRjlDLEVBR0UsT0FIRjtBQUtBLGFBQU83SixRQUFRLENBQUMrQixFQUFULENBQVk7QUFDakJ2QixRQUFBQSxJQUFJLEVBQUU7QUFBRTBELFVBQUFBLEtBQUssRUFBRTJGLGlCQUFUO0FBQTRCZ0MsVUFBQUEsVUFBVSxFQUFFZixZQUFZLENBQUNqSztBQUFyRDtBQURXLE9BQVosQ0FBUDtBQUdELEtBMUVELENBMEVFLE9BQU9xQixLQUFQLEVBQWM7QUFDZCx1QkFDRSxrQ0FERixFQUVHLGlDQUFnQzJILGlCQUFrQixXQUFVM0gsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUFNLEVBRnRGO0FBS0EsWUFBTSxDQUFDRixVQUFELEVBQWErSCxZQUFiLElBQTZCLEtBQUtDLGVBQUwsQ0FBcUI5SCxLQUFyQixDQUFuQztBQUVBLGFBQU8sa0NBQWM2SCxZQUFZLElBQUk3SCxLQUE5QixFQUFxQyxJQUFyQyxFQUEyQ0YsVUFBM0MsRUFBdURoQyxRQUF2RCxDQUFQO0FBQ0Q7QUFDRjtBQUNEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDMEIsUUFBbEI4TCxrQkFBa0IsQ0FBQ2hNLE9BQUQsRUFBaUNDLE9BQWpDLEVBQTZGQyxRQUE3RixFQUE0STtBQUNsSztBQUVBLFVBQU02SixpQkFBaUIsR0FBRyxLQUFLcEssMEJBQUwsQ0FBZ0NNLE9BQU8sQ0FBQ1ksTUFBUixDQUFlakIsUUFBL0MsQ0FBMUI7O0FBRUEsUUFBSTtBQUNGO0FBQ0EsWUFBTXdLLEtBQUssR0FBRyxrQ0FBcUJuSyxPQUFPLENBQUNvSyxPQUFSLENBQWdCQyxNQUFyQyxFQUE2QyxVQUE3QyxDQUFkOztBQUNBLFVBQUksQ0FBQ0YsS0FBTCxFQUFZO0FBQ1YsZUFBTyxrQ0FBYyxtQkFBZCxFQUFtQyxHQUFuQyxFQUF3QyxHQUF4QyxFQUE2Q2xLLFFBQTdDLENBQVA7QUFDRDs7QUFBQTtBQUNELFlBQU1xSyxZQUFZLEdBQUcsd0JBQVVILEtBQVYsQ0FBckI7O0FBQ0EsVUFBSSxDQUFDRyxZQUFMLEVBQW1CO0FBQ2pCLGVBQU8sa0NBQWMseUJBQWQsRUFBeUMsR0FBekMsRUFBOEMsR0FBOUMsRUFBbURySyxRQUFuRCxDQUFQO0FBQ0Q7O0FBQUE7O0FBQ0QsVUFBSSxDQUFDcUssWUFBWSxDQUFDQyxVQUFkLElBQTRCLENBQUNELFlBQVksQ0FBQ0MsVUFBYixDQUF3QnBKLFFBQXhCLENBQWlDcUosc0NBQWpDLENBQWpDLEVBQWdHO0FBQzlGLGVBQU8sa0NBQWMsdUJBQWQsRUFBdUMsR0FBdkMsRUFBNEMsR0FBNUMsRUFBaUR2SyxRQUFqRCxDQUFQO0FBQ0Q7O0FBQUEsT0FaQyxDQWFGOztBQUNBLFlBQU13SyxTQUFTLEdBQUcsa0NBQXFCekssT0FBTyxDQUFDb0ssT0FBUixDQUFnQkMsTUFBckMsRUFBNkMsUUFBN0MsQ0FBbEI7O0FBQ0EsVUFBSSxDQUFDSSxTQUFMLEVBQWdCO0FBQ2QsZUFBTyxrQ0FBYyxvQkFBZCxFQUFvQyxHQUFwQyxFQUF5QyxHQUF6QyxFQUE4Q3hLLFFBQTlDLENBQVA7QUFDRDs7QUFBQTtBQUNELFlBQU15SyxzQkFBc0IsR0FBRyxNQUFNM0ssT0FBTyxDQUFDNkYsS0FBUixDQUFjK0UsR0FBZCxDQUFrQnRLLE1BQWxCLENBQXlCNEQsYUFBekIsQ0FBdUNqRSxPQUF2QyxDQUErQyxLQUEvQyxFQUF1RCxJQUF2RCxFQUE0RCxFQUE1RCxFQUFnRTtBQUFFeUssUUFBQUE7QUFBRixPQUFoRSxDQUFyQzs7QUFDQSxVQUFJQyxzQkFBc0IsQ0FBQ3hJLE1BQXZCLEtBQWtDLEdBQXRDLEVBQTJDO0FBQ3pDLGVBQU8sa0NBQWMsb0JBQWQsRUFBb0MsR0FBcEMsRUFBeUMsR0FBekMsRUFBOENqQyxRQUE5QyxDQUFQO0FBQ0Q7O0FBQUEsT0FyQkMsQ0F1QkY7O0FBQ0EsWUFBTThKLGlCQUFpQixHQUFHLE1BQU1oSyxPQUFPLENBQUNJLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0I0RCxhQUEvQixDQUE2Q3VGLE9BQTdDLENBQXFEQyxNQUFyRCxDQUE0RDtBQUMxRnRGLFFBQUFBLEtBQUssRUFBRTJGO0FBRG1GLE9BQTVELENBQWhDOztBQUdBLFVBQUlDLGlCQUFpQixDQUFDdEosSUFBdEIsRUFBNEI7QUFDMUI7QUFDQSxjQUFNVixPQUFPLENBQUNJLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0I0RCxhQUEvQixDQUE2Q3VGLE9BQTdDLENBQXFEd0MsTUFBckQsQ0FBNEQ7QUFBRTdILFVBQUFBLEtBQUssRUFBRTJGO0FBQVQsU0FBNUQsQ0FBTjtBQUNBLHlCQUNFLGtDQURGLEVBRUcsV0FBVUEsaUJBQWtCLFFBRi9CLEVBR0UsT0FIRjtBQUtBLGVBQU83SixRQUFRLENBQUMrQixFQUFULENBQVk7QUFDakJ2QixVQUFBQSxJQUFJLEVBQUU7QUFBRW1KLFlBQUFBLE1BQU0sRUFBRSxTQUFWO0FBQXFCekYsWUFBQUEsS0FBSyxFQUFFMkY7QUFBNUI7QUFEVyxTQUFaLENBQVA7QUFHRCxPQVhELE1BV087QUFDTCxlQUFPLGtDQUFlLEdBQUVBLGlCQUFrQixzQkFBbkMsRUFBMEQsSUFBMUQsRUFBZ0UsR0FBaEUsRUFBcUU3SixRQUFyRSxDQUFQO0FBQ0Q7QUFDRixLQXpDRCxDQXlDRSxPQUFPa0MsS0FBUCxFQUFjO0FBQ2QsdUJBQ0Usa0NBREYsRUFFRyxtQ0FBa0MySCxpQkFBa0IsV0FBVTNILEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBTSxFQUZ4RjtBQUlBLFlBQU0sQ0FBQ0YsVUFBRCxFQUFhK0gsWUFBYixJQUE2QixLQUFLQyxlQUFMLENBQXFCOUgsS0FBckIsQ0FBbkM7QUFFQSxhQUFPLGtDQUFjNkgsWUFBWSxJQUFJN0gsS0FBOUIsRUFBcUMsSUFBckMsRUFBMkNGLFVBQTNDLEVBQXVEaEMsUUFBdkQsQ0FBUDtBQUNEO0FBQ0Y7O0FBRVcsUUFBTmdMLE1BQU0sQ0FBQ2xMLE9BQUQsRUFBaUNDLE9BQWpDLEVBQXVFQyxRQUF2RSxFQUFzSDtBQUNoSSxRQUFJO0FBQ0YsWUFBTUMsSUFBSSxHQUFHLE1BQU1ILE9BQU8sQ0FBQ0ksSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUF4QixDQUErQjRELGFBQS9CLENBQTZDQyxNQUE3QyxDQUFvRGxFLE9BQU8sQ0FBQ1MsSUFBNUQsQ0FBbkI7QUFDQSxhQUFPUixRQUFRLENBQUMrQixFQUFULENBQVk7QUFDakJ2QixRQUFBQSxJQUFJLEVBQUVQLElBQUksQ0FBQ087QUFETSxPQUFaLENBQVA7QUFHRCxLQUxELENBS0UsT0FBTzBCLEtBQVAsRUFBYztBQUNkLHVCQUFJLHNCQUFKLEVBQTRCQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQTdDO0FBQ0EsYUFBTyxrQ0FBY0EsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUEvQixFQUFzQyxJQUF0QyxFQUE0QyxHQUE1QyxFQUFpRGxDLFFBQWpELENBQVA7QUFDRDtBQUNGLEdBbHlCMkIsQ0FveUI1Qjs7O0FBQzRCLFFBQXRCZ00sc0JBQXNCLENBQUNsTSxPQUFELEVBQWlDQyxPQUFqQyxFQUF1RUMsUUFBdkUsRUFBc0g7QUFDaEosUUFBSTtBQUNGLFlBQU1MLE1BQU0sR0FBRyx5Q0FBZjtBQUNBLFlBQU1zTSxpQkFBaUIsR0FBSSxHQUFFdE0sTUFBTSxDQUFDLGFBQUQsQ0FBTixJQUF5QixPQUFRLElBQUdBLE1BQU0sQ0FBQyw0QkFBRCxDQUFOLElBQXdDLFlBQWEsR0FBdEgsQ0FGRSxDQUV3SDs7QUFDMUgsWUFBTXVNLFVBQVUsR0FBRyxNQUFNcE0sT0FBTyxDQUFDSSxJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCNEQsYUFBL0IsQ0FBNkN1RixPQUE3QyxDQUFxREMsTUFBckQsQ0FBNEQ7QUFDbkZ0RixRQUFBQSxLQUFLLEVBQUUrSCxpQkFENEU7QUFFbkZFLFFBQUFBLGdCQUFnQixFQUFFO0FBRmlFLE9BQTVELENBQXpCO0FBSUEsYUFBT25NLFFBQVEsQ0FBQytCLEVBQVQsQ0FBWTtBQUNqQnZCLFFBQUFBLElBQUksRUFBRTBMLFVBQVUsQ0FBQzFMO0FBREEsT0FBWixDQUFQO0FBR0QsS0FWRCxDQVVFLE9BQU8wQixLQUFQLEVBQWM7QUFDZCx1QkFBSSx1Q0FBSixFQUE2Q0EsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUE5RDtBQUNBLGFBQU8sa0NBQWNBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBL0IsRUFBc0MsSUFBdEMsRUFBNEMsR0FBNUMsRUFBaURsQyxRQUFqRCxDQUFQO0FBQ0Q7QUFDRjs7QUFFRGdLLEVBQUFBLGVBQWUsQ0FBQzlILEtBQUQsRUFBTztBQUFBOztBQUNwQixVQUFNRixVQUFVLEdBQUcsQ0FBQUUsS0FBSyxTQUFMLElBQUFBLEtBQUssV0FBTCwyQkFBQUEsS0FBSyxDQUFFa0ssSUFBUCw0REFBYXBLLFVBQWIsS0FBMkIsR0FBOUM7QUFDQSxRQUFJK0gsWUFBWSxHQUFHN0gsS0FBSyxDQUFDQyxPQUF6Qjs7QUFFQSxRQUFHSCxVQUFVLEtBQUssR0FBbEIsRUFBc0I7QUFBQTs7QUFDcEIrSCxNQUFBQSxZQUFZLEdBQUcsQ0FBQTdILEtBQUssU0FBTCxJQUFBQSxLQUFLLFdBQUwsNEJBQUFBLEtBQUssQ0FBRWtLLElBQVAsbUZBQWE1TCxJQUFiLGlHQUFtQjBCLEtBQW5CLGdGQUEwQm1LLE1BQTFCLEtBQW9DLG1CQUFuRDtBQUNEOztBQUVELFdBQU8sQ0FBQ3JLLFVBQUQsRUFBYStILFlBQWIsQ0FBUDtBQUNEOztBQS96QjJCIiwic291cmNlc0NvbnRlbnQiOlsiLypcclxuICogV2F6dWggYXBwIC0gQ2xhc3MgZm9yIFdhenVoLUVsYXN0aWMgZnVuY3Rpb25zXHJcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXHJcbiAqXHJcbiAqIFRoaXMgcHJvZ3JhbSBpcyBmcmVlIHNvZnR3YXJlOyB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XHJcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XHJcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXHJcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXHJcbiAqXHJcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXHJcbiAqL1xyXG5pbXBvcnQgeyBFcnJvclJlc3BvbnNlIH0gZnJvbSAnLi4vbGliL2Vycm9yLXJlc3BvbnNlJztcclxuaW1wb3J0IHsgbG9nIH0gZnJvbSAnLi4vbGliL2xvZ2dlcic7XHJcbmltcG9ydCB7IGdldENvbmZpZ3VyYXRpb24gfSBmcm9tICcuLi9saWIvZ2V0LWNvbmZpZ3VyYXRpb24nO1xyXG5pbXBvcnQge1xyXG4gIEFnZW50c1Zpc3VhbGl6YXRpb25zLFxyXG4gIE92ZXJ2aWV3VmlzdWFsaXphdGlvbnMsXHJcbiAgQ2x1c3RlclZpc3VhbGl6YXRpb25zXHJcbn0gZnJvbSAnLi4vaW50ZWdyYXRpb24tZmlsZXMvdmlzdWFsaXphdGlvbnMnO1xyXG5cclxuaW1wb3J0IHsgZ2VuZXJhdGVBbGVydHMgfSBmcm9tICcuLi9saWIvZ2VuZXJhdGUtYWxlcnRzL2dlbmVyYXRlLWFsZXJ0cy1zY3JpcHQnO1xyXG5pbXBvcnQgeyBXQVpVSF9NT05JVE9SSU5HX1BBVFRFUk4sIFdBWlVIX1NBTVBMRV9BTEVSVF9QUkVGSVgsIFdBWlVIX1JPTEVfQURNSU5JU1RSQVRPUl9JRCwgV0FaVUhfU0FNUExFX0FMRVJUU19JTkRFWF9TSEFSRFMsIFdBWlVIX1NBTVBMRV9BTEVSVFNfSU5ERVhfUkVQTElDQVMgfSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcclxuaW1wb3J0IGp3dERlY29kZSBmcm9tICdqd3QtZGVjb2RlJztcclxuaW1wb3J0IHsgTWFuYWdlSG9zdHMgfSBmcm9tICcuLi9saWIvbWFuYWdlLWhvc3RzJztcclxuaW1wb3J0IHsgT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5LCBTYXZlZE9iamVjdCwgU2F2ZWRPYmplY3RzRmluZFJlc3BvbnNlIH0gZnJvbSAnc3JjL2NvcmUvc2VydmVyJztcclxuaW1wb3J0IHsgZ2V0Q29va2llVmFsdWVCeU5hbWUgfSBmcm9tICcuLi9saWIvY29va2llJztcclxuaW1wb3J0IHsgV0FaVUhfU0FNUExFX0FMRVJUU19DQVRFR09SSUVTX1RZUEVfQUxFUlRTLCBXQVpVSF9TQU1QTEVfQUxFUlRTX0RFRkFVTFRfTlVNQkVSX0FMRVJUUyB9IGZyb20gJy4uLy4uL2NvbW1vbi9jb25zdGFudHMnXHJcblxyXG5leHBvcnQgY2xhc3MgV2F6dWhFbGFzdGljQ3RybCB7XHJcbiAgd3pTYW1wbGVBbGVydHNJbmRleFByZWZpeDogc3RyaW5nXHJcbiAgbWFuYWdlSG9zdHM6IE1hbmFnZUhvc3RzXHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgICB0aGlzLnd6U2FtcGxlQWxlcnRzSW5kZXhQcmVmaXggPSB0aGlzLmdldFNhbXBsZUFsZXJ0UHJlZml4KCk7XHJcbiAgICB0aGlzLm1hbmFnZUhvc3RzID0gbmV3IE1hbmFnZUhvc3RzKCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBUaGlzIHJldHVybnMgdGhlIGluZGV4IGFjY29yZGluZyB0aGUgY2F0ZWdvcnlcclxuICAgKiBAcGFyYW0ge3N0cmluZ30gY2F0ZWdvcnlcclxuICAgKi9cclxuICBidWlsZFNhbXBsZUluZGV4QnlDYXRlZ29yeShjYXRlZ29yeTogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgIHJldHVybiBgJHt0aGlzLnd6U2FtcGxlQWxlcnRzSW5kZXhQcmVmaXh9c2FtcGxlLSR7Y2F0ZWdvcnl9YDtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFRoaXMgcmV0dXJucyB0aGUgZGVmaW5lZCBjb25maWcgZm9yIHNhbXBsZSBhbGVydHMgcHJlZml4IG9yIHRoZSBkZWZhdWx0IHZhbHVlLlxyXG4gICAqL1xyXG4gIGdldFNhbXBsZUFsZXJ0UHJlZml4KCk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBjb25maWcgPSBnZXRDb25maWd1cmF0aW9uKCk7XHJcbiAgICByZXR1cm4gY29uZmlnWydhbGVydHMuc2FtcGxlLnByZWZpeCddIHx8IFdBWlVIX1NBTVBMRV9BTEVSVF9QUkVGSVg7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBUaGlzIHJldHJpZXZlcyBhIHRlbXBsYXRlIGZyb20gRWxhc3RpY3NlYXJjaFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcclxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSB0ZW1wbGF0ZSBvciBFcnJvclJlc3BvbnNlXHJcbiAgICovXHJcbiAgYXN5bmMgZ2V0VGVtcGxhdGUoY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3Q8eyBwYXR0ZXJuOiBzdHJpbmcgfT4sIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlci5jYXQudGVtcGxhdGVzKCk7XHJcblxyXG4gICAgICBjb25zdCB0ZW1wbGF0ZXMgPSBkYXRhLmJvZHk7XHJcbiAgICAgIGlmICghdGVtcGxhdGVzIHx8IHR5cGVvZiB0ZW1wbGF0ZXMgIT09ICdzdHJpbmcnKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICAgICAgJ0FuIHVua25vd24gZXJyb3Igb2NjdXJyZWQgd2hlbiBmZXRjaGluZyB0ZW1wbGF0ZXMgZnJvbSBFbGFzdGljc2VhY2gnXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgbGFzdENoYXIgPSByZXF1ZXN0LnBhcmFtcy5wYXR0ZXJuW3JlcXVlc3QucGFyYW1zLnBhdHRlcm4ubGVuZ3RoIC0gMV07XHJcblxyXG4gICAgICAvLyBTcGxpdCBpbnRvIHNlcGFyYXRlIHBhdHRlcm5zXHJcbiAgICAgIGNvbnN0IHRtcGRhdGEgPSB0ZW1wbGF0ZXMubWF0Y2goL1xcWy4qXFxdL2cpO1xyXG4gICAgICBjb25zdCB0bXBhcnJheSA9IFtdO1xyXG4gICAgICBmb3IgKGxldCBpdGVtIG9mIHRtcGRhdGEpIHtcclxuICAgICAgICAvLyBBIHRlbXBsYXRlIG1pZ2h0IHVzZSBtb3JlIHRoYW4gb25lIHBhdHRlcm5cclxuICAgICAgICBpZiAoaXRlbS5pbmNsdWRlcygnLCcpKSB7XHJcbiAgICAgICAgICBpdGVtID0gaXRlbS5zdWJzdHIoMSkuc2xpY2UoMCwgLTEpO1xyXG4gICAgICAgICAgY29uc3Qgc3ViSXRlbXMgPSBpdGVtLnNwbGl0KCcsJyk7XHJcbiAgICAgICAgICBmb3IgKGNvbnN0IHN1Yml0ZW0gb2Ygc3ViSXRlbXMpIHtcclxuICAgICAgICAgICAgdG1wYXJyYXkucHVzaChgWyR7c3ViaXRlbS50cmltKCl9XWApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICB0bXBhcnJheS5wdXNoKGl0ZW0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gRW5zdXJlIHdlIGFyZSBoYW5kbGluZyBqdXN0IHBhdHRlcm5zXHJcbiAgICAgIGNvbnN0IGFycmF5ID0gdG1wYXJyYXkuZmlsdGVyKFxyXG4gICAgICAgIGl0ZW0gPT4gaXRlbS5pbmNsdWRlcygnWycpICYmIGl0ZW0uaW5jbHVkZXMoJ10nKVxyXG4gICAgICApO1xyXG5cclxuICAgICAgY29uc3QgcGF0dGVybiA9XHJcbiAgICAgICAgbGFzdENoYXIgPT09ICcqJyA/IHJlcXVlc3QucGFyYW1zLnBhdHRlcm4uc2xpY2UoMCwgLTEpIDogcmVxdWVzdC5wYXJhbXMucGF0dGVybjtcclxuICAgICAgY29uc3QgaXNJbmNsdWRlZCA9IGFycmF5LmZpbHRlcihpdGVtID0+IHtcclxuICAgICAgICBpdGVtID0gaXRlbS5zbGljZSgxLCAtMSk7XHJcbiAgICAgICAgY29uc3QgbGFzdENoYXIgPSBpdGVtW2l0ZW0ubGVuZ3RoIC0gMV07XHJcbiAgICAgICAgaXRlbSA9IGxhc3RDaGFyID09PSAnKicgPyBpdGVtLnNsaWNlKDAsIC0xKSA6IGl0ZW07XHJcbiAgICAgICAgcmV0dXJuIGl0ZW0uaW5jbHVkZXMocGF0dGVybikgfHwgcGF0dGVybi5pbmNsdWRlcyhpdGVtKTtcclxuICAgICAgfSk7XHJcbiAgICAgIGxvZyhcclxuICAgICAgICAnd2F6dWgtZWxhc3RpYzpnZXRUZW1wbGF0ZScsXHJcbiAgICAgICAgYFRlbXBsYXRlIGlzIHZhbGlkOiAke2lzSW5jbHVkZWQgJiYgQXJyYXkuaXNBcnJheShpc0luY2x1ZGVkKSAmJiBpc0luY2x1ZGVkLmxlbmd0aFxyXG4gICAgICAgICAgPyAneWVzJ1xyXG4gICAgICAgICAgOiAnbm8nXHJcbiAgICAgICAgfWAsXHJcbiAgICAgICAgJ2RlYnVnJ1xyXG4gICAgICApO1xyXG4gICAgICByZXR1cm4gaXNJbmNsdWRlZCAmJiBBcnJheS5pc0FycmF5KGlzSW5jbHVkZWQpICYmIGlzSW5jbHVkZWQubGVuZ3RoXHJcbiAgICAgICAgPyByZXNwb25zZS5vayh7XHJcbiAgICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcclxuICAgICAgICAgICAgc3RhdHVzOiB0cnVlLFxyXG4gICAgICAgICAgICBkYXRhOiBgVGVtcGxhdGUgZm91bmQgZm9yICR7cmVxdWVzdC5wYXJhbXMucGF0dGVybn1gXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICA6IHJlc3BvbnNlLm9rKHtcclxuICAgICAgICAgIGJvZHk6IHtcclxuICAgICAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxyXG4gICAgICAgICAgICBzdGF0dXM6IGZhbHNlLFxyXG4gICAgICAgICAgICBkYXRhOiBgTm8gdGVtcGxhdGUgZm91bmQgZm9yICR7cmVxdWVzdC5wYXJhbXMucGF0dGVybn1gXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3dhenVoLWVsYXN0aWM6Z2V0VGVtcGxhdGUnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXHJcbiAgICAgICAgYENvdWxkIG5vdCByZXRyaWV2ZSB0ZW1wbGF0ZXMgZnJvbSBFbGFzdGljc2VhcmNoIGR1ZSB0byAke2Vycm9yLm1lc3NhZ2UgfHxcclxuICAgICAgICBlcnJvcn1gLFxyXG4gICAgICAgIDQwMDIsXHJcbiAgICAgICAgNTAwLFxyXG4gICAgICAgIHJlc3BvbnNlXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBUaGlzIGNoZWNrIGluZGV4LXBhdHRlcm5cclxuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXHJcbiAgICogQHJldHVybnMge09iamVjdH0gc3RhdHVzIG9iaiBvciBFcnJvclJlc3BvbnNlXHJcbiAgICovXHJcbiAgYXN5bmMgY2hlY2tQYXR0ZXJuKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0PHsgcGF0dGVybjogc3RyaW5nIH0+LCByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnkpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBjb250ZXh0LmNvcmUuc2F2ZWRPYmplY3RzLmNsaWVudC5maW5kPFNhdmVkT2JqZWN0c0ZpbmRSZXNwb25zZTxTYXZlZE9iamVjdD4+KHsgdHlwZTogJ2luZGV4LXBhdHRlcm4nIH0pO1xyXG5cclxuICAgICAgY29uc3QgZXhpc3RzSW5kZXhQYXR0ZXJuID0gZGF0YS5zYXZlZF9vYmplY3RzLmZpbmQoXHJcbiAgICAgICAgaXRlbSA9PiBpdGVtLmF0dHJpYnV0ZXMudGl0bGUgPT09IHJlcXVlc3QucGFyYW1zLnBhdHRlcm5cclxuICAgICAgKTtcclxuICAgICAgbG9nKFxyXG4gICAgICAgICd3YXp1aC1lbGFzdGljOmNoZWNrUGF0dGVybicsXHJcbiAgICAgICAgYEluZGV4IHBhdHRlcm4gZm91bmQ6ICR7ZXhpc3RzSW5kZXhQYXR0ZXJuID8gZXhpc3RzSW5kZXhQYXR0ZXJuLmF0dHJpYnV0ZXMudGl0bGUgOiAnbm8nfWAsXHJcbiAgICAgICAgJ2RlYnVnJ1xyXG4gICAgICApO1xyXG4gICAgICByZXR1cm4gZXhpc3RzSW5kZXhQYXR0ZXJuXHJcbiAgICAgICAgPyByZXNwb25zZS5vayh7XHJcbiAgICAgICAgICBib2R5OiB7IHN0YXR1c0NvZGU6IDIwMCwgc3RhdHVzOiB0cnVlLCBkYXRhOiAnSW5kZXggcGF0dGVybiBmb3VuZCcgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgOiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMCxcclxuICAgICAgICAgICAgc3RhdHVzOiBmYWxzZSxcclxuICAgICAgICAgICAgZXJyb3I6IDEwMDIwLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiAnSW5kZXggcGF0dGVybiBub3QgZm91bmQnXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3dhenVoLWVsYXN0aWM6Y2hlY2tQYXR0ZXJuJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxyXG4gICAgICAgIGBTb21ldGhpbmcgd2VudCB3cm9uZyByZXRyaWV2aW5nIGluZGV4LXBhdHRlcm5zIGZyb20gRWxhc3RpY3NlYXJjaCBkdWUgdG8gJHtlcnJvci5tZXNzYWdlIHx8XHJcbiAgICAgICAgZXJyb3J9YCxcclxuICAgICAgICA0MDAzLFxyXG4gICAgICAgIDUwMCxcclxuICAgICAgICByZXNwb25zZVxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogVGhpcyBnZXQgdGhlIGZpZWxkcyBrZXlzXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxyXG4gICAqIEByZXR1cm5zIHtBcnJheTxPYmplY3Q+fSBmaWVsZHMgb3IgRXJyb3JSZXNwb25zZVxyXG4gICAqL1xyXG4gIGFzeW5jIGdldEZpZWxkVG9wKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0PHsgbW9kZTogc3RyaW5nLCBjbHVzdGVyOiBzdHJpbmcsIGZpZWxkOiBzdHJpbmcsIHBhdHRlcm46IHN0cmluZyB9LCB7IGFnZW50c0xpc3Q6IHN0cmluZyB9PiwgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5KSB7XHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBUb3AgZmllbGQgcGF5bG9hZFxyXG4gICAgICBsZXQgcGF5bG9hZCA9IHtcclxuICAgICAgICBzaXplOiAxLFxyXG4gICAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgICBib29sOiB7XHJcbiAgICAgICAgICAgIG11c3Q6IFtdLFxyXG4gICAgICAgICAgICBtdXN0X25vdDoge1xyXG4gICAgICAgICAgICAgIHRlcm06IHtcclxuICAgICAgICAgICAgICAgICdhZ2VudC5pZCc6ICcwMDAnXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBmaWx0ZXI6IFtcclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICByYW5nZTogeyB0aW1lc3RhbXA6IHt9IH1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIF1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIGFnZ3M6IHtcclxuICAgICAgICAgICcyJzoge1xyXG4gICAgICAgICAgICB0ZXJtczoge1xyXG4gICAgICAgICAgICAgIGZpZWxkOiAnJyxcclxuICAgICAgICAgICAgICBzaXplOiAxLFxyXG4gICAgICAgICAgICAgIG9yZGVyOiB7IF9jb3VudDogJ2Rlc2MnIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfTtcclxuXHJcbiAgICAgIC8vIFNldCB1cCB0aW1lIGludGVydmFsLCBkZWZhdWx0IHRvIExhc3QgMjRoXHJcbiAgICAgIGNvbnN0IHRpbWVHVEUgPSAnbm93LTFkJztcclxuICAgICAgY29uc3QgdGltZUxUID0gJ25vdyc7XHJcbiAgICAgIHBheWxvYWQucXVlcnkuYm9vbC5maWx0ZXJbMF0ucmFuZ2VbJ3RpbWVzdGFtcCddWydndGUnXSA9IHRpbWVHVEU7XHJcbiAgICAgIHBheWxvYWQucXVlcnkuYm9vbC5maWx0ZXJbMF0ucmFuZ2VbJ3RpbWVzdGFtcCddWydsdCddID0gdGltZUxUO1xyXG5cclxuICAgICAgLy8gU2V0IHVwIG1hdGNoIGZvciBkZWZhdWx0IGNsdXN0ZXIgbmFtZVxyXG4gICAgICBwYXlsb2FkLnF1ZXJ5LmJvb2wubXVzdC5wdXNoKFxyXG4gICAgICAgIHJlcXVlc3QucGFyYW1zLm1vZGUgPT09ICdjbHVzdGVyJ1xyXG4gICAgICAgICAgPyB7IG1hdGNoOiB7ICdjbHVzdGVyLm5hbWUnOiByZXF1ZXN0LnBhcmFtcy5jbHVzdGVyIH0gfVxyXG4gICAgICAgICAgOiB7IG1hdGNoOiB7ICdtYW5hZ2VyLm5hbWUnOiByZXF1ZXN0LnBhcmFtcy5jbHVzdGVyIH0gfVxyXG4gICAgICApO1xyXG5cclxuICAgICAgaWYocmVxdWVzdC5xdWVyeS5hZ2VudHNMaXN0KVxyXG4gICAgICAgIHBheWxvYWQucXVlcnkuYm9vbC5maWx0ZXIucHVzaChcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgdGVybXM6IHtcclxuICAgICAgICAgICAgICAnYWdlbnQuaWQnOiByZXF1ZXN0LnF1ZXJ5LmFnZW50c0xpc3Quc3BsaXQoJywnKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgICAgcGF5bG9hZC5hZ2dzWycyJ10udGVybXMuZmllbGQgPSByZXF1ZXN0LnBhcmFtcy5maWVsZDtcclxuXHJcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5zZWFyY2goe1xyXG4gICAgICAgIHNpemU6IDEsXHJcbiAgICAgICAgaW5kZXg6IHJlcXVlc3QucGFyYW1zLnBhdHRlcm4sXHJcbiAgICAgICAgYm9keTogcGF5bG9hZFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHJldHVybiBkYXRhLmJvZHkuaGl0cy50b3RhbC52YWx1ZSA9PT0gMCB8fFxyXG4gICAgICAgIHR5cGVvZiBkYXRhLmJvZHkuYWdncmVnYXRpb25zWycyJ10uYnVja2V0c1swXSA9PT0gJ3VuZGVmaW5lZCdcclxuICAgICAgICA/IHJlc3BvbnNlLm9rKHtcclxuICAgICAgICAgIGJvZHk6IHsgc3RhdHVzQ29kZTogMjAwLCBkYXRhOiAnJyB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICA6IHJlc3BvbnNlLm9rKHtcclxuICAgICAgICAgIGJvZHk6IHtcclxuICAgICAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxyXG4gICAgICAgICAgICBkYXRhOiBkYXRhLmJvZHkuYWdncmVnYXRpb25zWycyJ10uYnVja2V0c1swXS5rZXlcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGxvZygnd2F6dWgtZWxhc3RpYzpnZXRGaWVsZFRvcCcsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCA0MDA0LCA1MDAsIHJlc3BvbnNlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIENoZWNrcyBvbmUgYnkgb25lIGlmIHRoZSByZXF1ZXN0aW5nIHVzZXIgaGFzIGVub3VnaCBwcml2aWxlZ2VzIHRvIHVzZVxyXG4gICAqIGFuIGluZGV4IHBhdHRlcm4gZnJvbSB0aGUgbGlzdC5cclxuICAgKiBAcGFyYW0ge0FycmF5PE9iamVjdD59IGxpc3QgTGlzdCBvZiBpbmRleCBwYXR0ZXJuc1xyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXFcclxuICAgKiBAcmV0dXJucyB7QXJyYXk8T2JqZWN0Pn0gTGlzdCBvZiBhbGxvd2VkIGluZGV4XHJcbiAgICovXHJcbiAgYXN5bmMgZmlsdGVyQWxsb3dlZEluZGV4UGF0dGVybkxpc3QoY29udGV4dCwgbGlzdCwgcmVxKSB7XHJcbiAgICAvL1RPRE86IHJldmlldyBpZiBuZWNlc2FyeSB0byBkZWxldGVcclxuICAgIGxldCBmaW5hbExpc3QgPSBbXTtcclxuICAgIGZvciAobGV0IGl0ZW0gb2YgbGlzdCkge1xyXG4gICAgICBsZXQgcmVzdWx0cyA9IGZhbHNlLFxyXG4gICAgICAgIGZvcmJpZGRlbiA9IGZhbHNlO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHJlc3VsdHMgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5zZWFyY2goe1xyXG4gICAgICAgICAgaW5kZXg6IGl0ZW0udGl0bGVcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBmb3JiaWRkZW4gPSB0cnVlO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChcclxuICAgICAgICAoKChyZXN1bHRzIHx8IHt9KS5ib2R5IHx8IHt9KS5oaXRzIHx8IHt9KS50b3RhbC52YWx1ZSA+PSAxIHx8XHJcbiAgICAgICAgKCFmb3JiaWRkZW4gJiYgKCgocmVzdWx0cyB8fCB7fSkuYm9keSB8fCB7fSkuaGl0cyB8fCB7fSkudG90YWwgPT09IDApXHJcbiAgICAgICkge1xyXG4gICAgICAgIGZpbmFsTGlzdC5wdXNoKGl0ZW0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZmluYWxMaXN0O1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQ2hlY2tzIGZvciBtaW5pbXVtIGluZGV4IHBhdHRlcm4gZmllbGRzIGluIGEgbGlzdCBvZiBpbmRleCBwYXR0ZXJucy5cclxuICAgKiBAcGFyYW0ge0FycmF5PE9iamVjdD59IGluZGV4UGF0dGVybkxpc3QgTGlzdCBvZiBpbmRleCBwYXR0ZXJuc1xyXG4gICAqL1xyXG4gIHZhbGlkYXRlSW5kZXhQYXR0ZXJuKGluZGV4UGF0dGVybkxpc3QpIHtcclxuICAgIGNvbnN0IG1pbmltdW0gPSBbJ3RpbWVzdGFtcCcsICdydWxlLmdyb3VwcycsICdtYW5hZ2VyLm5hbWUnLCAnYWdlbnQuaWQnXTtcclxuICAgIGxldCBsaXN0ID0gW107XHJcbiAgICBmb3IgKGNvbnN0IGluZGV4IG9mIGluZGV4UGF0dGVybkxpc3QpIHtcclxuICAgICAgbGV0IHZhbGlkLCBwYXJzZWQ7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgcGFyc2VkID0gSlNPTi5wYXJzZShpbmRleC5hdHRyaWJ1dGVzLmZpZWxkcyk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29udGludWU7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHZhbGlkID0gcGFyc2VkLmZpbHRlcihpdGVtID0+IG1pbmltdW0uaW5jbHVkZXMoaXRlbS5uYW1lKSk7XHJcbiAgICAgIGlmICh2YWxpZC5sZW5ndGggPT09IDQpIHtcclxuICAgICAgICBsaXN0LnB1c2goe1xyXG4gICAgICAgICAgaWQ6IGluZGV4LmlkLFxyXG4gICAgICAgICAgdGl0bGU6IGluZGV4LmF0dHJpYnV0ZXMudGl0bGVcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGxpc3Q7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBSZXR1cm5zIGN1cnJlbnQgc2VjdXJpdHkgcGxhdGZvcm1cclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcGx5XHJcbiAgICogQHJldHVybnMge1N0cmluZ31cclxuICAgKi9cclxuICBhc3luYyBnZXRDdXJyZW50UGxhdGZvcm0oY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3Q8eyB1c2VyOiBzdHJpbmcgfT4sIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICBwbGF0Zm9ybTogY29udGV4dC53YXp1aC5zZWN1cml0eS5wbGF0Zm9ybVxyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3dhenVoLWVsYXN0aWM6Z2V0Q3VycmVudFBsYXRmb3JtJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDQwMTEsIDUwMCwgcmVzcG9uc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmVwbGFjZXMgdmlzdWFsaXphdGlvbnMgbWFpbiBmaWVsZHMgdG8gZml0IGEgY2VydGFpbiBwYXR0ZXJuLlxyXG4gICAqIEBwYXJhbSB7QXJyYXk8T2JqZWN0Pn0gYXBwX29iamVjdHMgT2JqZWN0IGNvbnRhaW5pbmcgcmF3IHZpc3VhbGl6YXRpb25zLlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBpZCBJbmRleC1wYXR0ZXJuIGlkIHRvIHVzZSBpbiB0aGUgdmlzdWFsaXphdGlvbnMuIEVnOiAnd2F6dWgtYWxlcnRzJ1xyXG4gICAqL1xyXG4gIGFzeW5jIGJ1aWxkVmlzdWFsaXphdGlvbnNSYXcoYXBwX29iamVjdHMsIGlkLCBuYW1lc3BhY2UgPSBmYWxzZSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgY29uZmlnID0gZ2V0Q29uZmlndXJhdGlvbigpO1xyXG4gICAgICBsZXQgbW9uaXRvcmluZ1BhdHRlcm4gPVxyXG4gICAgICAgIChjb25maWcgfHwge30pWyd3YXp1aC5tb25pdG9yaW5nLnBhdHRlcm4nXSB8fCBXQVpVSF9NT05JVE9SSU5HX1BBVFRFUk47XHJcbiAgICAgIGxvZyhcclxuICAgICAgICAnd2F6dWgtZWxhc3RpYzpidWlsZFZpc3VhbGl6YXRpb25zUmF3JyxcclxuICAgICAgICBgQnVpbGRpbmcgJHthcHBfb2JqZWN0cy5sZW5ndGh9IHZpc3VhbGl6YXRpb25zYCxcclxuICAgICAgICAnZGVidWcnXHJcbiAgICAgICk7XHJcbiAgICAgIGxvZyhcclxuICAgICAgICAnd2F6dWgtZWxhc3RpYzpidWlsZFZpc3VhbGl6YXRpb25zUmF3JyxcclxuICAgICAgICBgSW5kZXggcGF0dGVybiBJRDogJHtpZH1gLFxyXG4gICAgICAgICdkZWJ1ZydcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgdmlzQXJyYXkgPSBbXTtcclxuICAgICAgbGV0IGF1eF9zb3VyY2UsIGJ1bGtfY29udGVudDtcclxuICAgICAgZm9yIChsZXQgZWxlbWVudCBvZiBhcHBfb2JqZWN0cykge1xyXG4gICAgICAgIGF1eF9zb3VyY2UgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGVsZW1lbnQuX3NvdXJjZSkpO1xyXG5cclxuICAgICAgICAvLyBSZXBsYWNlIGluZGV4LXBhdHRlcm4gZm9yIHZpc3VhbGl6YXRpb25zXHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgYXV4X3NvdXJjZSAmJlxyXG4gICAgICAgICAgYXV4X3NvdXJjZS5raWJhbmFTYXZlZE9iamVjdE1ldGEgJiZcclxuICAgICAgICAgIGF1eF9zb3VyY2Uua2liYW5hU2F2ZWRPYmplY3RNZXRhLnNlYXJjaFNvdXJjZUpTT04gJiZcclxuICAgICAgICAgIHR5cGVvZiBhdXhfc291cmNlLmtpYmFuYVNhdmVkT2JqZWN0TWV0YS5zZWFyY2hTb3VyY2VKU09OID09PSAnc3RyaW5nJ1xyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgY29uc3QgZGVmYXVsdFN0ciA9IGF1eF9zb3VyY2Uua2liYW5hU2F2ZWRPYmplY3RNZXRhLnNlYXJjaFNvdXJjZUpTT047XHJcblxyXG4gICAgICAgICAgY29uc3QgaXNNb25pdG9yaW5nID0gZGVmYXVsdFN0ci5pbmNsdWRlcygnd2F6dWgtbW9uaXRvcmluZycpO1xyXG4gICAgICAgICAgaWYgKGlzTW9uaXRvcmluZykge1xyXG4gICAgICAgICAgICBpZiAobmFtZXNwYWNlICYmIG5hbWVzcGFjZSAhPT0gJ2RlZmF1bHQnKSB7XHJcbiAgICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAgbW9uaXRvcmluZ1BhdHRlcm4uaW5jbHVkZXMobmFtZXNwYWNlKSAmJlxyXG4gICAgICAgICAgICAgICAgbW9uaXRvcmluZ1BhdHRlcm4uaW5jbHVkZXMoJ2luZGV4LXBhdHRlcm46JylcclxuICAgICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgIG1vbml0b3JpbmdQYXR0ZXJuID0gbW9uaXRvcmluZ1BhdHRlcm4uc3BsaXQoXHJcbiAgICAgICAgICAgICAgICAgICdpbmRleC1wYXR0ZXJuOidcclxuICAgICAgICAgICAgICAgIClbMV07XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGF1eF9zb3VyY2Uua2liYW5hU2F2ZWRPYmplY3RNZXRhLnNlYXJjaFNvdXJjZUpTT04gPSBkZWZhdWx0U3RyLnJlcGxhY2UoXHJcbiAgICAgICAgICAgICAgL3dhenVoLW1vbml0b3JpbmcvZyxcclxuICAgICAgICAgICAgICBtb25pdG9yaW5nUGF0dGVyblttb25pdG9yaW5nUGF0dGVybi5sZW5ndGggLSAxXSA9PT0gJyonIHx8XHJcbiAgICAgICAgICAgICAgICAobmFtZXNwYWNlICYmIG5hbWVzcGFjZSAhPT0gJ2RlZmF1bHQnKVxyXG4gICAgICAgICAgICAgICAgPyBtb25pdG9yaW5nUGF0dGVyblxyXG4gICAgICAgICAgICAgICAgOiBtb25pdG9yaW5nUGF0dGVybiArICcqJ1xyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYXV4X3NvdXJjZS5raWJhbmFTYXZlZE9iamVjdE1ldGEuc2VhcmNoU291cmNlSlNPTiA9IGRlZmF1bHRTdHIucmVwbGFjZShcclxuICAgICAgICAgICAgICAvd2F6dWgtYWxlcnRzL2csXHJcbiAgICAgICAgICAgICAgaWRcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIFJlcGxhY2UgaW5kZXgtcGF0dGVybiBmb3Igc2VsZWN0b3IgdmlzdWFsaXphdGlvbnNcclxuICAgICAgICBpZiAodHlwZW9mIChhdXhfc291cmNlIHx8IHt9KS52aXNTdGF0ZSA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgICAgIGF1eF9zb3VyY2UudmlzU3RhdGUgPSBhdXhfc291cmNlLnZpc1N0YXRlLnJlcGxhY2UoXHJcbiAgICAgICAgICAgIC93YXp1aC1hbGVydHMvZyxcclxuICAgICAgICAgICAgaWRcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyBCdWxrIHNvdXJjZVxyXG4gICAgICAgIGJ1bGtfY29udGVudCA9IHt9O1xyXG4gICAgICAgIGJ1bGtfY29udGVudFtlbGVtZW50Ll90eXBlXSA9IGF1eF9zb3VyY2U7XHJcblxyXG4gICAgICAgIHZpc0FycmF5LnB1c2goe1xyXG4gICAgICAgICAgYXR0cmlidXRlczogYnVsa19jb250ZW50LnZpc3VhbGl6YXRpb24sXHJcbiAgICAgICAgICB0eXBlOiBlbGVtZW50Ll90eXBlLFxyXG4gICAgICAgICAgaWQ6IGVsZW1lbnQuX2lkLFxyXG4gICAgICAgICAgX3ZlcnNpb246IGJ1bGtfY29udGVudC52aXN1YWxpemF0aW9uLnZlcnNpb25cclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gdmlzQXJyYXk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3dhenVoLWVsYXN0aWM6YnVpbGRWaXN1YWxpemF0aW9uc1JhdycsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xyXG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmVwbGFjZXMgY2x1c3RlciB2aXN1YWxpemF0aW9ucyBtYWluIGZpZWxkcy5cclxuICAgKiBAcGFyYW0ge0FycmF5PE9iamVjdD59IGFwcF9vYmplY3RzIE9iamVjdCBjb250YWluaW5nIHJhdyB2aXN1YWxpemF0aW9ucy5cclxuICAgKiBAcGFyYW0ge1N0cmluZ30gaWQgSW5kZXgtcGF0dGVybiBpZCB0byB1c2UgaW4gdGhlIHZpc3VhbGl6YXRpb25zLiBFZzogJ3dhenVoLWFsZXJ0cydcclxuICAgKiBAcGFyYW0ge0FycmF5PFN0cmluZz59IG5vZGVzIEFycmF5IG9mIG5vZGUgbmFtZXMuIEVnOiBbJ25vZGUwMScsICdub2RlMDInXVxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBuYW1lIENsdXN0ZXIgbmFtZS4gRWc6ICd3YXp1aCdcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gbWFzdGVyX25vZGUgTWFzdGVyIG5vZGUgbmFtZS4gRWc6ICdub2RlMDEnXHJcbiAgICovXHJcbiAgYnVpbGRDbHVzdGVyVmlzdWFsaXphdGlvbnNSYXcoXHJcbiAgICBhcHBfb2JqZWN0cyxcclxuICAgIGlkLFxyXG4gICAgbm9kZXMgPSBbXSxcclxuICAgIG5hbWUsXHJcbiAgICBtYXN0ZXJfbm9kZSxcclxuICAgIHBhdHRlcm5fbmFtZSA9ICcqJ1xyXG4gICkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdmlzQXJyYXkgPSBbXTtcclxuICAgICAgbGV0IGF1eF9zb3VyY2UsIGJ1bGtfY29udGVudDtcclxuXHJcbiAgICAgIGZvciAoY29uc3QgZWxlbWVudCBvZiBhcHBfb2JqZWN0cykge1xyXG4gICAgICAgIC8vIFN0cmluZ2lmeSBhbmQgcmVwbGFjZSBpbmRleC1wYXR0ZXJuIGZvciB2aXN1YWxpemF0aW9uc1xyXG4gICAgICAgIGF1eF9zb3VyY2UgPSBKU09OLnN0cmluZ2lmeShlbGVtZW50Ll9zb3VyY2UpO1xyXG4gICAgICAgIGF1eF9zb3VyY2UgPSBhdXhfc291cmNlLnJlcGxhY2UoL3dhenVoLWFsZXJ0cy9nLCBpZCk7XHJcbiAgICAgICAgYXV4X3NvdXJjZSA9IEpTT04ucGFyc2UoYXV4X3NvdXJjZSk7XHJcblxyXG4gICAgICAgIC8vIEJ1bGsgc291cmNlXHJcbiAgICAgICAgYnVsa19jb250ZW50ID0ge307XHJcbiAgICAgICAgYnVsa19jb250ZW50W2VsZW1lbnQuX3R5cGVdID0gYXV4X3NvdXJjZTtcclxuXHJcbiAgICAgICAgY29uc3QgdmlzU3RhdGUgPSBKU09OLnBhcnNlKGJ1bGtfY29udGVudC52aXN1YWxpemF0aW9uLnZpc1N0YXRlKTtcclxuICAgICAgICBjb25zdCB0aXRsZSA9IHZpc1N0YXRlLnRpdGxlO1xyXG5cclxuICAgICAgICBpZiAodmlzU3RhdGUudHlwZSAmJiB2aXNTdGF0ZS50eXBlID09PSAndGltZWxpb24nKSB7XHJcbiAgICAgICAgICBsZXQgcXVlcnkgPSAnJztcclxuICAgICAgICAgIGlmICh0aXRsZSA9PT0gJ1dhenVoIEFwcCBDbHVzdGVyIE92ZXJ2aWV3Jykge1xyXG4gICAgICAgICAgICBmb3IgKGNvbnN0IG5vZGUgb2Ygbm9kZXMpIHtcclxuICAgICAgICAgICAgICBxdWVyeSArPSBgLmVzKGluZGV4PSR7cGF0dGVybl9uYW1lfSxxPVwiY2x1c3Rlci5uYW1lOiAke25hbWV9IEFORCBjbHVzdGVyLm5vZGU6ICR7bm9kZS5uYW1lfVwiKS5sYWJlbChcIiR7bm9kZS5uYW1lfVwiKSxgO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHF1ZXJ5ID0gcXVlcnkuc3Vic3RyaW5nKDAsIHF1ZXJ5Lmxlbmd0aCAtIDEpO1xyXG4gICAgICAgICAgfSBlbHNlIGlmICh0aXRsZSA9PT0gJ1dhenVoIEFwcCBDbHVzdGVyIE92ZXJ2aWV3IE1hbmFnZXInKSB7XHJcbiAgICAgICAgICAgIHF1ZXJ5ICs9IGAuZXMoaW5kZXg9JHtwYXR0ZXJuX25hbWV9LHE9XCJjbHVzdGVyLm5hbWU6ICR7bmFtZX1cIikubGFiZWwoXCIke25hbWV9IGNsdXN0ZXJcIilgO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHRpdGxlLnN0YXJ0c1dpdGgoJ1dhenVoIEFwcCBTdGF0aXN0aWNzJykpIHtcclxuICAgICAgICAgICAgICBjb25zdCB7IHNlYXJjaFNvdXJjZUpTT04gfSA9IGJ1bGtfY29udGVudC52aXN1YWxpemF0aW9uLmtpYmFuYVNhdmVkT2JqZWN0TWV0YTtcclxuICAgICAgICAgICAgICBidWxrX2NvbnRlbnQudmlzdWFsaXphdGlvbi5raWJhbmFTYXZlZE9iamVjdE1ldGEuc2VhcmNoU291cmNlSlNPTiA9IHNlYXJjaFNvdXJjZUpTT04ucmVwbGFjZSgnd2F6dWgtc3RhdGlzdGljcy0qJywgcGF0dGVybl9uYW1lKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAodGl0bGUuc3RhcnRzV2l0aCgnV2F6dWggQXBwIFN0YXRpc3RpY3MnKSAmJiBuYW1lICE9PSAnLScgJiYgbmFtZSAhPT0gJ2FsbCcgJiYgdmlzU3RhdGUucGFyYW1zLmV4cHJlc3Npb24uaW5jbHVkZXMoJ3E9JykpIHtcclxuICAgICAgICAgICAgICBjb25zdCBleHByZXNzaW9uUmVnZXggPSAvcT0nXFwqJy9naTtcclxuICAgICAgICAgICAgICBjb25zdCBfdmlzU3RhdGUgPSBidWxrX2NvbnRlbnQudmlzdWFsaXphdGlvbi52aXNTdGF0ZUJ5Tm9kZVxyXG4gICAgICAgICAgICAgICAgPyBKU09OLnBhcnNlKGJ1bGtfY29udGVudC52aXN1YWxpemF0aW9uLnZpc1N0YXRlQnlOb2RlKVxyXG4gICAgICAgICAgICAgICAgOiB2aXNTdGF0ZTtcclxuICAgICAgICAgICAgICBxdWVyeSArPSBfdmlzU3RhdGUucGFyYW1zLmV4cHJlc3Npb24ucmVwbGFjZSgvd2F6dWgtc3RhdGlzdGljcy1cXCovZywgcGF0dGVybl9uYW1lKS5yZXBsYWNlKGV4cHJlc3Npb25SZWdleCwgYHE9XCJub2RlTmFtZS5rZXl3b3JkOiR7bmFtZX0gQU5EIGFwaU5hbWUua2V5d29yZDoke21hc3Rlcl9ub2RlfVwiYClcclxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKFwiTk9ERV9OQU1FXCIsIG5hbWUpXHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodGl0bGUuc3RhcnRzV2l0aCgnV2F6dWggQXBwIFN0YXRpc3RpY3MnKSkge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGV4cHJlc3Npb25SZWdleCA9IC9xPSdcXConL2dpXHJcbiAgICAgICAgICAgICAgcXVlcnkgKz0gdmlzU3RhdGUucGFyYW1zLmV4cHJlc3Npb24ucmVwbGFjZSgvd2F6dWgtc3RhdGlzdGljcy1cXCovZywgcGF0dGVybl9uYW1lKS5yZXBsYWNlKGV4cHJlc3Npb25SZWdleCwgYHE9XCJhcGlOYW1lLmtleXdvcmQ6JHttYXN0ZXJfbm9kZX1cImApXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgcXVlcnkgPSB2aXNTdGF0ZS5wYXJhbXMuZXhwcmVzc2lvbjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIHZpc1N0YXRlLnBhcmFtcy5leHByZXNzaW9uID0gcXVlcnkucmVwbGFjZSgvJy9nLCBcIlxcXCJcIik7XHJcbiAgICAgICAgICBidWxrX2NvbnRlbnQudmlzdWFsaXphdGlvbi52aXNTdGF0ZSA9IEpTT04uc3RyaW5naWZ5KHZpc1N0YXRlKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHZpc0FycmF5LnB1c2goe1xyXG4gICAgICAgICAgYXR0cmlidXRlczogYnVsa19jb250ZW50LnZpc3VhbGl6YXRpb24sXHJcbiAgICAgICAgICB0eXBlOiBlbGVtZW50Ll90eXBlLFxyXG4gICAgICAgICAgaWQ6IGVsZW1lbnQuX2lkLFxyXG4gICAgICAgICAgX3ZlcnNpb246IGJ1bGtfY29udGVudC52aXN1YWxpemF0aW9uLnZlcnNpb25cclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIHZpc0FycmF5O1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgbG9nKFxyXG4gICAgICAgICd3YXp1aC1lbGFzdGljOmJ1aWxkQ2x1c3RlclZpc3VhbGl6YXRpb25zUmF3JyxcclxuICAgICAgICBlcnJvci5tZXNzYWdlIHx8IGVycm9yXHJcbiAgICAgICk7XHJcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBUaGlzIGNyZWF0ZXMgYSB2aXN1YWxpemF0aW9uIG9mIGRhdGEgaW4gcmVxXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxyXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IHZpcyBvYmogb3IgRXJyb3JSZXNwb25zZVxyXG4gICAqL1xyXG4gIGFzeW5jIGNyZWF0ZVZpcyhjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdDx7IHBhdHRlcm46IHN0cmluZywgdGFiOiBzdHJpbmcgfT4sIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKFxyXG4gICAgICAgICghcmVxdWVzdC5wYXJhbXMudGFiLmluY2x1ZGVzKCdvdmVydmlldy0nKSAmJlxyXG4gICAgICAgICAgIXJlcXVlc3QucGFyYW1zLnRhYi5pbmNsdWRlcygnYWdlbnRzLScpKVxyXG4gICAgICApIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ01pc3NpbmcgcGFyYW1ldGVycyBjcmVhdGluZyB2aXN1YWxpemF0aW9ucycpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCB0YWJQcmVmaXggPSByZXF1ZXN0LnBhcmFtcy50YWIuaW5jbHVkZXMoJ292ZXJ2aWV3JylcclxuICAgICAgICA/ICdvdmVydmlldydcclxuICAgICAgICA6ICdhZ2VudHMnO1xyXG5cclxuICAgICAgY29uc3QgdGFiU3BsaXQgPSByZXF1ZXN0LnBhcmFtcy50YWIuc3BsaXQoJy0nKTtcclxuICAgICAgY29uc3QgdGFiU3VmaXggPSB0YWJTcGxpdFsxXTtcclxuXHJcbiAgICAgIGNvbnN0IGZpbGUgPVxyXG4gICAgICAgIHRhYlByZWZpeCA9PT0gJ292ZXJ2aWV3J1xyXG4gICAgICAgICAgPyBPdmVydmlld1Zpc3VhbGl6YXRpb25zW3RhYlN1Zml4XVxyXG4gICAgICAgICAgOiBBZ2VudHNWaXN1YWxpemF0aW9uc1t0YWJTdWZpeF07XHJcbiAgICAgIGlmICghZmlsZSkge1xyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5ub3RGb3VuZCh7Ym9keTp7bWVzc2FnZTogYFZpc3VhbGl6YXRpb25zIG5vdCBmb3VuZCBmb3IgJHtyZXF1ZXN0LnBhcmFtcy50YWJ9YH19KTtcclxuICAgICAgfVxyXG4gICAgICBsb2coJ3dhenVoLWVsYXN0aWM6Y3JlYXRlVmlzJywgYCR7dGFiUHJlZml4fVske3RhYlN1Zml4fV0gd2l0aCBpbmRleCBwYXR0ZXJuICR7cmVxdWVzdC5wYXJhbXMucGF0dGVybn1gLCAnZGVidWcnKTtcclxuICAgICAgY29uc3QgcmF3ID0gYXdhaXQgdGhpcy5idWlsZFZpc3VhbGl6YXRpb25zUmF3KFxyXG4gICAgICAgIGZpbGUsXHJcbiAgICAgICAgcmVxdWVzdC5wYXJhbXMucGF0dGVyblxyXG4gICAgICApO1xyXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgIGJvZHk6IHsgYWNrbm93bGVkZ2U6IHRydWUsIHJhdzogcmF3IH1cclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3dhenVoLWVsYXN0aWM6Y3JlYXRlVmlzJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDQwMDcsIDUwMCwgcmVzcG9uc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogVGhpcyBjcmVhdGVzIGEgdmlzdWFsaXphdGlvbiBvZiBjbHVzdGVyXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxyXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IHZpcyBvYmogb3IgRXJyb3JSZXNwb25zZVxyXG4gICAqL1xyXG4gIGFzeW5jIGNyZWF0ZUNsdXN0ZXJWaXMoY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3Q8eyBwYXR0ZXJuOiBzdHJpbmcsIHRhYjogc3RyaW5nIH0sIHVua25vd24sIGFueT4sIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKFxyXG4gICAgICAgICFyZXF1ZXN0LnBhcmFtcy5wYXR0ZXJuIHx8XHJcbiAgICAgICAgIXJlcXVlc3QucGFyYW1zLnRhYiB8fFxyXG4gICAgICAgICFyZXF1ZXN0LmJvZHkgfHxcclxuICAgICAgICAhcmVxdWVzdC5ib2R5Lm5vZGVzIHx8XHJcbiAgICAgICAgIXJlcXVlc3QuYm9keS5ub2Rlcy5hZmZlY3RlZF9pdGVtcyB8fFxyXG4gICAgICAgICFyZXF1ZXN0LmJvZHkubm9kZXMubmFtZSB8fFxyXG4gICAgICAgIChyZXF1ZXN0LnBhcmFtcy50YWIgJiYgIXJlcXVlc3QucGFyYW1zLnRhYi5pbmNsdWRlcygnY2x1c3Rlci0nKSlcclxuICAgICAgKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdNaXNzaW5nIHBhcmFtZXRlcnMgY3JlYXRpbmcgdmlzdWFsaXphdGlvbnMnKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgdHlwZSA9IHJlcXVlc3QucGFyYW1zLnRhYi5zcGxpdCgnLScpWzFdO1xyXG5cclxuICAgICAgY29uc3QgZmlsZSA9IENsdXN0ZXJWaXN1YWxpemF0aW9uc1t0eXBlXTtcclxuICAgICAgY29uc3Qgbm9kZXMgPSByZXF1ZXN0LmJvZHkubm9kZXMuYWZmZWN0ZWRfaXRlbXM7XHJcbiAgICAgIGNvbnN0IG5hbWUgPSByZXF1ZXN0LmJvZHkubm9kZXMubmFtZTtcclxuICAgICAgY29uc3QgbWFzdGVyTm9kZSA9IHJlcXVlc3QuYm9keS5ub2Rlcy5tYXN0ZXJfbm9kZTtcclxuXHJcbiAgICAgIGNvbnN0IHsgaWQ6IHBhdHRlcm5JRCwgdGl0bGU6IHBhdHRlcm5OYW1lIH0gPSByZXF1ZXN0LmJvZHkucGF0dGVybjtcclxuXHJcbiAgICAgIGNvbnN0IHJhdyA9IGF3YWl0IHRoaXMuYnVpbGRDbHVzdGVyVmlzdWFsaXphdGlvbnNSYXcoXHJcbiAgICAgICAgZmlsZSxcclxuICAgICAgICBwYXR0ZXJuSUQsXHJcbiAgICAgICAgbm9kZXMsXHJcbiAgICAgICAgbmFtZSxcclxuICAgICAgICBtYXN0ZXJOb2RlLFxyXG4gICAgICAgIHBhdHRlcm5OYW1lXHJcbiAgICAgICk7XHJcblxyXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgIGJvZHk6IHsgYWNrbm93bGVkZ2U6IHRydWUsIHJhdzogcmF3IH1cclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3dhenVoLWVsYXN0aWM6Y3JlYXRlQ2x1c3RlclZpcycsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCA0MDA5LCA1MDAsIHJlc3BvbnNlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFRoaXMgY2hlY2tzIGlmIHRoZXJlIGlzIHNhbXBsZSBhbGVydHNcclxuICAgKiBHRVQgL2VsYXN0aWMvc2FtcGxlYWxlcnRzXHJcbiAgICogQHBhcmFtIHsqfSBjb250ZXh0XHJcbiAgICogQHBhcmFtIHsqfSByZXF1ZXN0XHJcbiAgICogQHBhcmFtIHsqfSByZXNwb25zZVxyXG4gICAqIHthbGVydHM6IFsuLi5dfSBvciBFcnJvclJlc3BvbnNlXHJcbiAgICovXHJcbiAgYXN5bmMgaGF2ZVNhbXBsZUFsZXJ0cyhjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCwgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5KSB7XHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBDaGVjayBpZiB3YXp1aCBzYW1wbGUgYWxlcnRzIGluZGV4IGV4aXN0c1xyXG4gICAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgUHJvbWlzZS5hbGwoT2JqZWN0LmtleXMoV0FaVUhfU0FNUExFX0FMRVJUU19DQVRFR09SSUVTX1RZUEVfQUxFUlRTKVxyXG4gICAgICAgIC5tYXAoKGNhdGVnb3J5KSA9PiBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5pbmRpY2VzLmV4aXN0cyh7XHJcbiAgICAgICAgICBpbmRleDogdGhpcy5idWlsZFNhbXBsZUluZGV4QnlDYXRlZ29yeShjYXRlZ29yeSlcclxuICAgICAgICB9KSkpO1xyXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgIGJvZHk6IHsgc2FtcGxlQWxlcnRzSW5zdGFsbGVkOiByZXN1bHRzLnNvbWUocmVzdWx0ID0+IHJlc3VsdC5ib2R5KSB9XHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoJ1NhbXBsZSBBbGVydHMgY2F0ZWdvcnkgbm90IHZhbGlkJywgMTAwMCwgNTAwLCByZXNwb25zZSk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIC8qKlxyXG4gICAqIFRoaXMgY3JlYXRlcyBzYW1wbGUgYWxlcnRzIGluIHdhenVoLXNhbXBsZS1hbGVydHNcclxuICAgKiBHRVQgL2VsYXN0aWMvc2FtcGxlYWxlcnRzL3tjYXRlZ29yeX1cclxuICAgKiBAcGFyYW0geyp9IGNvbnRleHRcclxuICAgKiBAcGFyYW0geyp9IHJlcXVlc3RcclxuICAgKiBAcGFyYW0geyp9IHJlc3BvbnNlXHJcbiAgICoge2FsZXJ0czogWy4uLl19IG9yIEVycm9yUmVzcG9uc2VcclxuICAgKi9cclxuICBhc3luYyBoYXZlU2FtcGxlQWxlcnRzT2ZDYXRlZ29yeShjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdDx7IGNhdGVnb3J5OiBzdHJpbmcgfT4sIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3Qgc2FtcGxlQWxlcnRzSW5kZXggPSB0aGlzLmJ1aWxkU2FtcGxlSW5kZXhCeUNhdGVnb3J5KHJlcXVlc3QucGFyYW1zLmNhdGVnb3J5KTtcclxuICAgICAgLy8gQ2hlY2sgaWYgd2F6dWggc2FtcGxlIGFsZXJ0cyBpbmRleCBleGlzdHNcclxuICAgICAgY29uc3QgZXhpc3RzU2FtcGxlSW5kZXggPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5pbmRpY2VzLmV4aXN0cyh7XHJcbiAgICAgICAgaW5kZXg6IHNhbXBsZUFsZXJ0c0luZGV4XHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgIGJvZHk6IHsgaW5kZXg6IHNhbXBsZUFsZXJ0c0luZGV4LCBleGlzdHM6IGV4aXN0c1NhbXBsZUluZGV4LmJvZHkgfVxyXG4gICAgICB9KVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgbG9nKFxyXG4gICAgICAgICd3YXp1aC1lbGFzdGljOmhhdmVTYW1wbGVBbGVydHNPZkNhdGVnb3J5JyxcclxuICAgICAgICBgRXJyb3IgY2hlY2tpbmcgaWYgdGhlcmUgYXJlIHNhbXBsZSBhbGVydHMgaW5kaWNlczogJHtlcnJvci5tZXNzYWdlIHx8IGVycm9yfWBcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IFtzdGF0dXNDb2RlLCBlcnJvck1lc3NhZ2VdID0gdGhpcy5nZXRFcnJvckRldGFpbHMoZXJyb3IpO1xyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShgRXJyb3IgY2hlY2tpbmcgaWYgdGhlcmUgYXJlIHNhbXBsZSBhbGVydHMgaW5kaWNlczogJHtlcnJvck1lc3NhZ2UgfHwgZXJyb3J9YCwgMTAwMCwgc3RhdHVzQ29kZSwgcmVzcG9uc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuICAvKipcclxuICAgKiBUaGlzIGNyZWF0ZXMgc2FtcGxlIGFsZXJ0cyBpbiB3YXp1aC1zYW1wbGUtYWxlcnRzXHJcbiAgICogUE9TVCAvZWxhc3RpYy9zYW1wbGVhbGVydHMve2NhdGVnb3J5fVxyXG4gICAqIHtcclxuICAgKiAgIFwibWFuYWdlclwiOiB7XHJcbiAgICogICAgICBcIm5hbWVcIjogXCJtYW5hZ2VyX25hbWVcIlxyXG4gICAqICAgIH0sXHJcbiAgICogICAgY2x1c3Rlcjoge1xyXG4gICAqICAgICAgbmFtZTogXCJteWNsdXN0ZXJcIixcclxuICAgKiAgICAgIG5vZGU6IFwibXlub2RlXCJcclxuICAgKiAgICB9XHJcbiAgICogfVxyXG4gICAqIEBwYXJhbSB7Kn0gY29udGV4dFxyXG4gICAqIEBwYXJhbSB7Kn0gcmVxdWVzdFxyXG4gICAqIEBwYXJhbSB7Kn0gcmVzcG9uc2VcclxuICAgKiB7aW5kZXg6IHN0cmluZywgYWxlcnRzOiBbLi4uXSwgY291bnQ6IG51bWJlcn0gb3IgRXJyb3JSZXNwb25zZVxyXG4gICAqL1xyXG4gIGFzeW5jIGNyZWF0ZVNhbXBsZUFsZXJ0cyhjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdDx7IGNhdGVnb3J5OiBzdHJpbmcgfT4sIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSkge1xyXG4gICAgY29uc3Qgc2FtcGxlQWxlcnRzSW5kZXggPSB0aGlzLmJ1aWxkU2FtcGxlSW5kZXhCeUNhdGVnb3J5KHJlcXVlc3QucGFyYW1zLmNhdGVnb3J5KTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBDaGVjayBpZiB1c2VyIGhhcyBhZG1pbmlzdHJhdG9yIHJvbGUgaW4gdG9rZW5cclxuICAgICAgY29uc3QgdG9rZW4gPSBnZXRDb29raWVWYWx1ZUJ5TmFtZShyZXF1ZXN0LmhlYWRlcnMuY29va2llLCAnd3otdG9rZW4nKTtcclxuICAgICAgaWYgKCF0b2tlbikge1xyXG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdObyB0b2tlbiBwcm92aWRlZCcsIDQwMSwgNDAxLCByZXNwb25zZSk7XHJcbiAgICAgIH07XHJcbiAgICAgIGNvbnN0IGRlY29kZWRUb2tlbiA9IGp3dERlY29kZSh0b2tlbik7XHJcbiAgICAgIGlmICghZGVjb2RlZFRva2VuKSB7XHJcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoJ05vIHBlcm1pc3Npb25zIGluIHRva2VuJywgNDAxLCA0MDEsIHJlc3BvbnNlKTtcclxuICAgICAgfTtcclxuICAgICAgaWYgKCFkZWNvZGVkVG9rZW4ucmJhY19yb2xlcyB8fCAhZGVjb2RlZFRva2VuLnJiYWNfcm9sZXMuaW5jbHVkZXMoV0FaVUhfUk9MRV9BRE1JTklTVFJBVE9SX0lEKSkge1xyXG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdObyBhZG1pbmlzdHJhdG9yIHJvbGUnLCA0MDEsIDQwMSwgcmVzcG9uc2UpO1xyXG4gICAgICB9O1xyXG4gICAgICAvLyBDaGVjayB0aGUgcHJvdmlkZWQgdG9rZW4gaXMgdmFsaWRcclxuICAgICAgY29uc3QgYXBpSG9zdElEID0gZ2V0Q29va2llVmFsdWVCeU5hbWUocmVxdWVzdC5oZWFkZXJzLmNvb2tpZSwgJ3d6LWFwaScpO1xyXG4gICAgICBpZiAoIWFwaUhvc3RJRCkge1xyXG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdObyBBUEkgaWQgcHJvdmlkZWQnLCA0MDEsIDQwMSwgcmVzcG9uc2UpO1xyXG4gICAgICB9O1xyXG4gICAgICBjb25zdCByZXNwb25zZVRva2VuSXNXb3JraW5nID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdCgnR0VUJywgYC8vYCwge30sIHsgYXBpSG9zdElEIH0pO1xyXG4gICAgICBpZiAocmVzcG9uc2VUb2tlbklzV29ya2luZy5zdGF0dXMgIT09IDIwMCkge1xyXG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdUb2tlbiBpcyBub3QgdmFsaWQnLCA1MDAsIDUwMCwgcmVzcG9uc2UpO1xyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgYnVsa1ByZWZpeCA9IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICBpbmRleDoge1xyXG4gICAgICAgICAgX2luZGV4OiBzYW1wbGVBbGVydHNJbmRleFxyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICAgIGNvbnN0IGFsZXJ0R2VuZXJhdGVQYXJhbXMgPSByZXF1ZXN0LmJvZHkgJiYgcmVxdWVzdC5ib2R5LnBhcmFtcyB8fCB7fTtcclxuXHJcbiAgICAgIGNvbnN0IHNhbXBsZUFsZXJ0cyA9IFdBWlVIX1NBTVBMRV9BTEVSVFNfQ0FURUdPUklFU19UWVBFX0FMRVJUU1tyZXF1ZXN0LnBhcmFtcy5jYXRlZ29yeV0ubWFwKCh0eXBlQWxlcnQpID0+IGdlbmVyYXRlQWxlcnRzKHsgLi4udHlwZUFsZXJ0LCAuLi5hbGVydEdlbmVyYXRlUGFyYW1zIH0sIHJlcXVlc3QuYm9keS5hbGVydHMgfHwgdHlwZUFsZXJ0LmFsZXJ0cyB8fCBXQVpVSF9TQU1QTEVfQUxFUlRTX0RFRkFVTFRfTlVNQkVSX0FMRVJUUykpLmZsYXQoKTtcclxuICAgICAgY29uc3QgYnVsayA9IHNhbXBsZUFsZXJ0cy5tYXAoc2FtcGxlQWxlcnQgPT4gYCR7YnVsa1ByZWZpeH1cXG4ke0pTT04uc3RyaW5naWZ5KHNhbXBsZUFsZXJ0KX1cXG5gKS5qb2luKCcnKTtcclxuXHJcbiAgICAgIC8vIEluZGV4IGFsZXJ0c1xyXG5cclxuICAgICAgLy8gQ2hlY2sgaWYgd2F6dWggc2FtcGxlIGFsZXJ0cyBpbmRleCBleGlzdHNcclxuICAgICAgY29uc3QgZXhpc3RzU2FtcGxlSW5kZXggPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5pbmRpY2VzLmV4aXN0cyh7XHJcbiAgICAgICAgaW5kZXg6IHNhbXBsZUFsZXJ0c0luZGV4XHJcbiAgICAgIH0pO1xyXG4gICAgICBpZiAoIWV4aXN0c1NhbXBsZUluZGV4LmJvZHkpIHtcclxuICAgICAgICAvLyBDcmVhdGUgd2F6dWggc2FtcGxlIGFsZXJ0cyBpbmRleFxyXG5cclxuICAgICAgICBjb25zdCBjb25maWd1cmF0aW9uID0ge1xyXG4gICAgICAgICAgc2V0dGluZ3M6IHtcclxuICAgICAgICAgICAgaW5kZXg6IHtcclxuICAgICAgICAgICAgICBudW1iZXJfb2Zfc2hhcmRzOiBXQVpVSF9TQU1QTEVfQUxFUlRTX0lOREVYX1NIQVJEUyxcclxuICAgICAgICAgICAgICBudW1iZXJfb2ZfcmVwbGljYXM6IFdBWlVIX1NBTVBMRV9BTEVSVFNfSU5ERVhfUkVQTElDQVNcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmluZGljZXMuY3JlYXRlKHtcclxuICAgICAgICAgIGluZGV4OiBzYW1wbGVBbGVydHNJbmRleCxcclxuICAgICAgICAgIGJvZHk6IGNvbmZpZ3VyYXRpb25cclxuICAgICAgICB9KTtcclxuICAgICAgICBsb2coXHJcbiAgICAgICAgICAnd2F6dWgtZWxhc3RpYzpjcmVhdGVTYW1wbGVBbGVydHMnLFxyXG4gICAgICAgICAgYENyZWF0ZWQgJHtzYW1wbGVBbGVydHNJbmRleH0gaW5kZXhgLFxyXG4gICAgICAgICAgJ2RlYnVnJ1xyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmJ1bGsoe1xyXG4gICAgICAgIGluZGV4OiBzYW1wbGVBbGVydHNJbmRleCxcclxuICAgICAgICBib2R5OiBidWxrXHJcbiAgICAgIH0pO1xyXG4gICAgICBsb2coXHJcbiAgICAgICAgJ3dhenVoLWVsYXN0aWM6Y3JlYXRlU2FtcGxlQWxlcnRzJyxcclxuICAgICAgICBgQWRkZWQgc2FtcGxlIGFsZXJ0cyB0byAke3NhbXBsZUFsZXJ0c0luZGV4fSBpbmRleGAsXHJcbiAgICAgICAgJ2RlYnVnJ1xyXG4gICAgICApO1xyXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgIGJvZHk6IHsgaW5kZXg6IHNhbXBsZUFsZXJ0c0luZGV4LCBhbGVydENvdW50OiBzYW1wbGVBbGVydHMubGVuZ3RoIH1cclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coXHJcbiAgICAgICAgJ3dhenVoLWVsYXN0aWM6Y3JlYXRlU2FtcGxlQWxlcnRzJyxcclxuICAgICAgICBgRXJyb3IgYWRkaW5nIHNhbXBsZSBhbGVydHMgdG8gJHtzYW1wbGVBbGVydHNJbmRleH0gaW5kZXg6ICR7ZXJyb3IubWVzc2FnZSB8fCBlcnJvcn1gXHJcbiAgICAgICk7XHJcbiAgICAgIFxyXG4gICAgICBjb25zdCBbc3RhdHVzQ29kZSwgZXJyb3JNZXNzYWdlXSA9IHRoaXMuZ2V0RXJyb3JEZXRhaWxzKGVycm9yKTtcclxuICAgICAgXHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yTWVzc2FnZSB8fCBlcnJvciwgMTAwMCwgc3RhdHVzQ29kZSwgcmVzcG9uc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuICAvKipcclxuICAgKiBUaGlzIGRlbGV0ZXMgc2FtcGxlIGFsZXJ0c1xyXG4gICAqIEBwYXJhbSB7Kn0gY29udGV4dFxyXG4gICAqIEBwYXJhbSB7Kn0gcmVxdWVzdFxyXG4gICAqIEBwYXJhbSB7Kn0gcmVzcG9uc2VcclxuICAgKiB7cmVzdWx0OiBcImRlbGV0ZWRcIiwgaW5kZXg6IHN0cmluZ30gb3IgRXJyb3JSZXNwb25zZVxyXG4gICAqL1xyXG4gIGFzeW5jIGRlbGV0ZVNhbXBsZUFsZXJ0cyhjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdDx7IGNhdGVnb3J5OiBzdHJpbmcgfT4sIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSkge1xyXG4gICAgLy8gRGVsZXRlIFdhenVoIHNhbXBsZSBhbGVydCBpbmRleFxyXG5cclxuICAgIGNvbnN0IHNhbXBsZUFsZXJ0c0luZGV4ID0gdGhpcy5idWlsZFNhbXBsZUluZGV4QnlDYXRlZ29yeShyZXF1ZXN0LnBhcmFtcy5jYXRlZ29yeSk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgLy8gQ2hlY2sgaWYgdXNlciBoYXMgYWRtaW5pc3RyYXRvciByb2xlIGluIHRva2VuXHJcbiAgICAgIGNvbnN0IHRva2VuID0gZ2V0Q29va2llVmFsdWVCeU5hbWUocmVxdWVzdC5oZWFkZXJzLmNvb2tpZSwgJ3d6LXRva2VuJyk7XHJcbiAgICAgIGlmICghdG9rZW4pIHtcclxuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZSgnTm8gdG9rZW4gcHJvdmlkZWQnLCA0MDEsIDQwMSwgcmVzcG9uc2UpO1xyXG4gICAgICB9O1xyXG4gICAgICBjb25zdCBkZWNvZGVkVG9rZW4gPSBqd3REZWNvZGUodG9rZW4pO1xyXG4gICAgICBpZiAoIWRlY29kZWRUb2tlbikge1xyXG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdObyBwZXJtaXNzaW9ucyBpbiB0b2tlbicsIDQwMSwgNDAxLCByZXNwb25zZSk7XHJcbiAgICAgIH07XHJcbiAgICAgIGlmICghZGVjb2RlZFRva2VuLnJiYWNfcm9sZXMgfHwgIWRlY29kZWRUb2tlbi5yYmFjX3JvbGVzLmluY2x1ZGVzKFdBWlVIX1JPTEVfQURNSU5JU1RSQVRPUl9JRCkpIHtcclxuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZSgnTm8gYWRtaW5pc3RyYXRvciByb2xlJywgNDAxLCA0MDEsIHJlc3BvbnNlKTtcclxuICAgICAgfTtcclxuICAgICAgLy8gQ2hlY2sgdGhlIHByb3ZpZGVkIHRva2VuIGlzIHZhbGlkXHJcbiAgICAgIGNvbnN0IGFwaUhvc3RJRCA9IGdldENvb2tpZVZhbHVlQnlOYW1lKHJlcXVlc3QuaGVhZGVycy5jb29raWUsICd3ei1hcGknKTtcclxuICAgICAgaWYgKCFhcGlIb3N0SUQpIHtcclxuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZSgnTm8gQVBJIGlkIHByb3ZpZGVkJywgNDAxLCA0MDEsIHJlc3BvbnNlKTtcclxuICAgICAgfTtcclxuICAgICAgY29uc3QgcmVzcG9uc2VUb2tlbklzV29ya2luZyA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoJ0dFVCcsIGAvL2AsIHt9LCB7IGFwaUhvc3RJRCB9KTtcclxuICAgICAgaWYgKHJlc3BvbnNlVG9rZW5Jc1dvcmtpbmcuc3RhdHVzICE9PSAyMDApIHtcclxuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZSgnVG9rZW4gaXMgbm90IHZhbGlkJywgNTAwLCA1MDAsIHJlc3BvbnNlKTtcclxuICAgICAgfTtcclxuXHJcbiAgICAgIC8vIENoZWNrIGlmIFdhenVoIHNhbXBsZSBhbGVydHMgaW5kZXggZXhpc3RzXHJcbiAgICAgIGNvbnN0IGV4aXN0c1NhbXBsZUluZGV4ID0gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuaW5kaWNlcy5leGlzdHMoe1xyXG4gICAgICAgIGluZGV4OiBzYW1wbGVBbGVydHNJbmRleFxyXG4gICAgICB9KTtcclxuICAgICAgaWYgKGV4aXN0c1NhbXBsZUluZGV4LmJvZHkpIHtcclxuICAgICAgICAvLyBEZWxldGUgV2F6dWggc2FtcGxlIGFsZXJ0cyBpbmRleFxyXG4gICAgICAgIGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmluZGljZXMuZGVsZXRlKHsgaW5kZXg6IHNhbXBsZUFsZXJ0c0luZGV4IH0pO1xyXG4gICAgICAgIGxvZyhcclxuICAgICAgICAgICd3YXp1aC1lbGFzdGljOmRlbGV0ZVNhbXBsZUFsZXJ0cycsXHJcbiAgICAgICAgICBgRGVsZXRlZCAke3NhbXBsZUFsZXJ0c0luZGV4fSBpbmRleGAsXHJcbiAgICAgICAgICAnZGVidWcnXHJcbiAgICAgICAgKTtcclxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgICAgYm9keTogeyByZXN1bHQ6ICdkZWxldGVkJywgaW5kZXg6IHNhbXBsZUFsZXJ0c0luZGV4IH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShgJHtzYW1wbGVBbGVydHNJbmRleH0gaW5kZXggZG9lc24ndCBleGlzdGAsIDEwMDAsIDUwMCwgcmVzcG9uc2UpXHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGxvZyhcclxuICAgICAgICAnd2F6dWgtZWxhc3RpYzpkZWxldGVTYW1wbGVBbGVydHMnLFxyXG4gICAgICAgIGBFcnJvciBkZWxldGluZyBzYW1wbGUgYWxlcnRzIG9mICR7c2FtcGxlQWxlcnRzSW5kZXh9IGluZGV4OiAke2Vycm9yLm1lc3NhZ2UgfHwgZXJyb3J9YFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBbc3RhdHVzQ29kZSwgZXJyb3JNZXNzYWdlXSA9IHRoaXMuZ2V0RXJyb3JEZXRhaWxzKGVycm9yKTtcclxuXHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yTWVzc2FnZSB8fCBlcnJvciwgMTAwMCwgc3RhdHVzQ29kZSwgcmVzcG9uc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgYWxlcnRzKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnkpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5zZWFyY2gocmVxdWVzdC5ib2R5KTtcclxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICBib2R5OiBkYXRhLmJvZHlcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3dhenVoLWVsYXN0aWM6YWxlcnRzJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDQwMTAsIDUwMCwgcmVzcG9uc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gQ2hlY2sgaWYgdGhlcmUgYXJlIGluZGljZXMgZm9yIFN0YXRpc3RpY3NcclxuICBhc3luYyBleGlzdFN0YXRpc3RpY3NJbmRpY2VzKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnkpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldENvbmZpZ3VyYXRpb24oKTtcclxuICAgICAgY29uc3Qgc3RhdGlzdGljc1BhdHRlcm4gPSBgJHtjb25maWdbJ2Nyb24ucHJlZml4J10gfHwgJ3dhenVoJ30tJHtjb25maWdbJ2Nyb24uc3RhdGlzdGljcy5pbmRleC5uYW1lJ10gfHwgJ3N0YXRpc3RpY3MnfSpgOyAvL1RPRE86IHJlcGxhY2UgYnkgZGVmYXVsdCBhcyBjb25zdGFudHMgaW5zdGVhZCBoYXJkY29kZWQgKCd3YXp1aCcgYW5kICdzdGF0aXN0aWNzJylcclxuICAgICAgY29uc3QgZXhpc3RJbmRleCA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmluZGljZXMuZXhpc3RzKHtcclxuICAgICAgICBpbmRleDogc3RhdGlzdGljc1BhdHRlcm4sXHJcbiAgICAgICAgYWxsb3dfbm9faW5kaWNlczogZmFsc2VcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgYm9keTogZXhpc3RJbmRleC5ib2R5XHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgbG9nKCd3YXp1aC1lbGFzdGljOmV4aXN0c1N0YXRpc3RpY3NJbmRpY2VzJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDEwMDAsIDUwMCwgcmVzcG9uc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0RXJyb3JEZXRhaWxzKGVycm9yKXtcclxuICAgIGNvbnN0IHN0YXR1c0NvZGUgPSBlcnJvcj8ubWV0YT8uc3RhdHVzQ29kZSB8fCA1MDA7XHJcbiAgICBsZXQgZXJyb3JNZXNzYWdlID0gZXJyb3IubWVzc2FnZTtcclxuXHJcbiAgICBpZihzdGF0dXNDb2RlID09PSA0MDMpe1xyXG4gICAgICBlcnJvck1lc3NhZ2UgPSBlcnJvcj8ubWV0YT8uYm9keT8uZXJyb3I/LnJlYXNvbiB8fCAnUGVybWlzc2lvbiBkZW5pZWQnO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBbc3RhdHVzQ29kZSwgZXJyb3JNZXNzYWdlXTtcclxuICB9XHJcbn1cclxuIl19