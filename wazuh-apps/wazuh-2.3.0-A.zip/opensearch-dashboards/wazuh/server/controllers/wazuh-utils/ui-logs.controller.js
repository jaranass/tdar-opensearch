"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.UiLogsCtrl = void 0;

var _errorResponse = require("../../lib/error-response");

var _readLastLines = require("read-last-lines");

var _constants = require("../../../common/constants");

var _uiLogger = _interopRequireDefault(require("../../lib/ui-logger"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 * Wazuh app - Class for UI Logs functions
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
// Require some libraries
class UiLogsCtrl {
  /**
   * Constructor
   * @param {*} server
   */
  constructor() {}
  /**
   * Returns Wazuh ui logs
   * @param {Object} response
   * @returns {Array<String>} app logs or ErrorResponse
   */


  async getUiLogs(response) {
    try {
      return _uiLogger.default.initDirectory().then(async () => {
        if (!_uiLogger.default.checkFileExist(_constants.WAZUH_UI_LOGS_RAW_PATH)) {
          return response.ok({
            body: {
              error: 0,
              rawLogs: []
            }
          });
        } else {
          let arrayLog = await this.getUiFileLogs(_constants.WAZUH_UI_LOGS_RAW_PATH);
          return response.ok({
            body: {
              error: 0,
              rawLogs: arrayLog.filter(item => typeof item === 'string' && item.length)
            }
          });
        }
      });
    } catch (error) {
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3036, 500, response);
    }
  }
  /**
   * Add new UI Log entry in ui logs file
   * @param request
   * @param response
   * @returns success message or ErrorResponse
   */


  async createUiLogs(request, response) {
    try {
      const {
        location,
        message,
        level
      } = request.body;
      await _uiLogger.default.log(location, message, level);
      return response.ok({
        body: {
          statusCode: 200,
          error: 0,
          message: 'Log has been added'
        }
      });
    } catch (error) {
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3021, 500, response);
    }
  }
  /**
   * Get UI logs from specific log file
   * @param filepath
   * @returns Array
   */


  async getUiFileLogs(filepath) {
    try {
      const lastLogs = await (0, _readLastLines.read)(filepath, 50);
      return lastLogs.split('\n');
    } catch (err) {
      throw err;
    }
  }

}

exports.UiLogsCtrl = UiLogsCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVpLWxvZ3MuY29udHJvbGxlci50cyJdLCJuYW1lcyI6WyJVaUxvZ3NDdHJsIiwiY29uc3RydWN0b3IiLCJnZXRVaUxvZ3MiLCJyZXNwb25zZSIsInVpTG9nZ2VyIiwiaW5pdERpcmVjdG9yeSIsInRoZW4iLCJjaGVja0ZpbGVFeGlzdCIsIldBWlVIX1VJX0xPR1NfUkFXX1BBVEgiLCJvayIsImJvZHkiLCJlcnJvciIsInJhd0xvZ3MiLCJhcnJheUxvZyIsImdldFVpRmlsZUxvZ3MiLCJmaWx0ZXIiLCJpdGVtIiwibGVuZ3RoIiwibWVzc2FnZSIsImNyZWF0ZVVpTG9ncyIsInJlcXVlc3QiLCJsb2NhdGlvbiIsImxldmVsIiwibG9nIiwic3RhdHVzQ29kZSIsImZpbGVwYXRoIiwibGFzdExvZ3MiLCJzcGxpdCIsImVyciJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQWFBOztBQUNBOztBQUNBOztBQUVBOzs7O0FBakJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQU9PLE1BQU1BLFVBQU4sQ0FBaUI7QUFDdEI7QUFDRjtBQUNBO0FBQ0E7QUFDRUMsRUFBQUEsV0FBVyxHQUFHLENBQUU7QUFFaEI7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ2lCLFFBQVRDLFNBQVMsQ0FBQ0MsUUFBRCxFQUFnRDtBQUM3RCxRQUFJO0FBQ0YsYUFBT0Msa0JBQVNDLGFBQVQsR0FBeUJDLElBQXpCLENBQThCLFlBQVk7QUFDL0MsWUFBSSxDQUFDRixrQkFBU0csY0FBVCxDQUF3QkMsaUNBQXhCLENBQUwsRUFBc0Q7QUFDcEQsaUJBQU9MLFFBQVEsQ0FBQ00sRUFBVCxDQUFZO0FBQ2pCQyxZQUFBQSxJQUFJLEVBQUU7QUFDSkMsY0FBQUEsS0FBSyxFQUFFLENBREg7QUFFSkMsY0FBQUEsT0FBTyxFQUFFO0FBRkw7QUFEVyxXQUFaLENBQVA7QUFNRCxTQVBELE1BT087QUFDTCxjQUFJQyxRQUFRLEdBQUcsTUFBTSxLQUFLQyxhQUFMLENBQW1CTixpQ0FBbkIsQ0FBckI7QUFDQSxpQkFBT0wsUUFBUSxDQUFDTSxFQUFULENBQVk7QUFDakJDLFlBQUFBLElBQUksRUFBRTtBQUNKQyxjQUFBQSxLQUFLLEVBQUUsQ0FESDtBQUVKQyxjQUFBQSxPQUFPLEVBQUVDLFFBQVEsQ0FBQ0UsTUFBVCxDQUFpQkMsSUFBRCxJQUFVLE9BQU9BLElBQVAsS0FBZ0IsUUFBaEIsSUFBNEJBLElBQUksQ0FBQ0MsTUFBM0Q7QUFGTDtBQURXLFdBQVosQ0FBUDtBQU1EO0FBQ0YsT0FqQk0sQ0FBUDtBQWtCRCxLQW5CRCxDQW1CRSxPQUFPTixLQUFQLEVBQWM7QUFDZCxhQUFPLGtDQUFjQSxLQUFLLENBQUNPLE9BQU4sSUFBaUJQLEtBQS9CLEVBQXNDLElBQXRDLEVBQTRDLEdBQTVDLEVBQWlEUixRQUFqRCxDQUFQO0FBQ0Q7QUFDRjtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ29CLFFBQVpnQixZQUFZLENBQUNDLE9BQUQsRUFBdUNqQixRQUF2QyxFQUFzRjtBQUN0RyxRQUFJO0FBQ0YsWUFBTTtBQUFFa0IsUUFBQUEsUUFBRjtBQUFZSCxRQUFBQSxPQUFaO0FBQXFCSSxRQUFBQTtBQUFyQixVQUErQkYsT0FBTyxDQUFDVixJQUE3QztBQUNBLFlBQU1OLGtCQUFTbUIsR0FBVCxDQUFhRixRQUFiLEVBQXVCSCxPQUF2QixFQUFnQ0ksS0FBaEMsQ0FBTjtBQUNBLGFBQU9uQixRQUFRLENBQUNNLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFO0FBQ0pjLFVBQUFBLFVBQVUsRUFBRSxHQURSO0FBRUpiLFVBQUFBLEtBQUssRUFBRSxDQUZIO0FBR0pPLFVBQUFBLE9BQU8sRUFBRTtBQUhMO0FBRFcsT0FBWixDQUFQO0FBT0QsS0FWRCxDQVVFLE9BQU9QLEtBQVAsRUFBYztBQUNkLGFBQU8sa0NBQWNBLEtBQUssQ0FBQ08sT0FBTixJQUFpQlAsS0FBL0IsRUFBc0MsSUFBdEMsRUFBNEMsR0FBNUMsRUFBaURSLFFBQWpELENBQVA7QUFDRDtBQUNGO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTs7O0FBQ3FCLFFBQWJXLGFBQWEsQ0FBQ1csUUFBRCxFQUFXO0FBQzVCLFFBQUk7QUFDRixZQUFNQyxRQUFRLEdBQUcsTUFBTSx5QkFBS0QsUUFBTCxFQUFlLEVBQWYsQ0FBdkI7QUFDQSxhQUFPQyxRQUFRLENBQUNDLEtBQVQsQ0FBZSxJQUFmLENBQVA7QUFDRCxLQUhELENBR0UsT0FBT0MsR0FBUCxFQUFZO0FBQ1osWUFBTUEsR0FBTjtBQUNEO0FBQ0Y7O0FBdkVxQiIsInNvdXJjZXNDb250ZW50IjpbIi8qXHJcbiAqIFdhenVoIGFwcCAtIENsYXNzIGZvciBVSSBMb2dzIGZ1bmN0aW9uc1xyXG4gKiBDb3B5cmlnaHQgKEMpIDIwMTUtMjAyMiBXYXp1aCwgSW5jLlxyXG4gKlxyXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxyXG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxyXG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxyXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxyXG4gKlxyXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxyXG4gKi9cclxuXHJcbi8vIFJlcXVpcmUgc29tZSBsaWJyYXJpZXNcclxuaW1wb3J0IHsgRXJyb3JSZXNwb25zZSB9IGZyb20gJy4uLy4uL2xpYi9lcnJvci1yZXNwb25zZSc7XHJcbmltcG9ydCB7IHJlYWQgfSBmcm9tICdyZWFkLWxhc3QtbGluZXMnO1xyXG5pbXBvcnQgeyBXQVpVSF9VSV9MT0dTX1JBV19QQVRIIH0gZnJvbSAnLi4vLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XHJcbmltcG9ydCB7IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCwgT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnkgfSBmcm9tICdzcmMvY29yZS9zZXJ2ZXInO1xyXG5pbXBvcnQgdWlMb2dnZXIgZnJvbSAnLi4vLi4vbGliL3VpLWxvZ2dlcic7XHJcblxyXG5leHBvcnQgY2xhc3MgVWlMb2dzQ3RybCB7XHJcbiAgLyoqXHJcbiAgICogQ29uc3RydWN0b3JcclxuICAgKiBAcGFyYW0geyp9IHNlcnZlclxyXG4gICAqL1xyXG4gIGNvbnN0cnVjdG9yKCkge31cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyBXYXp1aCB1aSBsb2dzXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXHJcbiAgICogQHJldHVybnMge0FycmF5PFN0cmluZz59IGFwcCBsb2dzIG9yIEVycm9yUmVzcG9uc2VcclxuICAgKi9cclxuICBhc3luYyBnZXRVaUxvZ3MocmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5KSB7XHJcbiAgICB0cnkge1xyXG4gICAgICByZXR1cm4gdWlMb2dnZXIuaW5pdERpcmVjdG9yeSgpLnRoZW4oYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGlmICghdWlMb2dnZXIuY2hlY2tGaWxlRXhpc3QoV0FaVUhfVUlfTE9HU19SQVdfUEFUSCkpIHtcclxuICAgICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgICAgIGJvZHk6IHtcclxuICAgICAgICAgICAgICBlcnJvcjogMCxcclxuICAgICAgICAgICAgICByYXdMb2dzOiBbXSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBsZXQgYXJyYXlMb2cgPSBhd2FpdCB0aGlzLmdldFVpRmlsZUxvZ3MoV0FaVUhfVUlfTE9HU19SQVdfUEFUSCk7XHJcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICAgICAgZXJyb3I6IDAsXHJcbiAgICAgICAgICAgICAgcmF3TG9nczogYXJyYXlMb2cuZmlsdGVyKChpdGVtKSA9PiB0eXBlb2YgaXRlbSA9PT0gJ3N0cmluZycgJiYgaXRlbS5sZW5ndGgpLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDMwMzYsIDUwMCwgcmVzcG9uc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQWRkIG5ldyBVSSBMb2cgZW50cnkgaW4gdWkgbG9ncyBmaWxlXHJcbiAgICogQHBhcmFtIHJlcXVlc3RcclxuICAgKiBAcGFyYW0gcmVzcG9uc2VcclxuICAgKiBAcmV0dXJucyBzdWNjZXNzIG1lc3NhZ2Ugb3IgRXJyb3JSZXNwb25zZVxyXG4gICAqL1xyXG4gIGFzeW5jIGNyZWF0ZVVpTG9ncyhyZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgeyBsb2NhdGlvbiwgbWVzc2FnZSwgbGV2ZWwgfSA9IHJlcXVlc3QuYm9keTtcclxuICAgICAgYXdhaXQgdWlMb2dnZXIubG9nKGxvY2F0aW9uLCBtZXNzYWdlLCBsZXZlbCk7XHJcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgYm9keToge1xyXG4gICAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxyXG4gICAgICAgICAgZXJyb3I6IDAsXHJcbiAgICAgICAgICBtZXNzYWdlOiAnTG9nIGhhcyBiZWVuIGFkZGVkJyxcclxuICAgICAgICB9LFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDMwMjEsIDUwMCwgcmVzcG9uc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogR2V0IFVJIGxvZ3MgZnJvbSBzcGVjaWZpYyBsb2cgZmlsZVxyXG4gICAqIEBwYXJhbSBmaWxlcGF0aFxyXG4gICAqIEByZXR1cm5zIEFycmF5XHJcbiAgICovXHJcbiAgYXN5bmMgZ2V0VWlGaWxlTG9ncyhmaWxlcGF0aCkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgbGFzdExvZ3MgPSBhd2FpdCByZWFkKGZpbGVwYXRoLCA1MCk7XHJcbiAgICAgIHJldHVybiBsYXN0TG9ncy5zcGxpdCgnXFxuJyk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgdGhyb3cgZXJyO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0=