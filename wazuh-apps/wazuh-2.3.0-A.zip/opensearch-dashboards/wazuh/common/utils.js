"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.delayAsPromise = void 0;

/**
 * 
 * @param timeMs Time in milliseconds
 * @returns Promise
 */
const delayAsPromise = timeMs => new Promise(resolve => setTimeout(resolve, timeMs));

exports.delayAsPromise = delayAsPromise;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInV0aWxzLnRzIl0sIm5hbWVzIjpbImRlbGF5QXNQcm9taXNlIiwidGltZU1zIiwiUHJvbWlzZSIsInJlc29sdmUiLCJzZXRUaW1lb3V0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1BLGNBQWMsR0FBSUMsTUFBRCxJQUFvQixJQUFJQyxPQUFKLENBQVlDLE9BQU8sSUFBSUMsVUFBVSxDQUFDRCxPQUFELEVBQVVGLE1BQVYsQ0FBakMsQ0FBM0MiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogXHJcbiAqIEBwYXJhbSB0aW1lTXMgVGltZSBpbiBtaWxsaXNlY29uZHNcclxuICogQHJldHVybnMgUHJvbWlzZVxyXG4gKi9cclxuZXhwb3J0IGNvbnN0IGRlbGF5QXNQcm9taXNlID0gKHRpbWVNczogbnVtYmVyKSA9PiBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgdGltZU1zKSk7Il19