"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.addJobToQueue = addJobToQueue;
exports.jobQueueRun = jobQueueRun;
exports.queue = void 0;

var _nodeCron = _interopRequireDefault(require("node-cron"));

var _logger = require("../../lib/logger");

var _constants = require("../../../common/constants");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 * Wazuh app - Add delayed jobs to a queue.
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
let queue = [];
exports.queue = queue;
;
/**
 * Add a job to the queue.
 * @param job Job to add to queue
 */

function addJobToQueue(job) {
  (0, _logger.log)('queue:addJob', `New job added`, 'debug');
  queue.push(job);
}

;

async function executePendingJobs() {
  try {
    if (!queue || !queue.length) return;
    const now = new Date();
    const pendingJobs = queue.filter(item => item.startAt <= now);
    (0, _logger.log)('queue:executePendingJobs', `Pending jobs: ${pendingJobs.length}`, 'debug');

    if (!pendingJobs || !pendingJobs.length) {
      return;
    }

    ;
    exports.queue = queue = queue.filter(item => item.startAt > now);

    for (const job of pendingJobs) {
      try {
        await job.run();
      } catch (error) {
        continue;
      }

      ;
    }
  } catch (error) {
    exports.queue = queue = [];
    (0, _logger.log)('queue:executePendingJobs', error.message || error);
    return Promise.reject(error);
  }
}
/**
 * Run the job queue it plugin start.
 * @param context 
 */


function jobQueueRun(context) {
  _nodeCron.default.schedule(_constants.WAZUH_QUEUE_CRON_FREQ, async () => {
    try {
      await executePendingJobs();
    } catch (error) {
      (0, _logger.log)('queue:launchCronJob', error.message || error);
    }
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbInF1ZXVlIiwiYWRkSm9iVG9RdWV1ZSIsImpvYiIsInB1c2giLCJleGVjdXRlUGVuZGluZ0pvYnMiLCJsZW5ndGgiLCJub3ciLCJEYXRlIiwicGVuZGluZ0pvYnMiLCJmaWx0ZXIiLCJpdGVtIiwic3RhcnRBdCIsInJ1biIsImVycm9yIiwibWVzc2FnZSIsIlByb21pc2UiLCJyZWplY3QiLCJqb2JRdWV1ZVJ1biIsImNvbnRleHQiLCJjcm9uIiwic2NoZWR1bGUiLCJXQVpVSF9RVUVVRV9DUk9OX0ZSRVEiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQVdBOztBQUNBOztBQUNBOzs7O0FBYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUtPLElBQUlBLEtBQUssR0FBRyxFQUFaOztBQU9OO0FBRUQ7QUFDQTtBQUNBO0FBQ0E7O0FBQ08sU0FBU0MsYUFBVCxDQUF1QkMsR0FBdkIsRUFBdUM7QUFDNUMsbUJBQUksY0FBSixFQUFxQixlQUFyQixFQUFxQyxPQUFyQztBQUNBRixFQUFBQSxLQUFLLENBQUNHLElBQU4sQ0FBV0QsR0FBWDtBQUNEOztBQUFBOztBQUVELGVBQWVFLGtCQUFmLEdBQW9DO0FBQ2xDLE1BQUk7QUFDRixRQUFJLENBQUNKLEtBQUQsSUFBVSxDQUFDQSxLQUFLLENBQUNLLE1BQXJCLEVBQTZCO0FBQzdCLFVBQU1DLEdBQVMsR0FBRyxJQUFJQyxJQUFKLEVBQWxCO0FBQ0EsVUFBTUMsV0FBd0IsR0FBR1IsS0FBSyxDQUFDUyxNQUFOLENBQWFDLElBQUksSUFBSUEsSUFBSSxDQUFDQyxPQUFMLElBQWdCTCxHQUFyQyxDQUFqQztBQUNBLHFCQUNFLDBCQURGLEVBRUcsaUJBQWdCRSxXQUFXLENBQUNILE1BQU8sRUFGdEMsRUFHRSxPQUhGOztBQUtBLFFBQUksQ0FBQ0csV0FBRCxJQUFnQixDQUFDQSxXQUFXLENBQUNILE1BQWpDLEVBQXdDO0FBQ3RDO0FBQ0Q7O0FBQUE7QUFDRCxvQkFBQUwsS0FBSyxHQUFHQSxLQUFLLENBQUNTLE1BQU4sQ0FBY0MsSUFBRCxJQUFxQkEsSUFBSSxDQUFDQyxPQUFMLEdBQWVMLEdBQWpELENBQVI7O0FBRUEsU0FBSyxNQUFNSixHQUFYLElBQWtCTSxXQUFsQixFQUErQjtBQUM3QixVQUFJO0FBQ0YsY0FBTU4sR0FBRyxDQUFDVSxHQUFKLEVBQU47QUFDRCxPQUZELENBRUUsT0FBT0MsS0FBUCxFQUFjO0FBQ2Q7QUFDRDs7QUFBQTtBQUNGO0FBQ0YsR0FyQkQsQ0FxQkUsT0FBT0EsS0FBUCxFQUFjO0FBQ2Qsb0JBQUFiLEtBQUssR0FBRyxFQUFSO0FBQ0EscUJBQUksMEJBQUosRUFBZ0NhLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBakQ7QUFDQSxXQUFPRSxPQUFPLENBQUNDLE1BQVIsQ0FBZUgsS0FBZixDQUFQO0FBQ0Q7QUFDRjtBQUVEO0FBQ0E7QUFDQTtBQUNBOzs7QUFDTyxTQUFTSSxXQUFULENBQXFCQyxPQUFyQixFQUE4QjtBQUNuQ0Msb0JBQUtDLFFBQUwsQ0FDRUMsZ0NBREYsRUFFRSxZQUFZO0FBQ1YsUUFBSTtBQUNGLFlBQU1qQixrQkFBa0IsRUFBeEI7QUFDRCxLQUZELENBRUUsT0FBT1MsS0FBUCxFQUFjO0FBQ2QsdUJBQUkscUJBQUosRUFBMkJBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBNUM7QUFDRDtBQUNGLEdBUkg7QUFVRCIsInNvdXJjZXNDb250ZW50IjpbIi8qXHJcbiAqIFdhenVoIGFwcCAtIEFkZCBkZWxheWVkIGpvYnMgdG8gYSBxdWV1ZS5cclxuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cclxuICpcclxuICogVGhpcyBwcm9ncmFtIGlzIGZyZWUgc29mdHdhcmU7IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcclxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcclxuICogdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbjsgZWl0aGVyIHZlcnNpb24gMiBvZiB0aGUgTGljZW5zZSwgb3JcclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cclxuICpcclxuICogRmluZCBtb3JlIGluZm9ybWF0aW9uIGFib3V0IHRoaXMgb24gdGhlIExJQ0VOU0UgZmlsZS5cclxuICovXHJcbmltcG9ydCBjcm9uIGZyb20gJ25vZGUtY3Jvbic7XHJcbmltcG9ydCB7IGxvZyB9IGZyb20gJy4uLy4uL2xpYi9sb2dnZXInO1xyXG5pbXBvcnQgeyBXQVpVSF9RVUVVRV9DUk9OX0ZSRVEgfSBmcm9tICcuLi8uLi8uLi9jb21tb24vY29uc3RhbnRzJztcclxuXHJcbmV4cG9ydCBsZXQgcXVldWUgPSBbXTtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVF1ZXVlSm9ie1xyXG4gIC8qKiBEYXRlIG9iamVjdCB0byBzdGFydCB0aGUgam9iICovXHJcbiAgc3RhcnRBdDogRGF0ZVxyXG4gIC8qKiBGdW5jdGlvbiB0byBleGVjdXRlICovXHJcbiAgcnVuOiAoKSA9PiB2b2lkXHJcbn07XHJcblxyXG4vKipcclxuICogQWRkIGEgam9iIHRvIHRoZSBxdWV1ZS5cclxuICogQHBhcmFtIGpvYiBKb2IgdG8gYWRkIHRvIHF1ZXVlXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gYWRkSm9iVG9RdWV1ZShqb2I6IElRdWV1ZUpvYikge1xyXG4gIGxvZygncXVldWU6YWRkSm9iJywgYE5ldyBqb2IgYWRkZWRgLCAnZGVidWcnKTtcclxuICBxdWV1ZS5wdXNoKGpvYik7XHJcbn07XHJcblxyXG5hc3luYyBmdW5jdGlvbiBleGVjdXRlUGVuZGluZ0pvYnMoKSB7XHJcbiAgdHJ5IHtcclxuICAgIGlmICghcXVldWUgfHwgIXF1ZXVlLmxlbmd0aCkgcmV0dXJuO1xyXG4gICAgY29uc3Qgbm93OiBEYXRlID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IHBlbmRpbmdKb2JzOiBJUXVldWVKb2JbXSA9IHF1ZXVlLmZpbHRlcihpdGVtID0+IGl0ZW0uc3RhcnRBdCA8PSBub3cpO1xyXG4gICAgbG9nKFxyXG4gICAgICAncXVldWU6ZXhlY3V0ZVBlbmRpbmdKb2JzJyxcclxuICAgICAgYFBlbmRpbmcgam9iczogJHtwZW5kaW5nSm9icy5sZW5ndGh9YCxcclxuICAgICAgJ2RlYnVnJ1xyXG4gICAgKTtcclxuICAgIGlmICghcGVuZGluZ0pvYnMgfHwgIXBlbmRpbmdKb2JzLmxlbmd0aCl7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH07XHJcbiAgICBxdWV1ZSA9IHF1ZXVlLmZpbHRlcigoaXRlbTogSVF1ZXVlSm9iKSA9PiBpdGVtLnN0YXJ0QXQgPiBub3cpO1xyXG5cclxuICAgIGZvciAoY29uc3Qgam9iIG9mIHBlbmRpbmdKb2JzKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgam9iLnJ1bigpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBxdWV1ZSA9IFtdO1xyXG4gICAgbG9nKCdxdWV1ZTpleGVjdXRlUGVuZGluZ0pvYnMnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XHJcbiAgfVxyXG59XHJcblxyXG4vKipcclxuICogUnVuIHRoZSBqb2IgcXVldWUgaXQgcGx1Z2luIHN0YXJ0LlxyXG4gKiBAcGFyYW0gY29udGV4dCBcclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBqb2JRdWV1ZVJ1bihjb250ZXh0KSB7XHJcbiAgY3Jvbi5zY2hlZHVsZShcclxuICAgIFdBWlVIX1FVRVVFX0NST05fRlJFUSxcclxuICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBleGVjdXRlUGVuZGluZ0pvYnMoKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBsb2coJ3F1ZXVlOmxhdW5jaENyb25Kb2InLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICk7XHJcbn1cclxuIl19