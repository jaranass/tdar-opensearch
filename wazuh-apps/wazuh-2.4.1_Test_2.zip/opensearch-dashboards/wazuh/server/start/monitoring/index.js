"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.jobMonitoringRun = jobMonitoringRun;

var _nodeCron = _interopRequireDefault(require("node-cron"));

var _logger = require("../../lib/logger");

var _monitoringTemplate = require("../../integration-files/monitoring-template");

var _getConfiguration = require("../../lib/get-configuration");

var _parseCron = require("../../lib/parse-cron");

var _indexDate = require("../../lib/index-date");

var _buildIndexSettings = require("../../lib/build-index-settings");

var _wazuhHosts = require("../../controllers/wazuh-hosts");

var _constants = require("../../../common/constants");

var _tryCatchForIndexPermissionError = require("../tryCatchForIndexPermissionError");

var _utils = require("../../../common/utils");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 * Wazuh app - Module for agent info fetching functions
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
const blueWazuh = '\u001b[34mwazuh\u001b[39m';
const monitoringErrorLogColors = [blueWazuh, 'monitoring', 'error'];
const wazuhHostController = new _wazuhHosts.WazuhHostsCtrl();
let MONITORING_ENABLED, MONITORING_FREQUENCY, MONITORING_CRON_FREQ, MONITORING_CREATION, MONITORING_INDEX_PATTERN, MONITORING_INDEX_PREFIX; // Utils functions

/**
 * Get the setting value from the configuration
 * @param setting
 * @param configuration
 * @param defaultValue
 */

function getAppConfigurationSetting(setting, configuration, defaultValue) {
  return typeof configuration[setting] !== 'undefined' ? configuration[setting] : defaultValue;
}

;
/**
 * Set the monitoring variables
 * @param context
 */

function initMonitoringConfiguration(context) {
  try {
    const appConfig = (0, _getConfiguration.getConfiguration)();
    MONITORING_ENABLED = appConfig && typeof appConfig['wazuh.monitoring.enabled'] !== 'undefined' ? appConfig['wazuh.monitoring.enabled'] && appConfig['wazuh.monitoring.enabled'] !== 'worker' : _constants.WAZUH_MONITORING_DEFAULT_ENABLED;
    MONITORING_FREQUENCY = getAppConfigurationSetting('wazuh.monitoring.frequency', appConfig, _constants.WAZUH_MONITORING_DEFAULT_FREQUENCY);
    MONITORING_CRON_FREQ = (0, _parseCron.parseCron)(MONITORING_FREQUENCY);
    MONITORING_CREATION = getAppConfigurationSetting('wazuh.monitoring.creation', appConfig, _constants.WAZUH_MONITORING_DEFAULT_CREATION);
    MONITORING_INDEX_PATTERN = getAppConfigurationSetting('wazuh.monitoring.pattern', appConfig, _constants.WAZUH_MONITORING_PATTERN);
    const lastCharIndexPattern = MONITORING_INDEX_PATTERN[MONITORING_INDEX_PATTERN.length - 1];

    if (lastCharIndexPattern !== '*') {
      MONITORING_INDEX_PATTERN += '*';
    }

    ;
    MONITORING_INDEX_PREFIX = MONITORING_INDEX_PATTERN.slice(0, MONITORING_INDEX_PATTERN.length - 1);
    (0, _logger.log)('monitoring:initMonitoringConfiguration', `wazuh.monitoring.enabled: ${MONITORING_ENABLED}`, 'debug');
    (0, _logger.log)('monitoring:initMonitoringConfiguration', `wazuh.monitoring.frequency: ${MONITORING_FREQUENCY} (${MONITORING_CRON_FREQ})`, 'debug');
    (0, _logger.log)('monitoring:initMonitoringConfiguration', `wazuh.monitoring.pattern: ${MONITORING_INDEX_PATTERN} (index prefix: ${MONITORING_INDEX_PREFIX})`, 'debug');
  } catch (error) {
    const errorMessage = error.message || error;
    (0, _logger.log)('monitoring:initMonitoringConfiguration', errorMessage);
    context.wazuh.logger.error(errorMessage);
  }
}

;
/**
 * Main. First execution when installing / loading App.
 * @param context
 */

async function init(context) {
  try {
    if (MONITORING_ENABLED) {
      await checkTemplate(context);
    }

    ;
  } catch (error) {
    const errorMessage = error.message || error;
    (0, _logger.log)('monitoring:init', error.message || error);
    context.wazuh.logger.error(errorMessage);
  }
}
/**
 * Verify wazuh-agent template
 */


async function checkTemplate(context) {
  try {
    (0, _logger.log)('monitoring:checkTemplate', 'Updating the monitoring template', 'debug');

    try {
      // Check if the template already exists
      const currentTemplate = await context.core.opensearch.client.asInternalUser.indices.getTemplate({
        name: _constants.WAZUH_MONITORING_TEMPLATE_NAME
      }); // Copy already created index patterns

      _monitoringTemplate.monitoringTemplate.index_patterns = currentTemplate.body[_constants.WAZUH_MONITORING_TEMPLATE_NAME].index_patterns;
    } catch (error) {
      // Init with the default index pattern
      _monitoringTemplate.monitoringTemplate.index_patterns = [_constants.WAZUH_MONITORING_PATTERN];
    } // Check if the user is using a custom pattern and add it to the template if it does


    if (!_monitoringTemplate.monitoringTemplate.index_patterns.includes(MONITORING_INDEX_PATTERN)) {
      _monitoringTemplate.monitoringTemplate.index_patterns.push(MONITORING_INDEX_PATTERN);
    }

    ; // Update the monitoring template

    await context.core.opensearch.client.asInternalUser.indices.putTemplate({
      name: _constants.WAZUH_MONITORING_TEMPLATE_NAME,
      body: _monitoringTemplate.monitoringTemplate
    });
    (0, _logger.log)('monitoring:checkTemplate', 'Updated the monitoring template', 'debug');
  } catch (error) {
    const errorMessage = `Something went wrong updating the monitoring template ${error.message || error}`;
    (0, _logger.log)('monitoring:checkTemplate', errorMessage);
    context.wazuh.logger.error(monitoringErrorLogColors, errorMessage);
    throw error;
  }
}
/**
 * Save agent status into elasticsearch, create index and/or insert document
 * @param {*} context
 * @param {*} data
 */


async function insertMonitoringDataElasticsearch(context, data) {
  const monitoringIndexName = MONITORING_INDEX_PREFIX + (0, _indexDate.indexDate)(MONITORING_CREATION);

  if (!MONITORING_ENABLED) {
    return;
  }

  ;

  try {
    await (0, _tryCatchForIndexPermissionError.tryCatchForIndexPermissionError)(monitoringIndexName)(async () => {
      const exists = await context.core.opensearch.client.asInternalUser.indices.exists({
        index: monitoringIndexName
      });

      if (!exists.body) {
        await createIndex(context, monitoringIndexName);
      }

      ; // Update the index configuration

      const appConfig = (0, _getConfiguration.getConfiguration)();
      const indexConfiguration = (0, _buildIndexSettings.buildIndexSettings)(appConfig, 'wazuh.monitoring', _constants.WAZUH_MONITORING_DEFAULT_INDICES_SHARDS); // To update the index settings with this client is required close the index, update the settings and open it
      // Number of shards is not dynamic so delete that setting if it's given

      delete indexConfiguration.settings.index.number_of_shards;
      await context.core.opensearch.client.asInternalUser.indices.putSettings({
        index: monitoringIndexName,
        body: indexConfiguration
      }); // Insert data to the monitoring index

      await insertDataToIndex(context, monitoringIndexName, data);
    })();
  } catch (error) {
    (0, _logger.log)('monitoring:insertMonitoringDataElasticsearch', error.message || error);
    context.wazuh.logger.error(error.message);
  }
}
/**
 * Inserting one document per agent into Elastic. Bulk.
 * @param {*} context Endpoint
 * @param {String} indexName The name for the index (e.g. daily: wazuh-monitoring-YYYY.MM.DD)
 * @param {*} data
 */


async function insertDataToIndex(context, indexName, data) {
  const {
    agents,
    apiHost
  } = data;

  try {
    if (agents.length > 0) {
      (0, _logger.log)('monitoring:insertDataToIndex', `Bulk data to index ${indexName} for ${agents.length} agents`, 'debug');
      const bodyBulk = agents.map(agent => {
        const agentInfo = { ...agent
        };
        agentInfo['timestamp'] = new Date(Date.now()).toISOString();
        agentInfo.host = agent.manager;
        agentInfo.cluster = {
          name: apiHost.clusterName ? apiHost.clusterName : 'disabled'
        };
        return `{ "index":  { "_index": "${indexName}" } }\n${JSON.stringify(agentInfo)}\n`;
      }).join('');
      await context.core.opensearch.client.asInternalUser.bulk({
        index: indexName,
        body: bodyBulk
      });
      (0, _logger.log)('monitoring:insertDataToIndex', `Bulk data to index ${indexName} for ${agents.length} agents completed`, 'debug');
    }
  } catch (error) {
    (0, _logger.log)('monitoring:insertDataToIndex', `Error inserting agent data into elasticsearch. Bulk request failed due to ${error.message || error}`);
  }
}
/**
 * Create the wazuh-monitoring index
 * @param {*} context context
 * @param {String} indexName The name for the index (e.g. daily: wazuh-monitoring-YYYY.MM.DD)
 */


async function createIndex(context, indexName) {
  try {
    if (!MONITORING_ENABLED) return;
    const appConfig = (0, _getConfiguration.getConfiguration)();
    const IndexConfiguration = {
      settings: {
        index: {
          number_of_shards: getAppConfigurationSetting('wazuh.monitoring.shards', appConfig, _constants.WAZUH_MONITORING_DEFAULT_INDICES_SHARDS),
          number_of_replicas: getAppConfigurationSetting('wazuh.monitoring.replicas', appConfig, _constants.WAZUH_MONITORING_DEFAULT_INDICES_REPLICAS)
        }
      }
    };
    await context.core.opensearch.client.asInternalUser.indices.create({
      index: indexName,
      body: IndexConfiguration
    });
    (0, _logger.log)('monitoring:createIndex', `Successfully created new index: ${indexName}`, 'debug');
  } catch (error) {
    const errorMessage = `Could not create ${indexName} index on elasticsearch due to ${error.message || error}`;
    (0, _logger.log)('monitoring:createIndex', errorMessage);
    context.wazuh.logger.error(errorMessage);
  }
}
/**
* Wait until Kibana server is ready
*/


async function checkPluginPlatformStatus(context) {
  try {
    (0, _logger.log)('monitoring:checkPluginPlatformStatus', 'Waiting for Kibana and Elasticsearch servers to be ready...', 'debug');
    await checkElasticsearchServer(context);
    await init(context);
    return;
  } catch (error) {
    (0, _logger.log)('monitoring:checkPluginPlatformStatus', error.mesage || error);

    try {
      await (0, _utils.delayAsPromise)(3000);
      await checkPluginPlatformStatus(context);
    } catch (error) {}

    ;
  }
}
/**
 * Check Elasticsearch Server status and Kibana index presence
 */


async function checkElasticsearchServer(context) {
  try {
    const data = await context.core.opensearch.client.asInternalUser.indices.exists({
      index: context.server.config.opensearchDashboards.index
    });
    return data.body; // TODO: check if Elasticsearch can receive requests
    // if (data) {
    //   const pluginsData = await this.server.plugins.elasticsearch.waitUntilReady();
    //   return pluginsData;
    // }

    return Promise.reject(data);
  } catch (error) {
    (0, _logger.log)('monitoring:checkElasticsearchServer', error.message || error);
    return Promise.reject(error);
  }
}

const fakeResponseEndpoint = {
  ok: body => body,
  custom: body => body
};
/**
 * Get API configuration from elastic and callback to loadCredentials
 */

async function getHostsConfiguration() {
  try {
    const hosts = await wazuhHostController.getHostsEntries(false, false, fakeResponseEndpoint);

    if (hosts.body.length) {
      return hosts.body;
    }

    ;
    (0, _logger.log)('monitoring:getConfig', 'There are no Wazuh API entries yet', 'debug');
    return Promise.reject({
      error: 'no credentials',
      error_code: 1
    });
  } catch (error) {
    (0, _logger.log)('monitoring:getHostsConfiguration', error.message || error);
    return Promise.reject({
      error: 'no wazuh hosts',
      error_code: 2
    });
  }
}
/**
   * Task used by the cron job.
   */


async function cronTask(context) {
  try {
    const templateMonitoring = await context.core.opensearch.client.asInternalUser.indices.getTemplate({
      name: _constants.WAZUH_MONITORING_TEMPLATE_NAME
    });
    const apiHosts = await getHostsConfiguration();
    const apiHostsUnique = (apiHosts || []).filter((apiHost, index, self) => index === self.findIndex(t => t.user === apiHost.user && t.password === apiHost.password && t.url === apiHost.url && t.port === apiHost.port));

    for (let apiHost of apiHostsUnique) {
      try {
        const {
          agents,
          apiHost: host
        } = await getApiInfo(context, apiHost);
        await insertMonitoringDataElasticsearch(context, {
          agents,
          apiHost: host
        });
      } catch (error) {}

      ;
    }
  } catch (error) {
    // Retry to call itself again if Kibana index is not ready yet
    // try {
    //   if (
    //     this.wzWrapper.buildingKibanaIndex ||
    //     ((error || {}).status === 404 &&
    //       (error || {}).displayName === 'NotFound')
    //   ) {
    //     await delayAsPromise(1000);
    //     return cronTask(context);
    //   }
    // } catch (error) {} //eslint-disable-line
    (0, _logger.log)('monitoring:cronTask', error.message || error);
    context.wazuh.logger.error(error.message || error);
  }
}
/**
 * Get API and agents info
 * @param context
 * @param apiHost
 */


async function getApiInfo(context, apiHost) {
  try {
    (0, _logger.log)('monitoring:getApiInfo', `Getting API info for ${apiHost.id}`, 'debug');
    const responseIsCluster = await context.wazuh.api.client.asInternalUser.request('GET', '/cluster/status', {}, {
      apiHostID: apiHost.id
    });
    const isCluster = (((responseIsCluster || {}).data || {}).data || {}).enabled === 'yes';

    if (isCluster) {
      const responseClusterInfo = await context.wazuh.api.client.asInternalUser.request('GET', `/cluster/local/info`, {}, {
        apiHostID: apiHost.id
      });
      apiHost.clusterName = responseClusterInfo.data.data.affected_items[0].cluster;
    }

    ;
    const agents = await fetchAllAgentsFromApiHost(context, apiHost);
    return {
      agents,
      apiHost
    };
  } catch (error) {
    (0, _logger.log)('monitoring:getApiInfo', error.message || error);
    throw error;
  }
}

;
/**
 * Fetch all agents for the API provided
 * @param context
 * @param apiHost
 */

async function fetchAllAgentsFromApiHost(context, apiHost) {
  let agents = [];

  try {
    (0, _logger.log)('monitoring:fetchAllAgentsFromApiHost', `Getting all agents from ApiID: ${apiHost.id}`, 'debug');
    const responseAgentsCount = await context.wazuh.api.client.asInternalUser.request('GET', '/agents', {
      params: {
        offset: 0,
        limit: 1,
        q: 'id!=000'
      }
    }, {
      apiHostID: apiHost.id
    });
    const agentsCount = responseAgentsCount.data.data.total_affected_items;
    (0, _logger.log)('monitoring:fetchAllAgentsFromApiHost', `ApiID: ${apiHost.id}, Agent count: ${agentsCount}`, 'debug');
    let payload = {
      offset: 0,
      limit: 500,
      q: 'id!=000'
    };

    while (agents.length < agentsCount && payload.offset < agentsCount) {
      try {
        /*
        TODO: Improve the performance of request with:
          - Reduce the number of requests to the Wazuh API
          - Reduce (if possible) the quantity of data to index by document
          Requirements:
          - Research about the neccesary data to index.
          How to do:
          - Wazuh API request:
            - select the required data to retrieve depending on is required to index (using the `select` query param)
            - increase the limit of results to retrieve (currently, the requests use the recommended value: 500).
              See the allowed values. This depends on the selected data because the response could fail if contains a lot of data
        */
        const responseAgents = await context.wazuh.api.client.asInternalUser.request('GET', `/agents`, {
          params: payload
        }, {
          apiHostID: apiHost.id
        });
        agents = [...agents, ...responseAgents.data.data.affected_items];
        payload.offset += payload.limit;
      } catch (error) {
        (0, _logger.log)('monitoring:fetchAllAgentsFromApiHost', `ApiID: ${apiHost.id}, Error request with offset/limit ${payload.offset}/${payload.limit}: ${error.message || error}`);
      }
    }

    return agents;
  } catch (error) {
    (0, _logger.log)('monitoring:fetchAllAgentsFromApiHost', `ApiID: ${apiHost.id}. Error: ${error.message || error}`);
    throw error;
  }
}

;
/**
 * Start the cron job
 */

async function jobMonitoringRun(context) {
  // Init the monitoring variables
  initMonitoringConfiguration(context); // Check Kibana index and if it is prepared, start the initialization of Wazuh App.

  await checkPluginPlatformStatus(context); // // Run the cron job only it it's enabled

  if (MONITORING_ENABLED) {
    cronTask(context);

    _nodeCron.default.schedule(MONITORING_CRON_FREQ, () => cronTask(context));
  }
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbImJsdWVXYXp1aCIsIm1vbml0b3JpbmdFcnJvckxvZ0NvbG9ycyIsIndhenVoSG9zdENvbnRyb2xsZXIiLCJXYXp1aEhvc3RzQ3RybCIsIk1PTklUT1JJTkdfRU5BQkxFRCIsIk1PTklUT1JJTkdfRlJFUVVFTkNZIiwiTU9OSVRPUklOR19DUk9OX0ZSRVEiLCJNT05JVE9SSU5HX0NSRUFUSU9OIiwiTU9OSVRPUklOR19JTkRFWF9QQVRURVJOIiwiTU9OSVRPUklOR19JTkRFWF9QUkVGSVgiLCJnZXRBcHBDb25maWd1cmF0aW9uU2V0dGluZyIsInNldHRpbmciLCJjb25maWd1cmF0aW9uIiwiZGVmYXVsdFZhbHVlIiwiaW5pdE1vbml0b3JpbmdDb25maWd1cmF0aW9uIiwiY29udGV4dCIsImFwcENvbmZpZyIsIldBWlVIX01PTklUT1JJTkdfREVGQVVMVF9FTkFCTEVEIiwiV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0ZSRVFVRU5DWSIsIldBWlVIX01PTklUT1JJTkdfREVGQVVMVF9DUkVBVElPTiIsIldBWlVIX01PTklUT1JJTkdfUEFUVEVSTiIsImxhc3RDaGFySW5kZXhQYXR0ZXJuIiwibGVuZ3RoIiwic2xpY2UiLCJlcnJvciIsImVycm9yTWVzc2FnZSIsIm1lc3NhZ2UiLCJ3YXp1aCIsImxvZ2dlciIsImluaXQiLCJjaGVja1RlbXBsYXRlIiwiY3VycmVudFRlbXBsYXRlIiwiY29yZSIsIm9wZW5zZWFyY2giLCJjbGllbnQiLCJhc0ludGVybmFsVXNlciIsImluZGljZXMiLCJnZXRUZW1wbGF0ZSIsIm5hbWUiLCJXQVpVSF9NT05JVE9SSU5HX1RFTVBMQVRFX05BTUUiLCJtb25pdG9yaW5nVGVtcGxhdGUiLCJpbmRleF9wYXR0ZXJucyIsImJvZHkiLCJpbmNsdWRlcyIsInB1c2giLCJwdXRUZW1wbGF0ZSIsImluc2VydE1vbml0b3JpbmdEYXRhRWxhc3RpY3NlYXJjaCIsImRhdGEiLCJtb25pdG9yaW5nSW5kZXhOYW1lIiwiZXhpc3RzIiwiaW5kZXgiLCJjcmVhdGVJbmRleCIsImluZGV4Q29uZmlndXJhdGlvbiIsIldBWlVIX01PTklUT1JJTkdfREVGQVVMVF9JTkRJQ0VTX1NIQVJEUyIsInNldHRpbmdzIiwibnVtYmVyX29mX3NoYXJkcyIsInB1dFNldHRpbmdzIiwiaW5zZXJ0RGF0YVRvSW5kZXgiLCJpbmRleE5hbWUiLCJhZ2VudHMiLCJhcGlIb3N0IiwiYm9keUJ1bGsiLCJtYXAiLCJhZ2VudCIsImFnZW50SW5mbyIsIkRhdGUiLCJub3ciLCJ0b0lTT1N0cmluZyIsImhvc3QiLCJtYW5hZ2VyIiwiY2x1c3RlciIsImNsdXN0ZXJOYW1lIiwiSlNPTiIsInN0cmluZ2lmeSIsImpvaW4iLCJidWxrIiwiSW5kZXhDb25maWd1cmF0aW9uIiwibnVtYmVyX29mX3JlcGxpY2FzIiwiV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0lORElDRVNfUkVQTElDQVMiLCJjcmVhdGUiLCJjaGVja1BsdWdpblBsYXRmb3JtU3RhdHVzIiwiY2hlY2tFbGFzdGljc2VhcmNoU2VydmVyIiwibWVzYWdlIiwic2VydmVyIiwiY29uZmlnIiwib3BlbnNlYXJjaERhc2hib2FyZHMiLCJQcm9taXNlIiwicmVqZWN0IiwiZmFrZVJlc3BvbnNlRW5kcG9pbnQiLCJvayIsImN1c3RvbSIsImdldEhvc3RzQ29uZmlndXJhdGlvbiIsImhvc3RzIiwiZ2V0SG9zdHNFbnRyaWVzIiwiZXJyb3JfY29kZSIsImNyb25UYXNrIiwidGVtcGxhdGVNb25pdG9yaW5nIiwiYXBpSG9zdHMiLCJhcGlIb3N0c1VuaXF1ZSIsImZpbHRlciIsInNlbGYiLCJmaW5kSW5kZXgiLCJ0IiwidXNlciIsInBhc3N3b3JkIiwidXJsIiwicG9ydCIsImdldEFwaUluZm8iLCJpZCIsInJlc3BvbnNlSXNDbHVzdGVyIiwiYXBpIiwicmVxdWVzdCIsImFwaUhvc3RJRCIsImlzQ2x1c3RlciIsImVuYWJsZWQiLCJyZXNwb25zZUNsdXN0ZXJJbmZvIiwiYWZmZWN0ZWRfaXRlbXMiLCJmZXRjaEFsbEFnZW50c0Zyb21BcGlIb3N0IiwicmVzcG9uc2VBZ2VudHNDb3VudCIsInBhcmFtcyIsIm9mZnNldCIsImxpbWl0IiwicSIsImFnZW50c0NvdW50IiwidG90YWxfYWZmZWN0ZWRfaXRlbXMiLCJwYXlsb2FkIiwicmVzcG9uc2VBZ2VudHMiLCJqb2JNb25pdG9yaW5nUnVuIiwiY3JvbiIsInNjaGVkdWxlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBV0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBU0E7O0FBQ0E7Ozs7QUE3QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXFCQSxNQUFNQSxTQUFTLEdBQUcsMkJBQWxCO0FBQ0EsTUFBTUMsd0JBQXdCLEdBQUcsQ0FBQ0QsU0FBRCxFQUFZLFlBQVosRUFBMEIsT0FBMUIsQ0FBakM7QUFDQSxNQUFNRSxtQkFBbUIsR0FBRyxJQUFJQywwQkFBSixFQUE1QjtBQUVBLElBQUlDLGtCQUFKLEVBQXdCQyxvQkFBeEIsRUFBOENDLG9CQUE5QyxFQUFvRUMsbUJBQXBFLEVBQXlGQyx3QkFBekYsRUFBbUhDLHVCQUFuSCxDLENBRUE7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFNBQVNDLDBCQUFULENBQW9DQyxPQUFwQyxFQUFxREMsYUFBckQsRUFBeUVDLFlBQXpFLEVBQTJGO0FBQ3pGLFNBQU8sT0FBT0QsYUFBYSxDQUFDRCxPQUFELENBQXBCLEtBQWtDLFdBQWxDLEdBQWdEQyxhQUFhLENBQUNELE9BQUQsQ0FBN0QsR0FBeUVFLFlBQWhGO0FBQ0Q7O0FBQUE7QUFFRDtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxTQUFTQywyQkFBVCxDQUFxQ0MsT0FBckMsRUFBNkM7QUFDM0MsTUFBRztBQUNELFVBQU1DLFNBQVMsR0FBRyx5Q0FBbEI7QUFDQVosSUFBQUEsa0JBQWtCLEdBQUdZLFNBQVMsSUFBSSxPQUFPQSxTQUFTLENBQUMsMEJBQUQsQ0FBaEIsS0FBaUQsV0FBOUQsR0FDakJBLFNBQVMsQ0FBQywwQkFBRCxDQUFULElBQ0FBLFNBQVMsQ0FBQywwQkFBRCxDQUFULEtBQTBDLFFBRnpCLEdBR2pCQywyQ0FISjtBQUlBWixJQUFBQSxvQkFBb0IsR0FBR0ssMEJBQTBCLENBQUMsNEJBQUQsRUFBK0JNLFNBQS9CLEVBQTBDRSw2Q0FBMUMsQ0FBakQ7QUFDQVosSUFBQUEsb0JBQW9CLEdBQUcsMEJBQVVELG9CQUFWLENBQXZCO0FBQ0FFLElBQUFBLG1CQUFtQixHQUFHRywwQkFBMEIsQ0FBQywyQkFBRCxFQUE4Qk0sU0FBOUIsRUFBeUNHLDRDQUF6QyxDQUFoRDtBQUVBWCxJQUFBQSx3QkFBd0IsR0FBR0UsMEJBQTBCLENBQUMsMEJBQUQsRUFBNkJNLFNBQTdCLEVBQXdDSSxtQ0FBeEMsQ0FBckQ7QUFDQSxVQUFNQyxvQkFBb0IsR0FBR2Isd0JBQXdCLENBQUNBLHdCQUF3QixDQUFDYyxNQUF6QixHQUFrQyxDQUFuQyxDQUFyRDs7QUFDQSxRQUFJRCxvQkFBb0IsS0FBSyxHQUE3QixFQUFrQztBQUNoQ2IsTUFBQUEsd0JBQXdCLElBQUksR0FBNUI7QUFDRDs7QUFBQTtBQUNEQyxJQUFBQSx1QkFBdUIsR0FBR0Qsd0JBQXdCLENBQUNlLEtBQXpCLENBQStCLENBQS9CLEVBQWlDZix3QkFBd0IsQ0FBQ2MsTUFBekIsR0FBa0MsQ0FBbkUsQ0FBMUI7QUFFQSxxQkFDRSx3Q0FERixFQUVHLDZCQUE0QmxCLGtCQUFtQixFQUZsRCxFQUdFLE9BSEY7QUFNQSxxQkFDRSx3Q0FERixFQUVHLCtCQUE4QkMsb0JBQXFCLEtBQUlDLG9CQUFxQixHQUYvRSxFQUdFLE9BSEY7QUFNQSxxQkFDRSx3Q0FERixFQUVHLDZCQUE0QkUsd0JBQXlCLG1CQUFrQkMsdUJBQXdCLEdBRmxHLEVBR0UsT0FIRjtBQUtELEdBbENELENBa0NDLE9BQU1lLEtBQU4sRUFBWTtBQUNYLFVBQU1DLFlBQVksR0FBR0QsS0FBSyxDQUFDRSxPQUFOLElBQWlCRixLQUF0QztBQUNBLHFCQUNFLHdDQURGLEVBRUVDLFlBRkY7QUFJQVYsSUFBQUEsT0FBTyxDQUFDWSxLQUFSLENBQWNDLE1BQWQsQ0FBcUJKLEtBQXJCLENBQTJCQyxZQUEzQjtBQUNEO0FBQ0Y7O0FBQUE7QUFFRDtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxlQUFlSSxJQUFmLENBQW9CZCxPQUFwQixFQUE2QjtBQUMzQixNQUFJO0FBQ0YsUUFBSVgsa0JBQUosRUFBd0I7QUFDdEIsWUFBTTBCLGFBQWEsQ0FBQ2YsT0FBRCxDQUFuQjtBQUNEOztBQUFBO0FBQ0YsR0FKRCxDQUlFLE9BQU9TLEtBQVAsRUFBYztBQUNkLFVBQU1DLFlBQVksR0FBR0QsS0FBSyxDQUFDRSxPQUFOLElBQWlCRixLQUF0QztBQUNBLHFCQUFJLGlCQUFKLEVBQXVCQSxLQUFLLENBQUNFLE9BQU4sSUFBaUJGLEtBQXhDO0FBQ0FULElBQUFBLE9BQU8sQ0FBQ1ksS0FBUixDQUFjQyxNQUFkLENBQXFCSixLQUFyQixDQUEyQkMsWUFBM0I7QUFDRDtBQUNGO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQSxlQUFlSyxhQUFmLENBQTZCZixPQUE3QixFQUFzQztBQUNwQyxNQUFJO0FBQ0YscUJBQ0UsMEJBREYsRUFFRSxrQ0FGRixFQUdFLE9BSEY7O0FBTUEsUUFBSTtBQUNGO0FBQ0EsWUFBTWdCLGVBQWUsR0FBRyxNQUFNaEIsT0FBTyxDQUFDaUIsSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUF4QixDQUErQkMsY0FBL0IsQ0FBOENDLE9BQTlDLENBQXNEQyxXQUF0RCxDQUFrRTtBQUM5RkMsUUFBQUEsSUFBSSxFQUFFQztBQUR3RixPQUFsRSxDQUE5QixDQUZFLENBS0Y7O0FBQ0FDLDZDQUFtQkMsY0FBbkIsR0FBb0NWLGVBQWUsQ0FBQ1csSUFBaEIsQ0FBcUJILHlDQUFyQixFQUFxREUsY0FBekY7QUFDRCxLQVBELENBT0MsT0FBT2pCLEtBQVAsRUFBYztBQUNiO0FBQ0FnQiw2Q0FBbUJDLGNBQW5CLEdBQW9DLENBQUNyQixtQ0FBRCxDQUFwQztBQUNELEtBakJDLENBbUJGOzs7QUFDQSxRQUFJLENBQUNvQix1Q0FBbUJDLGNBQW5CLENBQWtDRSxRQUFsQyxDQUEyQ25DLHdCQUEzQyxDQUFMLEVBQTJFO0FBQ3pFZ0MsNkNBQW1CQyxjQUFuQixDQUFrQ0csSUFBbEMsQ0FBdUNwQyx3QkFBdkM7QUFDRDs7QUFBQSxLQXRCQyxDQXdCRjs7QUFDQSxVQUFNTyxPQUFPLENBQUNpQixJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCQyxjQUEvQixDQUE4Q0MsT0FBOUMsQ0FBc0RTLFdBQXRELENBQWtFO0FBQ3RFUCxNQUFBQSxJQUFJLEVBQUVDLHlDQURnRTtBQUV0RUcsTUFBQUEsSUFBSSxFQUFFRjtBQUZnRSxLQUFsRSxDQUFOO0FBSUEscUJBQ0UsMEJBREYsRUFFRSxpQ0FGRixFQUdFLE9BSEY7QUFLRCxHQWxDRCxDQWtDRSxPQUFPaEIsS0FBUCxFQUFjO0FBQ2QsVUFBTUMsWUFBWSxHQUFJLHlEQUF3REQsS0FBSyxDQUFDRSxPQUFOLElBQWlCRixLQUFNLEVBQXJHO0FBQ0EscUJBQ0UsMEJBREYsRUFFRUMsWUFGRjtBQUlBVixJQUFBQSxPQUFPLENBQUNZLEtBQVIsQ0FBY0MsTUFBZCxDQUFxQkosS0FBckIsQ0FBMkJ2Qix3QkFBM0IsRUFBcUR3QixZQUFyRDtBQUNBLFVBQU1ELEtBQU47QUFDRDtBQUNGO0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsZUFBZXNCLGlDQUFmLENBQWlEL0IsT0FBakQsRUFBMERnQyxJQUExRCxFQUFnRTtBQUM5RCxRQUFNQyxtQkFBbUIsR0FBR3ZDLHVCQUF1QixHQUFHLDBCQUFVRixtQkFBVixDQUF0RDs7QUFDRSxNQUFJLENBQUNILGtCQUFMLEVBQXdCO0FBQ3RCO0FBQ0Q7O0FBQUE7O0FBQ0QsTUFBSTtBQUNGLFVBQU0sc0VBQWdDNEMsbUJBQWhDLEVBQXNELFlBQVc7QUFDckUsWUFBTUMsTUFBTSxHQUFHLE1BQU1sQyxPQUFPLENBQUNpQixJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCQyxjQUEvQixDQUE4Q0MsT0FBOUMsQ0FBc0RhLE1BQXRELENBQTZEO0FBQUNDLFFBQUFBLEtBQUssRUFBRUY7QUFBUixPQUE3RCxDQUFyQjs7QUFDQSxVQUFHLENBQUNDLE1BQU0sQ0FBQ1AsSUFBWCxFQUFnQjtBQUNkLGNBQU1TLFdBQVcsQ0FBQ3BDLE9BQUQsRUFBVWlDLG1CQUFWLENBQWpCO0FBQ0Q7O0FBQUEsT0FKb0UsQ0FNckU7O0FBQ0EsWUFBTWhDLFNBQVMsR0FBRyx5Q0FBbEI7QUFDQSxZQUFNb0Msa0JBQWtCLEdBQUcsNENBQ3pCcEMsU0FEeUIsRUFFekIsa0JBRnlCLEVBR3pCcUMsa0RBSHlCLENBQTNCLENBUnFFLENBY3JFO0FBQ0E7O0FBQ0EsYUFBT0Qsa0JBQWtCLENBQUNFLFFBQW5CLENBQTRCSixLQUE1QixDQUFrQ0ssZ0JBQXpDO0FBQ0EsWUFBTXhDLE9BQU8sQ0FBQ2lCLElBQVIsQ0FBYUMsVUFBYixDQUF3QkMsTUFBeEIsQ0FBK0JDLGNBQS9CLENBQThDQyxPQUE5QyxDQUFzRG9CLFdBQXRELENBQWtFO0FBQ3RFTixRQUFBQSxLQUFLLEVBQUVGLG1CQUQrRDtBQUV0RU4sUUFBQUEsSUFBSSxFQUFFVTtBQUZnRSxPQUFsRSxDQUFOLENBakJxRSxDQXNCckU7O0FBQ0EsWUFBTUssaUJBQWlCLENBQUMxQyxPQUFELEVBQVVpQyxtQkFBVixFQUErQkQsSUFBL0IsQ0FBdkI7QUFDRCxLQXhCSyxHQUFOO0FBeUJELEdBMUJELENBMEJDLE9BQU12QixLQUFOLEVBQVk7QUFDWCxxQkFBSSw4Q0FBSixFQUFvREEsS0FBSyxDQUFDRSxPQUFOLElBQWlCRixLQUFyRTtBQUNBVCxJQUFBQSxPQUFPLENBQUNZLEtBQVIsQ0FBY0MsTUFBZCxDQUFxQkosS0FBckIsQ0FBMkJBLEtBQUssQ0FBQ0UsT0FBakM7QUFDRDtBQUNKO0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxlQUFlK0IsaUJBQWYsQ0FBaUMxQyxPQUFqQyxFQUEwQzJDLFNBQTFDLEVBQTZEWCxJQUE3RCxFQUE2RjtBQUMzRixRQUFNO0FBQUVZLElBQUFBLE1BQUY7QUFBVUMsSUFBQUE7QUFBVixNQUFzQmIsSUFBNUI7O0FBQ0EsTUFBSTtBQUNGLFFBQUlZLE1BQU0sQ0FBQ3JDLE1BQVAsR0FBZ0IsQ0FBcEIsRUFBdUI7QUFDckIsdUJBQ0UsOEJBREYsRUFFRyxzQkFBcUJvQyxTQUFVLFFBQU9DLE1BQU0sQ0FBQ3JDLE1BQU8sU0FGdkQsRUFHRSxPQUhGO0FBTUEsWUFBTXVDLFFBQVEsR0FBR0YsTUFBTSxDQUFDRyxHQUFQLENBQVdDLEtBQUssSUFBSTtBQUNuQyxjQUFNQyxTQUFTLEdBQUcsRUFBQyxHQUFHRDtBQUFKLFNBQWxCO0FBQ0FDLFFBQUFBLFNBQVMsQ0FBQyxXQUFELENBQVQsR0FBeUIsSUFBSUMsSUFBSixDQUFTQSxJQUFJLENBQUNDLEdBQUwsRUFBVCxFQUFxQkMsV0FBckIsRUFBekI7QUFDQUgsUUFBQUEsU0FBUyxDQUFDSSxJQUFWLEdBQWlCTCxLQUFLLENBQUNNLE9BQXZCO0FBQ0FMLFFBQUFBLFNBQVMsQ0FBQ00sT0FBVixHQUFvQjtBQUFFaEMsVUFBQUEsSUFBSSxFQUFFc0IsT0FBTyxDQUFDVyxXQUFSLEdBQXNCWCxPQUFPLENBQUNXLFdBQTlCLEdBQTRDO0FBQXBELFNBQXBCO0FBQ0EsZUFBUSw0QkFBMkJiLFNBQVUsVUFBU2MsSUFBSSxDQUFDQyxTQUFMLENBQWVULFNBQWYsQ0FBMEIsSUFBaEY7QUFDRCxPQU5nQixFQU1kVSxJQU5jLENBTVQsRUFOUyxDQUFqQjtBQVFBLFlBQU0zRCxPQUFPLENBQUNpQixJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCQyxjQUEvQixDQUE4Q3dDLElBQTlDLENBQW1EO0FBQ3ZEekIsUUFBQUEsS0FBSyxFQUFFUSxTQURnRDtBQUV2RGhCLFFBQUFBLElBQUksRUFBRW1CO0FBRmlELE9BQW5ELENBQU47QUFJQSx1QkFDRSw4QkFERixFQUVHLHNCQUFxQkgsU0FBVSxRQUFPQyxNQUFNLENBQUNyQyxNQUFPLG1CQUZ2RCxFQUdFLE9BSEY7QUFLRDtBQUNGLEdBMUJELENBMEJFLE9BQU9FLEtBQVAsRUFBYztBQUNkLHFCQUNFLDhCQURGLEVBRUcsNkVBQTRFQSxLQUFLLENBQUNFLE9BQU4sSUFDM0VGLEtBQU0sRUFIVjtBQUtEO0FBQ0Y7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxlQUFlMkIsV0FBZixDQUEyQnBDLE9BQTNCLEVBQW9DMkMsU0FBcEMsRUFBdUQ7QUFDckQsTUFBSTtBQUNGLFFBQUksQ0FBQ3RELGtCQUFMLEVBQXlCO0FBQ3pCLFVBQU1ZLFNBQVMsR0FBRyx5Q0FBbEI7QUFFQSxVQUFNNEQsa0JBQWtCLEdBQUc7QUFDekJ0QixNQUFBQSxRQUFRLEVBQUU7QUFDUkosUUFBQUEsS0FBSyxFQUFFO0FBQ0xLLFVBQUFBLGdCQUFnQixFQUFFN0MsMEJBQTBCLENBQUMseUJBQUQsRUFBNEJNLFNBQTVCLEVBQXVDcUMsa0RBQXZDLENBRHZDO0FBRUx3QixVQUFBQSxrQkFBa0IsRUFBRW5FLDBCQUEwQixDQUFDLDJCQUFELEVBQThCTSxTQUE5QixFQUF5QzhELG9EQUF6QztBQUZ6QztBQURDO0FBRGUsS0FBM0I7QUFTQSxVQUFNL0QsT0FBTyxDQUFDaUIsSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUF4QixDQUErQkMsY0FBL0IsQ0FBOENDLE9BQTlDLENBQXNEMkMsTUFBdEQsQ0FBNkQ7QUFDakU3QixNQUFBQSxLQUFLLEVBQUVRLFNBRDBEO0FBRWpFaEIsTUFBQUEsSUFBSSxFQUFFa0M7QUFGMkQsS0FBN0QsQ0FBTjtBQUtBLHFCQUNFLHdCQURGLEVBRUcsbUNBQWtDbEIsU0FBVSxFQUYvQyxFQUdFLE9BSEY7QUFLRCxHQXZCRCxDQXVCRSxPQUFPbEMsS0FBUCxFQUFjO0FBQ2QsVUFBTUMsWUFBWSxHQUFJLG9CQUFtQmlDLFNBQVUsa0NBQWlDbEMsS0FBSyxDQUFDRSxPQUFOLElBQWlCRixLQUFNLEVBQTNHO0FBQ0EscUJBQ0Usd0JBREYsRUFFRUMsWUFGRjtBQUlBVixJQUFBQSxPQUFPLENBQUNZLEtBQVIsQ0FBY0MsTUFBZCxDQUFxQkosS0FBckIsQ0FBMkJDLFlBQTNCO0FBQ0Q7QUFDRjtBQUVEO0FBQ0E7QUFDQTs7O0FBQ0EsZUFBZXVELHlCQUFmLENBQXlDakUsT0FBekMsRUFBa0Q7QUFDakQsTUFBSTtBQUNELHFCQUNFLHNDQURGLEVBRUUsNkRBRkYsRUFHRSxPQUhGO0FBTUQsVUFBTWtFLHdCQUF3QixDQUFDbEUsT0FBRCxDQUE5QjtBQUNBLFVBQU1jLElBQUksQ0FBQ2QsT0FBRCxDQUFWO0FBQ0E7QUFDRCxHQVZELENBVUUsT0FBT1MsS0FBUCxFQUFjO0FBQ2IscUJBQ0Usc0NBREYsRUFFRUEsS0FBSyxDQUFDMEQsTUFBTixJQUFlMUQsS0FGakI7O0FBSUEsUUFBRztBQUNELFlBQU0sMkJBQWUsSUFBZixDQUFOO0FBQ0EsWUFBTXdELHlCQUF5QixDQUFDakUsT0FBRCxDQUEvQjtBQUNELEtBSEQsQ0FHQyxPQUFNUyxLQUFOLEVBQVksQ0FBRTs7QUFBQTtBQUNqQjtBQUNEO0FBR0Q7QUFDQTtBQUNBOzs7QUFDQSxlQUFleUQsd0JBQWYsQ0FBd0NsRSxPQUF4QyxFQUFpRDtBQUMvQyxNQUFJO0FBQ0YsVUFBTWdDLElBQUksR0FBRyxNQUFNaEMsT0FBTyxDQUFDaUIsSUFBUixDQUFhQyxVQUFiLENBQXdCQyxNQUF4QixDQUErQkMsY0FBL0IsQ0FBOENDLE9BQTlDLENBQXNEYSxNQUF0RCxDQUE2RDtBQUM5RUMsTUFBQUEsS0FBSyxFQUFFbkMsT0FBTyxDQUFDb0UsTUFBUixDQUFlQyxNQUFmLENBQXNCQyxvQkFBdEIsQ0FBMkNuQztBQUQ0QixLQUE3RCxDQUFuQjtBQUlBLFdBQU9ILElBQUksQ0FBQ0wsSUFBWixDQUxFLENBTUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxXQUFPNEMsT0FBTyxDQUFDQyxNQUFSLENBQWV4QyxJQUFmLENBQVA7QUFDRCxHQVpELENBWUUsT0FBT3ZCLEtBQVAsRUFBYztBQUNkLHFCQUFJLHFDQUFKLEVBQTJDQSxLQUFLLENBQUNFLE9BQU4sSUFBaUJGLEtBQTVEO0FBQ0EsV0FBTzhELE9BQU8sQ0FBQ0MsTUFBUixDQUFlL0QsS0FBZixDQUFQO0FBQ0Q7QUFDRjs7QUFFRCxNQUFNZ0Usb0JBQW9CLEdBQUc7QUFDM0JDLEVBQUFBLEVBQUUsRUFBRy9DLElBQUQsSUFBZUEsSUFEUTtBQUUzQmdELEVBQUFBLE1BQU0sRUFBR2hELElBQUQsSUFBZUE7QUFGSSxDQUE3QjtBQUlBO0FBQ0E7QUFDQTs7QUFDQSxlQUFlaUQscUJBQWYsR0FBdUM7QUFDckMsTUFBSTtBQUNGLFVBQU1DLEtBQUssR0FBRyxNQUFNMUYsbUJBQW1CLENBQUMyRixlQUFwQixDQUFvQyxLQUFwQyxFQUEyQyxLQUEzQyxFQUFrREwsb0JBQWxELENBQXBCOztBQUNBLFFBQUlJLEtBQUssQ0FBQ2xELElBQU4sQ0FBV3BCLE1BQWYsRUFBdUI7QUFDckIsYUFBT3NFLEtBQUssQ0FBQ2xELElBQWI7QUFDRDs7QUFBQTtBQUVELHFCQUNFLHNCQURGLEVBRUUsb0NBRkYsRUFHRSxPQUhGO0FBS0EsV0FBTzRDLE9BQU8sQ0FBQ0MsTUFBUixDQUFlO0FBQ3BCL0QsTUFBQUEsS0FBSyxFQUFFLGdCQURhO0FBRXBCc0UsTUFBQUEsVUFBVSxFQUFFO0FBRlEsS0FBZixDQUFQO0FBSUQsR0FmRCxDQWVFLE9BQU90RSxLQUFQLEVBQWM7QUFDZCxxQkFBSSxrQ0FBSixFQUF3Q0EsS0FBSyxDQUFDRSxPQUFOLElBQWlCRixLQUF6RDtBQUNBLFdBQU84RCxPQUFPLENBQUNDLE1BQVIsQ0FBZTtBQUNwQi9ELE1BQUFBLEtBQUssRUFBRSxnQkFEYTtBQUVwQnNFLE1BQUFBLFVBQVUsRUFBRTtBQUZRLEtBQWYsQ0FBUDtBQUlEO0FBQ0Y7QUFFRDtBQUNBO0FBQ0E7OztBQUNBLGVBQWVDLFFBQWYsQ0FBd0JoRixPQUF4QixFQUFpQztBQUMvQixNQUFJO0FBQ0YsVUFBTWlGLGtCQUFrQixHQUFHLE1BQU1qRixPQUFPLENBQUNpQixJQUFSLENBQWFDLFVBQWIsQ0FBd0JDLE1BQXhCLENBQStCQyxjQUEvQixDQUE4Q0MsT0FBOUMsQ0FBc0RDLFdBQXRELENBQWtFO0FBQUNDLE1BQUFBLElBQUksRUFBRUM7QUFBUCxLQUFsRSxDQUFqQztBQUVBLFVBQU0wRCxRQUFRLEdBQUcsTUFBTU4scUJBQXFCLEVBQTVDO0FBQ0EsVUFBTU8sY0FBYyxHQUFHLENBQUNELFFBQVEsSUFBSSxFQUFiLEVBQWlCRSxNQUFqQixDQUNyQixDQUFDdkMsT0FBRCxFQUFVVixLQUFWLEVBQWlCa0QsSUFBakIsS0FDRWxELEtBQUssS0FDTGtELElBQUksQ0FBQ0MsU0FBTCxDQUNFQyxDQUFDLElBQ0NBLENBQUMsQ0FBQ0MsSUFBRixLQUFXM0MsT0FBTyxDQUFDMkMsSUFBbkIsSUFDQUQsQ0FBQyxDQUFDRSxRQUFGLEtBQWU1QyxPQUFPLENBQUM0QyxRQUR2QixJQUVBRixDQUFDLENBQUNHLEdBQUYsS0FBVTdDLE9BQU8sQ0FBQzZDLEdBRmxCLElBR0FILENBQUMsQ0FBQ0ksSUFBRixLQUFXOUMsT0FBTyxDQUFDOEMsSUFMdkIsQ0FIbUIsQ0FBdkI7O0FBV0EsU0FBSSxJQUFJOUMsT0FBUixJQUFtQnNDLGNBQW5CLEVBQWtDO0FBQ2hDLFVBQUc7QUFDRCxjQUFNO0FBQUV2QyxVQUFBQSxNQUFGO0FBQVVDLFVBQUFBLE9BQU8sRUFBRVE7QUFBbkIsWUFBMkIsTUFBTXVDLFVBQVUsQ0FBQzVGLE9BQUQsRUFBVTZDLE9BQVYsQ0FBakQ7QUFDQSxjQUFNZCxpQ0FBaUMsQ0FBQy9CLE9BQUQsRUFBVTtBQUFDNEMsVUFBQUEsTUFBRDtBQUFTQyxVQUFBQSxPQUFPLEVBQUVRO0FBQWxCLFNBQVYsQ0FBdkM7QUFDRCxPQUhELENBR0MsT0FBTTVDLEtBQU4sRUFBWSxDQUVaOztBQUFBO0FBQ0Y7QUFDRixHQXZCRCxDQXVCRSxPQUFPQSxLQUFQLEVBQWM7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEscUJBQUkscUJBQUosRUFBMkJBLEtBQUssQ0FBQ0UsT0FBTixJQUFpQkYsS0FBNUM7QUFDQVQsSUFBQUEsT0FBTyxDQUFDWSxLQUFSLENBQWNDLE1BQWQsQ0FBcUJKLEtBQXJCLENBQTJCQSxLQUFLLENBQUNFLE9BQU4sSUFBaUJGLEtBQTVDO0FBQ0Q7QUFDRjtBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLGVBQWVtRixVQUFmLENBQTBCNUYsT0FBMUIsRUFBbUM2QyxPQUFuQyxFQUEyQztBQUN6QyxNQUFHO0FBQ0QscUJBQUksdUJBQUosRUFBOEIsd0JBQXVCQSxPQUFPLENBQUNnRCxFQUFHLEVBQWhFLEVBQW1FLE9BQW5FO0FBQ0EsVUFBTUMsaUJBQWlCLEdBQUcsTUFBTTlGLE9BQU8sQ0FBQ1ksS0FBUixDQUFjbUYsR0FBZCxDQUFrQjVFLE1BQWxCLENBQXlCQyxjQUF6QixDQUF3QzRFLE9BQXhDLENBQWdELEtBQWhELEVBQXVELGlCQUF2RCxFQUEwRSxFQUExRSxFQUE4RTtBQUFFQyxNQUFBQSxTQUFTLEVBQUVwRCxPQUFPLENBQUNnRDtBQUFyQixLQUE5RSxDQUFoQztBQUNBLFVBQU1LLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQ0osaUJBQWlCLElBQUksRUFBdEIsRUFBMEI5RCxJQUExQixJQUFrQyxFQUFuQyxFQUF1Q0EsSUFBdkMsSUFBK0MsRUFBaEQsRUFBb0RtRSxPQUFwRCxLQUFnRSxLQUFsRjs7QUFDQSxRQUFHRCxTQUFILEVBQWE7QUFDWCxZQUFNRSxtQkFBbUIsR0FBRyxNQUFNcEcsT0FBTyxDQUFDWSxLQUFSLENBQWNtRixHQUFkLENBQWtCNUUsTUFBbEIsQ0FBeUJDLGNBQXpCLENBQXdDNEUsT0FBeEMsQ0FBZ0QsS0FBaEQsRUFBd0QscUJBQXhELEVBQThFLEVBQTlFLEVBQW1GO0FBQUVDLFFBQUFBLFNBQVMsRUFBRXBELE9BQU8sQ0FBQ2dEO0FBQXJCLE9BQW5GLENBQWxDO0FBQ0FoRCxNQUFBQSxPQUFPLENBQUNXLFdBQVIsR0FBc0I0QyxtQkFBbUIsQ0FBQ3BFLElBQXBCLENBQXlCQSxJQUF6QixDQUE4QnFFLGNBQTlCLENBQTZDLENBQTdDLEVBQWdEOUMsT0FBdEU7QUFDRDs7QUFBQTtBQUNELFVBQU1YLE1BQU0sR0FBRyxNQUFNMEQseUJBQXlCLENBQUN0RyxPQUFELEVBQVU2QyxPQUFWLENBQTlDO0FBQ0EsV0FBTztBQUFFRCxNQUFBQSxNQUFGO0FBQVVDLE1BQUFBO0FBQVYsS0FBUDtBQUNELEdBVkQsQ0FVQyxPQUFNcEMsS0FBTixFQUFZO0FBQ1gscUJBQUksdUJBQUosRUFBNkJBLEtBQUssQ0FBQ0UsT0FBTixJQUFpQkYsS0FBOUM7QUFDQSxVQUFNQSxLQUFOO0FBQ0Q7QUFDRjs7QUFBQTtBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsZUFBZTZGLHlCQUFmLENBQXlDdEcsT0FBekMsRUFBa0Q2QyxPQUFsRCxFQUEwRDtBQUN4RCxNQUFJRCxNQUFNLEdBQUcsRUFBYjs7QUFDQSxNQUFHO0FBQ0QscUJBQUksc0NBQUosRUFBNkMsa0NBQWlDQyxPQUFPLENBQUNnRCxFQUFHLEVBQXpGLEVBQTRGLE9BQTVGO0FBQ0EsVUFBTVUsbUJBQW1CLEdBQUcsTUFBTXZHLE9BQU8sQ0FBQ1ksS0FBUixDQUFjbUYsR0FBZCxDQUFrQjVFLE1BQWxCLENBQXlCQyxjQUF6QixDQUF3QzRFLE9BQXhDLENBQ2hDLEtBRGdDLEVBRWhDLFNBRmdDLEVBR2hDO0FBQ0VRLE1BQUFBLE1BQU0sRUFBRTtBQUNOQyxRQUFBQSxNQUFNLEVBQUUsQ0FERjtBQUVOQyxRQUFBQSxLQUFLLEVBQUUsQ0FGRDtBQUdOQyxRQUFBQSxDQUFDLEVBQUU7QUFIRztBQURWLEtBSGdDLEVBUzdCO0FBQUNWLE1BQUFBLFNBQVMsRUFBRXBELE9BQU8sQ0FBQ2dEO0FBQXBCLEtBVDZCLENBQWxDO0FBV0EsVUFBTWUsV0FBVyxHQUFHTCxtQkFBbUIsQ0FBQ3ZFLElBQXBCLENBQXlCQSxJQUF6QixDQUE4QjZFLG9CQUFsRDtBQUNBLHFCQUFJLHNDQUFKLEVBQTZDLFVBQVNoRSxPQUFPLENBQUNnRCxFQUFHLGtCQUFpQmUsV0FBWSxFQUE5RixFQUFpRyxPQUFqRztBQUVBLFFBQUlFLE9BQU8sR0FBRztBQUNaTCxNQUFBQSxNQUFNLEVBQUUsQ0FESTtBQUVaQyxNQUFBQSxLQUFLLEVBQUUsR0FGSztBQUdaQyxNQUFBQSxDQUFDLEVBQUU7QUFIUyxLQUFkOztBQU1BLFdBQU8vRCxNQUFNLENBQUNyQyxNQUFQLEdBQWdCcUcsV0FBaEIsSUFBK0JFLE9BQU8sQ0FBQ0wsTUFBUixHQUFpQkcsV0FBdkQsRUFBb0U7QUFDbEUsVUFBRztBQUNEO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdRLGNBQU1HLGNBQWMsR0FBRyxNQUFNL0csT0FBTyxDQUFDWSxLQUFSLENBQWNtRixHQUFkLENBQWtCNUUsTUFBbEIsQ0FBeUJDLGNBQXpCLENBQXdDNEUsT0FBeEMsQ0FDM0IsS0FEMkIsRUFFMUIsU0FGMEIsRUFHM0I7QUFBQ1EsVUFBQUEsTUFBTSxFQUFFTTtBQUFULFNBSDJCLEVBSTNCO0FBQUNiLFVBQUFBLFNBQVMsRUFBRXBELE9BQU8sQ0FBQ2dEO0FBQXBCLFNBSjJCLENBQTdCO0FBTUFqRCxRQUFBQSxNQUFNLEdBQUcsQ0FBQyxHQUFHQSxNQUFKLEVBQVksR0FBR21FLGNBQWMsQ0FBQy9FLElBQWYsQ0FBb0JBLElBQXBCLENBQXlCcUUsY0FBeEMsQ0FBVDtBQUNBUyxRQUFBQSxPQUFPLENBQUNMLE1BQVIsSUFBa0JLLE9BQU8sQ0FBQ0osS0FBMUI7QUFDRCxPQXZCRCxDQXVCQyxPQUFNakcsS0FBTixFQUFZO0FBQ1gseUJBQUksc0NBQUosRUFBNkMsVUFBU29DLE9BQU8sQ0FBQ2dELEVBQUcscUNBQW9DaUIsT0FBTyxDQUFDTCxNQUFPLElBQUdLLE9BQU8sQ0FBQ0osS0FBTSxLQUFJakcsS0FBSyxDQUFDRSxPQUFOLElBQWlCRixLQUFNLEVBQWhLO0FBQ0Q7QUFDRjs7QUFDRCxXQUFPbUMsTUFBUDtBQUNELEdBbkRELENBbURDLE9BQU1uQyxLQUFOLEVBQVk7QUFDWCxxQkFBSSxzQ0FBSixFQUE2QyxVQUFTb0MsT0FBTyxDQUFDZ0QsRUFBRyxZQUFXcEYsS0FBSyxDQUFDRSxPQUFOLElBQWlCRixLQUFNLEVBQW5HO0FBQ0EsVUFBTUEsS0FBTjtBQUNEO0FBQ0Y7O0FBQUE7QUFFRDtBQUNBO0FBQ0E7O0FBQ08sZUFBZXVHLGdCQUFmLENBQWdDaEgsT0FBaEMsRUFBeUM7QUFDOUM7QUFDQUQsRUFBQUEsMkJBQTJCLENBQUNDLE9BQUQsQ0FBM0IsQ0FGOEMsQ0FHOUM7O0FBQ0EsUUFBTWlFLHlCQUF5QixDQUFDakUsT0FBRCxDQUEvQixDQUo4QyxDQUs5Qzs7QUFDQSxNQUFJWCxrQkFBSixFQUF3QjtBQUN0QjJGLElBQUFBLFFBQVEsQ0FBQ2hGLE9BQUQsQ0FBUjs7QUFDQWlILHNCQUFLQyxRQUFMLENBQWMzSCxvQkFBZCxFQUFvQyxNQUFNeUYsUUFBUSxDQUFDaEYsT0FBRCxDQUFsRDtBQUNEO0FBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxyXG4gKiBXYXp1aCBhcHAgLSBNb2R1bGUgZm9yIGFnZW50IGluZm8gZmV0Y2hpbmcgZnVuY3Rpb25zXHJcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXHJcbiAqXHJcbiAqIFRoaXMgcHJvZ3JhbSBpcyBmcmVlIHNvZnR3YXJlOyB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XHJcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XHJcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXHJcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXHJcbiAqXHJcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXHJcbiAqL1xyXG5pbXBvcnQgY3JvbiBmcm9tICdub2RlLWNyb24nO1xyXG5pbXBvcnQgeyBsb2cgfSBmcm9tICcuLi8uLi9saWIvbG9nZ2VyJztcclxuaW1wb3J0IHsgbW9uaXRvcmluZ1RlbXBsYXRlIH0gZnJvbSAnLi4vLi4vaW50ZWdyYXRpb24tZmlsZXMvbW9uaXRvcmluZy10ZW1wbGF0ZSc7XHJcbmltcG9ydCB7IGdldENvbmZpZ3VyYXRpb24gfSBmcm9tICcuLi8uLi9saWIvZ2V0LWNvbmZpZ3VyYXRpb24nO1xyXG5pbXBvcnQgeyBwYXJzZUNyb24gfSBmcm9tICcuLi8uLi9saWIvcGFyc2UtY3Jvbic7XHJcbmltcG9ydCB7IGluZGV4RGF0ZSB9IGZyb20gJy4uLy4uL2xpYi9pbmRleC1kYXRlJztcclxuaW1wb3J0IHsgYnVpbGRJbmRleFNldHRpbmdzIH0gZnJvbSAnLi4vLi4vbGliL2J1aWxkLWluZGV4LXNldHRpbmdzJztcclxuaW1wb3J0IHsgV2F6dWhIb3N0c0N0cmwgfSBmcm9tICcuLi8uLi9jb250cm9sbGVycy93YXp1aC1ob3N0cyc7XHJcbmltcG9ydCB7XHJcbiAgV0FaVUhfTU9OSVRPUklOR19QQVRURVJOLFxyXG4gIFdBWlVIX01PTklUT1JJTkdfVEVNUExBVEVfTkFNRSxcclxuICBXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfQ1JFQVRJT04sXHJcbiAgV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0VOQUJMRUQsXHJcbiAgV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0ZSRVFVRU5DWSxcclxuICBXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfSU5ESUNFU19TSEFSRFMsXHJcbiAgV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0lORElDRVNfUkVQTElDQVMsXHJcbn0gZnJvbSAnLi4vLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XHJcbmltcG9ydCB7IHRyeUNhdGNoRm9ySW5kZXhQZXJtaXNzaW9uRXJyb3IgfSBmcm9tICcuLi90cnlDYXRjaEZvckluZGV4UGVybWlzc2lvbkVycm9yJztcclxuaW1wb3J0IHsgZGVsYXlBc1Byb21pc2UgfSBmcm9tICcuLi8uLi8uLi9jb21tb24vdXRpbHMnO1xyXG5cclxuY29uc3QgYmx1ZVdhenVoID0gJ1xcdTAwMWJbMzRtd2F6dWhcXHUwMDFiWzM5bSc7XHJcbmNvbnN0IG1vbml0b3JpbmdFcnJvckxvZ0NvbG9ycyA9IFtibHVlV2F6dWgsICdtb25pdG9yaW5nJywgJ2Vycm9yJ107XHJcbmNvbnN0IHdhenVoSG9zdENvbnRyb2xsZXIgPSBuZXcgV2F6dWhIb3N0c0N0cmwoKTtcclxuXHJcbmxldCBNT05JVE9SSU5HX0VOQUJMRUQsIE1PTklUT1JJTkdfRlJFUVVFTkNZLCBNT05JVE9SSU5HX0NST05fRlJFUSwgTU9OSVRPUklOR19DUkVBVElPTiwgTU9OSVRPUklOR19JTkRFWF9QQVRURVJOLCBNT05JVE9SSU5HX0lOREVYX1BSRUZJWDtcclxuXHJcbi8vIFV0aWxzIGZ1bmN0aW9uc1xyXG4vKipcclxuICogR2V0IHRoZSBzZXR0aW5nIHZhbHVlIGZyb20gdGhlIGNvbmZpZ3VyYXRpb25cclxuICogQHBhcmFtIHNldHRpbmdcclxuICogQHBhcmFtIGNvbmZpZ3VyYXRpb25cclxuICogQHBhcmFtIGRlZmF1bHRWYWx1ZVxyXG4gKi9cclxuZnVuY3Rpb24gZ2V0QXBwQ29uZmlndXJhdGlvblNldHRpbmcoc2V0dGluZzogc3RyaW5nLCBjb25maWd1cmF0aW9uOiBhbnksIGRlZmF1bHRWYWx1ZTogYW55KXtcclxuICByZXR1cm4gdHlwZW9mIGNvbmZpZ3VyYXRpb25bc2V0dGluZ10gIT09ICd1bmRlZmluZWQnID8gY29uZmlndXJhdGlvbltzZXR0aW5nXSA6IGRlZmF1bHRWYWx1ZTtcclxufTtcclxuXHJcbi8qKlxyXG4gKiBTZXQgdGhlIG1vbml0b3JpbmcgdmFyaWFibGVzXHJcbiAqIEBwYXJhbSBjb250ZXh0XHJcbiAqL1xyXG5mdW5jdGlvbiBpbml0TW9uaXRvcmluZ0NvbmZpZ3VyYXRpb24oY29udGV4dCl7XHJcbiAgdHJ5e1xyXG4gICAgY29uc3QgYXBwQ29uZmlnID0gZ2V0Q29uZmlndXJhdGlvbigpO1xyXG4gICAgTU9OSVRPUklOR19FTkFCTEVEID0gYXBwQ29uZmlnICYmIHR5cGVvZiBhcHBDb25maWdbJ3dhenVoLm1vbml0b3JpbmcuZW5hYmxlZCddICE9PSAndW5kZWZpbmVkJ1xyXG4gICAgICA/IGFwcENvbmZpZ1snd2F6dWgubW9uaXRvcmluZy5lbmFibGVkJ10gJiZcclxuICAgICAgICBhcHBDb25maWdbJ3dhenVoLm1vbml0b3JpbmcuZW5hYmxlZCddICE9PSAnd29ya2VyJ1xyXG4gICAgICA6IFdBWlVIX01PTklUT1JJTkdfREVGQVVMVF9FTkFCTEVEO1xyXG4gICAgTU9OSVRPUklOR19GUkVRVUVOQ1kgPSBnZXRBcHBDb25maWd1cmF0aW9uU2V0dGluZygnd2F6dWgubW9uaXRvcmluZy5mcmVxdWVuY3knLCBhcHBDb25maWcsIFdBWlVIX01PTklUT1JJTkdfREVGQVVMVF9GUkVRVUVOQ1kpO1xyXG4gICAgTU9OSVRPUklOR19DUk9OX0ZSRVEgPSBwYXJzZUNyb24oTU9OSVRPUklOR19GUkVRVUVOQ1kpO1xyXG4gICAgTU9OSVRPUklOR19DUkVBVElPTiA9IGdldEFwcENvbmZpZ3VyYXRpb25TZXR0aW5nKCd3YXp1aC5tb25pdG9yaW5nLmNyZWF0aW9uJywgYXBwQ29uZmlnLCBXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfQ1JFQVRJT04pO1xyXG5cclxuICAgIE1PTklUT1JJTkdfSU5ERVhfUEFUVEVSTiA9IGdldEFwcENvbmZpZ3VyYXRpb25TZXR0aW5nKCd3YXp1aC5tb25pdG9yaW5nLnBhdHRlcm4nLCBhcHBDb25maWcsIFdBWlVIX01PTklUT1JJTkdfUEFUVEVSTik7XHJcbiAgICBjb25zdCBsYXN0Q2hhckluZGV4UGF0dGVybiA9IE1PTklUT1JJTkdfSU5ERVhfUEFUVEVSTltNT05JVE9SSU5HX0lOREVYX1BBVFRFUk4ubGVuZ3RoIC0gMV07XHJcbiAgICBpZiAobGFzdENoYXJJbmRleFBhdHRlcm4gIT09ICcqJykge1xyXG4gICAgICBNT05JVE9SSU5HX0lOREVYX1BBVFRFUk4gKz0gJyonO1xyXG4gICAgfTtcclxuICAgIE1PTklUT1JJTkdfSU5ERVhfUFJFRklYID0gTU9OSVRPUklOR19JTkRFWF9QQVRURVJOLnNsaWNlKDAsTU9OSVRPUklOR19JTkRFWF9QQVRURVJOLmxlbmd0aCAtIDEpO1xyXG5cclxuICAgIGxvZyhcclxuICAgICAgJ21vbml0b3Jpbmc6aW5pdE1vbml0b3JpbmdDb25maWd1cmF0aW9uJyxcclxuICAgICAgYHdhenVoLm1vbml0b3JpbmcuZW5hYmxlZDogJHtNT05JVE9SSU5HX0VOQUJMRUR9YCxcclxuICAgICAgJ2RlYnVnJ1xyXG4gICAgKTtcclxuXHJcbiAgICBsb2coXHJcbiAgICAgICdtb25pdG9yaW5nOmluaXRNb25pdG9yaW5nQ29uZmlndXJhdGlvbicsXHJcbiAgICAgIGB3YXp1aC5tb25pdG9yaW5nLmZyZXF1ZW5jeTogJHtNT05JVE9SSU5HX0ZSRVFVRU5DWX0gKCR7TU9OSVRPUklOR19DUk9OX0ZSRVF9KWAsXHJcbiAgICAgICdkZWJ1ZydcclxuICAgICk7XHJcblxyXG4gICAgbG9nKFxyXG4gICAgICAnbW9uaXRvcmluZzppbml0TW9uaXRvcmluZ0NvbmZpZ3VyYXRpb24nLFxyXG4gICAgICBgd2F6dWgubW9uaXRvcmluZy5wYXR0ZXJuOiAke01PTklUT1JJTkdfSU5ERVhfUEFUVEVSTn0gKGluZGV4IHByZWZpeDogJHtNT05JVE9SSU5HX0lOREVYX1BSRUZJWH0pYCxcclxuICAgICAgJ2RlYnVnJ1xyXG4gICAgKTtcclxuICB9Y2F0Y2goZXJyb3Ipe1xyXG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gZXJyb3IubWVzc2FnZSB8fCBlcnJvcjtcclxuICAgIGxvZyhcclxuICAgICAgJ21vbml0b3Jpbmc6aW5pdE1vbml0b3JpbmdDb25maWd1cmF0aW9uJyxcclxuICAgICAgZXJyb3JNZXNzYWdlXHJcbiAgICApO1xyXG4gICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoZXJyb3JNZXNzYWdlKVxyXG4gIH1cclxufTtcclxuXHJcbi8qKlxyXG4gKiBNYWluLiBGaXJzdCBleGVjdXRpb24gd2hlbiBpbnN0YWxsaW5nIC8gbG9hZGluZyBBcHAuXHJcbiAqIEBwYXJhbSBjb250ZXh0XHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiBpbml0KGNvbnRleHQpIHtcclxuICB0cnkge1xyXG4gICAgaWYgKE1PTklUT1JJTkdfRU5BQkxFRCkge1xyXG4gICAgICBhd2FpdCBjaGVja1RlbXBsYXRlKGNvbnRleHQpO1xyXG4gICAgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gZXJyb3IubWVzc2FnZSB8fCBlcnJvcjtcclxuICAgIGxvZygnbW9uaXRvcmluZzppbml0JywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvck1lc3NhZ2UpO1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFZlcmlmeSB3YXp1aC1hZ2VudCB0ZW1wbGF0ZVxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gY2hlY2tUZW1wbGF0ZShjb250ZXh0KSB7XHJcbiAgdHJ5IHtcclxuICAgIGxvZyhcclxuICAgICAgJ21vbml0b3Jpbmc6Y2hlY2tUZW1wbGF0ZScsXHJcbiAgICAgICdVcGRhdGluZyB0aGUgbW9uaXRvcmluZyB0ZW1wbGF0ZScsXHJcbiAgICAgICdkZWJ1ZydcclxuICAgICk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgLy8gQ2hlY2sgaWYgdGhlIHRlbXBsYXRlIGFscmVhZHkgZXhpc3RzXHJcbiAgICAgIGNvbnN0IGN1cnJlbnRUZW1wbGF0ZSA9IGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlci5pbmRpY2VzLmdldFRlbXBsYXRlKHtcclxuICAgICAgICBuYW1lOiBXQVpVSF9NT05JVE9SSU5HX1RFTVBMQVRFX05BTUVcclxuICAgICAgfSk7XHJcbiAgICAgIC8vIENvcHkgYWxyZWFkeSBjcmVhdGVkIGluZGV4IHBhdHRlcm5zXHJcbiAgICAgIG1vbml0b3JpbmdUZW1wbGF0ZS5pbmRleF9wYXR0ZXJucyA9IGN1cnJlbnRUZW1wbGF0ZS5ib2R5W1dBWlVIX01PTklUT1JJTkdfVEVNUExBVEVfTkFNRV0uaW5kZXhfcGF0dGVybnM7XHJcbiAgICB9Y2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIC8vIEluaXQgd2l0aCB0aGUgZGVmYXVsdCBpbmRleCBwYXR0ZXJuXHJcbiAgICAgIG1vbml0b3JpbmdUZW1wbGF0ZS5pbmRleF9wYXR0ZXJucyA9IFtXQVpVSF9NT05JVE9SSU5HX1BBVFRFUk5dO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIENoZWNrIGlmIHRoZSB1c2VyIGlzIHVzaW5nIGEgY3VzdG9tIHBhdHRlcm4gYW5kIGFkZCBpdCB0byB0aGUgdGVtcGxhdGUgaWYgaXQgZG9lc1xyXG4gICAgaWYgKCFtb25pdG9yaW5nVGVtcGxhdGUuaW5kZXhfcGF0dGVybnMuaW5jbHVkZXMoTU9OSVRPUklOR19JTkRFWF9QQVRURVJOKSkge1xyXG4gICAgICBtb25pdG9yaW5nVGVtcGxhdGUuaW5kZXhfcGF0dGVybnMucHVzaChNT05JVE9SSU5HX0lOREVYX1BBVFRFUk4pO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBVcGRhdGUgdGhlIG1vbml0b3JpbmcgdGVtcGxhdGVcclxuICAgIGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlci5pbmRpY2VzLnB1dFRlbXBsYXRlKHtcclxuICAgICAgbmFtZTogV0FaVUhfTU9OSVRPUklOR19URU1QTEFURV9OQU1FLFxyXG4gICAgICBib2R5OiBtb25pdG9yaW5nVGVtcGxhdGVcclxuICAgIH0pO1xyXG4gICAgbG9nKFxyXG4gICAgICAnbW9uaXRvcmluZzpjaGVja1RlbXBsYXRlJyxcclxuICAgICAgJ1VwZGF0ZWQgdGhlIG1vbml0b3JpbmcgdGVtcGxhdGUnLFxyXG4gICAgICAnZGVidWcnXHJcbiAgICApO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBgU29tZXRoaW5nIHdlbnQgd3JvbmcgdXBkYXRpbmcgdGhlIG1vbml0b3JpbmcgdGVtcGxhdGUgJHtlcnJvci5tZXNzYWdlIHx8IGVycm9yfWA7XHJcbiAgICBsb2coXHJcbiAgICAgICdtb25pdG9yaW5nOmNoZWNrVGVtcGxhdGUnLFxyXG4gICAgICBlcnJvck1lc3NhZ2VcclxuICAgICk7XHJcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihtb25pdG9yaW5nRXJyb3JMb2dDb2xvcnMsIGVycm9yTWVzc2FnZSk7XHJcbiAgICB0aHJvdyBlcnJvcjtcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBTYXZlIGFnZW50IHN0YXR1cyBpbnRvIGVsYXN0aWNzZWFyY2gsIGNyZWF0ZSBpbmRleCBhbmQvb3IgaW5zZXJ0IGRvY3VtZW50XHJcbiAqIEBwYXJhbSB7Kn0gY29udGV4dFxyXG4gKiBAcGFyYW0geyp9IGRhdGFcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIGluc2VydE1vbml0b3JpbmdEYXRhRWxhc3RpY3NlYXJjaChjb250ZXh0LCBkYXRhKSB7XHJcbiAgY29uc3QgbW9uaXRvcmluZ0luZGV4TmFtZSA9IE1PTklUT1JJTkdfSU5ERVhfUFJFRklYICsgaW5kZXhEYXRlKE1PTklUT1JJTkdfQ1JFQVRJT04pO1xyXG4gICAgaWYgKCFNT05JVE9SSU5HX0VOQUJMRUQpe1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9O1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgdHJ5Q2F0Y2hGb3JJbmRleFBlcm1pc3Npb25FcnJvcihtb25pdG9yaW5nSW5kZXhOYW1lKSAoYXN5bmMoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZXhpc3RzID0gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzSW50ZXJuYWxVc2VyLmluZGljZXMuZXhpc3RzKHtpbmRleDogbW9uaXRvcmluZ0luZGV4TmFtZX0pO1xyXG4gICAgICAgIGlmKCFleGlzdHMuYm9keSl7XHJcbiAgICAgICAgICBhd2FpdCBjcmVhdGVJbmRleChjb250ZXh0LCBtb25pdG9yaW5nSW5kZXhOYW1lKTtcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICAvLyBVcGRhdGUgdGhlIGluZGV4IGNvbmZpZ3VyYXRpb25cclxuICAgICAgICBjb25zdCBhcHBDb25maWcgPSBnZXRDb25maWd1cmF0aW9uKCk7XHJcbiAgICAgICAgY29uc3QgaW5kZXhDb25maWd1cmF0aW9uID0gYnVpbGRJbmRleFNldHRpbmdzKFxyXG4gICAgICAgICAgYXBwQ29uZmlnLFxyXG4gICAgICAgICAgJ3dhenVoLm1vbml0b3JpbmcnLFxyXG4gICAgICAgICAgV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0lORElDRVNfU0hBUkRTXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgLy8gVG8gdXBkYXRlIHRoZSBpbmRleCBzZXR0aW5ncyB3aXRoIHRoaXMgY2xpZW50IGlzIHJlcXVpcmVkIGNsb3NlIHRoZSBpbmRleCwgdXBkYXRlIHRoZSBzZXR0aW5ncyBhbmQgb3BlbiBpdFxyXG4gICAgICAgIC8vIE51bWJlciBvZiBzaGFyZHMgaXMgbm90IGR5bmFtaWMgc28gZGVsZXRlIHRoYXQgc2V0dGluZyBpZiBpdCdzIGdpdmVuXHJcbiAgICAgICAgZGVsZXRlIGluZGV4Q29uZmlndXJhdGlvbi5zZXR0aW5ncy5pbmRleC5udW1iZXJfb2Zfc2hhcmRzO1xyXG4gICAgICAgIGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlci5pbmRpY2VzLnB1dFNldHRpbmdzKHtcclxuICAgICAgICAgIGluZGV4OiBtb25pdG9yaW5nSW5kZXhOYW1lLFxyXG4gICAgICAgICAgYm9keTogaW5kZXhDb25maWd1cmF0aW9uXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vIEluc2VydCBkYXRhIHRvIHRoZSBtb25pdG9yaW5nIGluZGV4XHJcbiAgICAgICAgYXdhaXQgaW5zZXJ0RGF0YVRvSW5kZXgoY29udGV4dCwgbW9uaXRvcmluZ0luZGV4TmFtZSwgZGF0YSk7XHJcbiAgICAgIH0pKCk7XHJcbiAgICB9Y2F0Y2goZXJyb3Ipe1xyXG4gICAgICBsb2coJ21vbml0b3Jpbmc6aW5zZXJ0TW9uaXRvcmluZ0RhdGFFbGFzdGljc2VhcmNoJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgfVxyXG59XHJcblxyXG4vKipcclxuICogSW5zZXJ0aW5nIG9uZSBkb2N1bWVudCBwZXIgYWdlbnQgaW50byBFbGFzdGljLiBCdWxrLlxyXG4gKiBAcGFyYW0geyp9IGNvbnRleHQgRW5kcG9pbnRcclxuICogQHBhcmFtIHtTdHJpbmd9IGluZGV4TmFtZSBUaGUgbmFtZSBmb3IgdGhlIGluZGV4IChlLmcuIGRhaWx5OiB3YXp1aC1tb25pdG9yaW5nLVlZWVkuTU0uREQpXHJcbiAqIEBwYXJhbSB7Kn0gZGF0YVxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gaW5zZXJ0RGF0YVRvSW5kZXgoY29udGV4dCwgaW5kZXhOYW1lOiBzdHJpbmcsIGRhdGE6IHthZ2VudHM6IGFueVtdLCBhcGlIb3N0fSkge1xyXG4gIGNvbnN0IHsgYWdlbnRzLCBhcGlIb3N0IH0gPSBkYXRhO1xyXG4gIHRyeSB7XHJcbiAgICBpZiAoYWdlbnRzLmxlbmd0aCA+IDApIHtcclxuICAgICAgbG9nKFxyXG4gICAgICAgICdtb25pdG9yaW5nOmluc2VydERhdGFUb0luZGV4JyxcclxuICAgICAgICBgQnVsayBkYXRhIHRvIGluZGV4ICR7aW5kZXhOYW1lfSBmb3IgJHthZ2VudHMubGVuZ3RofSBhZ2VudHNgLFxyXG4gICAgICAgICdkZWJ1ZydcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IGJvZHlCdWxrID0gYWdlbnRzLm1hcChhZ2VudCA9PiB7XHJcbiAgICAgICAgY29uc3QgYWdlbnRJbmZvID0gey4uLmFnZW50fTtcclxuICAgICAgICBhZ2VudEluZm9bJ3RpbWVzdGFtcCddID0gbmV3IERhdGUoRGF0ZS5ub3coKSkudG9JU09TdHJpbmcoKTtcclxuICAgICAgICBhZ2VudEluZm8uaG9zdCA9IGFnZW50Lm1hbmFnZXI7XHJcbiAgICAgICAgYWdlbnRJbmZvLmNsdXN0ZXIgPSB7IG5hbWU6IGFwaUhvc3QuY2x1c3Rlck5hbWUgPyBhcGlIb3N0LmNsdXN0ZXJOYW1lIDogJ2Rpc2FibGVkJyB9O1xyXG4gICAgICAgIHJldHVybiBgeyBcImluZGV4XCI6ICB7IFwiX2luZGV4XCI6IFwiJHtpbmRleE5hbWV9XCIgfSB9XFxuJHtKU09OLnN0cmluZ2lmeShhZ2VudEluZm8pfVxcbmA7XHJcbiAgICAgIH0pLmpvaW4oJycpO1xyXG5cclxuICAgICAgYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzSW50ZXJuYWxVc2VyLmJ1bGsoe1xyXG4gICAgICAgIGluZGV4OiBpbmRleE5hbWUsXHJcbiAgICAgICAgYm9keTogYm9keUJ1bGtcclxuICAgICAgfSk7XHJcbiAgICAgIGxvZyhcclxuICAgICAgICAnbW9uaXRvcmluZzppbnNlcnREYXRhVG9JbmRleCcsXHJcbiAgICAgICAgYEJ1bGsgZGF0YSB0byBpbmRleCAke2luZGV4TmFtZX0gZm9yICR7YWdlbnRzLmxlbmd0aH0gYWdlbnRzIGNvbXBsZXRlZGAsXHJcbiAgICAgICAgJ2RlYnVnJ1xyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBsb2coXHJcbiAgICAgICdtb25pdG9yaW5nOmluc2VydERhdGFUb0luZGV4JyxcclxuICAgICAgYEVycm9yIGluc2VydGluZyBhZ2VudCBkYXRhIGludG8gZWxhc3RpY3NlYXJjaC4gQnVsayByZXF1ZXN0IGZhaWxlZCBkdWUgdG8gJHtlcnJvci5tZXNzYWdlIHx8XHJcbiAgICAgICAgZXJyb3J9YFxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBDcmVhdGUgdGhlIHdhenVoLW1vbml0b3JpbmcgaW5kZXhcclxuICogQHBhcmFtIHsqfSBjb250ZXh0IGNvbnRleHRcclxuICogQHBhcmFtIHtTdHJpbmd9IGluZGV4TmFtZSBUaGUgbmFtZSBmb3IgdGhlIGluZGV4IChlLmcuIGRhaWx5OiB3YXp1aC1tb25pdG9yaW5nLVlZWVkuTU0uREQpXHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiBjcmVhdGVJbmRleChjb250ZXh0LCBpbmRleE5hbWU6IHN0cmluZykge1xyXG4gIHRyeSB7XHJcbiAgICBpZiAoIU1PTklUT1JJTkdfRU5BQkxFRCkgcmV0dXJuO1xyXG4gICAgY29uc3QgYXBwQ29uZmlnID0gZ2V0Q29uZmlndXJhdGlvbigpO1xyXG5cclxuICAgIGNvbnN0IEluZGV4Q29uZmlndXJhdGlvbiA9IHtcclxuICAgICAgc2V0dGluZ3M6IHtcclxuICAgICAgICBpbmRleDoge1xyXG4gICAgICAgICAgbnVtYmVyX29mX3NoYXJkczogZ2V0QXBwQ29uZmlndXJhdGlvblNldHRpbmcoJ3dhenVoLm1vbml0b3Jpbmcuc2hhcmRzJywgYXBwQ29uZmlnLCBXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfSU5ESUNFU19TSEFSRFMpLFxyXG4gICAgICAgICAgbnVtYmVyX29mX3JlcGxpY2FzOiBnZXRBcHBDb25maWd1cmF0aW9uU2V0dGluZygnd2F6dWgubW9uaXRvcmluZy5yZXBsaWNhcycsIGFwcENvbmZpZywgV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0lORElDRVNfUkVQTElDQVMpXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGF3YWl0IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlci5pbmRpY2VzLmNyZWF0ZSh7XHJcbiAgICAgIGluZGV4OiBpbmRleE5hbWUsXHJcbiAgICAgIGJvZHk6IEluZGV4Q29uZmlndXJhdGlvblxyXG4gICAgfSk7XHJcblxyXG4gICAgbG9nKFxyXG4gICAgICAnbW9uaXRvcmluZzpjcmVhdGVJbmRleCcsXHJcbiAgICAgIGBTdWNjZXNzZnVsbHkgY3JlYXRlZCBuZXcgaW5kZXg6ICR7aW5kZXhOYW1lfWAsXHJcbiAgICAgICdkZWJ1ZydcclxuICAgICk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGBDb3VsZCBub3QgY3JlYXRlICR7aW5kZXhOYW1lfSBpbmRleCBvbiBlbGFzdGljc2VhcmNoIGR1ZSB0byAke2Vycm9yLm1lc3NhZ2UgfHwgZXJyb3J9YDtcclxuICAgIGxvZyhcclxuICAgICAgJ21vbml0b3Jpbmc6Y3JlYXRlSW5kZXgnLFxyXG4gICAgICBlcnJvck1lc3NhZ2VcclxuICAgICk7XHJcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvck1lc3NhZ2UpO1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiogV2FpdCB1bnRpbCBLaWJhbmEgc2VydmVyIGlzIHJlYWR5XHJcbiovXHJcbmFzeW5jIGZ1bmN0aW9uIGNoZWNrUGx1Z2luUGxhdGZvcm1TdGF0dXMoY29udGV4dCkge1xyXG4gdHJ5IHtcclxuICAgIGxvZyhcclxuICAgICAgJ21vbml0b3Jpbmc6Y2hlY2tQbHVnaW5QbGF0Zm9ybVN0YXR1cycsXHJcbiAgICAgICdXYWl0aW5nIGZvciBLaWJhbmEgYW5kIEVsYXN0aWNzZWFyY2ggc2VydmVycyB0byBiZSByZWFkeS4uLicsXHJcbiAgICAgICdkZWJ1ZydcclxuICAgICk7XHJcblxyXG4gICBhd2FpdCBjaGVja0VsYXN0aWNzZWFyY2hTZXJ2ZXIoY29udGV4dCk7XHJcbiAgIGF3YWl0IGluaXQoY29udGV4dCk7XHJcbiAgIHJldHVybjtcclxuIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBsb2coXHJcbiAgICAgICdtb25pdG9yaW5nOmNoZWNrUGx1Z2luUGxhdGZvcm1TdGF0dXMnLFxyXG4gICAgICBlcnJvci5tZXNhZ2UgfHxlcnJvclxyXG4gICAgKTtcclxuICAgIHRyeXtcclxuICAgICAgYXdhaXQgZGVsYXlBc1Byb21pc2UoMzAwMCk7XHJcbiAgICAgIGF3YWl0IGNoZWNrUGx1Z2luUGxhdGZvcm1TdGF0dXMoY29udGV4dCk7XHJcbiAgICB9Y2F0Y2goZXJyb3Ipe307XHJcbiB9XHJcbn1cclxuXHJcblxyXG4vKipcclxuICogQ2hlY2sgRWxhc3RpY3NlYXJjaCBTZXJ2ZXIgc3RhdHVzIGFuZCBLaWJhbmEgaW5kZXggcHJlc2VuY2VcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIGNoZWNrRWxhc3RpY3NlYXJjaFNlcnZlcihjb250ZXh0KSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNJbnRlcm5hbFVzZXIuaW5kaWNlcy5leGlzdHMoe1xyXG4gICAgICBpbmRleDogY29udGV4dC5zZXJ2ZXIuY29uZmlnLm9wZW5zZWFyY2hEYXNoYm9hcmRzLmluZGV4XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5ib2R5O1xyXG4gICAgLy8gVE9ETzogY2hlY2sgaWYgRWxhc3RpY3NlYXJjaCBjYW4gcmVjZWl2ZSByZXF1ZXN0c1xyXG4gICAgLy8gaWYgKGRhdGEpIHtcclxuICAgIC8vICAgY29uc3QgcGx1Z2luc0RhdGEgPSBhd2FpdCB0aGlzLnNlcnZlci5wbHVnaW5zLmVsYXN0aWNzZWFyY2gud2FpdFVudGlsUmVhZHkoKTtcclxuICAgIC8vICAgcmV0dXJuIHBsdWdpbnNEYXRhO1xyXG4gICAgLy8gfVxyXG4gICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGRhdGEpO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBsb2coJ21vbml0b3Jpbmc6Y2hlY2tFbGFzdGljc2VhcmNoU2VydmVyJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xyXG4gIH1cclxufVxyXG5cclxuY29uc3QgZmFrZVJlc3BvbnNlRW5kcG9pbnQgPSB7XHJcbiAgb2s6IChib2R5OiBhbnkpID0+IGJvZHksXHJcbiAgY3VzdG9tOiAoYm9keTogYW55KSA9PiBib2R5LFxyXG59XHJcbi8qKlxyXG4gKiBHZXQgQVBJIGNvbmZpZ3VyYXRpb24gZnJvbSBlbGFzdGljIGFuZCBjYWxsYmFjayB0byBsb2FkQ3JlZGVudGlhbHNcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIGdldEhvc3RzQ29uZmlndXJhdGlvbigpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgaG9zdHMgPSBhd2FpdCB3YXp1aEhvc3RDb250cm9sbGVyLmdldEhvc3RzRW50cmllcyhmYWxzZSwgZmFsc2UsIGZha2VSZXNwb25zZUVuZHBvaW50KTtcclxuICAgIGlmIChob3N0cy5ib2R5Lmxlbmd0aCkge1xyXG4gICAgICByZXR1cm4gaG9zdHMuYm9keTtcclxuICAgIH07XHJcblxyXG4gICAgbG9nKFxyXG4gICAgICAnbW9uaXRvcmluZzpnZXRDb25maWcnLFxyXG4gICAgICAnVGhlcmUgYXJlIG5vIFdhenVoIEFQSSBlbnRyaWVzIHlldCcsXHJcbiAgICAgICdkZWJ1ZydcclxuICAgICk7XHJcbiAgICByZXR1cm4gUHJvbWlzZS5yZWplY3Qoe1xyXG4gICAgICBlcnJvcjogJ25vIGNyZWRlbnRpYWxzJyxcclxuICAgICAgZXJyb3JfY29kZTogMVxyXG4gICAgfSk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGxvZygnbW9uaXRvcmluZzpnZXRIb3N0c0NvbmZpZ3VyYXRpb24nLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgIHJldHVybiBQcm9taXNlLnJlamVjdCh7XHJcbiAgICAgIGVycm9yOiAnbm8gd2F6dWggaG9zdHMnLFxyXG4gICAgICBlcnJvcl9jb2RlOiAyXHJcbiAgICB9KTtcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gICAqIFRhc2sgdXNlZCBieSB0aGUgY3JvbiBqb2IuXHJcbiAgICovXHJcbmFzeW5jIGZ1bmN0aW9uIGNyb25UYXNrKGNvbnRleHQpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgdGVtcGxhdGVNb25pdG9yaW5nID0gYXdhaXQgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzSW50ZXJuYWxVc2VyLmluZGljZXMuZ2V0VGVtcGxhdGUoe25hbWU6IFdBWlVIX01PTklUT1JJTkdfVEVNUExBVEVfTkFNRX0pO1xyXG5cclxuICAgIGNvbnN0IGFwaUhvc3RzID0gYXdhaXQgZ2V0SG9zdHNDb25maWd1cmF0aW9uKCk7XHJcbiAgICBjb25zdCBhcGlIb3N0c1VuaXF1ZSA9IChhcGlIb3N0cyB8fCBbXSkuZmlsdGVyKFxyXG4gICAgICAoYXBpSG9zdCwgaW5kZXgsIHNlbGYpID0+XHJcbiAgICAgICAgaW5kZXggPT09XHJcbiAgICAgICAgc2VsZi5maW5kSW5kZXgoXHJcbiAgICAgICAgICB0ID0+XHJcbiAgICAgICAgICAgIHQudXNlciA9PT0gYXBpSG9zdC51c2VyICYmXHJcbiAgICAgICAgICAgIHQucGFzc3dvcmQgPT09IGFwaUhvc3QucGFzc3dvcmQgJiZcclxuICAgICAgICAgICAgdC51cmwgPT09IGFwaUhvc3QudXJsICYmXHJcbiAgICAgICAgICAgIHQucG9ydCA9PT0gYXBpSG9zdC5wb3J0XHJcbiAgICAgICAgKVxyXG4gICAgKTtcclxuICAgIGZvcihsZXQgYXBpSG9zdCBvZiBhcGlIb3N0c1VuaXF1ZSl7XHJcbiAgICAgIHRyeXtcclxuICAgICAgICBjb25zdCB7IGFnZW50cywgYXBpSG9zdDogaG9zdH0gPSBhd2FpdCBnZXRBcGlJbmZvKGNvbnRleHQsIGFwaUhvc3QpO1xyXG4gICAgICAgIGF3YWl0IGluc2VydE1vbml0b3JpbmdEYXRhRWxhc3RpY3NlYXJjaChjb250ZXh0LCB7YWdlbnRzLCBhcGlIb3N0OiBob3N0fSk7XHJcbiAgICAgIH1jYXRjaChlcnJvcil7XHJcblxyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAvLyBSZXRyeSB0byBjYWxsIGl0c2VsZiBhZ2FpbiBpZiBLaWJhbmEgaW5kZXggaXMgbm90IHJlYWR5IHlldFxyXG4gICAgLy8gdHJ5IHtcclxuICAgIC8vICAgaWYgKFxyXG4gICAgLy8gICAgIHRoaXMud3pXcmFwcGVyLmJ1aWxkaW5nS2liYW5hSW5kZXggfHxcclxuICAgIC8vICAgICAoKGVycm9yIHx8IHt9KS5zdGF0dXMgPT09IDQwNCAmJlxyXG4gICAgLy8gICAgICAgKGVycm9yIHx8IHt9KS5kaXNwbGF5TmFtZSA9PT0gJ05vdEZvdW5kJylcclxuICAgIC8vICAgKSB7XHJcbiAgICAvLyAgICAgYXdhaXQgZGVsYXlBc1Byb21pc2UoMTAwMCk7XHJcbiAgICAvLyAgICAgcmV0dXJuIGNyb25UYXNrKGNvbnRleHQpO1xyXG4gICAgLy8gICB9XHJcbiAgICAvLyB9IGNhdGNoIChlcnJvcikge30gLy9lc2xpbnQtZGlzYWJsZS1saW5lXHJcblxyXG4gICAgbG9nKCdtb25pdG9yaW5nOmNyb25UYXNrJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBHZXQgQVBJIGFuZCBhZ2VudHMgaW5mb1xyXG4gKiBAcGFyYW0gY29udGV4dFxyXG4gKiBAcGFyYW0gYXBpSG9zdFxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gZ2V0QXBpSW5mbyhjb250ZXh0LCBhcGlIb3N0KXtcclxuICB0cnl7XHJcbiAgICBsb2coJ21vbml0b3Jpbmc6Z2V0QXBpSW5mbycsIGBHZXR0aW5nIEFQSSBpbmZvIGZvciAke2FwaUhvc3QuaWR9YCwgJ2RlYnVnJyk7XHJcbiAgICBjb25zdCByZXNwb25zZUlzQ2x1c3RlciA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KCdHRVQnLCAnL2NsdXN0ZXIvc3RhdHVzJywge30sIHsgYXBpSG9zdElEOiBhcGlIb3N0LmlkIH0pO1xyXG4gICAgY29uc3QgaXNDbHVzdGVyID0gKCgocmVzcG9uc2VJc0NsdXN0ZXIgfHwge30pLmRhdGEgfHwge30pLmRhdGEgfHwge30pLmVuYWJsZWQgPT09ICd5ZXMnO1xyXG4gICAgaWYoaXNDbHVzdGVyKXtcclxuICAgICAgY29uc3QgcmVzcG9uc2VDbHVzdGVySW5mbyA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KCdHRVQnLCBgL2NsdXN0ZXIvbG9jYWwvaW5mb2AsIHt9LCAgeyBhcGlIb3N0SUQ6IGFwaUhvc3QuaWQgfSk7XHJcbiAgICAgIGFwaUhvc3QuY2x1c3Rlck5hbWUgPSByZXNwb25zZUNsdXN0ZXJJbmZvLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc1swXS5jbHVzdGVyO1xyXG4gICAgfTtcclxuICAgIGNvbnN0IGFnZW50cyA9IGF3YWl0IGZldGNoQWxsQWdlbnRzRnJvbUFwaUhvc3QoY29udGV4dCwgYXBpSG9zdCk7XHJcbiAgICByZXR1cm4geyBhZ2VudHMsIGFwaUhvc3QgfTtcclxuICB9Y2F0Y2goZXJyb3Ipe1xyXG4gICAgbG9nKCdtb25pdG9yaW5nOmdldEFwaUluZm8nLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcclxuICAgIHRocm93IGVycm9yO1xyXG4gIH1cclxufTtcclxuXHJcbi8qKlxyXG4gKiBGZXRjaCBhbGwgYWdlbnRzIGZvciB0aGUgQVBJIHByb3ZpZGVkXHJcbiAqIEBwYXJhbSBjb250ZXh0XHJcbiAqIEBwYXJhbSBhcGlIb3N0XHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiBmZXRjaEFsbEFnZW50c0Zyb21BcGlIb3N0KGNvbnRleHQsIGFwaUhvc3Qpe1xyXG4gIGxldCBhZ2VudHMgPSBbXTtcclxuICB0cnl7XHJcbiAgICBsb2coJ21vbml0b3Jpbmc6ZmV0Y2hBbGxBZ2VudHNGcm9tQXBpSG9zdCcsIGBHZXR0aW5nIGFsbCBhZ2VudHMgZnJvbSBBcGlJRDogJHthcGlIb3N0LmlkfWAsICdkZWJ1ZycpO1xyXG4gICAgY29uc3QgcmVzcG9uc2VBZ2VudHNDb3VudCA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KFxyXG4gICAgICAnR0VUJyxcclxuICAgICAgJy9hZ2VudHMnLFxyXG4gICAgICB7XHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICBvZmZzZXQ6IDAsXHJcbiAgICAgICAgICBsaW1pdDogMSxcclxuICAgICAgICAgIHE6ICdpZCE9MDAwJ1xyXG4gICAgICAgIH1cclxuICAgICAgfSwge2FwaUhvc3RJRDogYXBpSG9zdC5pZH0pO1xyXG5cclxuICAgIGNvbnN0IGFnZW50c0NvdW50ID0gcmVzcG9uc2VBZ2VudHNDb3VudC5kYXRhLmRhdGEudG90YWxfYWZmZWN0ZWRfaXRlbXM7XHJcbiAgICBsb2coJ21vbml0b3Jpbmc6ZmV0Y2hBbGxBZ2VudHNGcm9tQXBpSG9zdCcsIGBBcGlJRDogJHthcGlIb3N0LmlkfSwgQWdlbnQgY291bnQ6ICR7YWdlbnRzQ291bnR9YCwgJ2RlYnVnJyk7XHJcblxyXG4gICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgIG9mZnNldDogMCxcclxuICAgICAgbGltaXQ6IDUwMCxcclxuICAgICAgcTogJ2lkIT0wMDAnXHJcbiAgICB9O1xyXG5cclxuICAgIHdoaWxlIChhZ2VudHMubGVuZ3RoIDwgYWdlbnRzQ291bnQgJiYgcGF5bG9hZC5vZmZzZXQgPCBhZ2VudHNDb3VudCkge1xyXG4gICAgICB0cnl7XHJcbiAgICAgICAgLypcclxuICAgICAgICBUT0RPOiBJbXByb3ZlIHRoZSBwZXJmb3JtYW5jZSBvZiByZXF1ZXN0IHdpdGg6XHJcbiAgICAgICAgICAtIFJlZHVjZSB0aGUgbnVtYmVyIG9mIHJlcXVlc3RzIHRvIHRoZSBXYXp1aCBBUElcclxuICAgICAgICAgIC0gUmVkdWNlIChpZiBwb3NzaWJsZSkgdGhlIHF1YW50aXR5IG9mIGRhdGEgdG8gaW5kZXggYnkgZG9jdW1lbnRcclxuXHJcbiAgICAgICAgUmVxdWlyZW1lbnRzOlxyXG4gICAgICAgICAgLSBSZXNlYXJjaCBhYm91dCB0aGUgbmVjY2VzYXJ5IGRhdGEgdG8gaW5kZXguXHJcblxyXG4gICAgICAgIEhvdyB0byBkbzpcclxuICAgICAgICAgIC0gV2F6dWggQVBJIHJlcXVlc3Q6XHJcbiAgICAgICAgICAgIC0gc2VsZWN0IHRoZSByZXF1aXJlZCBkYXRhIHRvIHJldHJpZXZlIGRlcGVuZGluZyBvbiBpcyByZXF1aXJlZCB0byBpbmRleCAodXNpbmcgdGhlIGBzZWxlY3RgIHF1ZXJ5IHBhcmFtKVxyXG4gICAgICAgICAgICAtIGluY3JlYXNlIHRoZSBsaW1pdCBvZiByZXN1bHRzIHRvIHJldHJpZXZlIChjdXJyZW50bHksIHRoZSByZXF1ZXN0cyB1c2UgdGhlIHJlY29tbWVuZGVkIHZhbHVlOiA1MDApLlxyXG4gICAgICAgICAgICAgIFNlZSB0aGUgYWxsb3dlZCB2YWx1ZXMuIFRoaXMgZGVwZW5kcyBvbiB0aGUgc2VsZWN0ZWQgZGF0YSBiZWNhdXNlIHRoZSByZXNwb25zZSBjb3VsZCBmYWlsIGlmIGNvbnRhaW5zIGEgbG90IG9mIGRhdGFcclxuICAgICAgICAqL1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlQWdlbnRzID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoXHJcbiAgICAgICAgICAnR0VUJyxcclxuICAgICAgICAgIGAvYWdlbnRzYCxcclxuICAgICAgICAgIHtwYXJhbXM6IHBheWxvYWR9LFxyXG4gICAgICAgICAge2FwaUhvc3RJRDogYXBpSG9zdC5pZH1cclxuICAgICAgICApO1xyXG4gICAgICAgIGFnZW50cyA9IFsuLi5hZ2VudHMsIC4uLnJlc3BvbnNlQWdlbnRzLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc107XHJcbiAgICAgICAgcGF5bG9hZC5vZmZzZXQgKz0gcGF5bG9hZC5saW1pdDtcclxuICAgICAgfWNhdGNoKGVycm9yKXtcclxuICAgICAgICBsb2coJ21vbml0b3Jpbmc6ZmV0Y2hBbGxBZ2VudHNGcm9tQXBpSG9zdCcsIGBBcGlJRDogJHthcGlIb3N0LmlkfSwgRXJyb3IgcmVxdWVzdCB3aXRoIG9mZnNldC9saW1pdCAke3BheWxvYWQub2Zmc2V0fS8ke3BheWxvYWQubGltaXR9OiAke2Vycm9yLm1lc3NhZ2UgfHwgZXJyb3J9YCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBhZ2VudHM7XHJcbiAgfWNhdGNoKGVycm9yKXtcclxuICAgIGxvZygnbW9uaXRvcmluZzpmZXRjaEFsbEFnZW50c0Zyb21BcGlIb3N0JywgYEFwaUlEOiAke2FwaUhvc3QuaWR9LiBFcnJvcjogJHtlcnJvci5tZXNzYWdlIHx8IGVycm9yfWApO1xyXG4gICAgdGhyb3cgZXJyb3I7XHJcbiAgfVxyXG59O1xyXG5cclxuLyoqXHJcbiAqIFN0YXJ0IHRoZSBjcm9uIGpvYlxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGpvYk1vbml0b3JpbmdSdW4oY29udGV4dCkge1xyXG4gIC8vIEluaXQgdGhlIG1vbml0b3JpbmcgdmFyaWFibGVzXHJcbiAgaW5pdE1vbml0b3JpbmdDb25maWd1cmF0aW9uKGNvbnRleHQpO1xyXG4gIC8vIENoZWNrIEtpYmFuYSBpbmRleCBhbmQgaWYgaXQgaXMgcHJlcGFyZWQsIHN0YXJ0IHRoZSBpbml0aWFsaXphdGlvbiBvZiBXYXp1aCBBcHAuXHJcbiAgYXdhaXQgY2hlY2tQbHVnaW5QbGF0Zm9ybVN0YXR1cyhjb250ZXh0KTtcclxuICAvLyAvLyBSdW4gdGhlIGNyb24gam9iIG9ubHkgaXQgaXQncyBlbmFibGVkXHJcbiAgaWYgKE1PTklUT1JJTkdfRU5BQkxFRCkge1xyXG4gICAgY3JvblRhc2soY29udGV4dCk7XHJcbiAgICBjcm9uLnNjaGVkdWxlKE1PTklUT1JJTkdfQ1JPTl9GUkVRLCAoKSA9PiBjcm9uVGFzayhjb250ZXh0KSk7XHJcbiAgfVxyXG59XHJcblxyXG4iXX0=