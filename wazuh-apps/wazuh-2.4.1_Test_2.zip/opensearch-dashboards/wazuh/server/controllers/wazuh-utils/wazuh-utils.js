"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhUtilsCtrl = void 0;

var _errorResponse = require("../../lib/error-response");

var _getConfiguration = require("../../lib/get-configuration");

var _readLastLines = require("read-last-lines");

var _updateConfiguration = require("../../lib/update-configuration");

var _jwtDecode = _interopRequireDefault(require("jwt-decode"));

var _constants = require("../../../common/constants");

var _manageHosts = require("../../lib/manage-hosts");

var _cookie = require("../../lib/cookie");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 * Wazuh app - Class for Wazuh-API functions
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
// Require some libraries
const updateConfigurationFile = new _updateConfiguration.UpdateConfigurationFile();

class WazuhUtilsCtrl {
  /**
   * Constructor
   * @param {*} server
   */
  constructor() {
    this.manageHosts = new _manageHosts.ManageHosts();
  }
  /**
   * Returns the wazuh.yml file parsed
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} Configuration File or ErrorResponse
   */


  getConfigurationFile(context, request, response) {
    try {
      const configFile = (0, _getConfiguration.getConfiguration)();
      return response.ok({
        body: {
          statusCode: 200,
          error: 0,
          data: configFile || {}
        }
      });
    } catch (error) {
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3019, 500, response);
    }
  }
  /**
   * Returns the wazuh.yml file in raw
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} Configuration File or ErrorResponse
   */


  async updateConfigurationFile(context, request, response) {
    try {
      // Check if user has administrator role in token
      const token = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-token');

      if (!token) {
        return (0, _errorResponse.ErrorResponse)('No token provided', 401, 401, response);
      }

      ;
      const decodedToken = (0, _jwtDecode.default)(token);

      if (!decodedToken) {
        return (0, _errorResponse.ErrorResponse)('No permissions in token', 401, 401, response);
      }

      ;

      if (!decodedToken.rbac_roles || !decodedToken.rbac_roles.includes(_constants.WAZUH_ROLE_ADMINISTRATOR_ID)) {
        return (0, _errorResponse.ErrorResponse)('No administrator role', 401, 401, response);
      }

      ;
      response; // Check the provided token is valid

      const apiHostID = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-api');

      if (!apiHostID) {
        return (0, _errorResponse.ErrorResponse)('No API id provided', 401, 401, response);
      }

      ;
      const responseTokenIsWorking = await context.wazuh.api.client.asCurrentUser.request('GET', '/', {}, {
        apiHostID
      });

      if (responseTokenIsWorking.status !== 200) {
        return (0, _errorResponse.ErrorResponse)('Token is not valid', 401, 401, response);
      }

      ;
      const result = await updateConfigurationFile.updateConfiguration(request);
      return response.ok({
        body: {
          statusCode: 200,
          error: 0,
          data: result
        }
      });
    } catch (error) {
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3021, 500, response);
    }
  }
  /**
   * Returns Wazuh app logs
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Array<String>} app logs or ErrorResponse
   */


  async getAppLogs(context, request, response) {
    try {
      const lastLogs = await (0, _readLastLines.read)(_constants.WAZUH_DATA_LOGS_RAW_PATH, 50);
      const spliterLog = lastLogs.split('\n');
      return spliterLog && Array.isArray(spliterLog) ? response.ok({
        body: {
          error: 0,
          lastLogs: spliterLog.filter(item => typeof item === 'string' && item.length)
        }
      }) : response.ok({
        error: 0,
        lastLogs: []
      });
    } catch (error) {
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3036, 500, response);
    }
  }

}

exports.WazuhUtilsCtrl = WazuhUtilsCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhenVoLXV0aWxzLnRzIl0sIm5hbWVzIjpbInVwZGF0ZUNvbmZpZ3VyYXRpb25GaWxlIiwiVXBkYXRlQ29uZmlndXJhdGlvbkZpbGUiLCJXYXp1aFV0aWxzQ3RybCIsImNvbnN0cnVjdG9yIiwibWFuYWdlSG9zdHMiLCJNYW5hZ2VIb3N0cyIsImdldENvbmZpZ3VyYXRpb25GaWxlIiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsImNvbmZpZ0ZpbGUiLCJvayIsImJvZHkiLCJzdGF0dXNDb2RlIiwiZXJyb3IiLCJkYXRhIiwibWVzc2FnZSIsInRva2VuIiwiaGVhZGVycyIsImNvb2tpZSIsImRlY29kZWRUb2tlbiIsInJiYWNfcm9sZXMiLCJpbmNsdWRlcyIsIldBWlVIX1JPTEVfQURNSU5JU1RSQVRPUl9JRCIsImFwaUhvc3RJRCIsInJlc3BvbnNlVG9rZW5Jc1dvcmtpbmciLCJ3YXp1aCIsImFwaSIsImNsaWVudCIsImFzQ3VycmVudFVzZXIiLCJzdGF0dXMiLCJyZXN1bHQiLCJ1cGRhdGVDb25maWd1cmF0aW9uIiwiZ2V0QXBwTG9ncyIsImxhc3RMb2dzIiwiV0FaVUhfREFUQV9MT0dTX1JBV19QQVRIIiwic3BsaXRlckxvZyIsInNwbGl0IiwiQXJyYXkiLCJpc0FycmF5IiwiZmlsdGVyIiwiaXRlbSIsImxlbmd0aCJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQWFBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUVBOzs7O0FBckJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQVdBLE1BQU1BLHVCQUF1QixHQUFHLElBQUlDLDRDQUFKLEVBQWhDOztBQUVPLE1BQU1DLGNBQU4sQ0FBcUI7QUFDMUI7QUFDRjtBQUNBO0FBQ0E7QUFDRUMsRUFBQUEsV0FBVyxHQUFHO0FBQ1osU0FBS0MsV0FBTCxHQUFtQixJQUFJQyx3QkFBSixFQUFuQjtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNFQyxFQUFBQSxvQkFBb0IsQ0FBQ0MsT0FBRCxFQUFpQ0MsT0FBakMsRUFBdUVDLFFBQXZFLEVBQXNIO0FBQ3hJLFFBQUk7QUFDRixZQUFNQyxVQUFVLEdBQUcseUNBQW5CO0FBRUEsYUFBT0QsUUFBUSxDQUFDRSxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRTtBQUNKQyxVQUFBQSxVQUFVLEVBQUUsR0FEUjtBQUVKQyxVQUFBQSxLQUFLLEVBQUUsQ0FGSDtBQUdKQyxVQUFBQSxJQUFJLEVBQUVMLFVBQVUsSUFBSTtBQUhoQjtBQURXLE9BQVosQ0FBUDtBQU9ELEtBVkQsQ0FVRSxPQUFPSSxLQUFQLEVBQWM7QUFDZCxhQUFPLGtDQUFjQSxLQUFLLENBQUNFLE9BQU4sSUFBaUJGLEtBQS9CLEVBQXNDLElBQXRDLEVBQTRDLEdBQTVDLEVBQWlETCxRQUFqRCxDQUFQO0FBQ0Q7QUFDRjtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDK0IsUUFBdkJULHVCQUF1QixDQUFDTyxPQUFELEVBQWlDQyxPQUFqQyxFQUF1RUMsUUFBdkUsRUFBc0g7QUFDakosUUFBSTtBQUNGO0FBQ0EsWUFBTVEsS0FBSyxHQUFHLGtDQUFxQlQsT0FBTyxDQUFDVSxPQUFSLENBQWdCQyxNQUFyQyxFQUE0QyxVQUE1QyxDQUFkOztBQUNBLFVBQUcsQ0FBQ0YsS0FBSixFQUFVO0FBQ1IsZUFBTyxrQ0FBYyxtQkFBZCxFQUFtQyxHQUFuQyxFQUF3QyxHQUF4QyxFQUE2Q1IsUUFBN0MsQ0FBUDtBQUNEOztBQUFBO0FBQ0QsWUFBTVcsWUFBWSxHQUFHLHdCQUFVSCxLQUFWLENBQXJCOztBQUNBLFVBQUcsQ0FBQ0csWUFBSixFQUFpQjtBQUNmLGVBQU8sa0NBQWMseUJBQWQsRUFBeUMsR0FBekMsRUFBOEMsR0FBOUMsRUFBbURYLFFBQW5ELENBQVA7QUFDRDs7QUFBQTs7QUFDRCxVQUFHLENBQUNXLFlBQVksQ0FBQ0MsVUFBZCxJQUE0QixDQUFDRCxZQUFZLENBQUNDLFVBQWIsQ0FBd0JDLFFBQXhCLENBQWlDQyxzQ0FBakMsQ0FBaEMsRUFBOEY7QUFDNUYsZUFBTyxrQ0FBYyx1QkFBZCxFQUF1QyxHQUF2QyxFQUE0QyxHQUE1QyxFQUFpRGQsUUFBakQsQ0FBUDtBQUNEOztBQUFBO0FBQUNBLE1BQUFBLFFBQVEsQ0FaUixDQWFGOztBQUNBLFlBQU1lLFNBQVMsR0FBRyxrQ0FBcUJoQixPQUFPLENBQUNVLE9BQVIsQ0FBZ0JDLE1BQXJDLEVBQTRDLFFBQTVDLENBQWxCOztBQUNBLFVBQUksQ0FBQ0ssU0FBTCxFQUFnQjtBQUNkLGVBQU8sa0NBQWMsb0JBQWQsRUFBb0MsR0FBcEMsRUFBeUMsR0FBekMsRUFBOENmLFFBQTlDLENBQVA7QUFDRDs7QUFBQTtBQUNELFlBQU1nQixzQkFBc0IsR0FBRyxNQUFNbEIsT0FBTyxDQUFDbUIsS0FBUixDQUFjQyxHQUFkLENBQWtCQyxNQUFsQixDQUF5QkMsYUFBekIsQ0FBdUNyQixPQUF2QyxDQUErQyxLQUEvQyxFQUFzRCxHQUF0RCxFQUEyRCxFQUEzRCxFQUErRDtBQUFDZ0IsUUFBQUE7QUFBRCxPQUEvRCxDQUFyQzs7QUFDQSxVQUFHQyxzQkFBc0IsQ0FBQ0ssTUFBdkIsS0FBa0MsR0FBckMsRUFBeUM7QUFDdkMsZUFBTyxrQ0FBYyxvQkFBZCxFQUFvQyxHQUFwQyxFQUF5QyxHQUF6QyxFQUE4Q3JCLFFBQTlDLENBQVA7QUFDRDs7QUFBQTtBQUNELFlBQU1zQixNQUFNLEdBQUcsTUFBTS9CLHVCQUF1QixDQUFDZ0MsbUJBQXhCLENBQTRDeEIsT0FBNUMsQ0FBckI7QUFDQSxhQUFPQyxRQUFRLENBQUNFLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFO0FBQ0pDLFVBQUFBLFVBQVUsRUFBRSxHQURSO0FBRUpDLFVBQUFBLEtBQUssRUFBRSxDQUZIO0FBR0pDLFVBQUFBLElBQUksRUFBRWdCO0FBSEY7QUFEVyxPQUFaLENBQVA7QUFPRCxLQTlCRCxDQThCRSxPQUFPakIsS0FBUCxFQUFjO0FBQ2QsYUFBTyxrQ0FBY0EsS0FBSyxDQUFDRSxPQUFOLElBQWlCRixLQUEvQixFQUFzQyxJQUF0QyxFQUE0QyxHQUE1QyxFQUFpREwsUUFBakQsQ0FBUDtBQUNEO0FBQ0Y7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ2tCLFFBQVZ3QixVQUFVLENBQUMxQixPQUFELEVBQWlDQyxPQUFqQyxFQUF1RUMsUUFBdkUsRUFBc0g7QUFDcEksUUFBSTtBQUNGLFlBQU15QixRQUFRLEdBQUcsTUFBTSx5QkFDckJDLG1DQURxQixFQUVyQixFQUZxQixDQUF2QjtBQUlBLFlBQU1DLFVBQVUsR0FBR0YsUUFBUSxDQUFDRyxLQUFULENBQWUsSUFBZixDQUFuQjtBQUNBLGFBQU9ELFVBQVUsSUFBSUUsS0FBSyxDQUFDQyxPQUFOLENBQWNILFVBQWQsQ0FBZCxHQUNIM0IsUUFBUSxDQUFDRSxFQUFULENBQVk7QUFDWkMsUUFBQUEsSUFBSSxFQUFFO0FBQ0pFLFVBQUFBLEtBQUssRUFBRSxDQURIO0FBRUpvQixVQUFBQSxRQUFRLEVBQUVFLFVBQVUsQ0FBQ0ksTUFBWCxDQUNSQyxJQUFJLElBQUksT0FBT0EsSUFBUCxLQUFnQixRQUFoQixJQUE0QkEsSUFBSSxDQUFDQyxNQURqQztBQUZOO0FBRE0sT0FBWixDQURHLEdBU0hqQyxRQUFRLENBQUNFLEVBQVQsQ0FBWTtBQUFFRyxRQUFBQSxLQUFLLEVBQUUsQ0FBVDtBQUFZb0IsUUFBQUEsUUFBUSxFQUFFO0FBQXRCLE9BQVosQ0FUSjtBQVVELEtBaEJELENBZ0JFLE9BQU9wQixLQUFQLEVBQWM7QUFDZCxhQUFPLGtDQUFjQSxLQUFLLENBQUNFLE9BQU4sSUFBaUJGLEtBQS9CLEVBQXNDLElBQXRDLEVBQTRDLEdBQTVDLEVBQWlETCxRQUFqRCxDQUFQO0FBQ0Q7QUFDRjs7QUF0R3lCIiwic291cmNlc0NvbnRlbnQiOlsiLypcclxuICogV2F6dWggYXBwIC0gQ2xhc3MgZm9yIFdhenVoLUFQSSBmdW5jdGlvbnNcclxuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cclxuICpcclxuICogVGhpcyBwcm9ncmFtIGlzIGZyZWUgc29mdHdhcmU7IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcclxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcclxuICogdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbjsgZWl0aGVyIHZlcnNpb24gMiBvZiB0aGUgTGljZW5zZSwgb3JcclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cclxuICpcclxuICogRmluZCBtb3JlIGluZm9ybWF0aW9uIGFib3V0IHRoaXMgb24gdGhlIExJQ0VOU0UgZmlsZS5cclxuICovXHJcblxyXG4vLyBSZXF1aXJlIHNvbWUgbGlicmFyaWVzXHJcbmltcG9ydCB7IEVycm9yUmVzcG9uc2UgfSBmcm9tICcuLi8uLi9saWIvZXJyb3ItcmVzcG9uc2UnO1xyXG5pbXBvcnQgeyBnZXRDb25maWd1cmF0aW9uIH0gZnJvbSAnLi4vLi4vbGliL2dldC1jb25maWd1cmF0aW9uJztcclxuaW1wb3J0IHsgcmVhZCB9IGZyb20gJ3JlYWQtbGFzdC1saW5lcyc7XHJcbmltcG9ydCB7IFVwZGF0ZUNvbmZpZ3VyYXRpb25GaWxlIH0gZnJvbSAnLi4vLi4vbGliL3VwZGF0ZS1jb25maWd1cmF0aW9uJztcclxuaW1wb3J0IGp3dERlY29kZSBmcm9tICdqd3QtZGVjb2RlJztcclxuaW1wb3J0IHsgV0FaVUhfUk9MRV9BRE1JTklTVFJBVE9SX0lELCBXQVpVSF9EQVRBX0xPR1NfUkFXX1BBVEgsIFdBWlVIX1VJX0xPR1NfUkFXX1BBVEggfSBmcm9tICcuLi8uLi8uLi9jb21tb24vY29uc3RhbnRzJztcclxuaW1wb3J0IHsgTWFuYWdlSG9zdHMgfSBmcm9tICcuLi8uLi9saWIvbWFuYWdlLWhvc3RzJztcclxuaW1wb3J0IHsgT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5IH0gZnJvbSAnc3JjL2NvcmUvc2VydmVyJztcclxuaW1wb3J0IHsgZ2V0Q29va2llVmFsdWVCeU5hbWUgfSBmcm9tICcuLi8uLi9saWIvY29va2llJztcclxuXHJcbmNvbnN0IHVwZGF0ZUNvbmZpZ3VyYXRpb25GaWxlID0gbmV3IFVwZGF0ZUNvbmZpZ3VyYXRpb25GaWxlKCk7XHJcblxyXG5leHBvcnQgY2xhc3MgV2F6dWhVdGlsc0N0cmwge1xyXG4gIC8qKlxyXG4gICAqIENvbnN0cnVjdG9yXHJcbiAgICogQHBhcmFtIHsqfSBzZXJ2ZXJcclxuICAgKi9cclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICAgIHRoaXMubWFuYWdlSG9zdHMgPSBuZXcgTWFuYWdlSG9zdHMoKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldHVybnMgdGhlIHdhenVoLnltbCBmaWxlIHBhcnNlZFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcclxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSBDb25maWd1cmF0aW9uIEZpbGUgb3IgRXJyb3JSZXNwb25zZVxyXG4gICAqL1xyXG4gIGdldENvbmZpZ3VyYXRpb25GaWxlKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnkpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGNvbmZpZ0ZpbGUgPSBnZXRDb25maWd1cmF0aW9uKCk7XHJcblxyXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgIGJvZHk6IHtcclxuICAgICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcclxuICAgICAgICAgIGVycm9yOiAwLFxyXG4gICAgICAgICAgZGF0YTogY29uZmlnRmlsZSB8fCB7fVxyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCAzMDE5LCA1MDAsIHJlc3BvbnNlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJldHVybnMgdGhlIHdhenVoLnltbCBmaWxlIGluIHJhd1xyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcclxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSBDb25maWd1cmF0aW9uIEZpbGUgb3IgRXJyb3JSZXNwb25zZVxyXG4gICAqL1xyXG4gIGFzeW5jIHVwZGF0ZUNvbmZpZ3VyYXRpb25GaWxlKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnkpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIC8vIENoZWNrIGlmIHVzZXIgaGFzIGFkbWluaXN0cmF0b3Igcm9sZSBpbiB0b2tlblxyXG4gICAgICBjb25zdCB0b2tlbiA9IGdldENvb2tpZVZhbHVlQnlOYW1lKHJlcXVlc3QuaGVhZGVycy5jb29raWUsJ3d6LXRva2VuJyk7XHJcbiAgICAgIGlmKCF0b2tlbil7XHJcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoJ05vIHRva2VuIHByb3ZpZGVkJywgNDAxLCA0MDEsIHJlc3BvbnNlKTtcclxuICAgICAgfTtcclxuICAgICAgY29uc3QgZGVjb2RlZFRva2VuID0gand0RGVjb2RlKHRva2VuKTtcclxuICAgICAgaWYoIWRlY29kZWRUb2tlbil7XHJcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoJ05vIHBlcm1pc3Npb25zIGluIHRva2VuJywgNDAxLCA0MDEsIHJlc3BvbnNlKTtcclxuICAgICAgfTtcclxuICAgICAgaWYoIWRlY29kZWRUb2tlbi5yYmFjX3JvbGVzIHx8ICFkZWNvZGVkVG9rZW4ucmJhY19yb2xlcy5pbmNsdWRlcyhXQVpVSF9ST0xFX0FETUlOSVNUUkFUT1JfSUQpKXtcclxuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZSgnTm8gYWRtaW5pc3RyYXRvciByb2xlJywgNDAxLCA0MDEsIHJlc3BvbnNlKTtcclxuICAgICAgfTtyZXNwb25zZVxyXG4gICAgICAvLyBDaGVjayB0aGUgcHJvdmlkZWQgdG9rZW4gaXMgdmFsaWRcclxuICAgICAgY29uc3QgYXBpSG9zdElEID0gZ2V0Q29va2llVmFsdWVCeU5hbWUocmVxdWVzdC5oZWFkZXJzLmNvb2tpZSwnd3otYXBpJyk7XHJcbiAgICAgIGlmKCAhYXBpSG9zdElEICl7XHJcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoJ05vIEFQSSBpZCBwcm92aWRlZCcsIDQwMSwgNDAxLCByZXNwb25zZSk7XHJcbiAgICAgIH07XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlVG9rZW5Jc1dvcmtpbmcgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KCdHRVQnLCAnLycsIHt9LCB7YXBpSG9zdElEfSk7XHJcbiAgICAgIGlmKHJlc3BvbnNlVG9rZW5Jc1dvcmtpbmcuc3RhdHVzICE9PSAyMDApe1xyXG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdUb2tlbiBpcyBub3QgdmFsaWQnLCA0MDEsIDQwMSwgcmVzcG9uc2UpO1xyXG4gICAgICB9O1xyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB1cGRhdGVDb25maWd1cmF0aW9uRmlsZS51cGRhdGVDb25maWd1cmF0aW9uKHJlcXVlc3QpO1xyXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgIGJvZHk6IHtcclxuICAgICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcclxuICAgICAgICAgIGVycm9yOiAwLFxyXG4gICAgICAgICAgZGF0YTogcmVzdWx0XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDMwMjEsIDUwMCwgcmVzcG9uc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUmV0dXJucyBXYXp1aCBhcHAgbG9nc1xyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcclxuICAgKiBAcmV0dXJucyB7QXJyYXk8U3RyaW5nPn0gYXBwIGxvZ3Mgb3IgRXJyb3JSZXNwb25zZVxyXG4gICAqL1xyXG4gIGFzeW5jIGdldEFwcExvZ3MoY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgbGFzdExvZ3MgPSBhd2FpdCByZWFkKFxyXG4gICAgICAgIFdBWlVIX0RBVEFfTE9HU19SQVdfUEFUSCxcclxuICAgICAgICA1MFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBzcGxpdGVyTG9nID0gbGFzdExvZ3Muc3BsaXQoJ1xcbicpO1xyXG4gICAgICByZXR1cm4gc3BsaXRlckxvZyAmJiBBcnJheS5pc0FycmF5KHNwbGl0ZXJMb2cpXHJcbiAgICAgICAgPyByZXNwb25zZS5vayh7XHJcbiAgICAgICAgICBib2R5OiB7XHJcbiAgICAgICAgICAgIGVycm9yOiAwLFxyXG4gICAgICAgICAgICBsYXN0TG9nczogc3BsaXRlckxvZy5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgaXRlbSA9PiB0eXBlb2YgaXRlbSA9PT0gJ3N0cmluZycgJiYgaXRlbS5sZW5ndGhcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgOiByZXNwb25zZS5vayh7IGVycm9yOiAwLCBsYXN0TG9nczogW10gfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCAzMDM2LCA1MDAsIHJlc3BvbnNlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxufVxyXG4iXX0=