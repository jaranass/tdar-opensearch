"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhHostsCtrl = void 0;

var _constants = require("../../common/constants");

var _cacheApiUserHasRunAs = require("../lib/cache-api-user-has-run-as");

var _errorResponse = require("../lib/error-response");

var _logger = require("../lib/logger");

var _manageHosts = require("../lib/manage-hosts");

var _updateRegistry = require("../lib/update-registry");

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class WazuhHostsCtrl {
  constructor() {
    _defineProperty(this, "manageHosts", void 0);

    _defineProperty(this, "updateRegistry", void 0);

    this.manageHosts = new _manageHosts.ManageHosts();
    this.updateRegistry = new _updateRegistry.UpdateRegistry();
  }
  /**
   * This get all hosts entries in the wazuh.yml and the related info in the wazuh-registry.json
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * API entries or ErrorResponse
   */


  async getHostsEntries(context, request, response) {
    try {
      const removePassword = true;
      const hosts = await this.manageHosts.getHosts();
      const registry = await this.updateRegistry.getHosts();
      const result = await this.joinHostRegistry(hosts, registry, removePassword);
      return response.ok({
        body: result
      });
    } catch (error) {
      if (error && error.message && ['ENOENT: no such file or directory', _constants.WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH].every(text => error.message.includes(text))) {
        return response.badRequest({
          body: {
            message: `Error getting the hosts entries: The \'${_constants.WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH}\' directory could not exist in your ${_constants.PLUGIN_PLATFORM_NAME} installation.
            If this doesn't exist, create it and give the permissions 'sudo mkdir ${_constants.WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH};sudo chown -R ${_constants.PLUGIN_PLATFORM_INSTALLATION_USER}:${_constants.PLUGIN_PLATFORM_INSTALLATION_USER_GROUP} ${_constants.WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH}'. After, restart the ${_constants.PLUGIN_PLATFORM_NAME} service.`
          }
        });
      }

      (0, _logger.log)('wazuh-hosts:getHostsEntries', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 2001, 500, response);
    }
  }
  /**
   * Joins the hosts with the related information in the registry
   * @param {Object} hosts
   * @param {Object} registry
   * @param {Boolean} removePassword
   */


  async joinHostRegistry(hosts, registry, removePassword = true) {
    try {
      if (!Array.isArray(hosts)) {
        throw new Error('Hosts configuration error in wazuh.yml');
      }

      return await Promise.all(hosts.map(async h => {
        const id = Object.keys(h)[0];
        const api = Object.assign(h[id], {
          id: id
        });
        const host = Object.assign(api, registry[id]); // Add to run_as from API user. Use the cached value or get it doing a request

        host.allow_run_as = await _cacheApiUserHasRunAs.APIUserAllowRunAs.check(id);

        if (removePassword) {
          delete host.password;
          delete host.token;
        }

        ;
        return host;
      }));
    } catch (error) {
      throw new Error(error);
    }
  }
  /**
   * This update an API hostname
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * Status response or ErrorResponse
   */


  async updateClusterInfo(context, request, response) {
    try {
      const {
        id
      } = request.params;
      const {
        cluster_info
      } = request.body;
      await this.updateRegistry.updateClusterInfo(id, cluster_info);
      (0, _logger.log)('wazuh-hosts:updateClusterInfo', `API entry ${id} hostname updated`, 'debug');
      return response.ok({
        body: {
          statusCode: 200,
          message: 'ok'
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-hosts:updateClusterInfo', error.message || error);
      return (0, _errorResponse.ErrorResponse)(`Could not update data in wazuh-registry.json due to ${error.message || error}`, 2012, 500, response);
    }
  }
  /**
   * Remove the orphan host entries in the registry
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   */


  async removeOrphanEntries(context, request, response) {
    try {
      const {
        entries
      } = request.body;
      (0, _logger.log)('wazuh-hosts:cleanRegistry', 'Cleaning registry', 'debug');
      await this.updateRegistry.removeOrphanEntries(entries);
      return response.ok({
        body: {
          statusCode: 200,
          message: 'ok'
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-hosts:cleanRegistry', error.message || error);
      return (0, _errorResponse.ErrorResponse)(`Could not clean entries in the wazuh-registry.json due to ${error.message || error}`, 2013, 500, response);
    }
  }

}

exports.WazuhHostsCtrl = WazuhHostsCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhenVoLWhvc3RzLnRzIl0sIm5hbWVzIjpbIldhenVoSG9zdHNDdHJsIiwiY29uc3RydWN0b3IiLCJtYW5hZ2VIb3N0cyIsIk1hbmFnZUhvc3RzIiwidXBkYXRlUmVnaXN0cnkiLCJVcGRhdGVSZWdpc3RyeSIsImdldEhvc3RzRW50cmllcyIsImNvbnRleHQiLCJyZXF1ZXN0IiwicmVzcG9uc2UiLCJyZW1vdmVQYXNzd29yZCIsImhvc3RzIiwiZ2V0SG9zdHMiLCJyZWdpc3RyeSIsInJlc3VsdCIsImpvaW5Ib3N0UmVnaXN0cnkiLCJvayIsImJvZHkiLCJlcnJvciIsIm1lc3NhZ2UiLCJXQVpVSF9EQVRBX1BMVUdJTl9QTEFURk9STV9CQVNFX0FCU09MVVRFX1BBVEgiLCJldmVyeSIsInRleHQiLCJpbmNsdWRlcyIsImJhZFJlcXVlc3QiLCJQTFVHSU5fUExBVEZPUk1fTkFNRSIsIlBMVUdJTl9QTEFURk9STV9JTlNUQUxMQVRJT05fVVNFUiIsIlBMVUdJTl9QTEFURk9STV9JTlNUQUxMQVRJT05fVVNFUl9HUk9VUCIsIkFycmF5IiwiaXNBcnJheSIsIkVycm9yIiwiUHJvbWlzZSIsImFsbCIsIm1hcCIsImgiLCJpZCIsIk9iamVjdCIsImtleXMiLCJhcGkiLCJhc3NpZ24iLCJob3N0IiwiYWxsb3dfcnVuX2FzIiwiQVBJVXNlckFsbG93UnVuQXMiLCJjaGVjayIsInBhc3N3b3JkIiwidG9rZW4iLCJ1cGRhdGVDbHVzdGVySW5mbyIsInBhcmFtcyIsImNsdXN0ZXJfaW5mbyIsInN0YXR1c0NvZGUiLCJyZW1vdmVPcnBoYW5FbnRyaWVzIiwiZW50cmllcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQWlCQTs7QUFNQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7OztBQUVPLE1BQU1BLGNBQU4sQ0FBcUI7QUFHMUJDLEVBQUFBLFdBQVcsR0FBRztBQUFBOztBQUFBOztBQUNaLFNBQUtDLFdBQUwsR0FBbUIsSUFBSUMsd0JBQUosRUFBbkI7QUFDQSxTQUFLQyxjQUFMLEdBQXNCLElBQUlDLDhCQUFKLEVBQXRCO0FBQ0Q7QUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ3VCLFFBQWZDLGVBQWUsQ0FBQ0MsT0FBRCxFQUFpQ0MsT0FBakMsRUFBdUVDLFFBQXZFLEVBQXNIO0FBQ3pJLFFBQUk7QUFDRixZQUFNQyxjQUFjLEdBQUcsSUFBdkI7QUFDQSxZQUFNQyxLQUFLLEdBQUcsTUFBTSxLQUFLVCxXQUFMLENBQWlCVSxRQUFqQixFQUFwQjtBQUNBLFlBQU1DLFFBQVEsR0FBRyxNQUFNLEtBQUtULGNBQUwsQ0FBb0JRLFFBQXBCLEVBQXZCO0FBQ0EsWUFBTUUsTUFBTSxHQUFHLE1BQU0sS0FBS0MsZ0JBQUwsQ0FBc0JKLEtBQXRCLEVBQTZCRSxRQUE3QixFQUF1Q0gsY0FBdkMsQ0FBckI7QUFDQSxhQUFPRCxRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFSDtBQURXLE9BQVosQ0FBUDtBQUdELEtBUkQsQ0FRRSxPQUFPSSxLQUFQLEVBQWM7QUFDZCxVQUFHQSxLQUFLLElBQUlBLEtBQUssQ0FBQ0MsT0FBZixJQUEwQixDQUFDLG1DQUFELEVBQXNDQyx3REFBdEMsRUFBcUZDLEtBQXJGLENBQTJGQyxJQUFJLElBQUlKLEtBQUssQ0FBQ0MsT0FBTixDQUFjSSxRQUFkLENBQXVCRCxJQUF2QixDQUFuRyxDQUE3QixFQUE4SjtBQUM1SixlQUFPYixRQUFRLENBQUNlLFVBQVQsQ0FBb0I7QUFDekJQLFVBQUFBLElBQUksRUFBRTtBQUNKRSxZQUFBQSxPQUFPLEVBQUcsMENBQXlDQyx3REFBOEMsd0NBQXVDSywrQkFBcUI7QUFDekssb0ZBQW9GTCx3REFBOEMsa0JBQWlCTSw0Q0FBa0MsSUFBR0Msa0RBQXdDLElBQUdQLHdEQUE4Qyx5QkFBd0JLLCtCQUFxQjtBQUY5UztBQURtQixTQUFwQixDQUFQO0FBTUQ7O0FBQ0QsdUJBQUksNkJBQUosRUFBbUNQLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBcEQ7QUFDQSxhQUFPLGtDQUFjQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQS9CLEVBQXNDLElBQXRDLEVBQTRDLEdBQTVDLEVBQWlEVCxRQUFqRCxDQUFQO0FBQ0Q7QUFDRjtBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ3dCLFFBQWhCTSxnQkFBZ0IsQ0FBQ0osS0FBRCxFQUFhRSxRQUFiLEVBQTRCSCxjQUF1QixHQUFHLElBQXRELEVBQTREO0FBQ2hGLFFBQUk7QUFDRixVQUFJLENBQUNrQixLQUFLLENBQUNDLE9BQU4sQ0FBY2xCLEtBQWQsQ0FBTCxFQUEyQjtBQUN6QixjQUFNLElBQUltQixLQUFKLENBQVUsd0NBQVYsQ0FBTjtBQUNEOztBQUVELGFBQU8sTUFBTUMsT0FBTyxDQUFDQyxHQUFSLENBQVlyQixLQUFLLENBQUNzQixHQUFOLENBQVUsTUFBTUMsQ0FBTixJQUFXO0FBQzVDLGNBQU1DLEVBQUUsR0FBR0MsTUFBTSxDQUFDQyxJQUFQLENBQVlILENBQVosRUFBZSxDQUFmLENBQVg7QUFDQSxjQUFNSSxHQUFHLEdBQUdGLE1BQU0sQ0FBQ0csTUFBUCxDQUFjTCxDQUFDLENBQUNDLEVBQUQsQ0FBZixFQUFxQjtBQUFFQSxVQUFBQSxFQUFFLEVBQUVBO0FBQU4sU0FBckIsQ0FBWjtBQUNBLGNBQU1LLElBQUksR0FBR0osTUFBTSxDQUFDRyxNQUFQLENBQWNELEdBQWQsRUFBbUJ6QixRQUFRLENBQUNzQixFQUFELENBQTNCLENBQWIsQ0FINEMsQ0FJNUM7O0FBQ0FLLFFBQUFBLElBQUksQ0FBQ0MsWUFBTCxHQUFvQixNQUFNQyx3Q0FBa0JDLEtBQWxCLENBQXdCUixFQUF4QixDQUExQjs7QUFDQSxZQUFJekIsY0FBSixFQUFvQjtBQUNsQixpQkFBTzhCLElBQUksQ0FBQ0ksUUFBWjtBQUNBLGlCQUFPSixJQUFJLENBQUNLLEtBQVo7QUFDRDs7QUFBQTtBQUNELGVBQU9MLElBQVA7QUFDRCxPQVh3QixDQUFaLENBQWI7QUFZRCxLQWpCRCxDQWlCRSxPQUFPdEIsS0FBUCxFQUFjO0FBQ2QsWUFBTSxJQUFJWSxLQUFKLENBQVVaLEtBQVYsQ0FBTjtBQUNEO0FBQ0Y7QUFDRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ3lCLFFBQWpCNEIsaUJBQWlCLENBQUN2QyxPQUFELEVBQWlDQyxPQUFqQyxFQUF1RUMsUUFBdkUsRUFBc0g7QUFDM0ksUUFBSTtBQUNGLFlBQU07QUFBRTBCLFFBQUFBO0FBQUYsVUFBUzNCLE9BQU8sQ0FBQ3VDLE1BQXZCO0FBQ0EsWUFBTTtBQUFFQyxRQUFBQTtBQUFGLFVBQW1CeEMsT0FBTyxDQUFDUyxJQUFqQztBQUNBLFlBQU0sS0FBS2IsY0FBTCxDQUFvQjBDLGlCQUFwQixDQUFzQ1gsRUFBdEMsRUFBMENhLFlBQTFDLENBQU47QUFDQSx1QkFDRSwrQkFERixFQUVHLGFBQVliLEVBQUcsbUJBRmxCLEVBR0UsT0FIRjtBQUtBLGFBQU8xQixRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFO0FBQUVnQyxVQUFBQSxVQUFVLEVBQUUsR0FBZDtBQUFtQjlCLFVBQUFBLE9BQU8sRUFBRTtBQUE1QjtBQURXLE9BQVosQ0FBUDtBQUdELEtBWkQsQ0FZRSxPQUFPRCxLQUFQLEVBQWM7QUFDZCx1QkFBSSwrQkFBSixFQUFxQ0EsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUF0RDtBQUNBLGFBQU8sa0NBQ0osdURBQXNEQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQU0sRUFEekUsRUFFTCxJQUZLLEVBR0wsR0FISyxFQUlMVCxRQUpLLENBQVA7QUFNRDtBQUNGO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDMkIsUUFBbkJ5QyxtQkFBbUIsQ0FBQzNDLE9BQUQsRUFBaUNDLE9BQWpDLEVBQXVFQyxRQUF2RSxFQUFzSDtBQUM3SSxRQUFJO0FBQ0YsWUFBTTtBQUFFMEMsUUFBQUE7QUFBRixVQUFjM0MsT0FBTyxDQUFDUyxJQUE1QjtBQUNBLHVCQUFJLDJCQUFKLEVBQWlDLG1CQUFqQyxFQUFzRCxPQUF0RDtBQUNBLFlBQU0sS0FBS2IsY0FBTCxDQUFvQjhDLG1CQUFwQixDQUF3Q0MsT0FBeEMsQ0FBTjtBQUNBLGFBQU8xQyxRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFO0FBQUVnQyxVQUFBQSxVQUFVLEVBQUUsR0FBZDtBQUFtQjlCLFVBQUFBLE9BQU8sRUFBRTtBQUE1QjtBQURXLE9BQVosQ0FBUDtBQUdELEtBUEQsQ0FPRSxPQUFPRCxLQUFQLEVBQWM7QUFDZCx1QkFBSSwyQkFBSixFQUFpQ0EsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUFsRDtBQUNBLGFBQU8sa0NBQ0osNkRBQTREQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQU0sRUFEL0UsRUFFTCxJQUZLLEVBR0wsR0FISyxFQUlMVCxRQUpLLENBQVA7QUFNRDtBQUNGOztBQXhIeUIiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxyXG4gKiBXYXp1aCBhcHAgLSBDbGFzcyBmb3IgV2F6dWgtQVBJIGZ1bmN0aW9uc1xyXG4gKiBDb3B5cmlnaHQgKEMpIDIwMTUtMjAyMiBXYXp1aCwgSW5jLlxyXG4gKlxyXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxyXG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxyXG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxyXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxyXG4gKlxyXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxyXG4gKi9cclxuXHJcbmltcG9ydCB7XHJcbiAgT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxyXG4gIFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcclxuICBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSxcclxufSBmcm9tICdzcmMvY29yZS9zZXJ2ZXInO1xyXG5pbXBvcnQge1xyXG4gIFBMVUdJTl9QTEFURk9STV9JTlNUQUxMQVRJT05fVVNFUixcclxuICBQTFVHSU5fUExBVEZPUk1fSU5TVEFMTEFUSU9OX1VTRVJfR1JPVVAsXHJcbiAgUExVR0lOX1BMQVRGT1JNX05BTUUsXHJcbiAgV0FaVUhfREFUQV9QTFVHSU5fUExBVEZPUk1fQkFTRV9BQlNPTFVURV9QQVRILFxyXG59IGZyb20gJy4uLy4uL2NvbW1vbi9jb25zdGFudHMnO1xyXG5pbXBvcnQgeyBBUElVc2VyQWxsb3dSdW5BcyB9IGZyb20gJy4uL2xpYi9jYWNoZS1hcGktdXNlci1oYXMtcnVuLWFzJztcclxuaW1wb3J0IHsgRXJyb3JSZXNwb25zZSB9IGZyb20gJy4uL2xpYi9lcnJvci1yZXNwb25zZSc7XHJcbmltcG9ydCB7IGxvZyB9IGZyb20gJy4uL2xpYi9sb2dnZXInO1xyXG5pbXBvcnQgeyBNYW5hZ2VIb3N0cyB9IGZyb20gJy4uL2xpYi9tYW5hZ2UtaG9zdHMnO1xyXG5pbXBvcnQgeyBVcGRhdGVSZWdpc3RyeSB9IGZyb20gJy4uL2xpYi91cGRhdGUtcmVnaXN0cnknO1xyXG5cclxuZXhwb3J0IGNsYXNzIFdhenVoSG9zdHNDdHJsIHtcclxuICBtYW5hZ2VIb3N0czogTWFuYWdlSG9zdHM7XHJcbiAgdXBkYXRlUmVnaXN0cnk6IFVwZGF0ZVJlZ2lzdHJ5O1xyXG4gIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgdGhpcy5tYW5hZ2VIb3N0cyA9IG5ldyBNYW5hZ2VIb3N0cygpO1xyXG4gICAgdGhpcy51cGRhdGVSZWdpc3RyeSA9IG5ldyBVcGRhdGVSZWdpc3RyeSgpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogVGhpcyBnZXQgYWxsIGhvc3RzIGVudHJpZXMgaW4gdGhlIHdhenVoLnltbCBhbmQgdGhlIHJlbGF0ZWQgaW5mbyBpbiB0aGUgd2F6dWgtcmVnaXN0cnkuanNvblxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcclxuICAgKiBBUEkgZW50cmllcyBvciBFcnJvclJlc3BvbnNlXHJcbiAgICovXHJcbiAgYXN5bmMgZ2V0SG9zdHNFbnRyaWVzKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnkpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlbW92ZVBhc3N3b3JkID0gdHJ1ZTtcclxuICAgICAgY29uc3QgaG9zdHMgPSBhd2FpdCB0aGlzLm1hbmFnZUhvc3RzLmdldEhvc3RzKCk7XHJcbiAgICAgIGNvbnN0IHJlZ2lzdHJ5ID0gYXdhaXQgdGhpcy51cGRhdGVSZWdpc3RyeS5nZXRIb3N0cygpO1xyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLmpvaW5Ib3N0UmVnaXN0cnkoaG9zdHMsIHJlZ2lzdHJ5LCByZW1vdmVQYXNzd29yZCk7XHJcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XHJcbiAgICAgICAgYm9keTogcmVzdWx0XHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgaWYoZXJyb3IgJiYgZXJyb3IubWVzc2FnZSAmJiBbJ0VOT0VOVDogbm8gc3VjaCBmaWxlIG9yIGRpcmVjdG9yeScsIFdBWlVIX0RBVEFfUExVR0lOX1BMQVRGT1JNX0JBU0VfQUJTT0xVVEVfUEFUSF0uZXZlcnkodGV4dCA9PiBlcnJvci5tZXNzYWdlLmluY2x1ZGVzKHRleHQpKSl7XHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmJhZFJlcXVlc3Qoe1xyXG4gICAgICAgICAgYm9keToge1xyXG4gICAgICAgICAgICBtZXNzYWdlOiBgRXJyb3IgZ2V0dGluZyB0aGUgaG9zdHMgZW50cmllczogVGhlIFxcJyR7V0FaVUhfREFUQV9QTFVHSU5fUExBVEZPUk1fQkFTRV9BQlNPTFVURV9QQVRIfVxcJyBkaXJlY3RvcnkgY291bGQgbm90IGV4aXN0IGluIHlvdXIgJHtQTFVHSU5fUExBVEZPUk1fTkFNRX0gaW5zdGFsbGF0aW9uLlxyXG4gICAgICAgICAgICBJZiB0aGlzIGRvZXNuJ3QgZXhpc3QsIGNyZWF0ZSBpdCBhbmQgZ2l2ZSB0aGUgcGVybWlzc2lvbnMgJ3N1ZG8gbWtkaXIgJHtXQVpVSF9EQVRBX1BMVUdJTl9QTEFURk9STV9CQVNFX0FCU09MVVRFX1BBVEh9O3N1ZG8gY2hvd24gLVIgJHtQTFVHSU5fUExBVEZPUk1fSU5TVEFMTEFUSU9OX1VTRVJ9OiR7UExVR0lOX1BMQVRGT1JNX0lOU1RBTExBVElPTl9VU0VSX0dST1VQfSAke1dBWlVIX0RBVEFfUExVR0lOX1BMQVRGT1JNX0JBU0VfQUJTT0xVVEVfUEFUSH0nLiBBZnRlciwgcmVzdGFydCB0aGUgJHtQTFVHSU5fUExBVEZPUk1fTkFNRX0gc2VydmljZS5gXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgICBsb2coJ3dhenVoLWhvc3RzOmdldEhvc3RzRW50cmllcycsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xyXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCAyMDAxLCA1MDAsIHJlc3BvbnNlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEpvaW5zIHRoZSBob3N0cyB3aXRoIHRoZSByZWxhdGVkIGluZm9ybWF0aW9uIGluIHRoZSByZWdpc3RyeVxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBob3N0c1xyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZWdpc3RyeVxyXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gcmVtb3ZlUGFzc3dvcmRcclxuICAgKi9cclxuICBhc3luYyBqb2luSG9zdFJlZ2lzdHJ5KGhvc3RzOiBhbnksIHJlZ2lzdHJ5OiBhbnksIHJlbW92ZVBhc3N3b3JkOiBib29sZWFuID0gdHJ1ZSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKCFBcnJheS5pc0FycmF5KGhvc3RzKSkge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignSG9zdHMgY29uZmlndXJhdGlvbiBlcnJvciBpbiB3YXp1aC55bWwnKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIGF3YWl0IFByb21pc2UuYWxsKGhvc3RzLm1hcChhc3luYyBoID0+IHtcclxuICAgICAgICBjb25zdCBpZCA9IE9iamVjdC5rZXlzKGgpWzBdO1xyXG4gICAgICAgIGNvbnN0IGFwaSA9IE9iamVjdC5hc3NpZ24oaFtpZF0sIHsgaWQ6IGlkIH0pO1xyXG4gICAgICAgIGNvbnN0IGhvc3QgPSBPYmplY3QuYXNzaWduKGFwaSwgcmVnaXN0cnlbaWRdKTtcclxuICAgICAgICAvLyBBZGQgdG8gcnVuX2FzIGZyb20gQVBJIHVzZXIuIFVzZSB0aGUgY2FjaGVkIHZhbHVlIG9yIGdldCBpdCBkb2luZyBhIHJlcXVlc3RcclxuICAgICAgICBob3N0LmFsbG93X3J1bl9hcyA9IGF3YWl0IEFQSVVzZXJBbGxvd1J1bkFzLmNoZWNrKGlkKTtcclxuICAgICAgICBpZiAocmVtb3ZlUGFzc3dvcmQpIHtcclxuICAgICAgICAgIGRlbGV0ZSBob3N0LnBhc3N3b3JkO1xyXG4gICAgICAgICAgZGVsZXRlIGhvc3QudG9rZW47XHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gaG9zdDtcclxuICAgICAgfSkpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKGVycm9yKTtcclxuICAgIH1cclxuICB9XHJcbiAgLyoqXHJcbiAgICogVGhpcyB1cGRhdGUgYW4gQVBJIGhvc3RuYW1lXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcclxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxyXG4gICAqIFN0YXR1cyByZXNwb25zZSBvciBFcnJvclJlc3BvbnNlXHJcbiAgICovXHJcbiAgYXN5bmMgdXBkYXRlQ2x1c3RlckluZm8oY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgeyBpZCB9ID0gcmVxdWVzdC5wYXJhbXM7XHJcbiAgICAgIGNvbnN0IHsgY2x1c3Rlcl9pbmZvIH0gPSByZXF1ZXN0LmJvZHk7XHJcbiAgICAgIGF3YWl0IHRoaXMudXBkYXRlUmVnaXN0cnkudXBkYXRlQ2x1c3RlckluZm8oaWQsIGNsdXN0ZXJfaW5mbyk7XHJcbiAgICAgIGxvZyhcclxuICAgICAgICAnd2F6dWgtaG9zdHM6dXBkYXRlQ2x1c3RlckluZm8nLFxyXG4gICAgICAgIGBBUEkgZW50cnkgJHtpZH0gaG9zdG5hbWUgdXBkYXRlZGAsXHJcbiAgICAgICAgJ2RlYnVnJ1xyXG4gICAgICApO1xyXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xyXG4gICAgICAgIGJvZHk6IHsgc3RhdHVzQ29kZTogMjAwLCBtZXNzYWdlOiAnb2snIH1cclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBsb2coJ3dhenVoLWhvc3RzOnVwZGF0ZUNsdXN0ZXJJbmZvJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxyXG4gICAgICAgIGBDb3VsZCBub3QgdXBkYXRlIGRhdGEgaW4gd2F6dWgtcmVnaXN0cnkuanNvbiBkdWUgdG8gJHtlcnJvci5tZXNzYWdlIHx8IGVycm9yfWAsXHJcbiAgICAgICAgMjAxMixcclxuICAgICAgICA1MDAsXHJcbiAgICAgICAgcmVzcG9uc2VcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFJlbW92ZSB0aGUgb3JwaGFuIGhvc3QgZW50cmllcyBpbiB0aGUgcmVnaXN0cnlcclxuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXHJcbiAgICovXHJcbiAgYXN5bmMgcmVtb3ZlT3JwaGFuRW50cmllcyhjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCwgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5KSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB7IGVudHJpZXMgfSA9IHJlcXVlc3QuYm9keTtcclxuICAgICAgbG9nKCd3YXp1aC1ob3N0czpjbGVhblJlZ2lzdHJ5JywgJ0NsZWFuaW5nIHJlZ2lzdHJ5JywgJ2RlYnVnJyk7XHJcbiAgICAgIGF3YWl0IHRoaXMudXBkYXRlUmVnaXN0cnkucmVtb3ZlT3JwaGFuRW50cmllcyhlbnRyaWVzKTtcclxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcclxuICAgICAgICBib2R5OiB7IHN0YXR1c0NvZGU6IDIwMCwgbWVzc2FnZTogJ29rJyB9XHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgbG9nKCd3YXp1aC1ob3N0czpjbGVhblJlZ2lzdHJ5JywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XHJcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxyXG4gICAgICAgIGBDb3VsZCBub3QgY2xlYW4gZW50cmllcyBpbiB0aGUgd2F6dWgtcmVnaXN0cnkuanNvbiBkdWUgdG8gJHtlcnJvci5tZXNzYWdlIHx8IGVycm9yfWAsXHJcbiAgICAgICAgMjAxMyxcclxuICAgICAgICA1MDAsXHJcbiAgICAgICAgcmVzcG9uc2VcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuIl19