"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "WazuhPluginSetup", {
  enumerable: true,
  get: function () {
    return _types.WazuhPluginSetup;
  }
});
Object.defineProperty(exports, "WazuhPluginStart", {
  enumerable: true,
  get: function () {
    return _types.WazuhPluginStart;
  }
});
exports.plugin = plugin;

var _plugin = require("./plugin");

var _types = require("./types");

//  This exports static code and TypeScript types,
//  as well as, plugin platform `plugin()` initializer.
function plugin(initializerContext) {
  return new _plugin.WazuhPlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbInBsdWdpbiIsImluaXRpYWxpemVyQ29udGV4dCIsIldhenVoUGx1Z2luIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUE7O0FBU0E7O0FBUEE7QUFDQTtBQUVPLFNBQVNBLE1BQVQsQ0FBZ0JDLGtCQUFoQixFQUE4RDtBQUNuRSxTQUFPLElBQUlDLG1CQUFKLENBQWdCRCxrQkFBaEIsQ0FBUDtBQUNEIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0IH0gZnJvbSAnb3BlbnNlYXJjaF9kYXNoYm9hcmRzL3NlcnZlcic7XHJcblxyXG5pbXBvcnQgeyBXYXp1aFBsdWdpbiB9IGZyb20gJy4vcGx1Z2luJztcclxuXHJcbi8vICBUaGlzIGV4cG9ydHMgc3RhdGljIGNvZGUgYW5kIFR5cGVTY3JpcHQgdHlwZXMsXHJcbi8vICBhcyB3ZWxsIGFzLCBwbHVnaW4gcGxhdGZvcm0gYHBsdWdpbigpYCBpbml0aWFsaXplci5cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBwbHVnaW4oaW5pdGlhbGl6ZXJDb250ZXh0OiBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQpIHtcclxuICByZXR1cm4gbmV3IFdhenVoUGx1Z2luKGluaXRpYWxpemVyQ29udGV4dCk7XHJcbn1cclxuXHJcbmV4cG9ydCB7IFdhenVoUGx1Z2luU2V0dXAsIFdhenVoUGx1Z2luU3RhcnQgfSBmcm9tICcuL3R5cGVzJztcclxuIl19