"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.monitoringTemplate = void 0;

/*
 * Wazuh app - Module for monitoring template
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
const monitoringTemplate = {
  order: 0,
  settings: {
    'index.refresh_interval': '5s'
  },
  mappings: {
    properties: {
      timestamp: {
        type: 'date',
        format: 'dateOptionalTime'
      },
      status: {
        type: 'keyword'
      },
      ip: {
        type: 'keyword'
      },
      host: {
        type: 'keyword'
      },
      name: {
        type: 'keyword'
      },
      id: {
        type: 'keyword'
      },
      cluster: {
        properties: {
          name: {
            type: 'keyword'
          }
        }
      }
    }
  }
};
exports.monitoringTemplate = monitoringTemplate;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1vbml0b3JpbmctdGVtcGxhdGUudHMiXSwibmFtZXMiOlsibW9uaXRvcmluZ1RlbXBsYXRlIiwib3JkZXIiLCJzZXR0aW5ncyIsIm1hcHBpbmdzIiwicHJvcGVydGllcyIsInRpbWVzdGFtcCIsInR5cGUiLCJmb3JtYXQiLCJzdGF0dXMiLCJpcCIsImhvc3QiLCJuYW1lIiwiaWQiLCJjbHVzdGVyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1BLGtCQUFrQixHQUFHO0FBQ2hDQyxFQUFBQSxLQUFLLEVBQUUsQ0FEeUI7QUFFaENDLEVBQUFBLFFBQVEsRUFBRTtBQUNSLDhCQUEwQjtBQURsQixHQUZzQjtBQUtoQ0MsRUFBQUEsUUFBUSxFQUFFO0FBQ1JDLElBQUFBLFVBQVUsRUFBRTtBQUNWQyxNQUFBQSxTQUFTLEVBQUU7QUFDVEMsUUFBQUEsSUFBSSxFQUFFLE1BREc7QUFFVEMsUUFBQUEsTUFBTSxFQUFFO0FBRkMsT0FERDtBQUtWQyxNQUFBQSxNQUFNLEVBQUU7QUFDTkYsUUFBQUEsSUFBSSxFQUFFO0FBREEsT0FMRTtBQVFWRyxNQUFBQSxFQUFFLEVBQUU7QUFDRkgsUUFBQUEsSUFBSSxFQUFFO0FBREosT0FSTTtBQVdWSSxNQUFBQSxJQUFJLEVBQUU7QUFDSkosUUFBQUEsSUFBSSxFQUFFO0FBREYsT0FYSTtBQWNWSyxNQUFBQSxJQUFJLEVBQUU7QUFDSkwsUUFBQUEsSUFBSSxFQUFFO0FBREYsT0FkSTtBQWlCVk0sTUFBQUEsRUFBRSxFQUFFO0FBQ0ZOLFFBQUFBLElBQUksRUFBRTtBQURKLE9BakJNO0FBb0JWTyxNQUFBQSxPQUFPLEVBQUU7QUFDUFQsUUFBQUEsVUFBVSxFQUFFO0FBQ1ZPLFVBQUFBLElBQUksRUFBRTtBQUNKTCxZQUFBQSxJQUFJLEVBQUU7QUFERjtBQURJO0FBREw7QUFwQkM7QUFESjtBQUxzQixDQUEzQiIsInNvdXJjZXNDb250ZW50IjpbIi8qXHJcbiAqIFdhenVoIGFwcCAtIE1vZHVsZSBmb3IgbW9uaXRvcmluZyB0ZW1wbGF0ZVxyXG4gKiBDb3B5cmlnaHQgKEMpIDIwMTUtMjAyMiBXYXp1aCwgSW5jLlxyXG4gKlxyXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxyXG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxyXG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxyXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxyXG4gKlxyXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxyXG4gKi9cclxuZXhwb3J0IGNvbnN0IG1vbml0b3JpbmdUZW1wbGF0ZSA9IHtcclxuICBvcmRlcjogMCxcclxuICBzZXR0aW5nczoge1xyXG4gICAgJ2luZGV4LnJlZnJlc2hfaW50ZXJ2YWwnOiAnNXMnXHJcbiAgfSxcclxuICBtYXBwaW5nczoge1xyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICB0aW1lc3RhbXA6IHtcclxuICAgICAgICB0eXBlOiAnZGF0ZScsXHJcbiAgICAgICAgZm9ybWF0OiAnZGF0ZU9wdGlvbmFsVGltZSdcclxuICAgICAgfSxcclxuICAgICAgc3RhdHVzOiB7XHJcbiAgICAgICAgdHlwZTogJ2tleXdvcmQnXHJcbiAgICAgIH0sXHJcbiAgICAgIGlwOiB7XHJcbiAgICAgICAgdHlwZTogJ2tleXdvcmQnXHJcbiAgICAgIH0sXHJcbiAgICAgIGhvc3Q6IHtcclxuICAgICAgICB0eXBlOiAna2V5d29yZCdcclxuICAgICAgfSxcclxuICAgICAgbmFtZToge1xyXG4gICAgICAgIHR5cGU6ICdrZXl3b3JkJ1xyXG4gICAgICB9LFxyXG4gICAgICBpZDoge1xyXG4gICAgICAgIHR5cGU6ICdrZXl3b3JkJ1xyXG4gICAgICB9LFxyXG4gICAgICBjbHVzdGVyOiB7XHJcbiAgICAgICAgcHJvcGVydGllczoge1xyXG4gICAgICAgICAgbmFtZToge1xyXG4gICAgICAgICAgICB0eXBlOiAna2V5d29yZCdcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn07XHJcbiJdfQ==