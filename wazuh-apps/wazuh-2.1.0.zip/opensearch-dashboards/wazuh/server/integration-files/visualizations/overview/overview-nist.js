"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

/*
 * Wazuh app - Module for Overview/NIST visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Overview-NIST-Requirements-over-time',
  _source: {
    title: 'Requirements over time',
    visState: JSON.stringify({
      title: 'NIST-Requirements-over-time',
      type: 'histogram',
      params: {
        type: 'histogram',
        grid: {
          categoryLines: true,
          valueAxis: 'ValueAxis-1'
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'line',
          mode: 'normal',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          showCircles: true,
          interpolate: 'linear'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {
          show: false
        },
        dimensions: {
          x: {
            accessor: 0,
            format: {
              id: 'date',
              params: {
                pattern: 'YYYY-MM-DD HH:mm'
              }
            },
            params: {
              date: true,
              interval: 'PT1H',
              format: 'YYYY-MM-DD HH:mm',
              bounds: {
                min: '2019-08-20T12:33:23.360Z',
                max: '2019-08-22T12:33:23.360Z'
              }
            },
            aggType: 'date_histogram'
          },
          y: [{
            accessor: 2,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          series: [{
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-2d',
            to: 'now'
          },
          useNormalizedEsInterval: true,
          interval: 'auto',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {}
        }
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.nist_800_53',
          orderBy: '1',
          order: 'desc',
          size: 50,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          language: 'lucene',
          query: ''
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-NIST-Requirements-Agents-heatmap',
  _type: 'visualization',
  _source: {
    title: 'Alerts volume by agent',
    visState: JSON.stringify({
      aggs: [{
        enabled: true,
        id: '1',
        params: {},
        schema: 'metric',
        type: 'count'
      }, {
        enabled: true,
        id: '3',
        params: {
          customLabel: 'Requirement',
          field: 'rule.nist_800_53',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          size: 10
        },
        schema: 'group',
        type: 'terms'
      }, {
        enabled: true,
        id: '2',
        params: {
          customLabel: 'Agent',
          field: 'agent.id',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          size: 5
        },
        schema: 'segment',
        type: 'terms'
      }],
      params: {
        addLegend: true,
        addTooltip: true,
        colorSchema: 'Blues',
        colorsNumber: 10,
        colorsRange: [],
        dimensions: {
          series: [{
            accessor: 0,
            aggType: 'terms',
            format: {
              id: 'terms',
              params: {
                id: 'string',
                missingBucketLabel: 'Missing',
                otherBucketLabel: 'Other'
              }
            },
            params: {}
          }],
          x: {
            accessor: 1,
            aggType: 'terms',
            format: {
              id: 'terms',
              params: {
                id: 'string',
                missingBucketLabel: 'Missing',
                otherBucketLabel: 'Other'
              }
            },
            params: {}
          },
          y: [{
            accessor: 2,
            aggType: 'count',
            format: {
              id: 'number'
            },
            params: {}
          }]
        },
        enableHover: false,
        invertColors: false,
        legendPosition: 'right',
        percentageMode: false,
        setColorRange: false,
        times: [],
        type: 'heatmap',
        valueAxes: [{
          id: 'ValueAxis-1',
          labels: {
            color: 'black',
            overwriteColor: false,
            rotate: 0,
            show: false
          },
          scale: {
            defaultYExtents: false,
            type: 'linear'
          },
          show: false,
          type: 'value'
        }]
      },
      title: 'NIST-Last-alerts',
      type: 'heatmap'
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 160': 'rgb(247,251,255)',
          '160 - 320': 'rgb(227,238,249)',
          '320 - 480': 'rgb(208,225,242)',
          '480 - 640': 'rgb(182,212,233)',
          '640 - 800': 'rgb(148,196,223)',
          '800 - 960': 'rgb(107,174,214)',
          '960 - 1,120': 'rgb(74,152,201)',
          '1,120 - 1,280': 'rgb(46,126,188)',
          '1,280 - 1,440': 'rgb(23,100,171)',
          '1,440 - 1,600': 'rgb(8,74,145)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-NIST-requirements-by-agents',
  _source: {
    title: 'Requiments distribution by agent',
    visState: JSON.stringify({
      title: 'NIST-Top-requirements-by-agent',
      type: 'area',
      params: {
        type: 'area',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          showCircles: true,
          interpolate: 'linear',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        dimensions: {
          x: {
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          },
          y: [{
            accessor: 2,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          series: [{
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'agent.id',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Agent'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.nist_800_53',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        legendOpen: false
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-NIST-Metrics',
  _source: {
    title: 'Stats',
    visState: JSON.stringify({
      title: 'nist-metrics',
      type: 'metric',
      params: {
        metric: {
          percentageMode: false,
          useRanges: false,
          colorSchema: 'Green to Red',
          metricColorMode: 'None',
          colorsRange: [{
            type: 'range',
            from: 0,
            to: 10000
          }],
          labels: {
            show: true
          },
          invertColors: false,
          style: {
            bgFill: '#000',
            bgColor: false,
            labelColor: false,
            subText: '',
            fontSize: 20
          }
        },
        dimensions: {
          metrics: [{
            type: 'vis_dimension',
            accessor: 0,
            format: {
              id: 'number',
              params: {}
            }
          }, {
            type: 'vis_dimension',
            accessor: 1,
            format: {
              id: 'number',
              params: {}
            }
          }]
        },
        addTooltip: true,
        addLegend: false,
        type: 'metric'
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {
          customLabel: 'Total alerts'
        }
      }, {
        id: '2',
        enabled: true,
        type: 'max',
        schema: 'metric',
        params: {
          field: 'rule.level',
          customLabel: 'Max rule level detected'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-NIST-Top-10-requirements',
  _source: {
    title: 'Top 10 requirements',
    visState: JSON.stringify({
      title: 'NIST-Top-10-requirements',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        },
        dimensions: {
          metric: {
            accessor: 1,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          },
          buckets: [{
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'rule.nist_800_53',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-NIST-Agents',
  _source: {
    title: 'Most active agents',
    visState: JSON.stringify({
      title: 'NIST-Top-10-agents',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        },
        dimensions: {
          metric: {
            accessor: 1,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          },
          buckets: [{
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'agent.name',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Agent'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-NIST-Alerts-summary',
  _type: 'visualization',
  _source: {
    title: 'Alerts summary',
    visState: JSON.stringify({
      title: 'NIST-Alerts-summary',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMetricsAtAllLevels: false,
        sort: {
          columnIndex: 3,
          direction: 'desc'
        },
        showTotal: false,
        showToolbar: true,
        totalFunc: 'sum',
        dimensions: {
          metrics: [{
            accessor: 3,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          buckets: [{
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }, {
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }, {
            accessor: 2,
            format: {
              id: 'terms',
              params: {
                id: 'number',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'agent.name',
          orderBy: '1',
          order: 'desc',
          size: 50,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Agent'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.nist_800_53',
          orderBy: '1',
          order: 'desc',
          size: 20,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.level',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Rule level'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm92ZXJ2aWV3LW5pc3QudHMiXSwibmFtZXMiOlsiX2lkIiwiX3NvdXJjZSIsInRpdGxlIiwidmlzU3RhdGUiLCJKU09OIiwic3RyaW5naWZ5IiwidHlwZSIsInBhcmFtcyIsImdyaWQiLCJjYXRlZ29yeUxpbmVzIiwidmFsdWVBeGlzIiwiY2F0ZWdvcnlBeGVzIiwiaWQiLCJwb3NpdGlvbiIsInNob3ciLCJzdHlsZSIsInNjYWxlIiwibGFiZWxzIiwiZmlsdGVyIiwidHJ1bmNhdGUiLCJ2YWx1ZUF4ZXMiLCJuYW1lIiwibW9kZSIsInJvdGF0ZSIsInRleHQiLCJzZXJpZXNQYXJhbXMiLCJkYXRhIiwibGFiZWwiLCJkcmF3TGluZXNCZXR3ZWVuUG9pbnRzIiwic2hvd0NpcmNsZXMiLCJpbnRlcnBvbGF0ZSIsImFkZFRvb2x0aXAiLCJhZGRMZWdlbmQiLCJsZWdlbmRQb3NpdGlvbiIsInRpbWVzIiwiYWRkVGltZU1hcmtlciIsImRpbWVuc2lvbnMiLCJ4IiwiYWNjZXNzb3IiLCJmb3JtYXQiLCJwYXR0ZXJuIiwiZGF0ZSIsImludGVydmFsIiwiYm91bmRzIiwibWluIiwibWF4IiwiYWdnVHlwZSIsInkiLCJzZXJpZXMiLCJvdGhlckJ1Y2tldExhYmVsIiwibWlzc2luZ0J1Y2tldExhYmVsIiwiYWdncyIsImVuYWJsZWQiLCJzY2hlbWEiLCJmaWVsZCIsInRpbWVSYW5nZSIsImZyb20iLCJ0byIsInVzZU5vcm1hbGl6ZWRFc0ludGVydmFsIiwiZHJvcF9wYXJ0aWFscyIsIm1pbl9kb2NfY291bnQiLCJleHRlbmRlZF9ib3VuZHMiLCJvcmRlckJ5Iiwib3JkZXIiLCJzaXplIiwib3RoZXJCdWNrZXQiLCJtaXNzaW5nQnVja2V0IiwiY3VzdG9tTGFiZWwiLCJ1aVN0YXRlSlNPTiIsImRlc2NyaXB0aW9uIiwidmVyc2lvbiIsImtpYmFuYVNhdmVkT2JqZWN0TWV0YSIsInNlYXJjaFNvdXJjZUpTT04iLCJpbmRleCIsInF1ZXJ5IiwibGFuZ3VhZ2UiLCJfdHlwZSIsImNvbG9yU2NoZW1hIiwiY29sb3JzTnVtYmVyIiwiY29sb3JzUmFuZ2UiLCJlbmFibGVIb3ZlciIsImludmVydENvbG9ycyIsInBlcmNlbnRhZ2VNb2RlIiwic2V0Q29sb3JSYW5nZSIsImNvbG9yIiwib3ZlcndyaXRlQ29sb3IiLCJkZWZhdWx0WUV4dGVudHMiLCJ2aXMiLCJkZWZhdWx0Q29sb3JzIiwibGVnZW5kT3BlbiIsIm1ldHJpYyIsInVzZVJhbmdlcyIsIm1ldHJpY0NvbG9yTW9kZSIsImJnRmlsbCIsImJnQ29sb3IiLCJsYWJlbENvbG9yIiwic3ViVGV4dCIsImZvbnRTaXplIiwibWV0cmljcyIsImlzRG9udXQiLCJ2YWx1ZXMiLCJsYXN0X2xldmVsIiwiYnVja2V0cyIsInBlclBhZ2UiLCJzaG93UGFydGlhbFJvd3MiLCJzaG93TWV0cmljc0F0QWxsTGV2ZWxzIiwic29ydCIsImNvbHVtbkluZGV4IiwiZGlyZWN0aW9uIiwic2hvd1RvdGFsIiwic2hvd1Rvb2xiYXIiLCJ0b3RhbEZ1bmMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO2VBQ2UsQ0FDYjtBQUNFQSxFQUFBQSxHQUFHLEVBQUUsZ0RBRFA7QUFFRUMsRUFBQUEsT0FBTyxFQUFFO0FBQ1BDLElBQUFBLEtBQUssRUFBRSx3QkFEQTtBQUVQQyxJQUFBQSxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ3ZCSCxNQUFBQSxLQUFLLEVBQUUsNkJBRGdCO0FBRXZCSSxNQUFBQSxJQUFJLEVBQUUsV0FGaUI7QUFHdkJDLE1BQUFBLE1BQU0sRUFBRTtBQUNORCxRQUFBQSxJQUFJLEVBQUUsV0FEQTtBQUVORSxRQUFBQSxJQUFJLEVBQUU7QUFBRUMsVUFBQUEsYUFBYSxFQUFFLElBQWpCO0FBQXVCQyxVQUFBQSxTQUFTLEVBQUU7QUFBbEMsU0FGQTtBQUdOQyxRQUFBQSxZQUFZLEVBQUUsQ0FDWjtBQUNFQyxVQUFBQSxFQUFFLEVBQUUsZ0JBRE47QUFFRU4sVUFBQUEsSUFBSSxFQUFFLFVBRlI7QUFHRU8sVUFBQUEsUUFBUSxFQUFFLFFBSFo7QUFJRUMsVUFBQUEsSUFBSSxFQUFFLElBSlI7QUFLRUMsVUFBQUEsS0FBSyxFQUFFLEVBTFQ7QUFNRUMsVUFBQUEsS0FBSyxFQUFFO0FBQUVWLFlBQUFBLElBQUksRUFBRTtBQUFSLFdBTlQ7QUFPRVcsVUFBQUEsTUFBTSxFQUFFO0FBQUVILFlBQUFBLElBQUksRUFBRSxJQUFSO0FBQWNJLFlBQUFBLE1BQU0sRUFBRSxJQUF0QjtBQUE0QkMsWUFBQUEsUUFBUSxFQUFFO0FBQXRDLFdBUFY7QUFRRWpCLFVBQUFBLEtBQUssRUFBRTtBQVJULFNBRFksQ0FIUjtBQWVOa0IsUUFBQUEsU0FBUyxFQUFFLENBQ1Q7QUFDRVIsVUFBQUEsRUFBRSxFQUFFLGFBRE47QUFFRVMsVUFBQUEsSUFBSSxFQUFFLFlBRlI7QUFHRWYsVUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRU8sVUFBQUEsUUFBUSxFQUFFLE1BSlo7QUFLRUMsVUFBQUEsSUFBSSxFQUFFLElBTFI7QUFNRUMsVUFBQUEsS0FBSyxFQUFFLEVBTlQ7QUFPRUMsVUFBQUEsS0FBSyxFQUFFO0FBQUVWLFlBQUFBLElBQUksRUFBRSxRQUFSO0FBQWtCZ0IsWUFBQUEsSUFBSSxFQUFFO0FBQXhCLFdBUFQ7QUFRRUwsVUFBQUEsTUFBTSxFQUFFO0FBQUVILFlBQUFBLElBQUksRUFBRSxJQUFSO0FBQWNTLFlBQUFBLE1BQU0sRUFBRSxDQUF0QjtBQUF5QkwsWUFBQUEsTUFBTSxFQUFFLEtBQWpDO0FBQXdDQyxZQUFBQSxRQUFRLEVBQUU7QUFBbEQsV0FSVjtBQVNFakIsVUFBQUEsS0FBSyxFQUFFO0FBQUVzQixZQUFBQSxJQUFJLEVBQUU7QUFBUjtBQVRULFNBRFMsQ0FmTDtBQTRCTkMsUUFBQUEsWUFBWSxFQUFFLENBQ1o7QUFDRVgsVUFBQUEsSUFBSSxFQUFFLE1BRFI7QUFFRVIsVUFBQUEsSUFBSSxFQUFFLE1BRlI7QUFHRWdCLFVBQUFBLElBQUksRUFBRSxRQUhSO0FBSUVJLFVBQUFBLElBQUksRUFBRTtBQUFFQyxZQUFBQSxLQUFLLEVBQUUsT0FBVDtBQUFrQmYsWUFBQUEsRUFBRSxFQUFFO0FBQXRCLFdBSlI7QUFLRUYsVUFBQUEsU0FBUyxFQUFFLGFBTGI7QUFNRWtCLFVBQUFBLHNCQUFzQixFQUFFLElBTjFCO0FBT0VDLFVBQUFBLFdBQVcsRUFBRSxJQVBmO0FBUUVDLFVBQUFBLFdBQVcsRUFBRTtBQVJmLFNBRFksQ0E1QlI7QUF3Q05DLFFBQUFBLFVBQVUsRUFBRSxJQXhDTjtBQXlDTkMsUUFBQUEsU0FBUyxFQUFFLElBekNMO0FBMENOQyxRQUFBQSxjQUFjLEVBQUUsT0ExQ1Y7QUEyQ05DLFFBQUFBLEtBQUssRUFBRSxFQTNDRDtBQTRDTkMsUUFBQUEsYUFBYSxFQUFFLEtBNUNUO0FBNkNObEIsUUFBQUEsTUFBTSxFQUFFO0FBQUVILFVBQUFBLElBQUksRUFBRTtBQUFSLFNBN0NGO0FBOENOc0IsUUFBQUEsVUFBVSxFQUFFO0FBQ1ZDLFVBQUFBLENBQUMsRUFBRTtBQUNEQyxZQUFBQSxRQUFRLEVBQUUsQ0FEVDtBQUVEQyxZQUFBQSxNQUFNLEVBQUU7QUFBRTNCLGNBQUFBLEVBQUUsRUFBRSxNQUFOO0FBQWNMLGNBQUFBLE1BQU0sRUFBRTtBQUFFaUMsZ0JBQUFBLE9BQU8sRUFBRTtBQUFYO0FBQXRCLGFBRlA7QUFHRGpDLFlBQUFBLE1BQU0sRUFBRTtBQUNOa0MsY0FBQUEsSUFBSSxFQUFFLElBREE7QUFFTkMsY0FBQUEsUUFBUSxFQUFFLE1BRko7QUFHTkgsY0FBQUEsTUFBTSxFQUFFLGtCQUhGO0FBSU5JLGNBQUFBLE1BQU0sRUFBRTtBQUFFQyxnQkFBQUEsR0FBRyxFQUFFLDBCQUFQO0FBQW1DQyxnQkFBQUEsR0FBRyxFQUFFO0FBQXhDO0FBSkYsYUFIUDtBQVNEQyxZQUFBQSxPQUFPLEVBQUU7QUFUUixXQURPO0FBWVZDLFVBQUFBLENBQUMsRUFBRSxDQUFDO0FBQUVULFlBQUFBLFFBQVEsRUFBRSxDQUFaO0FBQWVDLFlBQUFBLE1BQU0sRUFBRTtBQUFFM0IsY0FBQUEsRUFBRSxFQUFFO0FBQU4sYUFBdkI7QUFBeUNMLFlBQUFBLE1BQU0sRUFBRSxFQUFqRDtBQUFxRHVDLFlBQUFBLE9BQU8sRUFBRTtBQUE5RCxXQUFELENBWk87QUFhVkUsVUFBQUEsTUFBTSxFQUFFLENBQ047QUFDRVYsWUFBQUEsUUFBUSxFQUFFLENBRFo7QUFFRUMsWUFBQUEsTUFBTSxFQUFFO0FBQ04zQixjQUFBQSxFQUFFLEVBQUUsT0FERTtBQUVOTCxjQUFBQSxNQUFNLEVBQUU7QUFDTkssZ0JBQUFBLEVBQUUsRUFBRSxRQURFO0FBRU5xQyxnQkFBQUEsZ0JBQWdCLEVBQUUsT0FGWjtBQUdOQyxnQkFBQUEsa0JBQWtCLEVBQUU7QUFIZDtBQUZGLGFBRlY7QUFVRTNDLFlBQUFBLE1BQU0sRUFBRSxFQVZWO0FBV0V1QyxZQUFBQSxPQUFPLEVBQUU7QUFYWCxXQURNO0FBYkU7QUE5Q04sT0FIZTtBQStFdkJLLE1BQUFBLElBQUksRUFBRSxDQUNKO0FBQUV2QyxRQUFBQSxFQUFFLEVBQUUsR0FBTjtBQUFXd0MsUUFBQUEsT0FBTyxFQUFFLElBQXBCO0FBQTBCOUMsUUFBQUEsSUFBSSxFQUFFLE9BQWhDO0FBQXlDK0MsUUFBQUEsTUFBTSxFQUFFLFFBQWpEO0FBQTJEOUMsUUFBQUEsTUFBTSxFQUFFO0FBQW5FLE9BREksRUFFSjtBQUNFSyxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFd0MsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRTlDLFFBQUFBLElBQUksRUFBRSxnQkFIUjtBQUlFK0MsUUFBQUEsTUFBTSxFQUFFLFNBSlY7QUFLRTlDLFFBQUFBLE1BQU0sRUFBRTtBQUNOK0MsVUFBQUEsS0FBSyxFQUFFLFdBREQ7QUFFTkMsVUFBQUEsU0FBUyxFQUFFO0FBQUVDLFlBQUFBLElBQUksRUFBRSxRQUFSO0FBQWtCQyxZQUFBQSxFQUFFLEVBQUU7QUFBdEIsV0FGTDtBQUdOQyxVQUFBQSx1QkFBdUIsRUFBRSxJQUhuQjtBQUlOaEIsVUFBQUEsUUFBUSxFQUFFLE1BSko7QUFLTmlCLFVBQUFBLGFBQWEsRUFBRSxLQUxUO0FBTU5DLFVBQUFBLGFBQWEsRUFBRSxDQU5UO0FBT05DLFVBQUFBLGVBQWUsRUFBRTtBQVBYO0FBTFYsT0FGSSxFQWlCSjtBQUNFakQsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRXdDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0U5QyxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFK0MsUUFBQUEsTUFBTSxFQUFFLE9BSlY7QUFLRTlDLFFBQUFBLE1BQU0sRUFBRTtBQUNOK0MsVUFBQUEsS0FBSyxFQUFFLGtCQUREO0FBRU5RLFVBQUFBLE9BQU8sRUFBRSxHQUZIO0FBR05DLFVBQUFBLEtBQUssRUFBRSxNQUhEO0FBSU5DLFVBQUFBLElBQUksRUFBRSxFQUpBO0FBS05DLFVBQUFBLFdBQVcsRUFBRSxLQUxQO0FBTU5oQixVQUFBQSxnQkFBZ0IsRUFBRSxPQU5aO0FBT05pQixVQUFBQSxhQUFhLEVBQUUsS0FQVDtBQVFOaEIsVUFBQUEsa0JBQWtCLEVBQUUsU0FSZDtBQVNOaUIsVUFBQUEsV0FBVyxFQUFFO0FBVFA7QUFMVixPQWpCSTtBQS9FaUIsS0FBZixDQUZIO0FBcUhQQyxJQUFBQSxXQUFXLEVBQUUsSUFySE47QUFzSFBDLElBQUFBLFdBQVcsRUFBRSxFQXRITjtBQXVIUEMsSUFBQUEsT0FBTyxFQUFFLENBdkhGO0FBd0hQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQUVwRSxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUMvQm9FLFFBQUFBLEtBQUssRUFBRSxjQUR3QjtBQUUvQnZELFFBQUFBLE1BQU0sRUFBRSxFQUZ1QjtBQUcvQndELFFBQUFBLEtBQUssRUFBRTtBQUFFQyxVQUFBQSxRQUFRLEVBQUUsUUFBWjtBQUFzQkQsVUFBQUEsS0FBSyxFQUFFO0FBQTdCO0FBSHdCLE9BQWY7QUFERztBQXhIaEIsR0FGWDtBQWtJRUUsRUFBQUEsS0FBSyxFQUFFO0FBbElULENBRGEsRUFxSWI7QUFDRTVFLEVBQUFBLEdBQUcsRUFBRSxxREFEUDtBQUVFNEUsRUFBQUEsS0FBSyxFQUFFLGVBRlQ7QUFHRTNFLEVBQUFBLE9BQU8sRUFBRTtBQUNQQyxJQUFBQSxLQUFLLEVBQUUsd0JBREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QjhDLE1BQUFBLElBQUksRUFBRSxDQUNKO0FBQUVDLFFBQUFBLE9BQU8sRUFBRSxJQUFYO0FBQWlCeEMsUUFBQUEsRUFBRSxFQUFFLEdBQXJCO0FBQTBCTCxRQUFBQSxNQUFNLEVBQUUsRUFBbEM7QUFBc0M4QyxRQUFBQSxNQUFNLEVBQUUsUUFBOUM7QUFBd0QvQyxRQUFBQSxJQUFJLEVBQUU7QUFBOUQsT0FESSxFQUVKO0FBQ0U4QyxRQUFBQSxPQUFPLEVBQUUsSUFEWDtBQUVFeEMsUUFBQUEsRUFBRSxFQUFFLEdBRk47QUFHRUwsUUFBQUEsTUFBTSxFQUFFO0FBQ040RCxVQUFBQSxXQUFXLEVBQUUsYUFEUDtBQUVOYixVQUFBQSxLQUFLLEVBQUUsa0JBRkQ7QUFHTlksVUFBQUEsYUFBYSxFQUFFLEtBSFQ7QUFJTmhCLFVBQUFBLGtCQUFrQixFQUFFLFNBSmQ7QUFLTmEsVUFBQUEsS0FBSyxFQUFFLE1BTEQ7QUFNTkQsVUFBQUEsT0FBTyxFQUFFLEdBTkg7QUFPTkcsVUFBQUEsV0FBVyxFQUFFLEtBUFA7QUFRTmhCLFVBQUFBLGdCQUFnQixFQUFFLE9BUlo7QUFTTmUsVUFBQUEsSUFBSSxFQUFFO0FBVEEsU0FIVjtBQWNFWCxRQUFBQSxNQUFNLEVBQUUsT0FkVjtBQWVFL0MsUUFBQUEsSUFBSSxFQUFFO0FBZlIsT0FGSSxFQW1CSjtBQUNFOEMsUUFBQUEsT0FBTyxFQUFFLElBRFg7QUFFRXhDLFFBQUFBLEVBQUUsRUFBRSxHQUZOO0FBR0VMLFFBQUFBLE1BQU0sRUFBRTtBQUNONEQsVUFBQUEsV0FBVyxFQUFFLE9BRFA7QUFFTmIsVUFBQUEsS0FBSyxFQUFFLFVBRkQ7QUFHTlksVUFBQUEsYUFBYSxFQUFFLEtBSFQ7QUFJTmhCLFVBQUFBLGtCQUFrQixFQUFFLFNBSmQ7QUFLTmEsVUFBQUEsS0FBSyxFQUFFLE1BTEQ7QUFNTkQsVUFBQUEsT0FBTyxFQUFFLEdBTkg7QUFPTkcsVUFBQUEsV0FBVyxFQUFFLEtBUFA7QUFRTmhCLFVBQUFBLGdCQUFnQixFQUFFLE9BUlo7QUFTTmUsVUFBQUEsSUFBSSxFQUFFO0FBVEEsU0FIVjtBQWNFWCxRQUFBQSxNQUFNLEVBQUUsU0FkVjtBQWVFL0MsUUFBQUEsSUFBSSxFQUFFO0FBZlIsT0FuQkksQ0FEaUI7QUFzQ3ZCQyxNQUFBQSxNQUFNLEVBQUU7QUFDTnlCLFFBQUFBLFNBQVMsRUFBRSxJQURMO0FBRU5ELFFBQUFBLFVBQVUsRUFBRSxJQUZOO0FBR044QyxRQUFBQSxXQUFXLEVBQUUsT0FIUDtBQUlOQyxRQUFBQSxZQUFZLEVBQUUsRUFKUjtBQUtOQyxRQUFBQSxXQUFXLEVBQUUsRUFMUDtBQU1OM0MsUUFBQUEsVUFBVSxFQUFFO0FBQ1ZZLFVBQUFBLE1BQU0sRUFBRSxDQUNOO0FBQ0VWLFlBQUFBLFFBQVEsRUFBRSxDQURaO0FBRUVRLFlBQUFBLE9BQU8sRUFBRSxPQUZYO0FBR0VQLFlBQUFBLE1BQU0sRUFBRTtBQUNOM0IsY0FBQUEsRUFBRSxFQUFFLE9BREU7QUFFTkwsY0FBQUEsTUFBTSxFQUFFO0FBQ05LLGdCQUFBQSxFQUFFLEVBQUUsUUFERTtBQUVOc0MsZ0JBQUFBLGtCQUFrQixFQUFFLFNBRmQ7QUFHTkQsZ0JBQUFBLGdCQUFnQixFQUFFO0FBSFo7QUFGRixhQUhWO0FBV0UxQyxZQUFBQSxNQUFNLEVBQUU7QUFYVixXQURNLENBREU7QUFnQlY4QixVQUFBQSxDQUFDLEVBQUU7QUFDREMsWUFBQUEsUUFBUSxFQUFFLENBRFQ7QUFFRFEsWUFBQUEsT0FBTyxFQUFFLE9BRlI7QUFHRFAsWUFBQUEsTUFBTSxFQUFFO0FBQ04zQixjQUFBQSxFQUFFLEVBQUUsT0FERTtBQUVOTCxjQUFBQSxNQUFNLEVBQUU7QUFBRUssZ0JBQUFBLEVBQUUsRUFBRSxRQUFOO0FBQWdCc0MsZ0JBQUFBLGtCQUFrQixFQUFFLFNBQXBDO0FBQStDRCxnQkFBQUEsZ0JBQWdCLEVBQUU7QUFBakU7QUFGRixhQUhQO0FBT0QxQyxZQUFBQSxNQUFNLEVBQUU7QUFQUCxXQWhCTztBQXlCVndDLFVBQUFBLENBQUMsRUFBRSxDQUFDO0FBQUVULFlBQUFBLFFBQVEsRUFBRSxDQUFaO0FBQWVRLFlBQUFBLE9BQU8sRUFBRSxPQUF4QjtBQUFpQ1AsWUFBQUEsTUFBTSxFQUFFO0FBQUUzQixjQUFBQSxFQUFFLEVBQUU7QUFBTixhQUF6QztBQUEyREwsWUFBQUEsTUFBTSxFQUFFO0FBQW5FLFdBQUQ7QUF6Qk8sU0FOTjtBQWlDTnlFLFFBQUFBLFdBQVcsRUFBRSxLQWpDUDtBQWtDTkMsUUFBQUEsWUFBWSxFQUFFLEtBbENSO0FBbUNOaEQsUUFBQUEsY0FBYyxFQUFFLE9BbkNWO0FBb0NOaUQsUUFBQUEsY0FBYyxFQUFFLEtBcENWO0FBcUNOQyxRQUFBQSxhQUFhLEVBQUUsS0FyQ1Q7QUFzQ05qRCxRQUFBQSxLQUFLLEVBQUUsRUF0Q0Q7QUF1Q041QixRQUFBQSxJQUFJLEVBQUUsU0F2Q0E7QUF3Q05jLFFBQUFBLFNBQVMsRUFBRSxDQUNUO0FBQ0VSLFVBQUFBLEVBQUUsRUFBRSxhQUROO0FBRUVLLFVBQUFBLE1BQU0sRUFBRTtBQUFFbUUsWUFBQUEsS0FBSyxFQUFFLE9BQVQ7QUFBa0JDLFlBQUFBLGNBQWMsRUFBRSxLQUFsQztBQUF5QzlELFlBQUFBLE1BQU0sRUFBRSxDQUFqRDtBQUFvRFQsWUFBQUEsSUFBSSxFQUFFO0FBQTFELFdBRlY7QUFHRUUsVUFBQUEsS0FBSyxFQUFFO0FBQUVzRSxZQUFBQSxlQUFlLEVBQUUsS0FBbkI7QUFBMEJoRixZQUFBQSxJQUFJLEVBQUU7QUFBaEMsV0FIVDtBQUlFUSxVQUFBQSxJQUFJLEVBQUUsS0FKUjtBQUtFUixVQUFBQSxJQUFJLEVBQUU7QUFMUixTQURTO0FBeENMLE9BdENlO0FBd0Z2QkosTUFBQUEsS0FBSyxFQUFFLGtCQXhGZ0I7QUF5RnZCSSxNQUFBQSxJQUFJLEVBQUU7QUF6RmlCLEtBQWYsQ0FGSDtBQTZGUDhELElBQUFBLFdBQVcsRUFBRWhFLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQzFCa0YsTUFBQUEsR0FBRyxFQUFFO0FBQ0hDLFFBQUFBLGFBQWEsRUFBRTtBQUNiLHFCQUFXLGtCQURFO0FBRWIsdUJBQWEsa0JBRkE7QUFHYix1QkFBYSxrQkFIQTtBQUliLHVCQUFhLGtCQUpBO0FBS2IsdUJBQWEsa0JBTEE7QUFNYix1QkFBYSxrQkFOQTtBQU9iLHlCQUFlLGlCQVBGO0FBUWIsMkJBQWlCLGlCQVJKO0FBU2IsMkJBQWlCLGlCQVRKO0FBVWIsMkJBQWlCO0FBVko7QUFEWjtBQURxQixLQUFmLENBN0ZOO0FBNkdQbkIsSUFBQUEsV0FBVyxFQUFFLEVBN0dOO0FBOEdQQyxJQUFBQSxPQUFPLEVBQUUsQ0E5R0Y7QUErR1BDLElBQUFBLHFCQUFxQixFQUFFO0FBQ3JCQyxNQUFBQSxnQkFBZ0IsRUFBRXBFLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQy9Cb0UsUUFBQUEsS0FBSyxFQUFFLGNBRHdCO0FBRS9CQyxRQUFBQSxLQUFLLEVBQUU7QUFBRUEsVUFBQUEsS0FBSyxFQUFFLEVBQVQ7QUFBYUMsVUFBQUEsUUFBUSxFQUFFO0FBQXZCLFNBRndCO0FBRy9CekQsUUFBQUEsTUFBTSxFQUFFO0FBSHVCLE9BQWY7QUFERztBQS9HaEI7QUFIWCxDQXJJYSxFQWdRYjtBQUNFbEIsRUFBQUEsR0FBRyxFQUFFLGdEQURQO0FBRUVDLEVBQUFBLE9BQU8sRUFBRTtBQUNQQyxJQUFBQSxLQUFLLEVBQUUsa0NBREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QkgsTUFBQUEsS0FBSyxFQUFFLGdDQURnQjtBQUV2QkksTUFBQUEsSUFBSSxFQUFFLE1BRmlCO0FBR3ZCQyxNQUFBQSxNQUFNLEVBQUU7QUFDTkQsUUFBQUEsSUFBSSxFQUFFLE1BREE7QUFFTkUsUUFBQUEsSUFBSSxFQUFFO0FBQUVDLFVBQUFBLGFBQWEsRUFBRTtBQUFqQixTQUZBO0FBR05FLFFBQUFBLFlBQVksRUFBRSxDQUNaO0FBQ0VDLFVBQUFBLEVBQUUsRUFBRSxnQkFETjtBQUVFTixVQUFBQSxJQUFJLEVBQUUsVUFGUjtBQUdFTyxVQUFBQSxRQUFRLEVBQUUsUUFIWjtBQUlFQyxVQUFBQSxJQUFJLEVBQUUsSUFKUjtBQUtFQyxVQUFBQSxLQUFLLEVBQUUsRUFMVDtBQU1FQyxVQUFBQSxLQUFLLEVBQUU7QUFBRVYsWUFBQUEsSUFBSSxFQUFFO0FBQVIsV0FOVDtBQU9FVyxVQUFBQSxNQUFNLEVBQUU7QUFBRUgsWUFBQUEsSUFBSSxFQUFFLElBQVI7QUFBY0ksWUFBQUEsTUFBTSxFQUFFLElBQXRCO0FBQTRCQyxZQUFBQSxRQUFRLEVBQUU7QUFBdEMsV0FQVjtBQVFFakIsVUFBQUEsS0FBSyxFQUFFO0FBUlQsU0FEWSxDQUhSO0FBZU5rQixRQUFBQSxTQUFTLEVBQUUsQ0FDVDtBQUNFUixVQUFBQSxFQUFFLEVBQUUsYUFETjtBQUVFUyxVQUFBQSxJQUFJLEVBQUUsWUFGUjtBQUdFZixVQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFTyxVQUFBQSxRQUFRLEVBQUUsTUFKWjtBQUtFQyxVQUFBQSxJQUFJLEVBQUUsSUFMUjtBQU1FQyxVQUFBQSxLQUFLLEVBQUUsRUFOVDtBQU9FQyxVQUFBQSxLQUFLLEVBQUU7QUFBRVYsWUFBQUEsSUFBSSxFQUFFLFFBQVI7QUFBa0JnQixZQUFBQSxJQUFJLEVBQUU7QUFBeEIsV0FQVDtBQVFFTCxVQUFBQSxNQUFNLEVBQUU7QUFBRUgsWUFBQUEsSUFBSSxFQUFFLElBQVI7QUFBY1MsWUFBQUEsTUFBTSxFQUFFLENBQXRCO0FBQXlCTCxZQUFBQSxNQUFNLEVBQUUsS0FBakM7QUFBd0NDLFlBQUFBLFFBQVEsRUFBRTtBQUFsRCxXQVJWO0FBU0VqQixVQUFBQSxLQUFLLEVBQUU7QUFBRXNCLFlBQUFBLElBQUksRUFBRTtBQUFSO0FBVFQsU0FEUyxDQWZMO0FBNEJOQyxRQUFBQSxZQUFZLEVBQUUsQ0FDWjtBQUNFWCxVQUFBQSxJQUFJLEVBQUUsTUFEUjtBQUVFUixVQUFBQSxJQUFJLEVBQUUsV0FGUjtBQUdFZ0IsVUFBQUEsSUFBSSxFQUFFLFNBSFI7QUFJRUksVUFBQUEsSUFBSSxFQUFFO0FBQUVDLFlBQUFBLEtBQUssRUFBRSxPQUFUO0FBQWtCZixZQUFBQSxFQUFFLEVBQUU7QUFBdEIsV0FKUjtBQUtFZ0IsVUFBQUEsc0JBQXNCLEVBQUUsSUFMMUI7QUFNRUMsVUFBQUEsV0FBVyxFQUFFLElBTmY7QUFPRUMsVUFBQUEsV0FBVyxFQUFFLFFBUGY7QUFRRXBCLFVBQUFBLFNBQVMsRUFBRTtBQVJiLFNBRFksQ0E1QlI7QUF3Q05xQixRQUFBQSxVQUFVLEVBQUUsSUF4Q047QUF5Q05DLFFBQUFBLFNBQVMsRUFBRSxJQXpDTDtBQTBDTkMsUUFBQUEsY0FBYyxFQUFFLE9BMUNWO0FBMkNOQyxRQUFBQSxLQUFLLEVBQUUsRUEzQ0Q7QUE0Q05DLFFBQUFBLGFBQWEsRUFBRSxLQTVDVDtBQTZDTkMsUUFBQUEsVUFBVSxFQUFFO0FBQ1ZDLFVBQUFBLENBQUMsRUFBRTtBQUNEQyxZQUFBQSxRQUFRLEVBQUUsQ0FEVDtBQUVEQyxZQUFBQSxNQUFNLEVBQUU7QUFDTjNCLGNBQUFBLEVBQUUsRUFBRSxPQURFO0FBRU5MLGNBQUFBLE1BQU0sRUFBRTtBQUFFSyxnQkFBQUEsRUFBRSxFQUFFLFFBQU47QUFBZ0JxQyxnQkFBQUEsZ0JBQWdCLEVBQUUsT0FBbEM7QUFBMkNDLGdCQUFBQSxrQkFBa0IsRUFBRTtBQUEvRDtBQUZGLGFBRlA7QUFNRDNDLFlBQUFBLE1BQU0sRUFBRSxFQU5QO0FBT0R1QyxZQUFBQSxPQUFPLEVBQUU7QUFQUixXQURPO0FBVVZDLFVBQUFBLENBQUMsRUFBRSxDQUFDO0FBQUVULFlBQUFBLFFBQVEsRUFBRSxDQUFaO0FBQWVDLFlBQUFBLE1BQU0sRUFBRTtBQUFFM0IsY0FBQUEsRUFBRSxFQUFFO0FBQU4sYUFBdkI7QUFBeUNMLFlBQUFBLE1BQU0sRUFBRSxFQUFqRDtBQUFxRHVDLFlBQUFBLE9BQU8sRUFBRTtBQUE5RCxXQUFELENBVk87QUFXVkUsVUFBQUEsTUFBTSxFQUFFLENBQ047QUFDRVYsWUFBQUEsUUFBUSxFQUFFLENBRFo7QUFFRUMsWUFBQUEsTUFBTSxFQUFFO0FBQ04zQixjQUFBQSxFQUFFLEVBQUUsT0FERTtBQUVOTCxjQUFBQSxNQUFNLEVBQUU7QUFDTkssZ0JBQUFBLEVBQUUsRUFBRSxRQURFO0FBRU5xQyxnQkFBQUEsZ0JBQWdCLEVBQUUsT0FGWjtBQUdOQyxnQkFBQUEsa0JBQWtCLEVBQUU7QUFIZDtBQUZGLGFBRlY7QUFVRTNDLFlBQUFBLE1BQU0sRUFBRSxFQVZWO0FBV0V1QyxZQUFBQSxPQUFPLEVBQUU7QUFYWCxXQURNO0FBWEU7QUE3Q04sT0FIZTtBQTRFdkJLLE1BQUFBLElBQUksRUFBRSxDQUNKO0FBQUV2QyxRQUFBQSxFQUFFLEVBQUUsR0FBTjtBQUFXd0MsUUFBQUEsT0FBTyxFQUFFLElBQXBCO0FBQTBCOUMsUUFBQUEsSUFBSSxFQUFFLE9BQWhDO0FBQXlDK0MsUUFBQUEsTUFBTSxFQUFFLFFBQWpEO0FBQTJEOUMsUUFBQUEsTUFBTSxFQUFFO0FBQW5FLE9BREksRUFFSjtBQUNFSyxRQUFBQSxFQUFFLEVBQUUsR0FETjtBQUVFd0MsUUFBQUEsT0FBTyxFQUFFLElBRlg7QUFHRTlDLFFBQUFBLElBQUksRUFBRSxPQUhSO0FBSUUrQyxRQUFBQSxNQUFNLEVBQUUsU0FKVjtBQUtFOUMsUUFBQUEsTUFBTSxFQUFFO0FBQ04rQyxVQUFBQSxLQUFLLEVBQUUsVUFERDtBQUVOUSxVQUFBQSxPQUFPLEVBQUUsR0FGSDtBQUdOQyxVQUFBQSxLQUFLLEVBQUUsTUFIRDtBQUlOQyxVQUFBQSxJQUFJLEVBQUUsQ0FKQTtBQUtOQyxVQUFBQSxXQUFXLEVBQUUsS0FMUDtBQU1OaEIsVUFBQUEsZ0JBQWdCLEVBQUUsT0FOWjtBQU9OaUIsVUFBQUEsYUFBYSxFQUFFLEtBUFQ7QUFRTmhCLFVBQUFBLGtCQUFrQixFQUFFLFNBUmQ7QUFTTmlCLFVBQUFBLFdBQVcsRUFBRTtBQVRQO0FBTFYsT0FGSSxFQW1CSjtBQUNFdkQsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRXdDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0U5QyxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFK0MsUUFBQUEsTUFBTSxFQUFFLE9BSlY7QUFLRTlDLFFBQUFBLE1BQU0sRUFBRTtBQUNOK0MsVUFBQUEsS0FBSyxFQUFFLGtCQUREO0FBRU5RLFVBQUFBLE9BQU8sRUFBRSxHQUZIO0FBR05DLFVBQUFBLEtBQUssRUFBRSxNQUhEO0FBSU5DLFVBQUFBLElBQUksRUFBRSxFQUpBO0FBS05DLFVBQUFBLFdBQVcsRUFBRSxLQUxQO0FBTU5oQixVQUFBQSxnQkFBZ0IsRUFBRSxPQU5aO0FBT05pQixVQUFBQSxhQUFhLEVBQUUsS0FQVDtBQVFOaEIsVUFBQUEsa0JBQWtCLEVBQUUsU0FSZDtBQVNOaUIsVUFBQUEsV0FBVyxFQUFFO0FBVFA7QUFMVixPQW5CSTtBQTVFaUIsS0FBZixDQUZIO0FBb0hQQyxJQUFBQSxXQUFXLEVBQUVoRSxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUFFa0YsTUFBQUEsR0FBRyxFQUFFO0FBQUVFLFFBQUFBLFVBQVUsRUFBRTtBQUFkO0FBQVAsS0FBZixDQXBITjtBQXFIUHBCLElBQUFBLFdBQVcsRUFBRSxFQXJITjtBQXNIUEMsSUFBQUEsT0FBTyxFQUFFLENBdEhGO0FBdUhQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQUVwRSxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUMvQm9FLFFBQUFBLEtBQUssRUFBRSxjQUR3QjtBQUUvQnZELFFBQUFBLE1BQU0sRUFBRSxFQUZ1QjtBQUcvQndELFFBQUFBLEtBQUssRUFBRTtBQUFFQSxVQUFBQSxLQUFLLEVBQUUsRUFBVDtBQUFhQyxVQUFBQSxRQUFRLEVBQUU7QUFBdkI7QUFId0IsT0FBZjtBQURHO0FBdkhoQixHQUZYO0FBaUlFQyxFQUFBQSxLQUFLLEVBQUU7QUFqSVQsQ0FoUWEsRUFtWWI7QUFDRTVFLEVBQUFBLEdBQUcsRUFBRSxpQ0FEUDtBQUVFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLE9BREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QkgsTUFBQUEsS0FBSyxFQUFFLGNBRGdCO0FBRXZCSSxNQUFBQSxJQUFJLEVBQUUsUUFGaUI7QUFHdkJDLE1BQUFBLE1BQU0sRUFBRTtBQUNObUYsUUFBQUEsTUFBTSxFQUFFO0FBQ05SLFVBQUFBLGNBQWMsRUFBRSxLQURWO0FBRU5TLFVBQUFBLFNBQVMsRUFBRSxLQUZMO0FBR05kLFVBQUFBLFdBQVcsRUFBRSxjQUhQO0FBSU5lLFVBQUFBLGVBQWUsRUFBRSxNQUpYO0FBS05iLFVBQUFBLFdBQVcsRUFBRSxDQUFDO0FBQUV6RSxZQUFBQSxJQUFJLEVBQUUsT0FBUjtBQUFpQmtELFlBQUFBLElBQUksRUFBRSxDQUF2QjtBQUEwQkMsWUFBQUEsRUFBRSxFQUFFO0FBQTlCLFdBQUQsQ0FMUDtBQU1OeEMsVUFBQUEsTUFBTSxFQUFFO0FBQUVILFlBQUFBLElBQUksRUFBRTtBQUFSLFdBTkY7QUFPTm1FLFVBQUFBLFlBQVksRUFBRSxLQVBSO0FBUU5sRSxVQUFBQSxLQUFLLEVBQUU7QUFBRThFLFlBQUFBLE1BQU0sRUFBRSxNQUFWO0FBQWtCQyxZQUFBQSxPQUFPLEVBQUUsS0FBM0I7QUFBa0NDLFlBQUFBLFVBQVUsRUFBRSxLQUE5QztBQUFxREMsWUFBQUEsT0FBTyxFQUFFLEVBQTlEO0FBQWtFQyxZQUFBQSxRQUFRLEVBQUU7QUFBNUU7QUFSRCxTQURGO0FBV043RCxRQUFBQSxVQUFVLEVBQUU7QUFDVjhELFVBQUFBLE9BQU8sRUFBRSxDQUNQO0FBQUU1RixZQUFBQSxJQUFJLEVBQUUsZUFBUjtBQUF5QmdDLFlBQUFBLFFBQVEsRUFBRSxDQUFuQztBQUFzQ0MsWUFBQUEsTUFBTSxFQUFFO0FBQUUzQixjQUFBQSxFQUFFLEVBQUUsUUFBTjtBQUFnQkwsY0FBQUEsTUFBTSxFQUFFO0FBQXhCO0FBQTlDLFdBRE8sRUFFUDtBQUFFRCxZQUFBQSxJQUFJLEVBQUUsZUFBUjtBQUF5QmdDLFlBQUFBLFFBQVEsRUFBRSxDQUFuQztBQUFzQ0MsWUFBQUEsTUFBTSxFQUFFO0FBQUUzQixjQUFBQSxFQUFFLEVBQUUsUUFBTjtBQUFnQkwsY0FBQUEsTUFBTSxFQUFFO0FBQXhCO0FBQTlDLFdBRk87QUFEQyxTQVhOO0FBaUJOd0IsUUFBQUEsVUFBVSxFQUFFLElBakJOO0FBa0JOQyxRQUFBQSxTQUFTLEVBQUUsS0FsQkw7QUFtQk4xQixRQUFBQSxJQUFJLEVBQUU7QUFuQkEsT0FIZTtBQXdCdkI2QyxNQUFBQSxJQUFJLEVBQUUsQ0FDSjtBQUNFdkMsUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRXdDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0U5QyxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFK0MsUUFBQUEsTUFBTSxFQUFFLFFBSlY7QUFLRTlDLFFBQUFBLE1BQU0sRUFBRTtBQUFFNEQsVUFBQUEsV0FBVyxFQUFFO0FBQWY7QUFMVixPQURJLEVBUUo7QUFDRXZELFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUV3QyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFOUMsUUFBQUEsSUFBSSxFQUFFLEtBSFI7QUFJRStDLFFBQUFBLE1BQU0sRUFBRSxRQUpWO0FBS0U5QyxRQUFBQSxNQUFNLEVBQUU7QUFBRStDLFVBQUFBLEtBQUssRUFBRSxZQUFUO0FBQXVCYSxVQUFBQSxXQUFXLEVBQUU7QUFBcEM7QUFMVixPQVJJO0FBeEJpQixLQUFmLENBRkg7QUEyQ1BDLElBQUFBLFdBQVcsRUFBRSxJQTNDTjtBQTRDUEMsSUFBQUEsV0FBVyxFQUFFLEVBNUNOO0FBNkNQQyxJQUFBQSxPQUFPLEVBQUUsQ0E3Q0Y7QUE4Q1BDLElBQUFBLHFCQUFxQixFQUFFO0FBQ3JCQyxNQUFBQSxnQkFBZ0IsRUFBRXBFLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQy9Cb0UsUUFBQUEsS0FBSyxFQUFFLGNBRHdCO0FBRS9CdkQsUUFBQUEsTUFBTSxFQUFFLEVBRnVCO0FBRy9Cd0QsUUFBQUEsS0FBSyxFQUFFO0FBQUVBLFVBQUFBLEtBQUssRUFBRSxFQUFUO0FBQWFDLFVBQUFBLFFBQVEsRUFBRTtBQUF2QjtBQUh3QixPQUFmO0FBREc7QUE5Q2hCLEdBRlg7QUF3REVDLEVBQUFBLEtBQUssRUFBRTtBQXhEVCxDQW5ZYSxFQTZiYjtBQUNFNUUsRUFBQUEsR0FBRyxFQUFFLDZDQURQO0FBRUVDLEVBQUFBLE9BQU8sRUFBRTtBQUNQQyxJQUFBQSxLQUFLLEVBQUUscUJBREE7QUFFUEMsSUFBQUEsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUN2QkgsTUFBQUEsS0FBSyxFQUFFLDBCQURnQjtBQUV2QkksTUFBQUEsSUFBSSxFQUFFLEtBRmlCO0FBR3ZCQyxNQUFBQSxNQUFNLEVBQUU7QUFDTkQsUUFBQUEsSUFBSSxFQUFFLEtBREE7QUFFTnlCLFFBQUFBLFVBQVUsRUFBRSxJQUZOO0FBR05DLFFBQUFBLFNBQVMsRUFBRSxJQUhMO0FBSU5DLFFBQUFBLGNBQWMsRUFBRSxPQUpWO0FBS05rRSxRQUFBQSxPQUFPLEVBQUUsSUFMSDtBQU1ObEYsUUFBQUEsTUFBTSxFQUFFO0FBQUVILFVBQUFBLElBQUksRUFBRSxLQUFSO0FBQWVzRixVQUFBQSxNQUFNLEVBQUUsSUFBdkI7QUFBNkJDLFVBQUFBLFVBQVUsRUFBRSxJQUF6QztBQUErQ2xGLFVBQUFBLFFBQVEsRUFBRTtBQUF6RCxTQU5GO0FBT05pQixRQUFBQSxVQUFVLEVBQUU7QUFDVnNELFVBQUFBLE1BQU0sRUFBRTtBQUFFcEQsWUFBQUEsUUFBUSxFQUFFLENBQVo7QUFBZUMsWUFBQUEsTUFBTSxFQUFFO0FBQUUzQixjQUFBQSxFQUFFLEVBQUU7QUFBTixhQUF2QjtBQUF5Q0wsWUFBQUEsTUFBTSxFQUFFLEVBQWpEO0FBQXFEdUMsWUFBQUEsT0FBTyxFQUFFO0FBQTlELFdBREU7QUFFVndELFVBQUFBLE9BQU8sRUFBRSxDQUNQO0FBQ0VoRSxZQUFBQSxRQUFRLEVBQUUsQ0FEWjtBQUVFQyxZQUFBQSxNQUFNLEVBQUU7QUFDTjNCLGNBQUFBLEVBQUUsRUFBRSxPQURFO0FBRU5MLGNBQUFBLE1BQU0sRUFBRTtBQUNOSyxnQkFBQUEsRUFBRSxFQUFFLFFBREU7QUFFTnFDLGdCQUFBQSxnQkFBZ0IsRUFBRSxPQUZaO0FBR05DLGdCQUFBQSxrQkFBa0IsRUFBRTtBQUhkO0FBRkYsYUFGVjtBQVVFM0MsWUFBQUEsTUFBTSxFQUFFLEVBVlY7QUFXRXVDLFlBQUFBLE9BQU8sRUFBRTtBQVhYLFdBRE87QUFGQztBQVBOLE9BSGU7QUE2QnZCSyxNQUFBQSxJQUFJLEVBQUUsQ0FDSjtBQUFFdkMsUUFBQUEsRUFBRSxFQUFFLEdBQU47QUFBV3dDLFFBQUFBLE9BQU8sRUFBRSxJQUFwQjtBQUEwQjlDLFFBQUFBLElBQUksRUFBRSxPQUFoQztBQUF5QytDLFFBQUFBLE1BQU0sRUFBRSxRQUFqRDtBQUEyRDlDLFFBQUFBLE1BQU0sRUFBRTtBQUFuRSxPQURJLEVBRUo7QUFDRUssUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRXdDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0U5QyxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFK0MsUUFBQUEsTUFBTSxFQUFFLFNBSlY7QUFLRTlDLFFBQUFBLE1BQU0sRUFBRTtBQUNOK0MsVUFBQUEsS0FBSyxFQUFFLGtCQUREO0FBRU5RLFVBQUFBLE9BQU8sRUFBRSxHQUZIO0FBR05DLFVBQUFBLEtBQUssRUFBRSxNQUhEO0FBSU5DLFVBQUFBLElBQUksRUFBRSxFQUpBO0FBS05DLFVBQUFBLFdBQVcsRUFBRSxLQUxQO0FBTU5oQixVQUFBQSxnQkFBZ0IsRUFBRSxPQU5aO0FBT05pQixVQUFBQSxhQUFhLEVBQUUsS0FQVDtBQVFOaEIsVUFBQUEsa0JBQWtCLEVBQUUsU0FSZDtBQVNOaUIsVUFBQUEsV0FBVyxFQUFFO0FBVFA7QUFMVixPQUZJO0FBN0JpQixLQUFmLENBRkg7QUFvRFBDLElBQUFBLFdBQVcsRUFBRSxJQXBETjtBQXFEUEMsSUFBQUEsV0FBVyxFQUFFLEVBckROO0FBc0RQQyxJQUFBQSxPQUFPLEVBQUUsQ0F0REY7QUF1RFBDLElBQUFBLHFCQUFxQixFQUFFO0FBQ3JCQyxNQUFBQSxnQkFBZ0IsRUFBRXBFLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQy9Cb0UsUUFBQUEsS0FBSyxFQUFFLGNBRHdCO0FBRS9CdkQsUUFBQUEsTUFBTSxFQUFFLEVBRnVCO0FBRy9Cd0QsUUFBQUEsS0FBSyxFQUFFO0FBQUVBLFVBQUFBLEtBQUssRUFBRSxFQUFUO0FBQWFDLFVBQUFBLFFBQVEsRUFBRTtBQUF2QjtBQUh3QixPQUFmO0FBREc7QUF2RGhCLEdBRlg7QUFpRUVDLEVBQUFBLEtBQUssRUFBRTtBQWpFVCxDQTdiYSxFQWdnQmI7QUFDRTVFLEVBQUFBLEdBQUcsRUFBRSxnQ0FEUDtBQUVFQyxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLG9CQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSxvQkFEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxLQUZpQjtBQUd2QkMsTUFBQUEsTUFBTSxFQUFFO0FBQ05ELFFBQUFBLElBQUksRUFBRSxLQURBO0FBRU55QixRQUFBQSxVQUFVLEVBQUUsSUFGTjtBQUdOQyxRQUFBQSxTQUFTLEVBQUUsSUFITDtBQUlOQyxRQUFBQSxjQUFjLEVBQUUsT0FKVjtBQUtOa0UsUUFBQUEsT0FBTyxFQUFFLElBTEg7QUFNTmxGLFFBQUFBLE1BQU0sRUFBRTtBQUFFSCxVQUFBQSxJQUFJLEVBQUUsS0FBUjtBQUFlc0YsVUFBQUEsTUFBTSxFQUFFLElBQXZCO0FBQTZCQyxVQUFBQSxVQUFVLEVBQUUsSUFBekM7QUFBK0NsRixVQUFBQSxRQUFRLEVBQUU7QUFBekQsU0FORjtBQU9OaUIsUUFBQUEsVUFBVSxFQUFFO0FBQ1ZzRCxVQUFBQSxNQUFNLEVBQUU7QUFBRXBELFlBQUFBLFFBQVEsRUFBRSxDQUFaO0FBQWVDLFlBQUFBLE1BQU0sRUFBRTtBQUFFM0IsY0FBQUEsRUFBRSxFQUFFO0FBQU4sYUFBdkI7QUFBeUNMLFlBQUFBLE1BQU0sRUFBRSxFQUFqRDtBQUFxRHVDLFlBQUFBLE9BQU8sRUFBRTtBQUE5RCxXQURFO0FBRVZ3RCxVQUFBQSxPQUFPLEVBQUUsQ0FDUDtBQUNFaEUsWUFBQUEsUUFBUSxFQUFFLENBRFo7QUFFRUMsWUFBQUEsTUFBTSxFQUFFO0FBQ04zQixjQUFBQSxFQUFFLEVBQUUsT0FERTtBQUVOTCxjQUFBQSxNQUFNLEVBQUU7QUFDTkssZ0JBQUFBLEVBQUUsRUFBRSxRQURFO0FBRU5xQyxnQkFBQUEsZ0JBQWdCLEVBQUUsT0FGWjtBQUdOQyxnQkFBQUEsa0JBQWtCLEVBQUU7QUFIZDtBQUZGLGFBRlY7QUFVRTNDLFlBQUFBLE1BQU0sRUFBRSxFQVZWO0FBV0V1QyxZQUFBQSxPQUFPLEVBQUU7QUFYWCxXQURPO0FBRkM7QUFQTixPQUhlO0FBNkJ2QkssTUFBQUEsSUFBSSxFQUFFLENBQ0o7QUFBRXZDLFFBQUFBLEVBQUUsRUFBRSxHQUFOO0FBQVd3QyxRQUFBQSxPQUFPLEVBQUUsSUFBcEI7QUFBMEI5QyxRQUFBQSxJQUFJLEVBQUUsT0FBaEM7QUFBeUMrQyxRQUFBQSxNQUFNLEVBQUUsUUFBakQ7QUFBMkQ5QyxRQUFBQSxNQUFNLEVBQUU7QUFBbkUsT0FESSxFQUVKO0FBQ0VLLFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUV3QyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFOUMsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRStDLFFBQUFBLE1BQU0sRUFBRSxTQUpWO0FBS0U5QyxRQUFBQSxNQUFNLEVBQUU7QUFDTitDLFVBQUFBLEtBQUssRUFBRSxZQUREO0FBRU5RLFVBQUFBLE9BQU8sRUFBRSxHQUZIO0FBR05DLFVBQUFBLEtBQUssRUFBRSxNQUhEO0FBSU5DLFVBQUFBLElBQUksRUFBRSxFQUpBO0FBS05DLFVBQUFBLFdBQVcsRUFBRSxLQUxQO0FBTU5oQixVQUFBQSxnQkFBZ0IsRUFBRSxPQU5aO0FBT05pQixVQUFBQSxhQUFhLEVBQUUsS0FQVDtBQVFOaEIsVUFBQUEsa0JBQWtCLEVBQUUsU0FSZDtBQVNOaUIsVUFBQUEsV0FBVyxFQUFFO0FBVFA7QUFMVixPQUZJO0FBN0JpQixLQUFmLENBRkg7QUFvRFBDLElBQUFBLFdBQVcsRUFBRSxJQXBETjtBQXFEUEMsSUFBQUEsV0FBVyxFQUFFLEVBckROO0FBc0RQQyxJQUFBQSxPQUFPLEVBQUUsQ0F0REY7QUF1RFBDLElBQUFBLHFCQUFxQixFQUFFO0FBQ3JCQyxNQUFBQSxnQkFBZ0IsRUFBRXBFLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQy9Cb0UsUUFBQUEsS0FBSyxFQUFFLGNBRHdCO0FBRS9CdkQsUUFBQUEsTUFBTSxFQUFFLEVBRnVCO0FBRy9Cd0QsUUFBQUEsS0FBSyxFQUFFO0FBQUVBLFVBQUFBLEtBQUssRUFBRSxFQUFUO0FBQWFDLFVBQUFBLFFBQVEsRUFBRTtBQUF2QjtBQUh3QixPQUFmO0FBREc7QUF2RGhCLEdBRlg7QUFpRUVDLEVBQUFBLEtBQUssRUFBRTtBQWpFVCxDQWhnQmEsRUFta0JiO0FBQ0U1RSxFQUFBQSxHQUFHLEVBQUUsd0NBRFA7QUFFRTRFLEVBQUFBLEtBQUssRUFBRSxlQUZUO0FBR0UzRSxFQUFBQSxPQUFPLEVBQUU7QUFDUEMsSUFBQUEsS0FBSyxFQUFFLGdCQURBO0FBRVBDLElBQUFBLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkJILE1BQUFBLEtBQUssRUFBRSxxQkFEZ0I7QUFFdkJJLE1BQUFBLElBQUksRUFBRSxPQUZpQjtBQUd2QkMsTUFBQUEsTUFBTSxFQUFFO0FBQ05nRyxRQUFBQSxPQUFPLEVBQUUsRUFESDtBQUVOQyxRQUFBQSxlQUFlLEVBQUUsS0FGWDtBQUdOQyxRQUFBQSxzQkFBc0IsRUFBRSxLQUhsQjtBQUlOQyxRQUFBQSxJQUFJLEVBQUU7QUFBRUMsVUFBQUEsV0FBVyxFQUFFLENBQWY7QUFBa0JDLFVBQUFBLFNBQVMsRUFBRTtBQUE3QixTQUpBO0FBS05DLFFBQUFBLFNBQVMsRUFBRSxLQUxMO0FBTU5DLFFBQUFBLFdBQVcsRUFBRSxJQU5QO0FBT05DLFFBQUFBLFNBQVMsRUFBRSxLQVBMO0FBUU4zRSxRQUFBQSxVQUFVLEVBQUU7QUFDVjhELFVBQUFBLE9BQU8sRUFBRSxDQUFDO0FBQUU1RCxZQUFBQSxRQUFRLEVBQUUsQ0FBWjtBQUFlQyxZQUFBQSxNQUFNLEVBQUU7QUFBRTNCLGNBQUFBLEVBQUUsRUFBRTtBQUFOLGFBQXZCO0FBQXlDTCxZQUFBQSxNQUFNLEVBQUUsRUFBakQ7QUFBcUR1QyxZQUFBQSxPQUFPLEVBQUU7QUFBOUQsV0FBRCxDQURDO0FBRVZ3RCxVQUFBQSxPQUFPLEVBQUUsQ0FDUDtBQUNFaEUsWUFBQUEsUUFBUSxFQUFFLENBRFo7QUFFRUMsWUFBQUEsTUFBTSxFQUFFO0FBQ04zQixjQUFBQSxFQUFFLEVBQUUsT0FERTtBQUVOTCxjQUFBQSxNQUFNLEVBQUU7QUFDTkssZ0JBQUFBLEVBQUUsRUFBRSxRQURFO0FBRU5xQyxnQkFBQUEsZ0JBQWdCLEVBQUUsT0FGWjtBQUdOQyxnQkFBQUEsa0JBQWtCLEVBQUU7QUFIZDtBQUZGLGFBRlY7QUFVRTNDLFlBQUFBLE1BQU0sRUFBRSxFQVZWO0FBV0V1QyxZQUFBQSxPQUFPLEVBQUU7QUFYWCxXQURPLEVBY1A7QUFDRVIsWUFBQUEsUUFBUSxFQUFFLENBRFo7QUFFRUMsWUFBQUEsTUFBTSxFQUFFO0FBQ04zQixjQUFBQSxFQUFFLEVBQUUsT0FERTtBQUVOTCxjQUFBQSxNQUFNLEVBQUU7QUFDTkssZ0JBQUFBLEVBQUUsRUFBRSxRQURFO0FBRU5xQyxnQkFBQUEsZ0JBQWdCLEVBQUUsT0FGWjtBQUdOQyxnQkFBQUEsa0JBQWtCLEVBQUU7QUFIZDtBQUZGLGFBRlY7QUFVRTNDLFlBQUFBLE1BQU0sRUFBRSxFQVZWO0FBV0V1QyxZQUFBQSxPQUFPLEVBQUU7QUFYWCxXQWRPLEVBMkJQO0FBQ0VSLFlBQUFBLFFBQVEsRUFBRSxDQURaO0FBRUVDLFlBQUFBLE1BQU0sRUFBRTtBQUNOM0IsY0FBQUEsRUFBRSxFQUFFLE9BREU7QUFFTkwsY0FBQUEsTUFBTSxFQUFFO0FBQ05LLGdCQUFBQSxFQUFFLEVBQUUsUUFERTtBQUVOcUMsZ0JBQUFBLGdCQUFnQixFQUFFLE9BRlo7QUFHTkMsZ0JBQUFBLGtCQUFrQixFQUFFO0FBSGQ7QUFGRixhQUZWO0FBVUUzQyxZQUFBQSxNQUFNLEVBQUUsRUFWVjtBQVdFdUMsWUFBQUEsT0FBTyxFQUFFO0FBWFgsV0EzQk87QUFGQztBQVJOLE9BSGU7QUF3RHZCSyxNQUFBQSxJQUFJLEVBQUUsQ0FDSjtBQUFFdkMsUUFBQUEsRUFBRSxFQUFFLEdBQU47QUFBV3dDLFFBQUFBLE9BQU8sRUFBRSxJQUFwQjtBQUEwQjlDLFFBQUFBLElBQUksRUFBRSxPQUFoQztBQUF5QytDLFFBQUFBLE1BQU0sRUFBRSxRQUFqRDtBQUEyRDlDLFFBQUFBLE1BQU0sRUFBRTtBQUFuRSxPQURJLEVBRUo7QUFDRUssUUFBQUEsRUFBRSxFQUFFLEdBRE47QUFFRXdDLFFBQUFBLE9BQU8sRUFBRSxJQUZYO0FBR0U5QyxRQUFBQSxJQUFJLEVBQUUsT0FIUjtBQUlFK0MsUUFBQUEsTUFBTSxFQUFFLFFBSlY7QUFLRTlDLFFBQUFBLE1BQU0sRUFBRTtBQUNOK0MsVUFBQUEsS0FBSyxFQUFFLFlBREQ7QUFFTlEsVUFBQUEsT0FBTyxFQUFFLEdBRkg7QUFHTkMsVUFBQUEsS0FBSyxFQUFFLE1BSEQ7QUFJTkMsVUFBQUEsSUFBSSxFQUFFLEVBSkE7QUFLTkMsVUFBQUEsV0FBVyxFQUFFLEtBTFA7QUFNTmhCLFVBQUFBLGdCQUFnQixFQUFFLE9BTlo7QUFPTmlCLFVBQUFBLGFBQWEsRUFBRSxLQVBUO0FBUU5oQixVQUFBQSxrQkFBa0IsRUFBRSxTQVJkO0FBU05pQixVQUFBQSxXQUFXLEVBQUU7QUFUUDtBQUxWLE9BRkksRUFtQko7QUFDRXZELFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUV3QyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFOUMsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRStDLFFBQUFBLE1BQU0sRUFBRSxRQUpWO0FBS0U5QyxRQUFBQSxNQUFNLEVBQUU7QUFDTitDLFVBQUFBLEtBQUssRUFBRSxrQkFERDtBQUVOUSxVQUFBQSxPQUFPLEVBQUUsR0FGSDtBQUdOQyxVQUFBQSxLQUFLLEVBQUUsTUFIRDtBQUlOQyxVQUFBQSxJQUFJLEVBQUUsRUFKQTtBQUtOQyxVQUFBQSxXQUFXLEVBQUUsS0FMUDtBQU1OaEIsVUFBQUEsZ0JBQWdCLEVBQUUsT0FOWjtBQU9OaUIsVUFBQUEsYUFBYSxFQUFFLEtBUFQ7QUFRTmhCLFVBQUFBLGtCQUFrQixFQUFFLFNBUmQ7QUFTTmlCLFVBQUFBLFdBQVcsRUFBRTtBQVRQO0FBTFYsT0FuQkksRUFvQ0o7QUFDRXZELFFBQUFBLEVBQUUsRUFBRSxHQUROO0FBRUV3QyxRQUFBQSxPQUFPLEVBQUUsSUFGWDtBQUdFOUMsUUFBQUEsSUFBSSxFQUFFLE9BSFI7QUFJRStDLFFBQUFBLE1BQU0sRUFBRSxRQUpWO0FBS0U5QyxRQUFBQSxNQUFNLEVBQUU7QUFDTitDLFVBQUFBLEtBQUssRUFBRSxZQUREO0FBRU5RLFVBQUFBLE9BQU8sRUFBRSxHQUZIO0FBR05DLFVBQUFBLEtBQUssRUFBRSxNQUhEO0FBSU5DLFVBQUFBLElBQUksRUFBRSxDQUpBO0FBS05DLFVBQUFBLFdBQVcsRUFBRSxLQUxQO0FBTU5oQixVQUFBQSxnQkFBZ0IsRUFBRSxPQU5aO0FBT05pQixVQUFBQSxhQUFhLEVBQUUsS0FQVDtBQVFOaEIsVUFBQUEsa0JBQWtCLEVBQUUsU0FSZDtBQVNOaUIsVUFBQUEsV0FBVyxFQUFFO0FBVFA7QUFMVixPQXBDSTtBQXhEaUIsS0FBZixDQUZIO0FBaUhQQyxJQUFBQSxXQUFXLEVBQUVoRSxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUMxQmtGLE1BQUFBLEdBQUcsRUFBRTtBQUFFaEYsUUFBQUEsTUFBTSxFQUFFO0FBQUVtRyxVQUFBQSxJQUFJLEVBQUU7QUFBRUMsWUFBQUEsV0FBVyxFQUFFLENBQWY7QUFBa0JDLFlBQUFBLFNBQVMsRUFBRTtBQUE3QjtBQUFSO0FBQVY7QUFEcUIsS0FBZixDQWpITjtBQW9IUHZDLElBQUFBLFdBQVcsRUFBRSxFQXBITjtBQXFIUEMsSUFBQUEsT0FBTyxFQUFFLENBckhGO0FBc0hQQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUNyQkMsTUFBQUEsZ0JBQWdCLEVBQUVwRSxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUMvQm9FLFFBQUFBLEtBQUssRUFBRSxjQUR3QjtBQUUvQnZELFFBQUFBLE1BQU0sRUFBRSxFQUZ1QjtBQUcvQndELFFBQUFBLEtBQUssRUFBRTtBQUFFQSxVQUFBQSxLQUFLLEVBQUUsRUFBVDtBQUFhQyxVQUFBQSxRQUFRLEVBQUU7QUFBdkI7QUFId0IsT0FBZjtBQURHO0FBdEhoQjtBQUhYLENBbmtCYSxDIiwic291cmNlc0NvbnRlbnQiOlsiLypcclxuICogV2F6dWggYXBwIC0gTW9kdWxlIGZvciBPdmVydmlldy9OSVNUIHZpc3VhbGl6YXRpb25zXHJcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXHJcbiAqXHJcbiAqIFRoaXMgcHJvZ3JhbSBpcyBmcmVlIHNvZnR3YXJlOyB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XHJcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XHJcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXHJcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXHJcbiAqXHJcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXHJcbiAqL1xyXG5leHBvcnQgZGVmYXVsdCBbXHJcbiAge1xyXG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU5JU1QtUmVxdWlyZW1lbnRzLW92ZXItdGltZScsXHJcbiAgICBfc291cmNlOiB7XHJcbiAgICAgIHRpdGxlOiAnUmVxdWlyZW1lbnRzIG92ZXIgdGltZScsXHJcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdGl0bGU6ICdOSVNULVJlcXVpcmVtZW50cy1vdmVyLXRpbWUnLFxyXG4gICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxyXG4gICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgdHlwZTogJ2hpc3RvZ3JhbScsXHJcbiAgICAgICAgICBncmlkOiB7IGNhdGVnb3J5TGluZXM6IHRydWUsIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyB9LFxyXG4gICAgICAgICAgY2F0ZWdvcnlBeGVzOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcclxuICAgICAgICAgICAgICB0eXBlOiAnY2F0ZWdvcnknLFxyXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcclxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxyXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcclxuICAgICAgICAgICAgICBzY2FsZTogeyB0eXBlOiAnbGluZWFyJyB9LFxyXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCBmaWx0ZXI6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcclxuICAgICAgICAgICAgICB0aXRsZToge30sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICBdLFxyXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcclxuICAgICAgICAgICAgICBuYW1lOiAnTGVmdEF4aXMtMScsXHJcbiAgICAgICAgICAgICAgdHlwZTogJ3ZhbHVlJyxcclxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxyXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXHJcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxyXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInLCBtb2RlOiAnbm9ybWFsJyB9LFxyXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCByb3RhdGU6IDAsIGZpbHRlcjogZmFsc2UsIHRydW5jYXRlOiAxMDAgfSxcclxuICAgICAgICAgICAgICB0aXRsZTogeyB0ZXh0OiAnQ291bnQnIH0sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICBdLFxyXG4gICAgICAgICAgc2VyaWVzUGFyYW1zOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBzaG93OiAndHJ1ZScsXHJcbiAgICAgICAgICAgICAgdHlwZTogJ2xpbmUnLFxyXG4gICAgICAgICAgICAgIG1vZGU6ICdub3JtYWwnLFxyXG4gICAgICAgICAgICAgIGRhdGE6IHsgbGFiZWw6ICdDb3VudCcsIGlkOiAnMScgfSxcclxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXHJcbiAgICAgICAgICAgICAgZHJhd0xpbmVzQmV0d2VlblBvaW50czogdHJ1ZSxcclxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcclxuICAgICAgICAgICAgICBpbnRlcnBvbGF0ZTogJ2xpbmVhcicsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICBdLFxyXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcclxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcclxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxyXG4gICAgICAgICAgdGltZXM6IFtdLFxyXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXHJcbiAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogZmFsc2UgfSxcclxuICAgICAgICAgIGRpbWVuc2lvbnM6IHtcclxuICAgICAgICAgICAgeDoge1xyXG4gICAgICAgICAgICAgIGFjY2Vzc29yOiAwLFxyXG4gICAgICAgICAgICAgIGZvcm1hdDogeyBpZDogJ2RhdGUnLCBwYXJhbXM6IHsgcGF0dGVybjogJ1lZWVktTU0tREQgSEg6bW0nIH0gfSxcclxuICAgICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICAgIGRhdGU6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBpbnRlcnZhbDogJ1BUMUgnLFxyXG4gICAgICAgICAgICAgICAgZm9ybWF0OiAnWVlZWS1NTS1ERCBISDptbScsXHJcbiAgICAgICAgICAgICAgICBib3VuZHM6IHsgbWluOiAnMjAxOS0wOC0yMFQxMjozMzoyMy4zNjBaJywgbWF4OiAnMjAxOS0wOC0yMlQxMjozMzoyMy4zNjBaJyB9LFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgYWdnVHlwZTogJ2RhdGVfaGlzdG9ncmFtJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgeTogW3sgYWNjZXNzb3I6IDIsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9XSxcclxuICAgICAgICAgICAgc2VyaWVzOiBbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDEsXHJcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcclxuICAgICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgICAgICAgIGlkOiAnc3RyaW5nJyxcclxuICAgICAgICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXHJcbiAgICAgICAgICAgICAgICBhZ2dUeXBlOiAndGVybXMnLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYWdnczogW1xyXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMicsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICdkYXRlX2hpc3RvZ3JhbScsXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ3RpbWVzdGFtcCcsXHJcbiAgICAgICAgICAgICAgdGltZVJhbmdlOiB7IGZyb206ICdub3ctMmQnLCB0bzogJ25vdycgfSxcclxuICAgICAgICAgICAgICB1c2VOb3JtYWxpemVkRXNJbnRlcnZhbDogdHJ1ZSxcclxuICAgICAgICAgICAgICBpbnRlcnZhbDogJ2F1dG8nLFxyXG4gICAgICAgICAgICAgIGRyb3BfcGFydGlhbHM6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG1pbl9kb2NfY291bnQ6IDEsXHJcbiAgICAgICAgICAgICAgZXh0ZW5kZWRfYm91bmRzOiB7fSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnNCcsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLm5pc3RfODAwXzUzJyxcclxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXHJcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcclxuICAgICAgICAgICAgICBzaXplOiA1MCxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcclxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1JlcXVpcmVtZW50JyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgfSksXHJcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcclxuICAgICAgICAgIGZpbHRlcjogW10sXHJcbiAgICAgICAgICBxdWVyeTogeyBsYW5ndWFnZTogJ2x1Y2VuZScsIHF1ZXJ5OiAnJyB9LFxyXG4gICAgICAgIH0pLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXHJcbiAgfSxcclxuICB7XHJcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctTklTVC1SZXF1aXJlbWVudHMtQWdlbnRzLWhlYXRtYXAnLFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdBbGVydHMgdm9sdW1lIGJ5IGFnZW50JyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICBhZ2dzOiBbXHJcbiAgICAgICAgICB7IGVuYWJsZWQ6IHRydWUsIGlkOiAnMScsIHBhcmFtczoge30sIHNjaGVtYTogJ21ldHJpYycsIHR5cGU6ICdjb3VudCcgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgaWQ6ICczJyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdSZXF1aXJlbWVudCcsXHJcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLm5pc3RfODAwXzUzJyxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcclxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxyXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcclxuICAgICAgICAgICAgICBzaXplOiAxMCxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxyXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgaWQ6ICcyJyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdBZ2VudCcsXHJcbiAgICAgICAgICAgICAgZmllbGQ6ICdhZ2VudC5pZCcsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXHJcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcclxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXHJcbiAgICAgICAgICAgICAgc2l6ZTogNSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF0sXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXHJcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxyXG4gICAgICAgICAgY29sb3JTY2hlbWE6ICdCbHVlcycsXHJcbiAgICAgICAgICBjb2xvcnNOdW1iZXI6IDEwLFxyXG4gICAgICAgICAgY29sb3JzUmFuZ2U6IFtdLFxyXG4gICAgICAgICAgZGltZW5zaW9uczoge1xyXG4gICAgICAgICAgICBzZXJpZXM6IFtcclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogMCxcclxuICAgICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcclxuICAgICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgICAgICAgIGlkOiAnc3RyaW5nJyxcclxuICAgICAgICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcclxuICAgICAgICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgeDoge1xyXG4gICAgICAgICAgICAgIGFjY2Vzc29yOiAxLFxyXG4gICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgICAgZm9ybWF0OiB7XHJcbiAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcclxuICAgICAgICAgICAgICAgIHBhcmFtczogeyBpZDogJ3N0cmluZycsIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLCBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInIH0sXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBwYXJhbXM6IHt9LFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB5OiBbeyBhY2Nlc3NvcjogMiwgYWdnVHlwZTogJ2NvdW50JywgZm9ybWF0OiB7IGlkOiAnbnVtYmVyJyB9LCBwYXJhbXM6IHt9IH1dLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGVuYWJsZUhvdmVyOiBmYWxzZSxcclxuICAgICAgICAgIGludmVydENvbG9yczogZmFsc2UsXHJcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcclxuICAgICAgICAgIHBlcmNlbnRhZ2VNb2RlOiBmYWxzZSxcclxuICAgICAgICAgIHNldENvbG9yUmFuZ2U6IGZhbHNlLFxyXG4gICAgICAgICAgdGltZXM6IFtdLFxyXG4gICAgICAgICAgdHlwZTogJ2hlYXRtYXAnLFxyXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcclxuICAgICAgICAgICAgICBsYWJlbHM6IHsgY29sb3I6ICdibGFjaycsIG92ZXJ3cml0ZUNvbG9yOiBmYWxzZSwgcm90YXRlOiAwLCBzaG93OiBmYWxzZSB9LFxyXG4gICAgICAgICAgICAgIHNjYWxlOiB7IGRlZmF1bHRZRXh0ZW50czogZmFsc2UsIHR5cGU6ICdsaW5lYXInIH0sXHJcbiAgICAgICAgICAgICAgc2hvdzogZmFsc2UsXHJcbiAgICAgICAgICAgICAgdHlwZTogJ3ZhbHVlJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIF0sXHJcbiAgICAgICAgfSxcclxuICAgICAgICB0aXRsZTogJ05JU1QtTGFzdC1hbGVydHMnLFxyXG4gICAgICAgIHR5cGU6ICdoZWF0bWFwJyxcclxuICAgICAgfSksXHJcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdmlzOiB7XHJcbiAgICAgICAgICBkZWZhdWx0Q29sb3JzOiB7XHJcbiAgICAgICAgICAgICcwIC0gMTYwJzogJ3JnYigyNDcsMjUxLDI1NSknLFxyXG4gICAgICAgICAgICAnMTYwIC0gMzIwJzogJ3JnYigyMjcsMjM4LDI0OSknLFxyXG4gICAgICAgICAgICAnMzIwIC0gNDgwJzogJ3JnYigyMDgsMjI1LDI0MiknLFxyXG4gICAgICAgICAgICAnNDgwIC0gNjQwJzogJ3JnYigxODIsMjEyLDIzMyknLFxyXG4gICAgICAgICAgICAnNjQwIC0gODAwJzogJ3JnYigxNDgsMTk2LDIyMyknLFxyXG4gICAgICAgICAgICAnODAwIC0gOTYwJzogJ3JnYigxMDcsMTc0LDIxNCknLFxyXG4gICAgICAgICAgICAnOTYwIC0gMSwxMjAnOiAncmdiKDc0LDE1MiwyMDEpJyxcclxuICAgICAgICAgICAgJzEsMTIwIC0gMSwyODAnOiAncmdiKDQ2LDEyNiwxODgpJyxcclxuICAgICAgICAgICAgJzEsMjgwIC0gMSw0NDAnOiAncmdiKDIzLDEwMCwxNzEpJyxcclxuICAgICAgICAgICAgJzEsNDQwIC0gMSw2MDAnOiAncmdiKDgsNzQsMTQ1KScsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcclxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXHJcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxyXG4gICAgICAgIH0pLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1OSVNULXJlcXVpcmVtZW50cy1ieS1hZ2VudHMnLFxyXG4gICAgX3NvdXJjZToge1xyXG4gICAgICB0aXRsZTogJ1JlcXVpbWVudHMgZGlzdHJpYnV0aW9uIGJ5IGFnZW50JyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ05JU1QtVG9wLXJlcXVpcmVtZW50cy1ieS1hZ2VudCcsXHJcbiAgICAgICAgdHlwZTogJ2FyZWEnLFxyXG4gICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgdHlwZTogJ2FyZWEnLFxyXG4gICAgICAgICAgZ3JpZDogeyBjYXRlZ29yeUxpbmVzOiBmYWxzZSB9LFxyXG4gICAgICAgICAgY2F0ZWdvcnlBeGVzOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcclxuICAgICAgICAgICAgICB0eXBlOiAnY2F0ZWdvcnknLFxyXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcclxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxyXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcclxuICAgICAgICAgICAgICBzY2FsZTogeyB0eXBlOiAnbGluZWFyJyB9LFxyXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCBmaWx0ZXI6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcclxuICAgICAgICAgICAgICB0aXRsZToge30sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICBdLFxyXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcclxuICAgICAgICAgICAgICBuYW1lOiAnTGVmdEF4aXMtMScsXHJcbiAgICAgICAgICAgICAgdHlwZTogJ3ZhbHVlJyxcclxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxyXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXHJcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxyXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInLCBtb2RlOiAnbm9ybWFsJyB9LFxyXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCByb3RhdGU6IDAsIGZpbHRlcjogZmFsc2UsIHRydW5jYXRlOiAxMDAgfSxcclxuICAgICAgICAgICAgICB0aXRsZTogeyB0ZXh0OiAnQ291bnQnIH0sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICBdLFxyXG4gICAgICAgICAgc2VyaWVzUGFyYW1zOiBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBzaG93OiAndHJ1ZScsXHJcbiAgICAgICAgICAgICAgdHlwZTogJ2hpc3RvZ3JhbScsXHJcbiAgICAgICAgICAgICAgbW9kZTogJ3N0YWNrZWQnLFxyXG4gICAgICAgICAgICAgIGRhdGE6IHsgbGFiZWw6ICdDb3VudCcsIGlkOiAnMScgfSxcclxuICAgICAgICAgICAgICBkcmF3TGluZXNCZXR3ZWVuUG9pbnRzOiB0cnVlLFxyXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxyXG4gICAgICAgICAgICAgIGludGVycG9sYXRlOiAnbGluZWFyJyxcclxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICBdLFxyXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcclxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcclxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxyXG4gICAgICAgICAgdGltZXM6IFtdLFxyXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXHJcbiAgICAgICAgICBkaW1lbnNpb25zOiB7XHJcbiAgICAgICAgICAgIHg6IHtcclxuICAgICAgICAgICAgICBhY2Nlc3NvcjogMCxcclxuICAgICAgICAgICAgICBmb3JtYXQ6IHtcclxuICAgICAgICAgICAgICAgIGlkOiAndGVybXMnLFxyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7IGlkOiAnc3RyaW5nJywgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJywgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycgfSxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIHBhcmFtczoge30sXHJcbiAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgeTogW3sgYWNjZXNzb3I6IDIsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9XSxcclxuICAgICAgICAgICAgc2VyaWVzOiBbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDEsXHJcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcclxuICAgICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgICAgICAgIGlkOiAnc3RyaW5nJyxcclxuICAgICAgICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXHJcbiAgICAgICAgICAgICAgICBhZ2dUeXBlOiAndGVybXMnLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYWdnczogW1xyXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMicsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ2FnZW50LmlkJyxcclxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXHJcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcclxuICAgICAgICAgICAgICBzaXplOiA1LFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxyXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnQWdlbnQnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICczJyxcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcclxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubmlzdF84MDBfNTMnLFxyXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcclxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxyXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxyXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUmVxdWlyZW1lbnQnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICB9KSxcclxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHsgdmlzOiB7IGxlZ2VuZE9wZW46IGZhbHNlIH0gfSksXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgICAgdmVyc2lvbjogMSxcclxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XHJcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxyXG4gICAgICAgICAgZmlsdGVyOiBbXSxcclxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXHJcbiAgICAgICAgfSksXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1OSVNULU1ldHJpY3MnLFxyXG4gICAgX3NvdXJjZToge1xyXG4gICAgICB0aXRsZTogJ1N0YXRzJyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ25pc3QtbWV0cmljcycsXHJcbiAgICAgICAgdHlwZTogJ21ldHJpYycsXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICBtZXRyaWM6IHtcclxuICAgICAgICAgICAgcGVyY2VudGFnZU1vZGU6IGZhbHNlLFxyXG4gICAgICAgICAgICB1c2VSYW5nZXM6IGZhbHNlLFxyXG4gICAgICAgICAgICBjb2xvclNjaGVtYTogJ0dyZWVuIHRvIFJlZCcsXHJcbiAgICAgICAgICAgIG1ldHJpY0NvbG9yTW9kZTogJ05vbmUnLFxyXG4gICAgICAgICAgICBjb2xvcnNSYW5nZTogW3sgdHlwZTogJ3JhbmdlJywgZnJvbTogMCwgdG86IDEwMDAwIH1dLFxyXG4gICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSB9LFxyXG4gICAgICAgICAgICBpbnZlcnRDb2xvcnM6IGZhbHNlLFxyXG4gICAgICAgICAgICBzdHlsZTogeyBiZ0ZpbGw6ICcjMDAwJywgYmdDb2xvcjogZmFsc2UsIGxhYmVsQ29sb3I6IGZhbHNlLCBzdWJUZXh0OiAnJywgZm9udFNpemU6IDIwIH0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgZGltZW5zaW9uczoge1xyXG4gICAgICAgICAgICBtZXRyaWNzOiBbXHJcbiAgICAgICAgICAgICAgeyB0eXBlOiAndmlzX2RpbWVuc2lvbicsIGFjY2Vzc29yOiAwLCBmb3JtYXQ6IHsgaWQ6ICdudW1iZXInLCBwYXJhbXM6IHt9IH0gfSxcclxuICAgICAgICAgICAgICB7IHR5cGU6ICd2aXNfZGltZW5zaW9uJywgYWNjZXNzb3I6IDEsIGZvcm1hdDogeyBpZDogJ251bWJlcicsIHBhcmFtczoge30gfSB9LFxyXG4gICAgICAgICAgICBdLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXHJcbiAgICAgICAgICBhZGRMZWdlbmQ6IGZhbHNlLFxyXG4gICAgICAgICAgdHlwZTogJ21ldHJpYycsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBhZ2dzOiBbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMScsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXHJcbiAgICAgICAgICAgIHBhcmFtczogeyBjdXN0b21MYWJlbDogJ1RvdGFsIGFsZXJ0cycgfSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMicsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICdtYXgnLFxyXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHsgZmllbGQ6ICdydWxlLmxldmVsJywgY3VzdG9tTGFiZWw6ICdNYXggcnVsZSBsZXZlbCBkZXRlY3RlZCcgfSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgfSksXHJcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxyXG4gICAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICAgIHZlcnNpb246IDEsXHJcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xyXG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcclxuICAgICAgICAgIGZpbHRlcjogW10sXHJcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxyXG4gICAgICAgIH0pLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXHJcbiAgfSxcclxuICB7XHJcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctTklTVC1Ub3AtMTAtcmVxdWlyZW1lbnRzJyxcclxuICAgIF9zb3VyY2U6IHtcclxuICAgICAgdGl0bGU6ICdUb3AgMTAgcmVxdWlyZW1lbnRzJyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ05JU1QtVG9wLTEwLXJlcXVpcmVtZW50cycsXHJcbiAgICAgICAgdHlwZTogJ3BpZScsXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICB0eXBlOiAncGllJyxcclxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXHJcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXHJcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcclxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXHJcbiAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogZmFsc2UsIHZhbHVlczogdHJ1ZSwgbGFzdF9sZXZlbDogdHJ1ZSwgdHJ1bmNhdGU6IDEwMCB9LFxyXG4gICAgICAgICAgZGltZW5zaW9uczoge1xyXG4gICAgICAgICAgICBtZXRyaWM6IHsgYWNjZXNzb3I6IDEsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9LFxyXG4gICAgICAgICAgICBidWNrZXRzOiBbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDAsXHJcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcclxuICAgICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgICAgICAgIGlkOiAnc3RyaW5nJyxcclxuICAgICAgICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXHJcbiAgICAgICAgICAgICAgICBhZ2dUeXBlOiAndGVybXMnLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYWdnczogW1xyXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMicsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubmlzdF84MDBfNTMnLFxyXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcclxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxyXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxyXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUmVxdWlyZW1lbnQnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICB9KSxcclxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgICAgdmVyc2lvbjogMSxcclxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XHJcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxyXG4gICAgICAgICAgZmlsdGVyOiBbXSxcclxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXHJcbiAgICAgICAgfSksXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1OSVNULUFnZW50cycsXHJcbiAgICBfc291cmNlOiB7XHJcbiAgICAgIHRpdGxlOiAnTW9zdCBhY3RpdmUgYWdlbnRzJyxcclxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICB0aXRsZTogJ05JU1QtVG9wLTEwLWFnZW50cycsXHJcbiAgICAgICAgdHlwZTogJ3BpZScsXHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICB0eXBlOiAncGllJyxcclxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXHJcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXHJcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcclxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXHJcbiAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogZmFsc2UsIHZhbHVlczogdHJ1ZSwgbGFzdF9sZXZlbDogdHJ1ZSwgdHJ1bmNhdGU6IDEwMCB9LFxyXG4gICAgICAgICAgZGltZW5zaW9uczoge1xyXG4gICAgICAgICAgICBtZXRyaWM6IHsgYWNjZXNzb3I6IDEsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9LFxyXG4gICAgICAgICAgICBidWNrZXRzOiBbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDAsXHJcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcclxuICAgICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgICAgICAgIGlkOiAnc3RyaW5nJyxcclxuICAgICAgICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXHJcbiAgICAgICAgICAgICAgICBhZ2dUeXBlOiAndGVybXMnLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYWdnczogW1xyXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMicsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ2FnZW50Lm5hbWUnLFxyXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcclxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxyXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxyXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnQWdlbnQnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICB9KSxcclxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgICAgdmVyc2lvbjogMSxcclxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XHJcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxyXG4gICAgICAgICAgZmlsdGVyOiBbXSxcclxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXHJcbiAgICAgICAgfSksXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcclxuICB9LFxyXG4gIHtcclxuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1OSVNULUFsZXJ0cy1zdW1tYXJ5JyxcclxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXHJcbiAgICBfc291cmNlOiB7XHJcbiAgICAgIHRpdGxlOiAnQWxlcnRzIHN1bW1hcnknLFxyXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgIHRpdGxlOiAnTklTVC1BbGVydHMtc3VtbWFyeScsXHJcbiAgICAgICAgdHlwZTogJ3RhYmxlJyxcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIHBlclBhZ2U6IDEwLFxyXG4gICAgICAgICAgc2hvd1BhcnRpYWxSb3dzOiBmYWxzZSxcclxuICAgICAgICAgIHNob3dNZXRyaWNzQXRBbGxMZXZlbHM6IGZhbHNlLFxyXG4gICAgICAgICAgc29ydDogeyBjb2x1bW5JbmRleDogMywgZGlyZWN0aW9uOiAnZGVzYycgfSxcclxuICAgICAgICAgIHNob3dUb3RhbDogZmFsc2UsXHJcbiAgICAgICAgICBzaG93VG9vbGJhcjogdHJ1ZSxcclxuICAgICAgICAgIHRvdGFsRnVuYzogJ3N1bScsXHJcbiAgICAgICAgICBkaW1lbnNpb25zOiB7XHJcbiAgICAgICAgICAgIG1ldHJpY3M6IFt7IGFjY2Vzc29yOiAzLCBmb3JtYXQ6IHsgaWQ6ICdudW1iZXInIH0sIHBhcmFtczoge30sIGFnZ1R5cGU6ICdjb3VudCcgfV0sXHJcbiAgICAgICAgICAgIGJ1Y2tldHM6IFtcclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogMCxcclxuICAgICAgICAgICAgICAgIGZvcm1hdDoge1xyXG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcclxuICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ6ICdzdHJpbmcnLFxyXG4gICAgICAgICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXHJcbiAgICAgICAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcclxuICAgICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogMSxcclxuICAgICAgICAgICAgICAgIGZvcm1hdDoge1xyXG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcclxuICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ6ICdzdHJpbmcnLFxyXG4gICAgICAgICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXHJcbiAgICAgICAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcclxuICAgICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogMixcclxuICAgICAgICAgICAgICAgIGZvcm1hdDoge1xyXG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcclxuICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ6ICdudW1iZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXHJcbiAgICAgICAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcclxuICAgICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgICBhZ2dzOiBbXHJcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6ICcyJyxcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcclxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgZmllbGQ6ICdhZ2VudC5uYW1lJyxcclxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXHJcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcclxuICAgICAgICAgICAgICBzaXplOiA1MCxcclxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcclxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcclxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ0FnZW50JyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiAnMycsXHJcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXHJcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXHJcbiAgICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5uaXN0XzgwMF81MycsXHJcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxyXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXHJcbiAgICAgICAgICAgICAgc2l6ZTogMjAsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXHJcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdSZXF1aXJlbWVudCcsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogJzQnLFxyXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxyXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxyXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubGV2ZWwnLFxyXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcclxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxyXG4gICAgICAgICAgICAgIHNpemU6IDUsXHJcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXHJcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdSdWxlIGxldmVsJyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgfSksXHJcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgdmlzOiB7IHBhcmFtczogeyBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9IH0gfSxcclxuICAgICAgfSksXHJcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgICAgdmVyc2lvbjogMSxcclxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XHJcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxyXG4gICAgICAgICAgZmlsdGVyOiBbXSxcclxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXHJcbiAgICAgICAgfSksXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gIH0sXHJcbl07XHJcbiJdfQ==