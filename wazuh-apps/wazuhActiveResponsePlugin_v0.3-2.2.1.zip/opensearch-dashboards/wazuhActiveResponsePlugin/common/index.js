"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_VERSION = exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'wazuhActiveResponsePlugin';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'TDAR Active Response';
exports.PLUGIN_NAME = PLUGIN_NAME;
const PLUGIN_VERSION = '(v0.3)';
exports.PLUGIN_VERSION = PLUGIN_VERSION;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbIlBMVUdJTl9JRCIsIlBMVUdJTl9OQU1FIiwiUExVR0lOX1ZFUlNJT04iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFPLE1BQU1BLFNBQVMsR0FBRywyQkFBbEI7O0FBQ0EsTUFBTUMsV0FBVyxHQUFHLHNCQUFwQjs7QUFDQSxNQUFNQyxjQUFjLEdBQUcsUUFBdkIiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgUExVR0lOX0lEID0gJ3dhenVoQWN0aXZlUmVzcG9uc2VQbHVnaW4nO1xuZXhwb3J0IGNvbnN0IFBMVUdJTl9OQU1FID0gJ1REQVIgQWN0aXZlIFJlc3BvbnNlJztcbmV4cG9ydCBjb25zdCBQTFVHSU5fVkVSU0lPTiA9ICcodjAuMyknO1xuIl19