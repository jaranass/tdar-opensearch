"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_VERSION = exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
// export const PLUGIN_ID = 'tenantSizeAlertPlugin';
const PLUGIN_ID = 'license_management_plugin';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'License Management';
exports.PLUGIN_NAME = PLUGIN_NAME;
const PLUGIN_VERSION = '(v1.6.5.0)';
exports.PLUGIN_VERSION = PLUGIN_VERSION;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbIlBMVUdJTl9JRCIsIlBMVUdJTl9OQU1FIiwiUExVR0lOX1ZFUlNJT04iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQ08sTUFBTUEsU0FBUyxHQUFHLDJCQUFsQjs7QUFDQSxNQUFNQyxXQUFXLEdBQUcsb0JBQXBCOztBQUNBLE1BQU1DLGNBQWMsR0FBRyxZQUF2QiIsInNvdXJjZXNDb250ZW50IjpbIi8vIGV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAndGVuYW50U2l6ZUFsZXJ0UGx1Z2luJztcbmV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAnbGljZW5zZV9tYW5hZ2VtZW50X3BsdWdpbic7XG5leHBvcnQgY29uc3QgUExVR0lOX05BTUUgPSAnTGljZW5zZSBNYW5hZ2VtZW50JztcbmV4cG9ydCBjb25zdCBQTFVHSU5fVkVSU0lPTiA9ICcodjEuNi41LjApJztcbiJdfQ==